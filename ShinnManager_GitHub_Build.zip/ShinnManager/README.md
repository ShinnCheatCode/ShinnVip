# ShinnManager

Ứng dụng Flutter quản lý key và điều khiển bot Telegram qua API riêng của bạn.

## Chức năng hiện có

- Đăng nhập bằng ID Telegram và xác nhận từ bot.
- Lưu URL server + phiên đăng nhập trong secure storage.
- Khóa/mở khóa app bằng Face ID khi khởi động lại.
- Quản lý key:
  - xem danh sách và thống kê;
  - tìm kiếm;
  - tạo nhiều key;
  - sao chép key;
  - reset thiết bị;
  - khóa/mở khóa;
  - xóa key;
  - khóa/mở khóa toàn bộ key.
- Điều khiển bot:
  - xem trạng thái;
  - xem BXH điểm;
  - cộng/trừ điểm;
  - gửi tin nhắn;
  - reset BXH + thưởng;
  - khóa/mở từng lệnh hoặc toàn bộ lệnh.

App không chứa token bot hay `ADMIN_TOKEN`; các bí mật này phải nằm ở server/VPS.

## API mà app đang sử dụng

App giữ nguyên các endpoint backend hiện tại:

```text
POST   /mgr/login/request
GET    /mgr/login/status/{req_id}
POST   /mgr/logout

GET    /mgr/keys?limit=200
GET    /mgr/stats
POST   /mgr/keys
POST   /mgr/keys/{key}/reset-devices
POST   /mgr/keys/{key}/lock
POST   /mgr/keys/{key}/unlock
DELETE /mgr/keys/{key}
POST   /mgr/keys-lock-all
POST   /mgr/keys-unlock-all

GET    /mgr/bot/state
POST   /mgr/bot/job
GET    /mgr/bot/job/{id}
```

Nếu backend của bạn đang dùng đúng các endpoint trên thì không cần sửa server.

## Build IPA trực tiếp bằng GitHub Actions

1. Tạo hoặc mở repository GitHub.
2. Upload toàn bộ nội dung thư mục `ShinnManager`.
3. Vào **Actions → Build ShinnManager IPA**.
4. Chọn **Run workflow**.
5. Chờ job hoàn tất.
6. Mở artifact **ShinnManager-ipa**.
7. Lấy:
   - `ShinnManager.ipa`
   - `ShinnManager.ipa.sha256`

Workflow tự tạo native iOS project trong runner macOS, chạy `flutter pub get`, `flutter analyze`, build release không ký và đóng gói IPA.

### Lưu ý về ký IPA

IPA do workflow tạo là **unsigned**. Đây là chủ ý để không đưa certificate/provisioning profile vào source code.

Bạn có thể ký/cài bằng công cụ sideload phù hợp với thiết bị của mình. Nếu muốn phát hành TestFlight/App Store, cần thêm bước signing riêng với Apple certificate và provisioning profile.

## Cấu hình server

Trong app, nhập URL API khi đăng nhập, ví dụ:

```text
https://api.example.com
```

Nên dùng HTTPS. Nếu API của bạn chỉ chạy HTTP, workflow đã bật ATS để app có thể kết nối; tuy nhiên HTTPS vẫn được khuyến nghị.

## Không đưa secret vào GitHub

Không commit các giá trị như:

```text
BOT_TOKEN
ADMIN_TOKEN
KEY_API_ADMIN_TOKEN
```

Các secret này thuộc VPS/backend. App chỉ nhận session token sau khi Telegram xác nhận đăng nhập.
