# ShinnManager

Owner-only Flutter control panel for the Shinn key server and Telegram bot.

## Current source scope

This build is intentionally an **admin/owner app**, not the ShinnCheat client.

### Included
- Owner login request through Telegram bot + one-time verification code.
- Configurable API server URL at login.
- Secure token storage + Face ID / device authentication.
- Dashboard for key/server/bot status.
- Key creation: test/1h, 1d, 3d, 7d, 30d, 1y, permanent.
- Device limit field (default 1); unlimited-device mode can be requested by the Owner for test keys.
- Copy, lock/unlock, reset device, and delete key.
- Telegram bot online state.
- Bot command list, add command, enable/disable command.
- Broadcast a text announcement to the configured group.
- Upload an image/file with title, description, trigger keyword, and auto-send flag.
- Send or delete uploaded bot content.
- Anti-spam settings exposed in the Manager. The server remains authoritative for identifying spam, mapping the device to its key, and locking/deleting the key.
- All new API paths are centralized in `lib/main.dart` under `ApiRoutes` so they can be remapped after the final `main.py` and bot are provided.

## Expected API contract for the next integration step

Existing paths kept from the original source:

- `POST /mgr/login/request`
- `GET /mgr/login/status/{request_id}`
- `POST /mgr/logout`
- `GET /mgr/stats`
- `GET /mgr/keys?limit=200`
- `POST /mgr/keys`
- `DELETE /mgr/keys/{key}`
- `POST /mgr/keys/{key}/lock`
- `POST /mgr/keys/{key}/unlock`
- `POST /mgr/keys/{key}/reset-devices`
- `POST /mgr/keys-lock-all`
- `POST /mgr/keys-unlock-all`
- `GET /mgr/bot/state`
- `POST /mgr/bot/job`
- `GET /mgr/bot/job/{id}`

New paths prepared for the next server/bot sync:

- `POST /mgr/login/verify`
- `GET /mgr/bot/commands`
- `POST /mgr/bot/commands`
- `PUT/POST /mgr/bot/commands/{command}` (server can map this to its preferred command mutation route)
- `GET /mgr/bot/content`
- `POST /mgr/bot/content` (multipart field `file`, plus `title`, `description`, `trigger`, `auto_send`)
- `POST /mgr/bot/job` with `send_content` / `delete_content` jobs
- `PUT /mgr/security` with `anti_spam` and `auto_delete_spam_key`

These are **UI-side contracts only for now**. Do not treat them as the final backend implementation until the real `main.py` and Telegram bot are supplied.

## GitHub build

The workflow creates the native iOS host project on the macOS runner, installs Flutter dependencies, analyzes Dart, builds an unsigned release, and packages `ShinnManager.ipa`.

Target deployment is iOS 17.0+.
