import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;
import 'package:local_auth/local_auth.dart';

const _storage = FlutterSecureStorage();

// All API paths are centralized here so they can be remapped easily when
// the final FastAPI main.py + Telegram bot are connected.
class ApiRoutes {
  static const loginRequest = '/mgr/login/request';
  static String loginStatus(String id) => '/mgr/login/status/$id';
  static const logout = '/mgr/logout';
  static const stats = '/mgr/stats';
  static const keys = '/mgr/keys?limit=200';
  static String key(String key) => '/mgr/keys/${Uri.encodeComponent(key)}';
  static String keyLock(String key, bool lock) => '/mgr/keys/${Uri.encodeComponent(key)}/${lock ? 'lock' : 'unlock'}';
  static String resetDevices(String key) => '/mgr/keys/${Uri.encodeComponent(key)}/reset-devices';
  static const lockAll = '/mgr/keys-lock-all';
  static const unlockAll = '/mgr/keys-unlock-all';

  static const botState = '/mgr/bot/state';
  static const botJob = '/mgr/bot/job';
  static String botJobStatus(String id) => '/mgr/bot/job/$id';
  static const botCommands = '/mgr/bot/commands';
  static String botCommand(String name) => '/mgr/bot/commands/${Uri.encodeComponent(name)}';
  static const botContent = '/mgr/bot/content';
  static String botContentItem(String id) => '/mgr/bot/content/${Uri.encodeComponent(id)}';
  static const botBroadcast = '/mgr/bot/broadcast';
  static const botLogs = '/mgr/bot/logs';
  static const security = '/mgr/security';
}

class ApiError implements Exception {
  final int code;
  final String msg;
  ApiError(this.code, this.msg);
  @override
  String toString() => msg;
}

class Api {
  final String base;
  final String? token;
  Api(this.base, this.token);

  Map<String, String> get _h => {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        if (token != null) 'Authorization': 'Bearer $token',
      };

  Future<dynamic> call(String method, String path, [Object? body]) async {
    final uri = Uri.parse('$base$path');
    const timeout = Duration(seconds: 20);
    late http.Response r;
    try {
      if (method == 'GET') {
        r = await http.get(uri, headers: _h).timeout(timeout);
      } else if (method == 'DELETE') {
        r = await http.delete(uri, headers: _h).timeout(timeout);
      } else if (method == 'PUT') {
        r = await http.put(uri, headers: _h, body: jsonEncode(body ?? {})).timeout(timeout);
      } else {
        r = await http.post(uri, headers: _h, body: jsonEncode(body ?? {})).timeout(timeout);
      }
    } on TimeoutException {
      throw ApiError(0, 'Server không phản hồi (quá 20 giây).');
    } on SocketException {
      throw ApiError(0, 'Không kết nối được server.');
    } catch (_) {
      throw ApiError(0, 'Không kết nối được server.');
    }
    return _decode(r);
  }

  dynamic _decode(http.Response r) {
    if (r.statusCode >= 400) {
      String msg = 'Lỗi HTTP ${r.statusCode}';
      try {
        final d = jsonDecode(utf8.decode(r.bodyBytes));
        if (d is Map) {
          msg = '${d['detail'] ?? d['message'] ?? d['error'] ?? msg}';
        }
      } catch (_) {}
      if (r.statusCode == 401 && token != null) onUnauthorized?.call();
      if (r.statusCode == 429) msg = 'Thao tác quá nhanh / có dấu hiệu spam.';
      throw ApiError(r.statusCode, msg);
    }
    if (r.bodyBytes.isEmpty) return null;
    try {
      return jsonDecode(utf8.decode(r.bodyBytes));
    } catch (_) {
      return utf8.decode(r.bodyBytes);
    }
  }

  Future<dynamic> upload({required String path, required PlatformFile file, Map<String, String> fields = const {}}) async {
    final uri = Uri.parse('$base$path');
    final req = http.MultipartRequest('POST', uri);
    req.headers.addAll({'Accept': 'application/json', if (token != null) 'Authorization': 'Bearer $token'});
    req.fields.addAll(fields);
    if (file.bytes != null) {
      req.files.add(http.MultipartFile.fromBytes('file', file.bytes!, filename: file.name));
    } else if (file.path != null) {
      req.files.add(await http.MultipartFile.fromPath('file', file.path!, filename: file.name));
    } else {
      throw ApiError(0, 'Không đọc được file đã chọn.');
    }
    try {
      final streamed = await req.send().timeout(const Duration(seconds: 60));
      final r = await http.Response.fromStream(streamed);
      return _decode(r);
    } on TimeoutException {
      throw ApiError(0, 'Upload quá lâu, server không phản hồi.');
    } catch (_) {
      throw ApiError(0, 'Upload thất bại.');
    }
  }
}

VoidCallback? onUnauthorized;

String fmtExpire(String? iso) {
  if (iso == null || iso.isEmpty) return '?';
  final d = DateTime.tryParse(iso);
  if (d == null) return iso;
  if (d.year >= 2099) return 'Vĩnh viễn';
  final diff = d.difference(DateTime.now());
  if (diff.isNegative) return 'Hết hạn';
  if (diff.inDays >= 1) return 'Còn ${diff.inDays} ngày ${diff.inHours % 24} giờ';
  if (diff.inHours >= 1) return 'Còn ${diff.inHours} giờ ${diff.inMinutes % 60} phút';
  return 'Còn ${diff.inMinutes} phút';
}

void toast(BuildContext c, String m, {bool error = false}) {
  ScaffoldMessenger.of(c).hideCurrentSnackBar();
  ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(m), backgroundColor: error ? Colors.red.shade800 : null));
}

Future<bool> confirm(BuildContext c, String text) async {
  final r = await showDialog<bool>(
    context: c,
    builder: (_) => AlertDialog(
      title: const Text('Xác nhận'),
      content: Text(text),
      actions: [
        TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Huỷ')),
        FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Đồng ý')),
      ],
    ),
  );
  return r == true;
}

void main() => runApp(const ShinnApp());

class ShinnApp extends StatelessWidget {
  const ShinnApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'ShinnManager',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          brightness: Brightness.dark,
          scaffoldBackgroundColor: const Color(0xFF050817),
          colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF8B5CF6), brightness: Brightness.dark),
          inputDecorationTheme: InputDecorationTheme(
            filled: true,
            fillColor: const Color(0xFF0C1430),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
          ),
          cardTheme: CardThemeData(color: const Color(0xFF0B1430), margin: const EdgeInsets.only(bottom: 10), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18))),
        ),
        home: const Root(),
      );
}

class Root extends StatefulWidget {
  const Root({super.key});
  @override
  State<Root> createState() => _RootState();
}

class _RootState extends State<Root> with WidgetsBindingObserver {
  Api? api;
  String? savedUrl;
  bool booting = true;
  bool locked = false;
  bool _backgrounded = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    onUnauthorized = _logout;
    _boot();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if ((state == AppLifecycleState.paused || state == AppLifecycleState.inactive) && api != null) _backgrounded = true;
    if (state == AppLifecycleState.resumed && _backgrounded && api != null && mounted) {
      _backgrounded = false;
      setState(() { api = null; locked = true; });
    }
  }

  Future<bool> _auth() async {
    try {
      final la = LocalAuthentication();
      if (!await la.isDeviceSupported()) return true;
      return await la.authenticate(localizedReason: 'Xác thực để mở ShinnManager');
    } catch (_) { return false; }
  }

  Future<void> _boot() async {
    final url = await _storage.read(key: 'url');
    final tok = await _storage.read(key: 'token');
    savedUrl = url;
    if (url != null && tok != null) {
      final ok = await _auth();
      if (!mounted) return;
      setState(() { booting = false; if (ok) api = Api(url, tok); else locked = true; });
    } else if (mounted) {
      setState(() => booting = false);
    }
  }

  Future<void> _logout() async {
    try { await api?.call('POST', ApiRoutes.logout); } catch (_) {}
    await _storage.delete(key: 'token');
    if (mounted) setState(() { api = null; locked = false; });
  }

  @override
  Widget build(BuildContext context) {
    if (booting) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    if (locked) return Scaffold(body: Center(child: FilledButton.icon(icon: const Icon(Icons.fingerprint), label: const Text('Mở khoá ShinnManager'), onPressed: () async { final ok = await _auth(); if (ok && mounted) { setState(() { locked = false; booting = true; }); await _boot(); } })));
    if (api == null) return LoginPage(initialUrl: savedUrl ?? '', onLogin: (a) => setState(() => api = a));
    return ManagerShell(api: api!, onLogout: _logout);
  }
}

class LoginPage extends StatefulWidget {
  final String initialUrl;
  final void Function(Api) onLogin;
  const LoginPage({super.key, required this.initialUrl, required this.onLogin});
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  late final TextEditingController url = TextEditingController(text: widget.initialUrl);
  final key = TextEditingController();
  final code = TextEditingController();
  bool busy = false;
  bool waiting = false;
  String? reqId;
  int ttl = 120;
  String? error;
  Timer? timer;

  @override
  void dispose() { timer?.cancel(); url.dispose(); key.dispose(); code.dispose(); super.dispose(); }

  String norm(String s) {
    var v = s.trim();
    while (v.endsWith('/')) v = v.substring(0, v.length - 1);
    if (v.isNotEmpty && !v.startsWith('http')) v = 'https://$v';
    return v;
  }

  Future<void> requestCode() async {
    final base = norm(url.text);
    final ownerKey = key.text.trim();
    if (base.isEmpty || ownerKey.isEmpty) { setState(() => error = 'Nhập Server URL và Owner Key.'); return; }
    setState(() { busy = true; waiting = false; error = null; });
    final a = Api(base, null);
    try {
      final r = await a.call('POST', ApiRoutes.loginRequest, {'key': ownerKey, 'device_id': Platform.isIOS ? 'iOS-ShinnManager' : 'ShinnManager'});
      reqId = '${r['req_id']}';
      ttl = (r['ttl'] is int ? r['ttl'] : 120) as int;
      setState(() { waiting = true; busy = false; });
      toast(context, 'Yêu cầu đã gửi. Bot sẽ gửi mã xác thực cho Owner Telegram.');
    } on ApiError catch (e) { if (mounted) setState(() { busy = false; error = e.msg; }); }
  }

  Future<void> verifyCode() async {
    final base = norm(url.text);
    if (reqId == null || code.text.trim().isEmpty) { setState(() => error = 'Nhập mã xác thực được bot gửi.'); return; }
    setState(() { busy = true; error = null; });
    try {
      final a = Api(base, null);
      final r = await a.call('POST', '/mgr/login/verify', {'req_id': reqId, 'code': code.text.trim()});
      final token = r['token'];
      if (token == null) throw ApiError(0, 'Server chưa trả token đăng nhập.');
      await _storage.write(key: 'url', value: base);
      await _storage.write(key: 'token', value: '$token');
      if (mounted) widget.onLogin(Api(base, '$token'));
    } on ApiError catch (e) { if (mounted) setState(() { busy = false; error = e.msg; }); }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(24), child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 460),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Container(height: 110, decoration: BoxDecoration(borderRadius: BorderRadius.circular(28), gradient: const LinearGradient(colors: [Color(0xFF25114F), Color(0xFF0B2A52)])), child: const Icon(Icons.admin_panel_settings, size: 64, color: Color(0xFFB794FF))),
          const SizedBox(height: 18),
          const Text('ShinnManager', textAlign: TextAlign.center, style: TextStyle(fontSize: 30, fontWeight: FontWeight.w800)),
          const SizedBox(height: 4),
          Text('Owner Control Panel', textAlign: TextAlign.center, style: TextStyle(color: Colors.white.withOpacity(.6))),
          const SizedBox(height: 28),
          TextField(controller: url, keyboardType: TextInputType.url, autocorrect: false, decoration: const InputDecoration(labelText: 'API Server URL', hintText: 'https://your-domain:port')),
          const SizedBox(height: 12),
          TextField(controller: key, obscureText: true, autocorrect: false, decoration: const InputDecoration(labelText: 'Owner Key', hintText: 'Nhập key admin/Owner')),
          const SizedBox(height: 14),
          if (waiting) ...[
            TextField(controller: code, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Mã xác thực từ bot', hintText: 'Nhập mã Owner nhận từ bot')),
            const SizedBox(height: 12),
            FilledButton.icon(onPressed: busy ? null : verifyCode, icon: const Icon(Icons.verified), label: const Padding(padding: EdgeInsets.all(12), child: Text('Xác thực & vào app'))),
            const SizedBox(height: 8),
            OutlinedButton(onPressed: busy ? null : requestCode, child: const Text('Gửi lại yêu cầu')),
          ] else
            FilledButton.icon(onPressed: busy ? null : requestCode, icon: const Icon(Icons.send), label: const Padding(padding: EdgeInsets.all(12), child: Text('Gửi yêu cầu qua Telegram'))),
          if (busy) const Padding(padding: EdgeInsets.only(top: 14), child: LinearProgressIndicator()),
          if (error != null) Padding(padding: const EdgeInsets.only(top: 14), child: Text(error!, textAlign: TextAlign.center, style: TextStyle(color: Colors.red.shade300))),
          const SizedBox(height: 22),
          const Card(child: Padding(padding: EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Luồng bảo mật', style: TextStyle(fontWeight: FontWeight.bold)),
            SizedBox(height: 8),
            Text('1. Nhập API server + Telegram ID.'),
            Text('2. Bot gửi yêu cầu xác thực cho Owner.'),
            Text('3. Owner lấy mã và nhập vào app.'),
            Text('4. Chỉ khi server xác nhận mới được tạo / quản lý key.'),
          ]))),
        ]),
      )))),
    );
  }
}

class ManagerShell extends StatefulWidget {
  final Api api;
  final Future<void> Function() onLogout;
  const ManagerShell({super.key, required this.api, required this.onLogout});
  @override
  State<ManagerShell> createState() => _ManagerShellState();
}

class _ManagerShellState extends State<ManagerShell> {
  int tab = 0;
  final titles = const ['Dashboard', 'Keys', 'Telegram Bot', 'Cài đặt'];
  @override
  Widget build(BuildContext context) {
    final pages = [DashboardTab(api: widget.api), KeysTab(api: widget.api), BotTab(api: widget.api), SettingsTab(api: widget.api, onLogout: widget.onLogout)];
    return Scaffold(
      appBar: AppBar(title: Text(titles[tab]), actions: [IconButton(onPressed: () => setState(() {}), icon: const Icon(Icons.refresh))]),
      body: IndexedStack(index: tab, children: pages),
      bottomNavigationBar: NavigationBar(selectedIndex: tab, onDestinationSelected: (v) => setState(() => tab = v), destinations: const [
        NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'Tổng quan'),
        NavigationDestination(icon: Icon(Icons.vpn_key_outlined), selectedIcon: Icon(Icons.vpn_key), label: 'Key'),
        NavigationDestination(icon: Icon(Icons.smart_toy_outlined), selectedIcon: Icon(Icons.smart_toy), label: 'Bot'),
        NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: 'Cài đặt'),
      ]),
    );
  }
}

abstract class Refreshable { void refresh(); }

class DashboardTab extends StatefulWidget {
  final Api api;
  const DashboardTab({super.key, required this.api});
  @override State<DashboardTab> createState() => _DashboardTabState();
}
class _DashboardTabState extends State<DashboardTab> implements Refreshable {
  Map<String,dynamic> stats = {};
  Map<String,dynamic> bot = {};
  bool loading = true;
  @override void initState(){super.initState(); refresh();}
  @override Future<void> refresh() async { setState(()=>loading=true); try { final a=await widget.api.call('GET',ApiRoutes.stats); final b=await widget.api.call('GET',ApiRoutes.botState); if(mounted)setState(()=>{stats=Map<String,dynamic>.from(a??{}),bot=Map<String,dynamic>.from(b??{}),loading=false}); } catch(_){if(mounted)setState(()=>loading=false);} }
  Widget tile(String title,dynamic value,IconData icon,{Color? color})=>Expanded(child:Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Icon(icon,color:color??Theme.of(context).colorScheme.primary),const SizedBox(height:8),Text('$value',style:const TextStyle(fontSize:24,fontWeight:FontWeight.w800)),Text(title,style:TextStyle(color:Colors.white.withOpacity(.6)))]))));
  @override Widget build(BuildContext context)=>RefreshIndicator(onRefresh: refresh,child:ListView(padding:const EdgeInsets.all(12),children:[
    Container(padding:const EdgeInsets.all(18),decoration:BoxDecoration(borderRadius:BorderRadius.circular(22),gradient:const LinearGradient(colors:[Color(0xFF26104F),Color(0xFF102B52)])),child:Row(children:[const CircleAvatar(radius:26,child:Icon(Icons.admin_panel_settings)),const SizedBox(width:14),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('ShinnManager',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),Text('Owner Control Panel',style:TextStyle(color:Colors.white60))])),const Icon(Icons.verified,color:Colors.greenAccent)])),
    const SizedBox(height:12),
    Row(children:[tile('Tổng key',stats['total']??'—',Icons.vpn_key),tile('Đang hoạt động',stats['used']??'—',Icons.check_circle,color:Colors.greenAccent)]),
    Row(children:[tile('Hết hạn',stats['expired']??'—',Icons.timer_off,color:Colors.orangeAccent),tile('Thiết bị',stats['devices']??'—',Icons.devices,color:Colors.lightBlueAccent)]),
    Card(child:ListTile(leading:CircleAvatar(child:Icon((bot['online']??false)==true?Icons.smart_toy:Icons.cloud_off)),title:Text((bot['online']??false)==true?'Telegram Bot Online':'Telegram Bot Offline'),subtitle:Text('${bot['username']??'Chưa xác định'} · ${bot['uptime']??''}'),trailing:Container(width:10,height:10,decoration:BoxDecoration(shape:BoxShape.circle,color:(bot['online']??false)==true?Colors.greenAccent:Colors.redAccent)))),
    Card(child:Column(children:[const ListTile(title:Text('Luồng bảo mật'),leading:Icon(Icons.shield)),const ListTile(leading:Icon(Icons.mark_email_read,color:Colors.greenAccent),title:Text('Owner phải xác thực qua Telegram'),subtitle:Text('Không có mã xác thực → không vào được Manager.')),const ListTile(leading:Icon(Icons.phonelink_lock,color:Colors.orangeAccent),title:Text('Key gắn theo thiết bị'),subtitle:Text('Có thể reset thiết bị từ Manager.')),const ListTile(leading:Icon(Icons.block,color:Colors.redAccent),title:Text('Anti-spam'),subtitle:Text('Server/Bot quyết định khoá hoặc xoá key khi vi phạm.'))])),
    if(loading) const Padding(padding:EdgeInsets.all(20),child:Center(child:CircularProgressIndicator())),
  ]));
}

const _durations=<String,int>{'Test / 1 giờ':3600,'1 ngày':86400,'3 ngày':259200,'7 ngày':604800,'30 ngày':2592000,'1 năm':31536000,'Vĩnh viễn':315360000};

class KeysTab extends StatefulWidget { final Api api; const KeysTab({super.key,required this.api}); @override State<KeysTab> createState()=>_KeysTabState(); }
class _KeysTabState extends State<KeysTab> implements Refreshable {
  List<dynamic> keys=[]; Map<String,dynamic> stats={}; String q=''; bool loading=true;
  @override void initState(){super.initState();refresh();}
  @override Future<void> refresh() async { try { final k=await widget.api.call('GET',ApiRoutes.keys); final s=await widget.api.call('GET',ApiRoutes.stats); if(mounted)setState(()=>{keys=k is List?k:[],stats=Map<String,dynamic>.from(s??{}),loading=false}); } on ApiError catch(e){if(mounted){loading=false;toast(context,e.msg,error:true);setState((){});}} }
  Future<void> act(Future<dynamic> Function() f,String msg)async{try{await f();if(mounted)toast(context,msg);refresh();}on ApiError catch(e){if(mounted)toast(context,e.msg,error:true);}}
  Future<void> createKey()async{
    String dur=_durations.keys.first;int qty=1;bool noLimit=false;
    final ok=await showDialog<bool>(context:context,builder:(ctx)=>StatefulBuilder(builder:(ctx,set)=>AlertDialog(title:const Text('Tạo key mới'),content:Column(mainAxisSize:MainAxisSize.min,children:[DropdownButton<String>(isExpanded:true,value:dur,items:_durations.keys.map((e)=>DropdownMenuItem(value:e,child:Text(e))).toList(),onChanged:(v)=>set(()=>dur=v!)),Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[const Text('Số lượng'),Row(children:[IconButton(onPressed:qty>1?()=>set(()=>qty--):null,icon:const Icon(Icons.remove)),Text('$qty'),IconButton(onPressed:qty<50?()=>set(()=>qty++):null,icon:const Icon(Icons.add))])]),SwitchListTile(contentPadding:EdgeInsets.zero,title:const Text('Không giới hạn thiết bị'),subtitle:const Text('Chỉ nên dùng cho key test/Owner'),value:noLimit,onChanged:(v)=>set(()=>noLimit=v)]),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Huỷ')),FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('Tạo'))])));) if(ok!=true)return;
    try{final r=await widget.api.call('POST','/mgr/keys',{'label':dur,'kind':dur.startsWith('Test')?'test':'vip','seconds':_durations[dur],'quantity':qty,'permanent':dur=='Vĩnh viễn','device_limit':noLimit?null:1});final list=r is List?r:[];final text=list.map((e)=>e['key']).join('\n');if(mounted)await showDialog(context:context,builder:(c)=>AlertDialog(title:Text('Đã tạo ${list.length} key'),content:SelectableText(text),actions:[TextButton(onPressed:(){Clipboard.setData(ClipboardData(text:text));toast(c,'Đã sao chép');},child:const Text('Sao chép')),FilledButton(onPressed:()=>Navigator.pop(c),child:const Text('Đóng'))]));refresh();}on ApiError catch(e){if(mounted)toast(context,e.msg,error:true);}
  }
  void menu(Map k){final key='${k['key']}';final locked=(k['locked']??0)==1;showModalBottomSheet(context:context,builder:(c)=>SafeArea(child:Column(mainAxisSize:MainAxisSize.min,children:[ListTile(title:SelectableText(key),subtitle:Text('${k['label']??k['kind']} · ${fmtExpire('${k['expires_at']??''}')}')),
    ListTile(leading:const Icon(Icons.copy),title:const Text('Sao chép key'),onTap:(){Clipboard.setData(ClipboardData(text:key));Navigator.pop(c);toast(context,'Đã sao chép');}),
    ListTile(leading:const Icon(Icons.devices),title:const Text('Reset thiết bị'),onTap:(){Navigator.pop(c);act(()=>widget.api.call('POST',ApiRoutes.resetDevices(key)),'Đã reset thiết bị');}),
    ListTile(leading:Icon(locked?Icons.lock_open:Icons.lock),title:Text(locked?'Mở khoá key':'Khoá key'),onTap:(){Navigator.pop(c);act(()=>widget.api.call('POST',ApiRoutes.keyLock(key,!locked)),locked?'Đã mở khoá':'Đã khoá');}),
    ListTile(leading:const Icon(Icons.delete,color:Colors.redAccent),title:const Text('Xoá key',style:TextStyle(color:Colors.redAccent)),onTap:()async{Navigator.pop(c);if(await confirm(context,'Xoá key $key?'))act(()=>widget.api.call('DELETE',ApiRoutes.key(key)),'Đã xoá key');})])));}
  @override Widget build(BuildContext context){final shown=keys.where((k)=>q.isEmpty||'${k['key']}'.toLowerCase().contains(q.toLowerCase())).toList();return RefreshIndicator(onRefresh: refresh,child:ListView(padding:const EdgeInsets.fromLTRB(12,8,12,100),children:[Row(children:[Expanded(child:TextField(onChanged:(v)=>setState(()=>q=v),decoration:const InputDecoration(prefixIcon:Icon(Icons.search),hintText:'Tìm key...'))),const SizedBox(width:8),FilledButton.icon(onPressed:createKey,icon:const Icon(Icons.add),label:const Text('Tạo'))]),const SizedBox(height:8),Row(children:[_mini('Tổng',stats['total']??'—'),_mini('Đang dùng',stats['used']??'—'),_mini('Hết hạn',stats['expired']??'—')]),if(loading)const Padding(padding:EdgeInsets.all(30),child:Center(child:CircularProgressIndicator())),for(final k in shown)Card(child:ListTile(onTap:()=>menu(Map<String,dynamic>.from(k)),leading:Icon((k['locked']??0)==1?Icons.lock:Icons.key,color:k['role']=='admin'?Colors.amber:Theme.of(context).colorScheme.primary),title:Text('${k['key']}',style:const TextStyle(fontFamily:'monospace',fontSize:13)),subtitle:Text('${k['label']??k['kind']} · ${fmtExpire('${k['expires_at']??''}') }'),trailing:Text('${k['device_count']??k['devices']??0}/${k['device_limit']??1}'))]));})
  Widget _mini(String l,dynamic v)=>Expanded(child:Card(child:Padding(padding:const EdgeInsets.all(10),child:Column(children:[Text('$v',style:const TextStyle(fontWeight:FontWeight.bold,fontSize:18)),Text(l,style:const TextStyle(fontSize:11))]))));
}

class BotTab extends StatefulWidget { final Api api; const BotTab({super.key,required this.api}); @override State<BotTab> createState()=>_BotTabState(); }
class _BotTabState extends State<BotTab> implements Refreshable {
  Map<String,dynamic> state={}; List<dynamic> commands=[]; List<dynamic> content=[]; bool loading=true; bool busy=false;
  @override void initState(){super.initState();refresh();}
  @override Future<void> refresh() async { try{final s=await widget.api.call('GET',ApiRoutes.botState); final c=await widget.api.call('GET',ApiRoutes.botCommands); final m=await widget.api.call('GET',ApiRoutes.botContent);if(mounted)setState(()=>{state=Map<String,dynamic>.from(s??{}),commands=c is List?c:[],content=m is List?m:[],loading=false});}on ApiError catch(e){if(mounted){loading=false;toast(context,e.msg,error:true);setState((){});}} }
  Future<void> job(String kind,Map p,String ok)async{setState(()=>busy=true);try{final r=await widget.api.call('POST',ApiRoutes.botJob,{'kind':kind,'payload':p});final id='${r['id']}';for(var i=0;i<20;i++){await Future.delayed(const Duration(milliseconds:700));final j=await widget.api.call('GET',ApiRoutes.botJobStatus(id));if(j['status']=='done'){if(mounted)toast(context,ok);break;}if(j['status']=='failed')throw ApiError(0,'${(j['result']??{})['error']??'Bot báo lỗi'}');}}on ApiError catch(e){if(mounted)toast(context,e.msg,error:true);}finally{if(mounted){setState(()=>busy=false);refresh();}}}
  Future<void> sendText()async{final c=TextEditingController();final ok=await showDialog<bool>(context:context,builder:(x)=>AlertDialog(title:const Text('Gửi thông báo group'),content:TextField(controller:c,maxLines:6,decoration:const InputDecoration(hintText:'Nội dung bot sẽ gửi...')),actions:[TextButton(onPressed:()=>Navigator.pop(x,false),child:const Text('Huỷ')),FilledButton(onPressed:()=>Navigator.pop(x,true),child:const Text('Gửi'))]));final text=c.text.trim();c.dispose();if(ok==true&&text.isNotEmpty)job('broadcast_group',{'text':text},'Đã gửi thông báo vào group');}
  Future<void> addCommand()async{final n=TextEditingController();final d=TextEditingController();final k=TextEditingController();final ok=await showDialog<bool>(context:context,builder:(x)=>AlertDialog(title:const Text('Thêm command'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:n,decoration:const InputDecoration(labelText:'Command',hintText:'/xthuc')),TextField(controller:d,decoration:const InputDecoration(labelText:'Mô tả')),TextField(controller:k,decoration:const InputDecoration(labelText:'Từ khoá kích hoạt (tuỳ chọn)'))]),actions:[TextButton(onPressed:()=>Navigator.pop(x,false),child:const Text('Huỷ')),FilledButton(onPressed:()=>Navigator.pop(x,true),child:const Text('Thêm'))]));if(ok==true&&n.text.trim().isNotEmpty){try{await widget.api.call('POST',ApiRoutes.botCommands,{'command':n.text.trim().replaceFirst('/',''),'description':d.text.trim(),'trigger':k.text.trim()});if(mounted)toast(context,'Đã thêm command');refresh();}on ApiError catch(e){if(mounted)toast(context,e.msg,error:true);}}n.dispose();d.dispose();k.dispose();}
  Future<void> uploadContent()async{final result=await FilePicker.platform.pickFiles(withData:true,allowMultiple:false);if(result==null||result.files.isEmpty)return;final f=result.files.single;final title=TextEditingController();final desc=TextEditingController();final trigger=TextEditingController();final auto=ValueNotifier<bool>(true);final ok=await showDialog<bool>(context:context,builder:(x)=>AlertDialog(title:const Text('Tải nội dung cho Bot'),content:SingleChildScrollView(child:ValueListenableBuilder(valueListenable:auto,builder:(_,v,__)=>(Column(mainAxisSize:MainAxisSize.min,children:[ListTile(leading:const Icon(Icons.insert_drive_file),title:Text(f.name),subtitle:Text('${((f.size)/1024/1024).toStringAsFixed(2)} MB')),TextField(controller:title,decoration:const InputDecoration(labelText:'Tiêu đề')),TextField(controller:desc,maxLines:3,decoration:const InputDecoration(labelText:'Mô tả')),TextField(controller:trigger,decoration:const InputDecoration(labelText:'Từ khoá kích hoạt',hintText:'ví dụ: vip / patch / key')),SwitchListTile(contentPadding:EdgeInsets.zero,title:const Text('Tự gửi vào group khi có từ khoá'),value:v,onChanged:(z)=>auto.value=z)])))),actions:[TextButton(onPressed:()=>Navigator.pop(x,false),child:const Text('Huỷ')),FilledButton(onPressed:()=>Navigator.pop(x,true),child:const Text('Upload'))]));if(ok!=true){title.dispose();desc.dispose();trigger.dispose();auto.dispose();return;}try{setState(()=>busy=true);await widget.api.upload(path:ApiRoutes.botContent,file:f,fields:{'title':title.text.trim(),'description':desc.text.trim(),'trigger':trigger.text.trim(),'auto_send':auto.value?'true':'false'});if(mounted)toast(context,'Đã upload nội dung');refresh();}on ApiError catch(e){if(mounted)toast(context,e.msg,error:true);}finally{if(mounted)setState(()=>busy=false);title.dispose();desc.dispose();trigger.dispose();auto.dispose();}}
  @override Widget build(BuildContext context){final online=state['online']==true;return Stack(children:[RefreshIndicator(onRefresh: refresh,child:ListView(padding:const EdgeInsets.all(12),children:[Card(child:ListTile(leading:CircleAvatar(child:Icon(online?Icons.smart_toy:Icons.cloud_off)),title:Text(online?'Bot Online':'Bot Offline'),subtitle:Text('${state['username']??'@ShinnThieuu_bot'} · Uptime ${state['uptime']??'—'}'),trailing:Icon(Icons.circle,size:12,color:online?Colors.greenAccent:Colors.redAccent))),Row(children:[Expanded(child:FilledButton.icon(onPressed:busy?null:sendText,icon:const Icon(Icons.campaign),label:const Text('Gửi group'))),const SizedBox(width:8),Expanded(child:OutlinedButton.icon(onPressed:busy?null:addCommand,icon:const Icon(Icons.add),label:const Text('Command')))]),const SizedBox(height:8),FilledButton.tonalIcon(onPressed:busy?null:uploadContent,icon:const Icon(Icons.upload_file),label:const Padding(padding:EdgeInsets.all(10),child:Text('Tải ảnh / file + mô tả + từ khoá'))),const SizedBox(height:16),const Text('Commands',style:TextStyle(fontSize:17,fontWeight:FontWeight.bold)),if(commands.isEmpty)const Card(child:ListTile(title:Text('Chưa có command'),subtitle:Text('Sau này bot/main.py sẽ đồng bộ danh sách này.'))),for(final c in commands)Card(child:ListTile(leading:const Icon(Icons.terminal),title:Text('/${c['command']??c['name']??''}'),subtitle:Text('${c['description']??''}${(c['trigger']??'').toString().isNotEmpty?'\nTừ khoá: ${c['trigger']}':''}'),trailing:Switch(value:c['enabled']!=false,onChanged:busy?null:(v)=>job('set_command',{'command':'${c['command']??c['name']}','enabled':v},v?'Đã bật command':'Đã tắt command')))),const SizedBox(height:10),Row(children:[const Expanded(child:Text('Nội dung bot',style:TextStyle(fontSize:17,fontWeight:FontWeight.bold)),),IconButton(onPressed:busy?null:uploadContent,icon:const Icon(Icons.add))]),if(content.isEmpty)const Card(child:ListTile(title:Text('Chưa có ảnh/file'),subtitle:Text('Upload file, nhập mô tả và từ khoá để bot tự phản hồi.'))),for(final x in content)Card(child:ListTile(leading:Icon('${x['mime']??''}'.startsWith('image/')?Icons.image:Icons.insert_drive_file),title:Text('${x['title']??x['name']??'Nội dung'}'),subtitle:Text('${x['description']??''}\nTừ khoá: ${x['trigger']??'—'}'),isThreeLine:true,trailing:PopupMenuButton<String>(onSelected:(v){if(v=='send')job('send_content',{'content_id':'${x['id']}'},'Đã gửi nội dung');if(v=='delete')job('delete_content',{'content_id':'${x['id']}'},'Đã xoá nội dung');},itemBuilder:(_)=>const[PopupMenuItem(value:'send',child:Text('Gửi ngay')),PopupMenuItem(value:'delete',child:Text('Xoá'))])))])),if(busy)const Positioned(top:0,left:0,right:0,child:LinearProgressIndicator())]);}
}

class SettingsTab extends StatefulWidget { final Api api; final Future<void> Function() onLogout; const SettingsTab({super.key,required this.api,required this.onLogout}); @override State<SettingsTab> createState()=>_SettingsTabState(); }
class _SettingsTabState extends State<SettingsTab>{late final TextEditingController server=TextEditingController(text:widget.api.base); bool spamLock=true; bool autoDelete=true;
  @override void dispose(){server.dispose();super.dispose();}
  Future<void> saveSecurity()async{try{await widget.api.call('PUT',ApiRoutes.security,{'anti_spam':spamLock,'auto_delete_spam_key':autoDelete});if(mounted)toast(context,'Đã lưu cấu hình bảo mật');}on ApiError catch(e){if(mounted)toast(context,e.msg,error:true);}}
  @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(12),children:[Card(child:ListTile(leading:const CircleAvatar(child:Icon(Icons.admin_panel_settings)),title:const Text('Owner Control'),subtitle:Text('Token đang đăng nhập · ${widget.api.base}'))),const Text('API Server',style:TextStyle(fontSize:17,fontWeight:FontWeight.bold)),const SizedBox(height:8),TextField(controller:server,decoration:const InputDecoration(labelText:'Server URL',hintText:'https://your-domain')),const SizedBox(height:8),const Text('URL chỉ là cấu hình hiển thị ở bản này; token hiện tại vẫn dùng server đã đăng nhập.',style:TextStyle(color:Colors.white54,fontSize:12)),const SizedBox(height:18),const Text('Anti-spam / thiết bị',style:TextStyle(fontSize:17,fontWeight:FontWeight.bold)),Card(child:Column(children:[SwitchListTile(title:const Text('Tự phát hiện spam'),subtitle:const Text('Bot/server đánh dấu hành vi spam'),value:spamLock,onChanged:(v)=>setState(()=>spamLock=v)),SwitchListTile(title:const Text('Tự khoá / xoá key vi phạm'),subtitle:const Text('Quyết định cuối cùng nằm ở server'),value:autoDelete,onChanged:(v)=>setState(()=>autoDelete=v))])),FilledButton.icon(onPressed:saveSecurity,icon:const Icon(Icons.save),label:const Text('Lưu cấu hình')),const SizedBox(height:18),Card(child:Column(children:[const ListTile(title:Text('Bảo mật ứng dụng'),leading:Icon(Icons.fingerprint)),const ListTile(leading:Icon(Icons.verified_user),title:Text('Owner xác thực qua Telegram'),subtitle:Text('Mã xác thực không nằm cố định trong app.')),const ListTile(leading:Icon(Icons.lock),title:Text('Token lưu trong Secure Storage')),ListTile(leading:const Icon(Icons.logout,color:Colors.redAccent),title:const Text('Đăng xuất',style:TextStyle(color:Colors.redAccent)),onTap:()async{if(await confirm(context,'Đăng xuất khỏi ShinnManager?'))widget.onLogout();})]))]);}
