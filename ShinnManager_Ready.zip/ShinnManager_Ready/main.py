"""ShinnCheat Key Server — FastAPI + SQLite."""
import os
import secrets
import sqlite3
import string
import time
import hashlib
from pathlib import Path
import json
from collections import defaultdict, deque
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone

from fastapi import Depends, FastAPI, Header, HTTPException, Request, UploadFile, File, Form
from pydantic import BaseModel, Field

ADMIN_TOKEN = os.environ.get("ADMIN_TOKEN", "")
DB_PATH = os.environ.get("DB_PATH", os.path.join(os.path.dirname(os.path.abspath(__file__)), "keys.db"))
KEY_PREFIX = os.environ.get("KEY_PREFIX", "SHINN")
RATE_LIMIT, RATE_WINDOW = 30, 60
PERMANENT = "2099-12-31T00:00:00+00:00"
MAX_SECONDS_LEFT = 315360000  # trần 10 năm để app không bị tràn số
MANAGER_SESSION_TTL = int(os.environ.get("MANAGER_SESSION_TTL", 7 * 86400))
OWNER_TELEGRAM_ID = str(os.environ.get("OWNER_TELEGRAM_ID", "8987709740")).strip()
XTHUC_TTL_SECONDS = int(os.environ.get("XTHUC_TTL_SECONDS", 300))
MEDIA_DIR = Path(os.environ.get("BOT_MEDIA_DIR", os.path.join(os.path.dirname(os.path.abspath(__file__)), "bot_media")))
MEDIA_DIR.mkdir(parents=True, exist_ok=True)

if len(ADMIN_TOKEN) < 24:
    raise RuntimeError("Hay dat ADMIN_TOKEN (>= 24 ky tu) trong bien moi truong.")

app = FastAPI(title="Key Server", docs_url=None, redoc_url=None, openapi_url=None)


_CHILD_TABLES = ("devices", "pending", "xthuc_requests", "key_telegram_auth")


def _has_table(con, name):
    return con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (name,)).fetchone() is not None


def _purge_expired(con):
    """Xoá key hết hạn + dữ liệu liên quan, đồng thời ghi expired_log để bot Telegram thông báo."""
    if not _has_table(con, "keys"):
        return []
    stamp = now_iso()
    rows = con.execute("SELECT key, kind, label, expires_at FROM keys WHERE expires_at < ?", (stamp,)).fetchall()
    if not rows:
        return []
    expired = [r[0] for r in rows]
    marks = ",".join("?" for _ in expired)
    if _has_table(con, "expired_log"):
        have_auth = _has_table(con, "key_telegram_auth")
        for r in rows:
            auth = None
            if have_auth:
                auth = con.execute(
                    "SELECT telegram_user_id, telegram_username, telegram_name FROM key_telegram_auth WHERE key=?",
                    (r[0],)).fetchone()
            con.execute(
                "INSERT INTO expired_log(key,kind,label,telegram_user_id,telegram_username,telegram_name,"
                "expires_at,deleted_at,notified) VALUES (?,?,?,?,?,?,?,?,0)",
                (r[0], r[1], r[2],
                 auth[0] if auth else "", auth[1] if auth else "", auth[2] if auth else "",
                 r[3], stamp))
    for table in _CHILD_TABLES:
        if _has_table(con, table):
            con.execute(f"DELETE FROM {table} WHERE key IN ({marks})", expired)
    con.execute(f"DELETE FROM keys WHERE key IN ({marks})", expired)
    return expired


def _expired_key_cleanup_loop():
    # Purge expired keys even when the server receives no traffic.
    while True:
        try:
            with db():
                pass  # db() tự gọi _purge_expired khi mở kết nối
        except Exception:
            # Keep the worker alive; next pass retries cleanup.
            pass
        time.sleep(60)


@app.on_event("startup")
def start_expired_key_cleanup():
    import threading
    threading.Thread(target=_expired_key_cleanup_loop, daemon=True, name="expired-key-cleanup").start()


@contextmanager
def db():
    con = sqlite3.connect(DB_PATH, timeout=10)
    con.row_factory = sqlite3.Row
    try:
        # Expired keys are removed automatically (and logged for Telegram notification).
        _purge_expired(con)
        yield con
        con.commit()
    finally:
        con.close()


def now_iso():
    return datetime.now(timezone.utc).isoformat()


def gen_key(kind="vip", label=""):
    alphabet = string.ascii_uppercase + string.digits
    suffix = "".join(secrets.choice(alphabet) for _ in range(10))
    # Test keys and timed keys use distinct, readable prefixes.
    prefix = "Shinn-Test-" if str(kind).lower() == "test" or str(label).lower() == "test" else "Shinn-Cheat-"
    return prefix + suffix


COLS = "key,role,kind,label,expires_at,max_devices,unlimited_devices,blocked_repos,created_at,last_used_at"
VALS = ":key,:role,:kind,:label,:expires_at,:max_devices,:unlimited_devices,:blocked_repos,:created_at,:last_used_at"


def insert_keys(c, label, kind, role, seconds, quantity, max_devices,
                unlimited=False, custom_key="", blocked_repos=""):
    created = now_iso()
    expires = (datetime.now(timezone.utc) + timedelta(seconds=seconds)).isoformat()
    rows = [dict(key=custom_key or gen_key(kind, label), role=role, kind=kind, label=label, expires_at=expires,
                 max_devices=max_devices, unlimited_devices=1 if unlimited else 0,
                 blocked_repos=blocked_repos, created_at=created, last_used_at=None)
            for _ in range(quantity)]
    c.executemany(f"INSERT INTO keys ({COLS}) VALUES ({VALS})", rows)
    return rows


def repos_of(row):
    return [x.strip() for x in (row["blocked_repos"] or "").split(",") if x.strip()]


# ---------------- Khởi tạo DB + key mặc định ----------------
with db() as c:
    c.execute("PRAGMA journal_mode=WAL")
    c.execute("""CREATE TABLE IF NOT EXISTS keys (
        key TEXT PRIMARY KEY, role TEXT DEFAULT 'member', kind TEXT DEFAULT 'vip',
        label TEXT, expires_at TEXT NOT NULL, max_devices INTEGER DEFAULT 1,
        unlimited_devices INTEGER DEFAULT 0, created_at TEXT NOT NULL, last_used_at TEXT,
        blocked_repos TEXT DEFAULT '', locked INTEGER DEFAULT 0)""")
    if "blocked_repos" not in [r["name"] for r in c.execute("PRAGMA table_info(keys)")]:
        c.execute("ALTER TABLE keys ADD COLUMN blocked_repos TEXT DEFAULT ''")
    if "locked" not in [r["name"] for r in c.execute("PRAGMA table_info(keys)")]:
        c.execute("ALTER TABLE keys ADD COLUMN locked INTEGER DEFAULT 0")
    c.execute("""CREATE TABLE IF NOT EXISTS devices (
        key TEXT NOT NULL, device_id TEXT NOT NULL, first_seen TEXT NOT NULL,
        PRIMARY KEY (key, device_id))""")
    c.execute("""CREATE TABLE IF NOT EXISTS pending (
        key TEXT NOT NULL, device_id TEXT NOT NULL, ip TEXT, ts TEXT NOT NULL,
        PRIMARY KEY (key, device_id))""")
    c.execute("""CREATE TABLE IF NOT EXISTS xthuc_requests (
        code TEXT PRIMARY KEY, key TEXT NOT NULL, device_id TEXT NOT NULL,
        ip TEXT, created_at TEXT NOT NULL, expires_at TEXT NOT NULL, used_at TEXT
    )""")
    c.execute("CREATE INDEX IF NOT EXISTS idx_xthuc_lookup ON xthuc_requests(key, device_id, used_at, expires_at)")
    c.execute("""CREATE TABLE IF NOT EXISTS key_telegram_auth (
        key TEXT PRIMARY KEY, device_id TEXT NOT NULL, telegram_user_id TEXT NOT NULL,
        telegram_username TEXT DEFAULT '', telegram_name TEXT NOT NULL, verified_at TEXT NOT NULL
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS expired_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT, key TEXT NOT NULL, kind TEXT, label TEXT,
        telegram_user_id TEXT DEFAULT '', telegram_username TEXT DEFAULT '', telegram_name TEXT DEFAULT '',
        expires_at TEXT, deleted_at TEXT NOT NULL, notified INTEGER DEFAULT 0)""")
    c.execute("CREATE TABLE IF NOT EXISTS meta (k TEXT PRIMARY KEY, v TEXT)")
    c.execute("""CREATE TABLE IF NOT EXISTS manager_login (
        req_id TEXT PRIMARY KEY, key TEXT NOT NULL, device_id TEXT NOT NULL,
        code TEXT NOT NULL, created_at TEXT NOT NULL, expires_at TEXT NOT NULL,
        notified INTEGER DEFAULT 0, used_at TEXT
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS manager_sessions (
        token_hash TEXT PRIMARY KEY, key TEXT NOT NULL, device_id TEXT NOT NULL,
        created_at TEXT NOT NULL, expires_at TEXT NOT NULL
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS bot_content (
        id TEXT PRIMARY KEY, name TEXT NOT NULL, mime TEXT DEFAULT '',
        size INTEGER DEFAULT 0, title TEXT DEFAULT '', description TEXT DEFAULT '',
        trigger TEXT DEFAULT '', auto_send INTEGER DEFAULT 0, active INTEGER DEFAULT 1,
        path TEXT NOT NULL, created_at TEXT NOT NULL
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS bot_commands (
        command TEXT PRIMARY KEY, description TEXT DEFAULT '', trigger TEXT DEFAULT '',
        enabled INTEGER DEFAULT 1, created_at TEXT NOT NULL
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS bot_jobs (
        id TEXT PRIMARY KEY, kind TEXT NOT NULL, payload TEXT DEFAULT '{}',
        status TEXT DEFAULT 'pending', result TEXT DEFAULT '{}',
        created_at TEXT NOT NULL, updated_at TEXT NOT NULL
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS bot_heartbeat (
        id INTEGER PRIMARY KEY CHECK (id=1), username TEXT DEFAULT '',
        started_at TEXT, last_seen TEXT NOT NULL, pid INTEGER DEFAULT 0
    )""")
    if not c.execute("SELECT 1 FROM meta WHERE k='seed_v1'").fetchone():
        base = dict(expires_at=PERMANENT, created_at=now_iso(), last_used_at=None)
        seeds = [
            # key test dùng chung: KHÔNG giới hạn thiết bị, vĩnh viễn, KHÔNG dùng được repo V2
            dict(base, key="ShinnCheatTest", role="member", kind="test", label="permanent",
                 max_devices=0, unlimited_devices=1, blocked_repos="V2"),
            # 2 key owner: mỗi key tối đa 1 thiết bị đã xác thực
            dict(base, key="ShinnThieuu", role="admin", kind="owner", label="owner",
                 max_devices=1, unlimited_devices=0, blocked_repos=""),
            dict(base, key="NgVuMinhHieuu", role="admin", kind="owner", label="owner",
                 max_devices=1, unlimited_devices=0, blocked_repos=""),
        ]
        c.executemany(f"INSERT OR IGNORE INTO keys ({COLS}) VALUES ({VALS})", seeds)
        c.execute("INSERT INTO meta VALUES ('seed_v1', ?)", (now_iso(),))

    # Migration: áp dụng giới hạn mới cho DB đã tồn tại, không chỉ DB tạo mới.
    c.execute("UPDATE keys SET max_devices=0, unlimited_devices=1 WHERE key='ShinnCheatTest'")
    for _owner_key in ("ShinnThieuu", "NgVuMinhHieuu"):
        c.execute("UPDATE keys SET max_devices=1, unlimited_devices=0 WHERE key=?", (_owner_key,))
        # Nếu DB cũ đã có >1 thiết bị cho Owner, giữ thiết bị đăng ký sớm nhất.
        extra = c.execute(
            "SELECT device_id FROM devices WHERE key=? ORDER BY first_seen ASC LIMIT -1 OFFSET 1",
            (_owner_key,),
        ).fetchall()
        for _row in extra:
            c.execute("DELETE FROM devices WHERE key=? AND device_id=?", (_owner_key, _row["device_id"]))


def client_ip(request: Request):
    return request.headers.get("x-real-ip") or (request.client.host if request.client else "")


def note_pending(c, key, device_id, ip):
    c.execute("INSERT OR REPLACE INTO pending VALUES (?,?,?,?)", (key, device_id, ip, now_iso()))
    c.execute("DELETE FROM pending WHERE rowid NOT IN (SELECT rowid FROM pending ORDER BY ts DESC LIMIT 50)")


def check_key(c, key, device_id, role=None, ip=""):
    """Trả về (row, None) nếu hợp lệ, hoặc (None, lý_do)."""
    row = c.execute("SELECT * FROM keys WHERE key=?", (key,)).fetchone()
    if not row:
        return None, "invalid_key"
    if row["locked"]:
        return None, "key_locked"
    if datetime.fromisoformat(row["expires_at"]) < datetime.now(timezone.utc):
        return None, "expired"
    if role and row["role"] != role:
        return None, "forbidden"
    if not c.execute("SELECT 1 FROM key_telegram_auth WHERE key=?", (key,)).fetchone():
        return None, "telegram_verification_required"
    if row["role"] == "admin":
        # Key owner: thiết bị phải được chủ duyệt trước (chống đoán key)
        if not device_id:
            return None, "device_required"
        ok = c.execute("SELECT 1 FROM devices WHERE key=? AND device_id=?", (key, device_id)).fetchone()
        if not ok:
            note_pending(c, key, device_id, ip)
            return None, "device_not_approved"
    elif not row["unlimited_devices"]:
        if not device_id:
            return None, "device_required"
        known = c.execute("SELECT 1 FROM devices WHERE key=? AND device_id=?", (key, device_id)).fetchone()
        if not known:
            n = c.execute("SELECT COUNT(*) FROM devices WHERE key=?", (key,)).fetchone()[0]
            if n >= row["max_devices"]:
                return None, "device_limit"
            c.execute("INSERT INTO devices VALUES (?,?,?)", (key, device_id, now_iso()))
    return row, None


# ---------------- ADMIN (bot Telegram / VPS, cần ADMIN_TOKEN) ----------------
def require_admin(x_admin_token: str = Header(default="")):
    if not secrets.compare_digest(x_admin_token, ADMIN_TOKEN):
        raise HTTPException(401, "unauthorized")


class CreateReq(BaseModel):
    label: str = ""
    kind: str = "vip"
    role: str = "member"
    seconds: int = Field(gt=0, le=3650 * 86400)
    quantity: int = Field(default=1, ge=1, le=500)
    max_devices: int = Field(default=1, ge=1, le=100)
    unlimited_devices: bool = False
    custom_key: str = Field(default="", max_length=32, pattern=r"^[A-Za-z0-9_-]*$")
    permanent: bool = False
    blocked_repos: str = Field(default="", max_length=64, pattern=r"^[A-Za-z0-9_,-]*$")


@app.post("/admin/keys", dependencies=[Depends(require_admin)])
def admin_create(r: CreateReq):
    if r.custom_key and r.quantity != 1:
        raise HTTPException(400, "custom_key chi tao 1 key")
    if r.custom_key == "ShinnCheatTest":
        r.unlimited_devices = True
        r.max_devices = 0
    else:
        r.unlimited_devices = False
        r.max_devices = 1
    try:
        with db() as c:
            return insert_keys(c, r.label, r.kind, r.role, r.seconds, r.quantity, r.max_devices,
                               r.unlimited_devices, r.custom_key, r.blocked_repos)
    except sqlite3.IntegrityError:
        raise HTTPException(409, "key da ton tai")


@app.get("/admin/keys", dependencies=[Depends(require_admin)])
def admin_list(limit: int = 20):
    with db() as c:
        rows = c.execute("SELECT * FROM keys ORDER BY created_at DESC LIMIT ?", (min(limit, 200),)).fetchall()
    return [dict(x) for x in rows]


@app.get("/admin/keys/{key}", dependencies=[Depends(require_admin)])
def admin_get(key: str):
    with db() as c:
        row = c.execute("SELECT * FROM keys WHERE key=?", (key,)).fetchone()
    if not row:
        raise HTTPException(404, "not found")
    return dict(row)


@app.delete("/admin/keys/{key}", dependencies=[Depends(require_admin)])
def admin_delete(key: str):
    with db() as c:
        n = c.execute("DELETE FROM keys WHERE key=?", (key,)).rowcount
        c.execute("DELETE FROM devices WHERE key=?", (key,))
        c.execute("DELETE FROM key_telegram_auth WHERE key=?", (key,))
        c.execute("DELETE FROM xthuc_requests WHERE key=?", (key,))
        c.execute("DELETE FROM pending WHERE key=?", (key,))
    if not n:
        raise HTTPException(404, "not found")
    return {"deleted": True}


@app.post("/admin/keys/{key}/reset-devices", dependencies=[Depends(require_admin)])
def admin_reset(key: str):
    with db() as c:
        c.execute("DELETE FROM devices WHERE key=?", (key,))
    return {"ok": True}


class LockReq(BaseModel):
    key: str = Field(max_length=64)


@app.post("/admin/keys/lock-all", dependencies=[Depends(require_admin)])
def admin_lock_all():
    with db() as c:
        n = c.execute("UPDATE keys SET locked=1").rowcount
    return {"ok": True, "locked": n}


@app.post("/admin/keys/unlock-all", dependencies=[Depends(require_admin)])
def admin_unlock_all():
    with db() as c:
        n = c.execute("UPDATE keys SET locked=0").rowcount
    return {"ok": True, "unlocked": n}


@app.post("/admin/keys/lock", dependencies=[Depends(require_admin)])
def admin_lock_one(r: LockReq):
    key = r.key.strip()
    with db() as c:
        n = c.execute("UPDATE keys SET locked=1 WHERE key=?", (key,)).rowcount
    if not n:
        raise HTTPException(404, "not found")
    return {"ok": True, "key": key, "locked": True}


@app.get("/admin/stats", dependencies=[Depends(require_admin)])
def admin_stats():
    with db() as c:
        total = c.execute("SELECT COUNT(*) FROM keys").fetchone()[0]
        used = c.execute("SELECT COUNT(*) FROM keys WHERE last_used_at IS NOT NULL").fetchone()[0]
        expired = c.execute("SELECT COUNT(*) FROM keys WHERE expires_at < ?", (now_iso(),)).fetchone()[0]
    return {"total": total, "used": used, "expired": expired}


@app.get("/admin/pending", dependencies=[Depends(require_admin)])
def admin_pending():
    with db() as c:
        rows = c.execute("SELECT * FROM pending ORDER BY ts DESC LIMIT 10").fetchall()
    return [dict(x) for x in rows]


class ApproveReq(BaseModel):
    device_id: str = Field(max_length=128)


@app.post("/admin/keys/{key}/approve", dependencies=[Depends(require_admin)])
def admin_approve(key: str, r: ApproveReq):
    with db() as c:
        row = c.execute("SELECT * FROM keys WHERE key=?", (key,)).fetchone()
        if not row:
            raise HTTPException(404, "not found")
        known = c.execute("SELECT 1 FROM devices WHERE key=? AND device_id=?", (key, r.device_id)).fetchone()
        if not known:
            n = c.execute("SELECT COUNT(*) FROM devices WHERE key=?", (key,)).fetchone()[0]
            if n >= row["max_devices"]:
                raise HTTPException(409, "device_limit")
            c.execute("INSERT INTO devices VALUES (?,?,?)", (key, r.device_id, now_iso()))
        c.execute("DELETE FROM pending WHERE key=? AND device_id=?", (key, r.device_id))
    return {"ok": True}


@app.get("/admin/expired/pending", dependencies=[Depends(require_admin)])
def admin_expired_pending(limit: int = 50):
    with db() as c:
        rows = c.execute("SELECT * FROM expired_log WHERE notified=0 ORDER BY id ASC LIMIT ?",
                         (min(max(limit, 1), 200),)).fetchall()
    return [dict(x) for x in rows]


class ExpiredAck(BaseModel):
    ids: list[int] = Field(default_factory=list, max_length=200)


@app.post("/admin/expired/ack", dependencies=[Depends(require_admin)])
def admin_expired_ack(r: ExpiredAck):
    with db() as c:
        for i in r.ids:
            c.execute("UPDATE expired_log SET notified=1 WHERE id=?", (i,))
        # giữ log gọn: xoá bản ghi đã báo quá 30 ngày
        c.execute("DELETE FROM expired_log WHERE notified=1 AND deleted_at < ?",
                  ((datetime.now(timezone.utc) - timedelta(days=30)).isoformat(),))
    return {"ok": True, "acked": len(r.ids)}


# ---------------- PUBLIC (app gọi) ----------------
_hits: dict[str, deque] = defaultdict(deque)


def rate_limit(request: Request):
    ip, q, now = client_ip(request) or "?", None, time.time()
    q = _hits[ip]
    while q and now - q[0] > RATE_WINDOW:
        q.popleft()
    if len(q) >= RATE_LIMIT:
        raise HTTPException(429, "too many requests")
    q.append(now)


# ---------------- XÁC THỰC APP -> TELEGRAM OWNER ----------------
XTHUC_TTL_SECONDS = 300  # mã 6 số có hiệu lực 5 phút


def _gen_xthuc_code(c):
    for _ in range(20):
        code = f"{secrets.randbelow(1_000_000):06d}"
        if not c.execute("SELECT 1 FROM xthuc_requests WHERE code=?", (code,)).fetchone():
            return code
    raise HTTPException(503, "cannot_generate_code")


class XthucRequest(BaseModel):
    key: str = Field(max_length=64)
    device_id: str = Field(max_length=128)


@app.post("/xthuc/request", dependencies=[Depends(rate_limit)])
def xthuc_request(r: XthucRequest, request: Request):
    key = r.key.strip()
    device_id = r.device_id.strip()
    if not key or not device_id:
        raise HTTPException(400, "key_and_device_required")

    with db() as c:
        row = c.execute("SELECT * FROM keys WHERE key=?", (key,)).fetchone()
        if not row:
            return {"ok": False, "reason": "invalid_key"}
        if row["locked"]:
            return {"ok": False, "reason": "key_locked"}
        if datetime.fromisoformat(row["expires_at"]) < datetime.now(timezone.utc):
            return {"ok": False, "reason": "expired"}

        auth = c.execute("SELECT * FROM key_telegram_auth WHERE key=?", (key,)).fetchone()
        if auth:
            return {"ok": True, "required": False, "verified": True,
                    "telegram_name": auth["telegram_name"],
                    "telegram_username": auth["telegram_username"]}

        # Every key, including ShinnCheatTest, must be verified once in Telegram.
        # A key can only be bound to one Telegram identity.
        existing_pending = c.execute(
            "SELECT 1 FROM xthuc_requests WHERE key=? AND device_id=? AND used_at IS NULL AND expires_at>?",
            (key, device_id, now_iso()),
        ).fetchone()
        if existing_pending:
            pending = c.execute(
                "SELECT * FROM xthuc_requests WHERE key=? AND device_id=? AND used_at IS NULL ORDER BY created_at DESC LIMIT 1",
                (key, device_id),
            ).fetchone()
            if pending:
                return {"ok": True, "required": True, "code": pending["code"],
                        "expires_at": pending["expires_at"], "expires_in": XTHUC_TTL_SECONDS,
                        "message": "Gửi mã này cho bot Telegram: /xthuc 123456"}

        # Hủy mã cũ chưa dùng của cùng key/device.
        c.execute(
            "UPDATE xthuc_requests SET used_at=? WHERE key=? AND device_id=? AND used_at IS NULL",
            (now_iso(), key, device_id),
        )
        now = datetime.now(timezone.utc)
        expires = now + timedelta(seconds=XTHUC_TTL_SECONDS)
        code = _gen_xthuc_code(c)
        c.execute(
            "INSERT INTO xthuc_requests(code,key,device_id,ip,created_at,expires_at,used_at) VALUES (?,?,?,?,?,?,NULL)",
            (code, key, device_id, client_ip(request), now.isoformat(), expires.isoformat()),
        )
    return {
        "ok": True,
        "required": True,
        "code": code,
        "expires_at": expires.isoformat(),
        "expires_in": XTHUC_TTL_SECONDS,
        "message": "Gửi mã này cho bot Telegram: /xthuc 123456",
    }


class XthucVerifyRequest(BaseModel):
    code: str = Field(min_length=6, max_length=6, pattern=r"^[0-9]{6}$")
    telegram_user_id: str = Field(min_length=1, max_length=64)
    telegram_username: str = Field(default="", max_length=64)
    telegram_name: str = Field(min_length=1, max_length=128)


@app.post("/admin/xthuc/verify", dependencies=[Depends(require_admin)])
def xthuc_verify(r: XthucVerifyRequest):
    now = datetime.now(timezone.utc)
    with db() as c:
        row = c.execute(
            "SELECT * FROM xthuc_requests WHERE code=? AND used_at IS NULL",
            (r.code.strip(),),
        ).fetchone()
        if not row:
            raise HTTPException(404, "invalid_or_used_code")
        if datetime.fromisoformat(row["expires_at"]) < now:
            c.execute("UPDATE xthuc_requests SET used_at=? WHERE code=?", (now_iso(), r.code.strip()))
            raise HTTPException(410, "code_expired")

        key_row = c.execute("SELECT * FROM keys WHERE key=?", (row["key"],)).fetchone()
        if not key_row:
            raise HTTPException(404, "key_not_found")
        if key_row["locked"]:
            raise HTTPException(423, "key_locked")
        # A key is verified only once and remains bound to this Telegram identity.
        existing_auth = c.execute("SELECT * FROM key_telegram_auth WHERE key=?", (row["key"],)).fetchone()
        if existing_auth:
            raise HTTPException(409, "key_already_verified")

        # Enforce one device for every key except the explicitly shared ShinnCheatTest key.
        known = c.execute(
            "SELECT 1 FROM devices WHERE key=? AND device_id=?",
            (row["key"], row["device_id"]),
        ).fetchone()
        if not known and not key_row["unlimited_devices"]:
            n = c.execute("SELECT COUNT(*) FROM devices WHERE key=?", (row["key"],)).fetchone()[0]
            if n >= key_row["max_devices"]:
                raise HTTPException(409, "device_limit")
            c.execute("INSERT INTO devices(key,device_id,first_seen) VALUES (?,?,?)",
                      (row["key"], row["device_id"], now_iso()))
        verified_at = now_iso()
        c.execute("""INSERT INTO key_telegram_auth
            (key,device_id,telegram_user_id,telegram_username,telegram_name,verified_at)
            VALUES (?,?,?,?,?,?)""",
            (row["key"], row["device_id"], r.telegram_user_id.strip(),
             r.telegram_username.strip().lstrip("@"), r.telegram_name.strip(), verified_at))
        c.execute("UPDATE xthuc_requests SET used_at=? WHERE code=?", (verified_at, r.code.strip()))
        c.execute("DELETE FROM pending WHERE key=? AND device_id=?", (row["key"], row["device_id"]))
    return {"ok": True, "key": row["key"], "device_id": row["device_id"],
            "kind": key_row["kind"], "label": key_row["label"], "expires_at": key_row["expires_at"],
            "telegram_user_id": r.telegram_user_id, "telegram_username": r.telegram_username,
            "telegram_name": r.telegram_name, "verified_at": verified_at}


class VerifyReq(BaseModel):
    key: str = Field(max_length=64)
    device_id: str = Field(default="", max_length=128)
    repo: str = Field(default="", max_length=32)   # tên repo app đang dùng (vd "V2")


@app.post("/verify", dependencies=[Depends(rate_limit)])
def verify(r: VerifyReq, request: Request):
    key = r.key.strip()
    with db() as c:
        row, reason = check_key(c, key, r.device_id, ip=client_ip(request))
        if reason:
            return {"ok": False, "reason": reason}
        blocked = repos_of(row)
        if r.repo and r.repo.strip().lower() in [b.lower() for b in blocked]:
            return {"ok": False, "reason": "repo_blocked", "blocked_repos": blocked}
        c.execute("UPDATE keys SET last_used_at=? WHERE key=?", (now_iso(), key))
        auth = c.execute("SELECT telegram_name,telegram_username FROM key_telegram_auth WHERE key=?", (key,)).fetchone()
    left = int((datetime.fromisoformat(row["expires_at"]) - datetime.now(timezone.utc)).total_seconds())
    return {"ok": True, "label": row["label"], "kind": row["kind"], "role": row["role"],
            "expires_at": row["expires_at"], "seconds_left": min(max(left, 0), MAX_SECONDS_LEFT),
            "permanent": row["expires_at"] >= "2099", "blocked_repos": blocked,
            "telegram_name": auth["telegram_name"] if auth else "",
            "telegram_username": auth["telegram_username"] if auth else "",
            "server_time": now_iso()}


# ---------------- QUẢN LÝ KEY TRONG APP (key role=admin đã được duyệt máy) ----------------
class AppAuth(BaseModel):
    key: str = Field(max_length=64)
    device_id: str = Field(default="", max_length=128)


class AppCreate(AppAuth):
    label: str = Field(default="", max_length=64)
    kind: str = Field(default="vip", max_length=16)
    seconds: int = Field(gt=0, le=3650 * 86400)
    quantity: int = Field(default=1, ge=1, le=100)
    custom_key: str = Field(default="", max_length=32, pattern=r"^[A-Za-z0-9_-]*$")
    permanent: bool = False


class AppList(AppAuth):
    limit: int = Field(default=30, ge=1, le=200)


class AppTarget(AppAuth):
    target: str = Field(max_length=64)


def need_admin(c, a, request):
    _, reason = check_key(c, a.key.strip(), a.device_id, role="admin", ip=client_ip(request))
    if reason:
        raise HTTPException(403, reason)


@app.post("/app/keys/create", dependencies=[Depends(rate_limit)])
def app_create(r: AppCreate, request: Request):
    with db() as c:
        need_admin(c, r, request)
        if r.custom_key and r.quantity != 1:
            raise HTTPException(400, "custom_key chi tao 1 key")
        try:
            rows = insert_keys(c, r.label, r.kind, "member", r.seconds, r.quantity, 1,
                               custom_key=r.custom_key)
            if r.permanent:
                c.executemany("UPDATE keys SET expires_at=? WHERE key=?", [(PERMANENT, row["key"]) for row in rows])
            return rows
        except sqlite3.IntegrityError:
            raise HTTPException(409, "key da ton tai")


@app.post("/app/keys/list", dependencies=[Depends(rate_limit)])
def app_list(r: AppList, request: Request):
    with db() as c:
        need_admin(c, r, request)
        rows = c.execute("SELECT * FROM keys ORDER BY created_at DESC LIMIT ?", (r.limit,)).fetchall()
    return [dict(x) for x in rows]


@app.post("/app/keys/delete", dependencies=[Depends(rate_limit)])
def app_delete(r: AppTarget, request: Request):
    with db() as c:
        need_admin(c, r, request)
        t = c.execute("SELECT role FROM keys WHERE key=?", (r.target.strip(),)).fetchone()
        if not t:
            raise HTTPException(404, "not found")
        if t["role"] == "admin":
            raise HTTPException(403, "cannot_delete_admin")
        c.execute("DELETE FROM keys WHERE key=?", (r.target.strip(),))
        c.execute("DELETE FROM devices WHERE key=?", (r.target.strip(),))
    return {"deleted": True}


@app.post("/app/keys/reset-devices", dependencies=[Depends(rate_limit)])
def app_reset(r: AppTarget, request: Request):
    with db() as c:
        need_admin(c, r, request)
        t = c.execute("SELECT role FROM keys WHERE key=?", (r.target.strip(),)).fetchone()
        if t and t["role"] == "admin":
            raise HTTPException(403, "cannot_reset_admin")
        c.execute("DELETE FROM devices WHERE key=?", (r.target.strip(),))
    return {"ok": True}


class AppRepoToggle(AppAuth):
    target: str = Field(default="", max_length=64)
    targets: list[str] = Field(default_factory=list, max_length=200)
    enabled: bool = False


@app.post("/app/keys/repo-v2", dependencies=[Depends(rate_limit)])
def app_repo_v2(r: AppRepoToggle, request: Request):
    """Owner gán/thu hồi Repo V2 ngay trên app; quyền lưu trong DB main.py."""
    with db() as c:
        need_admin(c, r, request)
        targets = [x.strip() for x in (r.targets or []) if x.strip()]
        if r.target.strip():
            targets.append(r.target.strip())
        if not targets:
            raise HTTPException(400, "target_required")
        updated = []
        for target in dict.fromkeys(targets):
            row = c.execute("SELECT role FROM keys WHERE key=?", (target,)).fetchone()
            if not row:
                raise HTTPException(404, f"key_not_found:{target}")
            if row["role"] == "admin":
                updated.append({"key": target, "enabled": True, "protected": True})
                continue
            if target.lower() == "shinncheattest":
                c.execute("UPDATE keys SET blocked_repos='V2' WHERE key=?", (target,))
                updated.append({"key": target, "enabled": False, "protected": True})
                continue
            if r.enabled:
                c.execute("UPDATE keys SET blocked_repos='' WHERE key=?", (target,))
            else:
                c.execute("UPDATE keys SET blocked_repos='V2' WHERE key=?", (target,))
            updated.append({"key": target, "enabled": bool(r.enabled), "protected": False})
    return {"ok": True, "updated": updated}

# ==================== SHINNMANAGER OWNER API ====================
def _hash_token(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()

def _manager_session(authorization: str = Header(default="")):
    token = authorization.strip()
    if token.lower().startswith("bearer "):
        token = token[7:].strip()
    if not token:
        raise HTTPException(401, "manager_auth_required")
    with db() as c:
        row = c.execute(
            "SELECT * FROM manager_sessions WHERE token_hash=? AND expires_at>?",
            (_hash_token(token), now_iso()),
        ).fetchone()
    if not row:
        raise HTTPException(401, "manager_session_expired")
    return dict(row)

class ManagerLoginRequest(BaseModel):
    telegram_id: str = Field(min_length=1, max_length=32)
    device_id: str = Field(min_length=1, max_length=128)

@app.post("/mgr/login/request", dependencies=[Depends(rate_limit)])
def manager_login_request(r: ManagerLoginRequest, request: Request):
    # Telegram ID alone is not the login secret: this endpoint only sends a one-time
    # code to the preconfigured Owner Telegram account. Never accept arbitrary IDs.
    if r.telegram_id.strip() != OWNER_TELEGRAM_ID:
        raise HTTPException(403, "owner_telegram_id_required")
    device = r.device_id.strip()
    with db() as c:
        row = c.execute("SELECT * FROM keys WHERE role='admin' AND locked=0 AND expires_at>? ORDER BY created_at LIMIT 1", (now_iso(),)).fetchone()
        if not row:
            raise HTTPException(503, "no_active_owner_key_configured")
        key = row["key"]
        # One active request per key/device.
        c.execute("UPDATE manager_login SET used_at=? WHERE key=? AND device_id=? AND used_at IS NULL",
                  (now_iso(), key, device))
        code = f"{secrets.randbelow(1000000):06d}"
        req_id = secrets.token_urlsafe(18)
        now = datetime.now(timezone.utc)
        exp = now + timedelta(seconds=XTHUC_TTL_SECONDS)
        c.execute("""INSERT INTO manager_login
            (req_id,key,device_id,code,created_at,expires_at,notified,used_at)
            VALUES (?,?,?,?,?,?,0,NULL)""",
            (req_id,key,device,code,now.isoformat(),exp.isoformat()))
    return {"ok": True, "req_id": req_id, "ttl": XTHUC_TTL_SECONDS,
            "message": "Bot sẽ gửi mã xác thực cho Owner Telegram."}

@app.get("/admin/manager/pending", dependencies=[Depends(require_admin)])
def admin_manager_pending(limit: int = 20):
    with db() as c:
        rows = c.execute(
            "SELECT req_id,key,device_id,code,created_at,expires_at FROM manager_login "
            "WHERE used_at IS NULL AND notified=0 AND expires_at>? ORDER BY created_at ASC LIMIT ?",
            (now_iso(), min(max(limit,1),100))).fetchall()
    return [dict(x) for x in rows]

@app.post("/admin/manager/pending/{req_id}/notified", dependencies=[Depends(require_admin)])
def admin_manager_mark_notified(req_id: str):
    with db() as c:
        c.execute("UPDATE manager_login SET notified=1 WHERE req_id=?", (req_id,))
    return {"ok": True}

class ManagerVerifyRequest(BaseModel):
    req_id: str = Field(min_length=1, max_length=128)
    code: str = Field(min_length=6, max_length=6, pattern=r"^[0-9]{6}$")
    telegram_id: str = Field(min_length=1, max_length=32)

@app.post("/mgr/login/verify", dependencies=[Depends(rate_limit)])
def manager_login_verify(r: ManagerVerifyRequest):
    if r.telegram_id.strip() != OWNER_TELEGRAM_ID:
        raise HTTPException(403, "owner_telegram_id_required")
    with db() as c:
        row = c.execute(
            "SELECT * FROM manager_login WHERE req_id=? AND used_at IS NULL",
            (r.req_id.strip(),)).fetchone()
        if not row:
            raise HTTPException(404, "login_request_not_found")
        if datetime.fromisoformat(row["expires_at"]) < datetime.now(timezone.utc):
            c.execute("UPDATE manager_login SET used_at=? WHERE req_id=?", (now_iso(), r.req_id))
            raise HTTPException(410, "login_code_expired")
        if not secrets.compare_digest(str(row["code"]), r.code.strip()):
            raise HTTPException(401, "invalid_login_code")
        key_row = c.execute("SELECT * FROM keys WHERE key=?", (row["key"],)).fetchone()
        if not key_row or key_row["role"] != "admin":
            raise HTTPException(403, "owner_key_required")
        token = secrets.token_urlsafe(48)
        now = datetime.now(timezone.utc)
        exp = now + timedelta(seconds=MANAGER_SESSION_TTL)
        c.execute("INSERT INTO manager_sessions(token_hash,key,device_id,created_at,expires_at) VALUES (?,?,?,?,?)",
                  (_hash_token(token), row["key"], row["device_id"], now.isoformat(), exp.isoformat()))
        c.execute("UPDATE manager_login SET used_at=? WHERE req_id=?", (now.isoformat(), r.req_id))
    return {"ok": True, "token": token, "expires_at": exp.isoformat(), "key": row["key"]}

@app.post("/mgr/logout")
def manager_logout(authorization: str = Header(default="")):
    token = authorization.strip()
    if token.lower().startswith("bearer "): token = token[7:].strip()
    if token:
        with db() as c:
            c.execute("DELETE FROM manager_sessions WHERE token_hash=?", (_hash_token(token),))
    return {"ok": True}

@app.get("/mgr/stats")
def manager_stats(session=Depends(_manager_session)):
    return admin_stats()

@app.get("/mgr/keys")
def manager_keys(limit: int = 200, session=Depends(_manager_session)):
    with db() as c:
        rows = c.execute("SELECT * FROM keys ORDER BY created_at DESC LIMIT ?",
                         (min(max(limit,1),500),)).fetchall()
    return [dict(x) for x in rows]

@app.get("/mgr/keys/{key}")
def manager_key(key: str, session=Depends(_manager_session)):
    with db() as c:
        row=c.execute("SELECT * FROM keys WHERE key=?", (key,)).fetchone()
        if not row: raise HTTPException(404,"not_found")
        devices=c.execute("SELECT device_id,first_seen FROM devices WHERE key=? ORDER BY first_seen",(key,)).fetchall()
    out=dict(row); out["devices"]=[dict(x) for x in devices]; return out

@app.post("/mgr/keys")
def manager_create_key(r: CreateReq, session=Depends(_manager_session)):
    if r.custom_key == "ShinnCheatTest":
        r.unlimited_devices=True; r.max_devices=0
    else:
        r.unlimited_devices=False; r.max_devices=1
    if r.custom_key and r.quantity != 1:
        raise HTTPException(400,"custom_key chi tao 1 key")
    with db() as c:
        try:
            rows=insert_keys(c,r.label,r.kind,"member",r.seconds,r.quantity,1,
                              r.unlimited_devices,r.custom_key,r.blocked_repos)
            if r.permanent:
                c.executemany("UPDATE keys SET expires_at=? WHERE key=?",
                              [(PERMANENT,x["key"]) for x in rows])
            return rows
        except sqlite3.IntegrityError:
            raise HTTPException(409,"key_da_ton_tai")

@app.delete("/mgr/keys/{key}")
def manager_delete_key(key: str, session=Depends(_manager_session)):
    with db() as c:
        row=c.execute("SELECT role FROM keys WHERE key=?", (key,)).fetchone()
        if not row: raise HTTPException(404,"not_found")
        if row["role"]=="admin": raise HTTPException(403,"cannot_delete_admin")
        c.execute("DELETE FROM keys WHERE key=?", (key,))
        c.execute("DELETE FROM devices WHERE key=?", (key,))
    return {"ok":True}

@app.delete("/mgr/keys/actions/delete-unused")
def manager_delete_unused_keys(session=Depends(_manager_session)):
    """Delete non-owner keys that have never been assigned a device or Telegram auth."""
    with db() as c:
        rows = c.execute("""SELECT k.key FROM keys k
            LEFT JOIN devices d ON d.key=k.key
            LEFT JOIN key_telegram_auth a ON a.key=k.key
            WHERE k.role!='admin' AND d.key IS NULL AND a.key IS NULL
              AND (k.last_used_at IS NULL OR k.last_used_at='')""").fetchall()
        keys = [r["key"] for r in rows]
        if keys:
            marks = ",".join("?" for _ in keys)
            for table in ("pending", "xthuc_requests"):
                c.execute(f"DELETE FROM {table} WHERE key IN ({marks})", keys)
            c.execute(f"DELETE FROM keys WHERE key IN ({marks})", keys)
    return {"ok": True, "deleted": len(keys)}

@app.post("/mgr/keys/{key}/reset-devices")
def manager_reset_devices(key: str, session=Depends(_manager_session)):
    with db() as c:
        row=c.execute("SELECT role FROM keys WHERE key=?", (key,)).fetchone()
        if not row: raise HTTPException(404,"not_found")
        if row["role"]=="admin": raise HTTPException(403,"cannot_reset_admin")
        c.execute("DELETE FROM devices WHERE key=?", (key,))
    return {"ok":True}

@app.post("/mgr/keys/{key}/{action}")
def manager_key_lock(key: str, action: str, session=Depends(_manager_session)):
    if action not in ("lock","unlock"): raise HTTPException(404,"unknown_action")
    with db() as c:
        row=c.execute("SELECT role FROM keys WHERE key=?", (key,)).fetchone()
        if not row: raise HTTPException(404,"not_found")
        if row["role"]=="admin" and action=="lock":
            raise HTTPException(403,"cannot_lock_owner")
        c.execute("UPDATE keys SET locked=? WHERE key=?", (1 if action=="lock" else 0,key))
    return {"ok":True,"locked":action=="lock"}

@app.post("/mgr/keys-lock-all")
def manager_lock_all(session=Depends(_manager_session)):
    with db() as c: c.execute("UPDATE keys SET locked=1 WHERE role!='admin'")
    return {"ok":True}

@app.post("/mgr/keys-unlock-all")
def manager_unlock_all(session=Depends(_manager_session)):
    with db() as c: c.execute("UPDATE keys SET locked=0")
    return {"ok":True}

@app.get("/mgr/bot/state")
def manager_bot_state(session=Depends(_manager_session)):
    with db() as c: row=c.execute("SELECT * FROM bot_heartbeat WHERE id=1").fetchone()
    if not row: return {"online":False,"username":"@ShinnThieuu_bot","uptime":"—"}
    last=datetime.fromisoformat(row["last_seen"])
    online=(datetime.now(timezone.utc)-last).total_seconds()<90
    return {"online":online,"username":row["username"],"last_seen":row["last_seen"],"pid":row["pid"]}

@app.post("/admin/bot/heartbeat", dependencies=[Depends(require_admin)])
def bot_heartbeat(r: dict):
    with db() as c:
        c.execute("""INSERT INTO bot_heartbeat(id,username,started_at,last_seen,pid)
                     VALUES(1,?,?,?,?)
                     ON CONFLICT(id) DO UPDATE SET username=excluded.username,last_seen=excluded.last_seen,pid=excluded.pid""",
                  (str(r.get("username","")),str(r.get("started_at","")),now_iso(),int(r.get("pid",0) or 0)))
    return {"ok":True}

_DEFAULT_COMMANDS = ["start","help","id","chatid","shinn","key","buy","owner","update","repo",
                     "support","rules","about","ad","diemdanh","checkin","diem","mydiem","bxh",
                     "topdiem","shop","doikey","keytest","key1h","key1d","key3d","key5d","key7d",
                     "key15d","key30d","keylist","keyinfo","keydel","keystats","keyshare","pending",
                     "approve","lockallkey","unlockallkey","lock","xthuc","setfile","info","stats","top"]
@app.get("/mgr/bot/commands")
def manager_bot_commands(session=Depends(_manager_session)):
    with db() as c:
        for cmd in _DEFAULT_COMMANDS:
            c.execute("INSERT OR IGNORE INTO bot_commands(command,description,trigger,enabled,created_at) VALUES (?,?,?,?,?)",
                      (cmd,"Lệnh Telegram","",1,now_iso()))
        rows=c.execute("SELECT * FROM bot_commands ORDER BY command").fetchall()
    return [dict(x) for x in rows]

class BotCommandReq(BaseModel):
    command: str = Field(min_length=1,max_length=64,pattern=r"^[A-Za-z0-9_]+$")
    description: str = Field(default="",max_length=500)
    trigger: str = Field(default="",max_length=128)
    enabled: bool = True

@app.post("/mgr/bot/commands")
def manager_add_command(r: BotCommandReq, session=Depends(_manager_session)):
    with db() as c:
        c.execute("""INSERT INTO bot_commands(command,description,trigger,enabled,created_at)
                     VALUES(?,?,?,?,?) ON CONFLICT(command) DO UPDATE SET description=excluded.description,
                     trigger=excluded.trigger,enabled=excluded.enabled""",
                  (r.command,r.description,r.trigger,1 if r.enabled else 0,now_iso()))
    return {"ok":True}

@app.delete("/mgr/bot/commands/{name}")
def manager_delete_command(name: str, session=Depends(_manager_session)):
    with db() as c: c.execute("DELETE FROM bot_commands WHERE command=?", (name,))
    return {"ok":True}

@app.get("/mgr/bot/content")
def manager_bot_content(session=Depends(_manager_session)):
    with db() as c: rows=c.execute("SELECT id,name,mime,size,title,description,trigger,auto_send,active,created_at FROM bot_content ORDER BY created_at DESC").fetchall()
    return [dict(x) for x in rows]

@app.post("/mgr/bot/content")
async def manager_upload_content(
    file: UploadFile = File(...),
    title: str = Form(""), description: str = Form(""),
    trigger: str = Form(""), auto_send: str = Form("true"),
    session=Depends(_manager_session)
):
    if not trigger.strip(): raise HTTPException(400,"trigger_required")
    if file.content_type and not (file.content_type.startswith("image/") or file.content_type in
                                   ("application/pdf","application/zip","application/octet-stream","text/plain")):
        raise HTTPException(415,"unsupported_file_type")
    raw=await file.read()
    if len(raw)>50*1024*1024: raise HTTPException(413,"file_too_large")
    cid=secrets.token_urlsafe(12)
    safe_name=re.sub(r"[^A-Za-z0-9._-]+","_",file.filename or "upload.bin")[:120]
    path=MEDIA_DIR/(cid+"_"+safe_name)
    path.write_bytes(raw)
    with db() as c:
        c.execute("""INSERT INTO bot_content
          (id,name,mime,size,title,description,trigger,auto_send,active,path,created_at)
          VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
          (cid,safe_name,file.content_type or "application/octet-stream",len(raw),title.strip(),
           description.strip(),trigger.strip(),1 if auto_send.lower()=="true" else 0,1,str(path),now_iso()))
    return {"ok":True,"id":cid,"name":safe_name,"size":len(raw)}

@app.delete("/mgr/bot/content/{content_id}")
def manager_delete_content(content_id: str, session=Depends(_manager_session)):
    with db() as c:
        row=c.execute("SELECT path FROM bot_content WHERE id=?",(content_id,)).fetchone()
        if not row: raise HTTPException(404,"not_found")
        c.execute("DELETE FROM bot_content WHERE id=?",(content_id,))
    try: Path(row["path"]).unlink(missing_ok=True)
    except Exception: pass
    return {"ok":True}

@app.get("/mgr/internal/content", dependencies=[Depends(require_admin)])
def internal_bot_content():
    with db() as c:
        rows=c.execute("SELECT id,name,mime,size,title,description,trigger,auto_send,active,path,created_at FROM bot_content ORDER BY created_at DESC").fetchall()
    return [dict(x) for x in rows]

@app.get("/mgr/internal/commands", dependencies=[Depends(require_admin)])
def internal_bot_commands():
    with db() as c:
        rows=c.execute("SELECT * FROM bot_commands ORDER BY command").fetchall()
    return [dict(x) for x in rows]

@app.get("/admin/keys/by-telegram/{telegram_user_id}", dependencies=[Depends(require_admin)])
def admin_keys_by_telegram(telegram_user_id: str):
    with db() as c:
        rows=c.execute("""SELECT k.key,k.kind,k.label,k.expires_at,k.role,a.device_id
                          FROM keys k JOIN key_telegram_auth a ON a.key=k.key
                          WHERE a.telegram_user_id=?""",(str(telegram_user_id),)).fetchall()
    return [dict(x) for x in rows]

@app.post("/admin/keys/delete-by-telegram/{telegram_user_id}", dependencies=[Depends(require_admin)])
def admin_delete_keys_by_telegram(telegram_user_id: str):
    with db() as c:
        rows=c.execute("""SELECT k.key,k.role,a.device_id FROM keys k
                          JOIN key_telegram_auth a ON a.key=k.key
                          WHERE a.telegram_user_id=?""",(str(telegram_user_id),)).fetchall()
        deleted=[]
        for row in rows:
            if row["role"]=="admin":
                continue
            c.execute("DELETE FROM keys WHERE key=?",(row["key"],))
            c.execute("DELETE FROM devices WHERE key=?",(row["key"],))
            c.execute("DELETE FROM key_telegram_auth WHERE key=?",(row["key"],))
            deleted.append(dict(row))
    return {"ok":True,"deleted":deleted}

@app.get("/admin/bot/jobs", dependencies=[Depends(require_admin)])
def admin_bot_jobs(limit: int = 10):
    with db() as c:
        rows=c.execute("SELECT * FROM bot_jobs WHERE status='pending' ORDER BY created_at ASC LIMIT ?",
                       (min(max(limit,1),50),)).fetchall()
    out=[]
    for x in rows:
        d=dict(x)
        try:d["payload"]=json.loads(d["payload"] or "{}")
        except Exception:d["payload"]={}
        out.append(d)
    return out

@app.post("/admin/bot/jobs/{job_id}/done", dependencies=[Depends(require_admin)])
def admin_bot_job_done(job_id: str, r: dict):
    with db() as c:
        status="done" if r.get("ok") else "failed"
        c.execute("UPDATE bot_jobs SET status=?,result=?,updated_at=? WHERE id=?",
                  (status,json.dumps(r,ensure_ascii=False),now_iso(),job_id))
    return {"ok":True}

@app.post("/mgr/bot/broadcast")
def manager_broadcast(r: dict, session=Depends(_manager_session)):
    job_id=secrets.token_urlsafe(12); now=now_iso()
    with db() as c:
        c.execute("INSERT INTO bot_jobs(id,kind,payload,status,result,created_at,updated_at) VALUES(?,?,?,?,?,?,?)",
                  (job_id,"broadcast_group",json.dumps(r,ensure_ascii=False),"pending","{}",now,now))
    return {"id":job_id}

@app.post("/mgr/bot/job")
def manager_bot_job(r: dict, session=Depends(_manager_session)):
    job_id=secrets.token_urlsafe(12); now=now_iso()
    with db() as c:
        c.execute("INSERT INTO bot_jobs(id,kind,payload,status,result,created_at,updated_at) VALUES(?,?,?,?,?,?,?)",
                  (job_id,str(r.get("kind","")),json.dumps(r.get("payload",{}),ensure_ascii=False),"pending","{}",now,now))
    return {"id":job_id}

@app.get("/mgr/bot/job/{job_id}")
def manager_bot_job_status(job_id: str, session=Depends(_manager_session)):
    with db() as c: row=c.execute("SELECT * FROM bot_jobs WHERE id=?",(job_id,)).fetchone()
    if not row: raise HTTPException(404,"job_not_found")
    out=dict(row)
    try: out["result"]=json.loads(out["result"] or "{}")
    except Exception: pass
    return out

class ManagerSecurityUpdate(BaseModel):
    anti_spam: bool = True
    auto_delete_spam_key: bool = True

@app.get("/mgr/security")
def manager_security(session=Depends(_manager_session)):
    with db() as c:
        values = {r["k"]: r["v"] for r in c.execute("SELECT k,v FROM meta WHERE k IN ('manager_anti_spam','manager_auto_delete_spam_key')").fetchall()}
    return {"session_ttl":MANAGER_SESSION_TTL,"manager_login_code_ttl":XTHUC_TTL_SECONDS,
            "media_limit_mb":50,"anti_spam":values.get("manager_anti_spam", "true") == "true",
            "auto_delete_spam_key":values.get("manager_auto_delete_spam_key", "true") == "true"}

@app.put("/mgr/security")
def manager_update_security(r: ManagerSecurityUpdate, session=Depends(_manager_session)):
    with db() as c:
        c.executemany("INSERT INTO meta(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v", [
            ("manager_anti_spam", str(r.anti_spam).lower()),
            ("manager_auto_delete_spam_key", str(r.auto_delete_spam_key).lower())])
    return {"ok": True, "anti_spam": r.anti_spam, "auto_delete_spam_key": r.auto_delete_spam_key}


@app.get("/health")
def health():
    return {"ok": True}
