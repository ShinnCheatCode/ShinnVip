# Shinn Cheat Access Flow

- Free repository: public access, no activation key required.
- Premium repository (Repo V2): requires a valid purchased key that has been explicitly granted Premium Repo access.
- Main group: https://t.me/ShinnCheatShare
- English chat: https://t.me/ShinnCheatChat
- Support: @ShinnThieuu
- Repository URLs are kept internal and are not displayed in the user-facing repository UI.
- Shinn AI and its command manager remain enabled.
