import SwiftUI
import UIKit
import LocalAuthentication
import CryptoKit
import Security
import UniformTypeIdentifiers
import PhotosUI

// Accent is user-customizable from Settings.
private var ShinnRed: Color {
    AppSettings.currentAccentColor
}

private var ShinnRedSoft: Color {
    AppSettings.currentAccentColor.opacity(0.42)
}

struct GlassCardModifier: ViewModifier {
    var radius: CGFloat = 22
    func body(content: Content) -> some View {
        content
            .background(
                .ultraThinMaterial,
                in: RoundedRectangle(cornerRadius: radius, style: .continuous)
            )
            .background(
                LinearGradient(
                    colors: [
                        Color.white.opacity(0.06),
                        ShinnRed.opacity(0.04),
                        Color.black.opacity(0.55)
                    ],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                ),
                in: RoundedRectangle(cornerRadius: radius, style: .continuous)
            )
            .overlay(
                RoundedRectangle(cornerRadius: radius, style: .continuous)
                    .stroke(
                        LinearGradient(
                            colors: [
                                Color.white.opacity(0.28),
                                ShinnRed.opacity(0.55),
                                Color.white.opacity(0.10)
                            ],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        ),
                        lineWidth: 1.1
                    )
            )
            .overlay(alignment: .top) {
                // Thanh highlight mỏng kiểu HUD 5.0
                RoundedRectangle(cornerRadius: 1, style: .continuous)
                    .fill(
                        LinearGradient(
                            colors: [Color.clear, ShinnRed.opacity(0.55), Color.clear],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
                    .frame(height: 1)
                    .padding(.horizontal, 18)
                    .padding(.top, 1)
            }
            .shadow(color: ShinnRed.opacity(0.12), radius: 14, y: 6)
    }
}

extension View {
    func shinnGlass(radius: CGFloat = 22) -> some View {
        modifier(GlassCardModifier(radius: radius))
    }
}

struct BackgroundView: View {
    private var base: Color { AppSettings.currentBackgroundColor }

    var body: some View {
        ZStack {
            base
            LinearGradient(
                colors: [
                    base.opacity(0.95),
                    Color.black.opacity(0.85),
                    base.opacity(0.9)
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            RadialGradient(
                colors: [ShinnRed.opacity(UserDefaults.standard.object(forKey: "accentIntensity") as? Double ?? 0.14), .clear],
                center: .topTrailing,
                startRadius: 0,
                endRadius: 420
            )
            RadialGradient(
                colors: [ShinnRedSoft.opacity((UserDefaults.standard.object(forKey: "accentIntensity") as? Double ?? 0.14) * 0.7), .clear],
                center: .bottomLeading,
                startRadius: 0,
                endRadius: 500
            )
            // Lưới tech mờ 5.0
            GeometryReader { geo in
                Path { path in
                    let step: CGFloat = 28
                    var x: CGFloat = 0
                    while x < geo.size.width {
                        path.move(to: CGPoint(x: x, y: 0))
                        path.addLine(to: CGPoint(x: x, y: geo.size.height))
                        x += step
                    }
                    var y: CGFloat = 0
                    while y < geo.size.height {
                        path.move(to: CGPoint(x: 0, y: y))
                        path.addLine(to: CGPoint(x: geo.size.width, y: y))
                        y += step
                    }
                }
                .stroke(Color.white.opacity(0.03), lineWidth: 0.5)
            }
            // Vệt chéo HUD
            GeometryReader { geo in
                Path { path in
                    path.move(to: CGPoint(x: geo.size.width * 0.68, y: -30))
                    path.addLine(to: CGPoint(x: geo.size.width + 40, y: geo.size.height * 0.18))
                    path.addLine(to: CGPoint(x: geo.size.width + 40, y: geo.size.height * 0.22))
                    path.addLine(to: CGPoint(x: geo.size.width * 0.72, y: 10))
                    path.closeSubpath()
                }
                .fill(ShinnRed.opacity(0.05))
            }
        }
        .ignoresSafeArea()
    }
}

struct ShinnPremiumButtonStyle: ButtonStyle {
    var destructive = false
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 15, weight: .bold, design: .rounded))
            .foregroundStyle(.white)
            .frame(maxWidth: .infinity, minHeight: 52)
            .background(
                LinearGradient(
                    colors: destructive
                        ? [Color.red.opacity(0.82), Color.red.opacity(0.58)]
                        : [ShinnRed, Color(red: 0.62, green: 0.005, blue: 0.045)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                ),
                in: RoundedRectangle(cornerRadius: 17, style: .continuous)
            )
            .overlay(
                RoundedRectangle(cornerRadius: 17, style: .continuous)
                    .stroke(Color.white.opacity(0.18), lineWidth: 0.8)
            )
            .shadow(color: ShinnRed.opacity(configuration.isPressed ? 0.18 : 0.38), radius: configuration.isPressed ? 7 : 16, y: 5)
            .scaleEffect(configuration.isPressed ? 0.985 : 1)
            .animation(.easeOut(duration: 0.16), value: configuration.isPressed)
    }
}

struct ShinnMiniGlassButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 11, weight: .black, design: .rounded))
            .foregroundStyle(.white.opacity(configuration.isPressed ? 0.55 : 0.82))
            .frame(minHeight: 44)
            .padding(.horizontal, 10)
            .background(Color.white.opacity(configuration.isPressed ? 0.07 : 0.055), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous).stroke(Color.white.opacity(0.09), lineWidth: 0.8))
            .scaleEffect(configuration.isPressed ? 0.985 : 1)
    }
}

struct ScreenPrivacyGuard: View {
    @State private var captured = UIScreen.main.isCaptured
    var body: some View {
        Color.black
            .opacity(captured ? 1 : 0)
            .ignoresSafeArea()
            .allowsHitTesting(captured)
            .onReceive(NotificationCenter.default.publisher(for: UIScreen.capturedDidChangeNotification)) { _ in
                captured = UIScreen.main.isCaptured
            }
    }
}

struct IconBox: View {
    let systemName: String
    var size: CGFloat = 56
    var body: some View {
        Image(systemName: systemName)
            .font(.system(size: size * 0.42, weight: .semibold))
            .foregroundStyle(.white)
            .frame(width: size, height: size)
            .background(
                LinearGradient(colors: [Color.white.opacity(0.10), ShinnRed.opacity(0.08)], startPoint: .topLeading, endPoint: .bottomTrailing),
                in: RoundedRectangle(cornerRadius: size * 0.30, style: .continuous)
            )
            .overlay(
                RoundedRectangle(cornerRadius: size * 0.30, style: .continuous)
                    .stroke(ShinnRed.opacity(0.18), lineWidth: 0.7)
            )
    }
}

struct Pill: View {
    let text: String
    var body: some View {
        Text(text)
            .font(.caption.bold())
            .foregroundStyle(ShinnRed)
            .padding(.horizontal, 12)
            .padding(.vertical, 7)
            .background(ShinnRed.opacity(0.14), in: Capsule())
            .overlay(Capsule().stroke(ShinnRed.opacity(0.28), lineWidth: 0.7))
    }
}

enum ShinnLanguage: String, CaseIterable, Identifiable {
    case vi
    case en
    var id: String { rawValue }
    var title: String { self == .vi ? "Tiếng Việt" : "English" }
}

enum ShinnTheme: String, CaseIterable, Identifiable {
    case system, light, dark
    var id: String { rawValue }
    var colorScheme: ColorScheme? {
        switch self {
        case .system: return nil
        case .light: return .light
        case .dark: return .dark
        }
    }
    var titleKey: K {
        switch self {
        case .system: return .themeSystem
        case .light: return .themeLight
        case .dark: return .themeDark
        }
    }
}

final class AppSettings: ObservableObject {
    @Published var theme: ShinnTheme {
        didSet { UserDefaults.standard.set(theme.rawValue, forKey: "theme") }
    }
    @Published var language: ShinnLanguage {
        didSet { UserDefaults.standard.set(language.rawValue, forKey: "language") }
    }
    @Published var autoRefresh: Bool {
        didSet { UserDefaults.standard.set(autoRefresh, forKey: "autoRefresh") }
    }

    // Người dùng có thể chọn bất kỳ màu nào cho toàn bộ accent của app.
    @Published var accentHex: String {
        didSet {
            let normalized = Self.normalizeHex(accentHex)
            if normalized != accentHex {
                accentHex = normalized
                return
            }
            UserDefaults.standard.set(normalized, forKey: "accentHex")
        }
    }

    // Độ mạnh của màu accent trong nền.
    @Published var accentIntensity: Double {
        didSet {
            let clamped = min(max(accentIntensity, 0.02), 0.18)
            if clamped != accentIntensity {
                accentIntensity = clamped
                return
            }
            UserDefaults.standard.set(clamped, forKey: "accentIntensity")
        }
    }

    // Màu nền app (base fill).
    @Published var bgHex: String {
        didSet {
            let normalized = Self.normalizeHex(bgHex, fallback: "#000000")
            if normalized != bgHex {
                bgHex = normalized
                return
            }
            UserDefaults.standard.set(normalized, forKey: "bgHex")
        }
    }

    static var currentAccentColor: Color {
        let hex = UserDefaults.standard.string(forKey: "accentHex") ?? "#F70A1F"
        return ShinnColor(hex: hex) ?? Color(red: 0.98, green: 0.04, blue: 0.12)
    }

    static var currentBackgroundColor: Color {
        let hex = UserDefaults.standard.string(forKey: "bgHex") ?? "#000000"
        return ShinnColor(hex: hex) ?? .black
    }

    var backgroundColor: Color {
        ShinnColor(hex: bgHex) ?? Self.currentBackgroundColor
    }

    var accentColor: Color {
        ShinnColor(hex: accentHex) ?? Self.currentAccentColor
    }

    func setAccent(_ color: Color) {
        let ui = UIColor(color)
        var r: CGFloat = 0
        var g: CGFloat = 0
        var b: CGFloat = 0
        var a: CGFloat = 1
        if ui.getRed(&r, green: &g, blue: &b, alpha: &a) {
            accentHex = String(
                format: "#%02X%02X%02X",
                Int((r * 255).rounded()),
                Int((g * 255).rounded()),
                Int((b * 255).rounded())
            )
        }
    }

    func resetAppearance() {
        accentHex = "#F70A1F"
        accentIntensity = 0.10
        bgHex = "#000000"
        theme = .dark
    }

    private static func normalizeHex(_ raw: String, fallback: String = "#F70A1F") -> String {
        var value = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        if !value.hasPrefix("#") { value = "#" + value }
        let hex = value.dropFirst()
        guard hex.count == 6, hex.allSatisfy({ $0.isHexDigit }) else {
            return fallback
        }
        return "#" + hex.uppercased()
    }

    init() {
        let defaults = UserDefaults.standard
        theme = ShinnTheme(rawValue: defaults.string(forKey: "theme") ?? "") ?? .system
        if let raw = defaults.string(forKey: "language"), let language = ShinnLanguage(rawValue: raw) {
            self.language = language
        } else {
            self.language = .en
        }
        autoRefresh = defaults.object(forKey: "autoRefresh") as? Bool ?? true
        accentHex = Self.normalizeHex(defaults.string(forKey: "accentHex") ?? "#F70A1F")
        accentIntensity = min(max(defaults.object(forKey: "accentIntensity") as? Double ?? 0.10, 0.02), 0.18)
        bgHex = Self.normalizeHex(defaults.string(forKey: "bgHex") ?? "#000000", fallback: "#000000")
    }

    func t(_ key: K) -> String { key.text.en }
    func countText(_ n: Int) -> String { n == 1 ? "1 package" : "\(n) packages" }
}


private func ShinnColor(hex: String) -> Color? {
    var value = hex.trimmingCharacters(in: .whitespacesAndNewlines)
    if value.hasPrefix("#") { value.removeFirst() }
    guard value.count == 6, let number = UInt64(value, radix: 16) else { return nil }
    return Color(
        red: Double((number >> 16) & 0xFF) / 255.0,
        green: Double((number >> 8) & 0xFF) / 255.0,
        blue: Double(number & 0xFF) / 255.0
    )
}

enum K {
    case heroFree, heroNote, categoriesTitle, allPackages, loadingText, loadFailed, retry
    case settingsTitle, settingsSub, aboutTitle, aboutSub
    case packagesTitle, packageCenter, packageCenterSub, searchPrompt, allLabel, notFound, notFoundDesc
    case versionLabel, authorLabel, categoryLabel, sizeLabel, descriptionLabel
    case downloadAction, downloading, downloaded, redownload, shareAction, savedHint, sha256OK
    case errHash, errHTTP, errURL
    case appearance, themeLabel, themeSystem, themeLight, themeDark, languageLabel
    case autoUpdate, repoSection, defaultSource, defaultBadge, repoLocked, refreshRepo, infoTitle
    case aboutDesc, madeBy, contactTitle, donateTitle, copy, copied
    case featRemote, featSHA
    case termsTitle, termsBody
    case supportTitle, telegramSub, reportTitle, reportSub
}

extension K {
    var text: (vi: String, en: String) {
        switch self {
        case .heroFree: return ("LÀ APP VÀ REPO HOÀN TOÀN FREE", "A COMPLETELY FREE APP AND REPO")
        case .heroNote: return ("Không bán key • Không khóa thiết bị", "No keys sold • No device lock")
        case .categoriesTitle: return ("DANH MỤC GÓI", "PACKAGE CATEGORIES")
        case .allPackages: return ("Tất cả gói", "All packages")
        case .loadingText: return ("Đang tải repo…", "Loading repo…")
        case .loadFailed: return ("Không tải được repo.", "Couldn't load the repo.")
        case .retry: return ("Thử lại", "Retry")
        case .settingsTitle: return ("Cài Đặt", "Settings")
        case .settingsSub: return ("Tùy chỉnh app", "Customize the app")
        case .aboutTitle: return ("Giới Thiệu", "About")
        case .aboutSub: return ("Thông tin app", "App information")
        case .packagesTitle: return ("Packages", "Packages")
        case .packageCenter: return ("Package Center", "Package Center")
        case .packageCenterSub: return ("Các package được cung cấp bởi Shinn Cheat", "Packages provided by Shinn Cheat")
        case .searchPrompt: return ("Tìm package", "Search packages")
        case .allLabel: return ("Tất cả", "All")
        case .notFound: return ("Không tìm thấy", "No results")
        case .notFoundDesc: return ("Không có package phù hợp.", "No packages match your search.")
        case .versionLabel: return ("Phiên bản", "Version")
        case .authorLabel: return ("Tác giả", "Author")
        case .categoryLabel: return ("Danh mục", "Category")
        case .sizeLabel: return ("Dung lượng", "Size")
        case .descriptionLabel: return ("Mô tả", "Description")
        case .downloadAction: return ("Tải xuống", "Download")
        case .downloading: return ("Đang tải…", "Downloading…")
        case .downloaded: return ("Đã tải xong", "Downloaded")
        case .redownload: return ("Tải lại", "Download again")
        case .shareAction: return ("Chia sẻ", "Share")
        case .savedHint: return ("File được lưu trong Tệp › Trên iPhone › Shinn Cheat.", "Saved in Files › On My iPhone › Shinn Cheat.")
        case .sha256OK: return ("Đã xác minh SHA256", "SHA256 verified")
        case .errHash: return ("File tải về không khớp SHA256.", "The downloaded file failed the SHA256 check.")
        case .errHTTP: return ("Lỗi máy chủ", "Server error")
        case .errURL: return ("Link tải không hợp lệ", "Invalid download link")
        case .appearance: return ("Giao diện", "Appearance")
        case .themeLabel: return ("Chủ đề", "Theme")
        case .themeSystem: return ("Theo hệ thống", "System")
        case .themeLight: return ("Sáng", "Light")
        case .themeDark: return ("Tối", "Dark")
        case .languageLabel: return ("Ngôn ngữ", "Language")
        case .autoUpdate: return ("Tự động cập nhật repo", "Auto-refresh repo")
        case .repoSection: return ("Nguồn repo", "Repository")
        case .defaultSource: return ("Nguồn mặc định", "Default source")
        case .defaultBadge: return ("MẶC ĐỊNH", "DEFAULT")
        case .repoLocked: return ("Nguồn mặc định của app.", "The app's built-in source.")
        case .refreshRepo: return ("Làm mới repo", "Refresh repo")
        case .infoTitle: return ("Thông tin", "Info")
        case .aboutDesc: return ("Shinn Cheat is an app for managing packages through Shinn's repository.", "Shinn Cheat is an app for managing packages through Shinn's repository.")
        case .madeBy: return ("App made by Shinn", "App made by Shinn")
        case .contactTitle: return ("Contact", "Contact")
        case .donateTitle: return ("Donate", "Donate")
        case .copy: return ("Copy", "Copy")
        case .copied: return ("Copied", "Copied")
        case .featRemote: return ("Sync data from the repository", "Sync data from the repository")
        case .featSHA: return ("Verify file integrity", "Verify file integrity")
        case .termsTitle: return ("Terms of use", "Terms of use")
        case .termsBody:
            return (
                "By installing and using this app, you agree to our policy.\n\n• The app and its repo are completely FREE.\n• Do not use the app for anything that violates the law.\n• Sabotage or deliberate violations will result in a warning.",
                "By installing and using this app, you agree to our policy.\n\n• The app and its repo are completely FREE.\n• Do not use the app for anything that violates the law.\n• Sabotage or deliberate violations will result in a warning."
            )
        case .supportTitle: return ("Support", "Support")
        case .telegramSub: return ("Contact the support team", "Contact the support team")
        case .reportTitle: return ("Report a bug", "Report a bug")
        case .reportSub: return ("Report a bug or issue", "Report a bug or issue")
        }
    }
}

// AppInfo đã có trong helpers/Utils.swift — mở rộng field Shinn + alias cho SettingsView.
extension AppInfo {
    /// Creates a URL without force-unwrapping. A malformed/changed remote URL
    /// must never be able to crash the app during static initialization.
    static func safeURL(_ string: String) -> URL {
        URL(string: string) ?? URL(fileURLWithPath: "/")
    }

    static let shinnTelegramHandle = "@ShinnThieuu"
    static var telegramLinkURL: URL {
        safeURL("https://t.me/ShinnThieuu")
    }
    static var telegramMainGroupURL: URL {
        safeURL("https://t.me/ShinnCheatShare")
    }
    static var telegramEnglishChatURL: URL {
        safeURL("https://t.me/ShinnCheatChat")
    }
    static let shinnBankName = "MB Bank"
    static let shinnBankAccount = "104877777"
    static let defaultRepoName = "ShinnCheat Repo V1"
    /// Repo V1 is fixed. Never derive Repo V1 from the active key's repo_url,
    /// because a V2-authorized key may return the V2 URL from the server.
    static var repoV1URL: URL {
        safeURL("https://raw.githubusercontent.com/ShinnCheatCode/Repo-V3/main/ShinnCheatV3.json")
    }
    static var defaultRepoURL: URL { repoV1URL }
    /// Repo V2 cố định — hiển thị cho MỌI key, nhưng chỉ key được Owner cấp mới tải patch được.
    static let repoV2Name = "ShinnCheat Repo V2"
    static var repoV2URL: URL {
        safeURL("https://raw.githubusercontent.com/ShinnCheatCode/RepoV2/main/ShinnCheatV2.json")
    }
    static var shinnVersion: String {
        Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "2.1"
    }

    // SettingsView.swift dùng các tên này
    static var version: String { shinnVersion }
    static var telegramHandle: String { shinnTelegramHandle }
    static var bankName: String { shinnBankName }
    static var bankAccount: String { shinnBankAccount }
}

struct RepoManifest: Codable {
    let name: String?
    let description: String?
    let icon: String?
    let packages: [RepoPackage]
}

struct RepoPackage: Codable, Identifiable, Hashable {
    let identifier: String
    let name: String
    let author: String?
    let version: String?
    let summary: String?
    let description: String?
    let category: String?
    let tags: [String]?
    let download: String
    let sha256: String?
    let size: Int?
    let icon: String?
    let patchPath: String?
    let openURL: String?
    var id: String { identifier }
}

struct CategoryInfo: Identifiable {
    let name: String
    let count: Int
    var id: String { name }
}

enum Route: Hashable {
    case packages(String?)
    case detail(String)
    case settings
    case about
    case support
    case aiChat
    case premiumRepo
    case community
    case repositoryManager
    case patchBuilder
    case patchProjects   // màn tạo patch kiểu 3105 (sẵn trong project)
    case cleanup         // dọn dẹp máy
}

func formatBytes(_ value: Int) -> String {
    ByteCountFormatter.string(fromByteCount: Int64(value), countStyle: .file)
}

enum DLError: Error {
    case badURL, http(Int), hashMismatch, other(String)
    /// Key hợp lệ nhưng chưa được Owner cấp quyền dùng repo này.
    case notAuthorized(String)

    var message: String {
        switch self {
        case .badURL: return "Link tải không hợp lệ."
        case .http(let code): return "Lỗi máy chủ (HTTP \(code))."
        case .hashMismatch: return "File tải về không khớp SHA256."
        case .other(let m): return m
        case .notAuthorized(let m): return m
        }
    }
}

enum PatchError: Error {
    case invalidPath, sourceNotFound, backupFailed, applyFailed, restoreFailed, other(String)
}

enum DownloadState { case idle, downloading, done(URL), failed(DLError) }

struct PatchDownloadHistoryItem: Codable, Identifiable, Hashable {
    let id: UUID
    let packageID: String
    let name: String
    let version: String?
    let repo: String
    let size: Int?
    let downloadedAt: Date

    init(
        id: UUID = UUID(),
        packageID: String,
        name: String,
        version: String?,
        repo: String,
        size: Int?,
        downloadedAt: Date = Date()
    ) {
        self.id = id
        self.packageID = packageID
        self.name = name
        self.version = version
        self.repo = repo
        self.size = size
        self.downloadedAt = downloadedAt
    }
}
struct PatchUsageHistoryItem: Codable, Identifiable, Hashable {
    let id: UUID
    let packageID: String
    let name: String
    let version: String?
    let repo: String
    let action: String
    let success: Bool
    let usedAt: Date

    init(id: UUID = UUID(), packageID: String, name: String, version: String?, repo: String, action: String, success: Bool, usedAt: Date = Date()) {
        self.id = id
        self.packageID = packageID
        self.name = name
        self.version = version
        self.repo = repo
        self.action = action
        self.success = success
        self.usedAt = usedAt
    }
}

enum LoadState { case idle, loading, loaded, failed }
enum PatchState { case idle, applying, applied, restoring, restored, failed(String) }

func sha256Hex(of url: URL) throws -> String {
    let data = try Data(contentsOf: url, options: .mappedIfSafe)
    return SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined()
}

@MainActor
final class RepoStore: ObservableObject {
    static func activeRepoURL() -> URL {
        // V1 is the standard public repository. It must NOT inherit repo_url
        // from an activated V2 key. That was the reason V2 packages could appear
        // under the V1 section in Patch Center.
        return AppInfo.repoV1URL
    }

    @Published private(set) var manifest: RepoManifest?
    @Published private(set) var loadState: LoadState = .idle
    @Published private(set) var downloads: [String: DownloadState] = [:]
    @Published private(set) var downloadHistory: [PatchDownloadHistoryItem] = []
    @Published private(set) var patchUsageHistory: [PatchUsageHistoryItem] = []
    @Published private(set) var patchStates: [String: PatchState] = [:]
    @Published private(set) var recentPatchIDs: [String] = []
    @Published private(set) var bulkDownloadDone: Int = 0
    @Published private(set) var bulkDownloadTotal: Int = 0
    @Published private(set) var bulkDownloading: Bool = false
    private let recentPatchIDsKey = "shinn.patch.recentIDs"
    private let downloadHistoryKey = "shinn.patch.downloadHistory.v1"
    private let patchUsageHistoryKey = "shinn.patch.usageHistory.v1"
    private var didBootstrap = false

    /// true khi user đang xem/duyệt ShinnCheat Repo V2 (ai cũng xem được danh sách package).
    @Published var usingRepoV2 = false

    /// Key hiện tại có được Owner cấp quyền dùng ShinnCheat Repo V2 hay không.
    /// Owner luôn được coi là authorized. Member/Admin CHỈ authorized nếu Owner đã
    /// cấp tường minh qua Repository Manager (RPC add_key_repo → result.repos).
    /// Không xét field repo_url đơn lẻ để tránh rò rỉ quyền cho key không được cấp.
    var isRepoV2Authorized: Bool {
        let defaults = UserDefaults.standard
        let role = (defaults.string(forKey: "shinn.license.role") ?? "").lowercased()
        if role == "owner" { return true }

        let target = AppInfo.repoV2URL.absoluteString
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .lowercased()

        // A member key can never keep Repo V2 open after its server-provided
        // expiry time. V1 remains available even when V2 is locked.
        if let expiry = defaults.object(forKey: "shinn.license.expires") as? Double,
           expiry > 0,
           Date(timeIntervalSince1970: expiry) <= Date() {
            return false
        }

        // Primary path: Owner explicitly granted Repo V2 through add_key_repo.
        if let data = defaults.data(forKey: "shinn.license.grantedRepos"),
           let list = try? JSONDecoder().decode([KeyRepoItem].self, from: data),
           list.contains(where: {
               $0.url.trimmingCharacters(in: .whitespacesAndNewlines).lowercased() == target
           }) {
            return true
        }

        // Compatibility path for V2 keys: some server responses identify the
        // authorized repository through repo_url instead of repos[]. Keep Repo V1
        // untouched; only an explicit V2 URL can enable V2 here.
        let activeRepo = (defaults.string(forKey: "shinn.license.repo") ?? "")
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .lowercased()
        let repoLocked = defaults.bool(forKey: "shinn.license.repoLocked")
        return activeRepo == target && !repoLocked
    }

    /// Chuyển đổi giữa repo mặc định và Repo V2, rồi tải lại danh sách package tương ứng.
    func selectRepo(v2: Bool) async {
        if v2 && !isRepoV2Authorized { return }
        guard usingRepoV2 != v2 else { return }
        usingRepoV2 = v2
        manifest = nil
        loadState = .idle
        await refresh()
    }

    /// Loads one repository explicitly, even when it is already selected.
    /// Patch Center uses this instead of relying on selectRepo's state guard,
    /// so the V1 and V2 arrays can never accidentally share the same manifest.
    func loadPackages(forV2 v2: Bool) async -> [RepoPackage] {
        if v2 && !isRepoV2Authorized { return [] }
        let previous = usingRepoV2
        usingRepoV2 = v2
        manifest = nil
        loadState = .idle
        await refresh()
        let result = packages

        if previous != v2 {
            usingRepoV2 = previous
            manifest = nil
            loadState = .idle
            await refresh()
        }
        return result
    }

    private var documentsURL: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }

    // Manifest cache tách riêng cho từng repo.
    private var cacheURL: URL {
        let dir = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0]
        return dir.appendingPathComponent(usingRepoV2 ? "repo_v2.json" : "repo_default.json")
    }

    // File .3105 tách riêng theo repo để không bao giờ lấy nhầm file cũ
    // của Repo mặc định khi đang dùng Repo V2.
    private var repoFilesDirectory: URL {
        let name = usingRepoV2 ? ".ShinnRepoV2" : ".ShinnRepoDefault"
        let dir = documentsURL.appendingPathComponent(name, isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir
    }
    private var backupDirectory: URL {
        documentsURL.appendingPathComponent(".ShinnBackups", isDirectory: true)
    }

    var packages: [RepoPackage] {
        // Repo V2 is private: without an Owner-authorized key, do not expose
        // its manifest/package list at all. Repo V1 remains unchanged.
        if usingRepoV2 && !isRepoV2Authorized { return [] }
        return manifest?.packages ?? []
    }

    var categories: [CategoryInfo] {
        var order: [String] = []
        var counts: [String: Int] = [:]
        for p in packages {
            let category = p.category ?? "Other"
            if counts[category] == nil { order.append(category) }
            counts[category, default: 0] += 1
        }
        return order.map { CategoryInfo(name: $0, count: counts[$0] ?? 0) }
    }

    func bootstrap(autoRefresh: Bool) async {
        if didBootstrap { return }
        didBootstrap = true
        loadRecentPatchIDs()
        loadDownloadHistory()
        loadPatchUsageHistory()
        loadPathOwners()
        loadCache()
        if manifest == nil || autoRefresh { await refresh() }
        await restoreAfterMultitaskingKillIfNeeded()
    }

    private func loadRecentPatchIDs() {
        recentPatchIDs = UserDefaults.standard.stringArray(forKey: recentPatchIDsKey) ?? []
    }

    private func loadDownloadHistory() {
        guard let data = UserDefaults.standard.data(forKey: downloadHistoryKey),
              let items = try? JSONDecoder().decode([PatchDownloadHistoryItem].self, from: data) else {
            downloadHistory = []
            return
        }
        downloadHistory = items.sorted { $0.downloadedAt > $1.downloadedAt }
    }

    private func loadPatchUsageHistory() {
        guard let data = UserDefaults.standard.data(forKey: patchUsageHistoryKey),
              let items = try? JSONDecoder().decode([PatchUsageHistoryItem].self, from: data) else {
            patchUsageHistory = []
            return
        }
        patchUsageHistory = items.sorted { $0.usedAt > $1.usedAt }
    }

    private func savePatchUsageHistory() {
        guard let data = try? JSONEncoder().encode(patchUsageHistory) else { return }
        UserDefaults.standard.set(data, forKey: patchUsageHistoryKey)
    }

    func recordPatchUsage(_ pkg: RepoPackage, action: String, success: Bool) {
        patchUsageHistory.insert(
            PatchUsageHistoryItem(
                packageID: pkg.id,
                name: pkg.name,
                version: pkg.version,
                repo: usingRepoV2 ? "Repo V2" : "Repo V1",
                action: action,
                success: success
            ),
            at: 0
        )
        if patchUsageHistory.count > 200 {
            patchUsageHistory = Array(patchUsageHistory.prefix(200))
        }
        savePatchUsageHistory()
    }

    func clearPatchUsageHistory() {
        patchUsageHistory.removeAll()
        UserDefaults.standard.removeObject(forKey: patchUsageHistoryKey)
    }

    private func saveDownloadHistory() {
        guard let data = try? JSONEncoder().encode(downloadHistory) else { return }
        UserDefaults.standard.set(data, forKey: downloadHistoryKey)
    }

    private func recordDownload(_ pkg: RepoPackage) {
        downloadHistory.removeAll { $0.packageID == pkg.id && $0.repo == (usingRepoV2 ? "Repo V2" : "Repo V1") }
        downloadHistory.insert(
            PatchDownloadHistoryItem(
                packageID: pkg.id,
                name: pkg.name,
                version: pkg.version,
                repo: usingRepoV2 ? "Repo V2" : "Repo V1",
                size: pkg.size
            ),
            at: 0
        )
        if downloadHistory.count > 100 {
            downloadHistory = Array(downloadHistory.prefix(100))
        }
        saveDownloadHistory()
    }

    func clearDownloadHistory() {
        downloadHistory.removeAll()
        UserDefaults.standard.removeObject(forKey: downloadHistoryKey)
    }

    private func saveRecentPatchIDs() {
        UserDefaults.standard.set(recentPatchIDs, forKey: recentPatchIDsKey)
    }

    private func markRecent(_ pkg: RepoPackage) {
        recentPatchIDs.removeAll { $0 == pkg.id }
        recentPatchIDs.insert(pkg.id, at: 0)
        if recentPatchIDs.count > 8 { recentPatchIDs = Array(recentPatchIDs.prefix(8)) }
        saveRecentPatchIDs()
    }

    var recentPackages: [RepoPackage] {
        recentPatchIDs.compactMap { id in packages.first(where: { $0.id == id }) }
    }

    private func loadCache() {
        guard let data = try? Data(contentsOf: cacheURL),
              let decoded = try? JSONDecoder().decode(RepoManifest.self, from: data) else { return }
        manifest = decoded
        loadState = .loaded
    }

    func refresh() async {
        if usingRepoV2 && !isRepoV2Authorized {
            manifest = nil
            loadState = .failed
            return
        }
        // Repo V1 is public and fixed. A V2/custom repo lock must never hide V1.
        loadState = .loading
        do {
            let url = usingRepoV2 ? AppInfo.repoV2URL : RepoStore.activeRepoURL()
            var request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 20)
            request.setValue("no-cache", forHTTPHeaderField: "Cache-Control")
            let (data, response) = try await URLSession.shared.data(for: request)
            if let http = response as? HTTPURLResponse, !(200..<300).contains(http.statusCode) {
                throw DLError.http(http.statusCode)
            }
            let decoded = try JSONDecoder().decode(RepoManifest.self, from: data)
            manifest = decoded
            try? data.write(to: cacheURL, options: .atomic)
            loadState = .loaded
        } catch {
            if manifest == nil { loadState = .failed } else { loadState = .loaded }
        }
    }

    private func destination(for pkg: RepoPackage) -> URL? {
        guard let url = URL(string: pkg.download) else { return nil }
        let original = url.lastPathComponent
        guard !original.isEmpty else { return nil }

        // Không dùng chỉ lastPathComponent: hai repo có thể có cùng tên .3105
        // nhưng nội dung khác nhau. ID + tên file giữ nguyên dữ liệu patch,
        // chỉ thay đổi nơi lưu cache.
        let safeID = pkg.id.unicodeScalars.map {
            ($0.isASCII && (CharacterSet.alphanumerics.contains($0) || $0 == "-" || $0 == "_")) ? String($0) : "_"
        }.joined()
        return repoFilesDirectory.appendingPathComponent(safeID + "__" + original)
    }

    func existingFile(for pkg: RepoPackage) -> URL? {
        guard let destination = destination(for: pkg) else { return nil }
        return FileManager.default.fileExists(atPath: destination.path) ? destination : nil
    }

    func state(for pkg: RepoPackage) -> DownloadState {
        if let state = downloads[pkg.id] { return state }
        if let file = existingFile(for: pkg) { return .done(file) }
        return .idle
    }

    func download(_ pkg: RepoPackage) async {
        if usingRepoV2, !isRepoV2Authorized {
            downloads[pkg.id] = .failed(.notAuthorized(
                "Key của bạn chưa được kích hoạt cho ShinnCheat Repo V2. Liên hệ Owner ShinnThieuu để kích hoạt key."
            ))
            return
        }
        guard let url = URL(string: pkg.download), let destination = destination(for: pkg) else {
            downloads[pkg.id] = .failed(.badURL)
            return
        }
        downloads[pkg.id] = .downloading
        do {
            let (temporaryURL, response) = try await URLSession.shared.download(from: url)
            if let http = response as? HTTPURLResponse, !(200..<300).contains(http.statusCode) {
                throw DLError.http(http.statusCode)
            }
            if let expected = pkg.sha256?.trimmingCharacters(in: .whitespacesAndNewlines).lowercased(), !expected.isEmpty {
                let actual = try await Task.detached(priority: .utility) { try sha256Hex(of: temporaryURL) }.value
                if actual.lowercased() != expected {
                    try? FileManager.default.removeItem(at: temporaryURL)
                    throw DLError.hashMismatch
                }
            }
            if FileManager.default.fileExists(atPath: destination.path) {
                try FileManager.default.removeItem(at: destination)
            }
            try FileManager.default.moveItem(at: temporaryURL, to: destination)
            downloads[pkg.id] = .done(destination)
            recordDownload(pkg)
        } catch let error as DLError {
            downloads[pkg.id] = .failed(error)
        } catch {
            downloads[pkg.id] = .failed(.other(error.localizedDescription))
        }
    }

    func downloadAll() async {
        let items = packages
        guard !items.isEmpty else { return }
        if usingRepoV2 && !isRepoV2Authorized { return }
        bulkDownloadTotal = items.count
        bulkDownloadDone = 0
        bulkDownloading = true
        defer { bulkDownloading = false }
        for pkg in items {
            await download(pkg)
            bulkDownloadDone += 1
        }
    }

    private func decodedPatchProject(for pkg: RepoPackage) throws -> PatchProject {
        guard let archive = existingFile(for: pkg) else { throw PatchError.sourceNotFound }
        let data = try Data(contentsOf: archive, options: .mappedIfSafe)
        let summary = try PatchPackageCodec.inspect(data)
        guard !summary.isPasswordProtected else {
            throw PatchError.other("Gói .3105 này được bảo vệ bằng mật khẩu.")
        }
        return try PatchPackageCodec.decode(data, password: nil).project
    }

    /// path (lowercased) -> nhiều package id đang dùng cùng đường dẫn.
    ///
    /// Trước đây app dùng [String: String], nên mỗi path chỉ có thể thuộc
    /// một patch. Cấu trúc mới là [String: [String]] để nhiều patch có thể
    /// cùng trỏ tới một path/URL.
    @Published private(set) var pathOwners: [String: [String]] = [:]
    @Published var lastApplyMessage: String?

    private let pathOwnersKey = "shinn.patch.pathOwners"

    private func loadPathOwners() {
        guard let data = UserDefaults.standard.data(forKey: pathOwnersKey) else { return }

        // Format mới: path -> [packageID]
        if let map = try? JSONDecoder().decode([String: [String]].self, from: data) {
            pathOwners = map
            return
        }

        // Migration format cũ: path -> packageID
        if let oldMap = try? JSONDecoder().decode([String: String].self, from: data) {
            pathOwners = oldMap.reduce(into: [String: [String]]()) { result, item in
                result[item.key] = [item.value]
            }
            savePathOwners()
        }
    }

    private func savePathOwners() {
        if let data = try? JSONEncoder().encode(pathOwners) {
            UserDefaults.standard.set(data, forKey: pathOwnersKey)
        }
    }

    /// Lấy các đường dẫn đích từ gói (Mirror + patchPath metadata)
    private func destinationPaths(for pkg: RepoPackage, project: Any) -> [String] {
        var paths: [String] = []
        if let p = pkg.patchPath?.trimmingCharacters(in: .whitespacesAndNewlines), !p.isEmpty {
            paths.append(p)
        }
        paths.append(contentsOf: mirrorCollectPaths(project))
        // Chuẩn hoá
        return Array(Set(paths.map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }.filter { !$0.isEmpty }))
    }

    private func mirrorCollectPaths(_ value: Any, depth: Int = 0) -> [String] {
        guard depth < 5 else { return [] }
        var found: [String] = []
        let mirror = Mirror(reflecting: value)
        for child in mirror.children {
            let label = (child.label ?? "").lowercased()
            if let s = child.value as? String {
                let looksPath = s.contains("/") || s.hasSuffix(".bytes") || s.hasSuffix(".bundle")
                    || label.contains("path") || label.contains("dest") || label.contains("target")
                if looksPath && s.count > 3 && s.count < 400 {
                    found.append(s)
                }
            } else {
                let sub = Mirror(reflecting: child.value)
                if !sub.children.isEmpty {
                    found.append(contentsOf: mirrorCollectPaths(child.value, depth: depth + 1))
                } else if let arr = child.value as? [Any] {
                    for el in arr { found.append(contentsOf: mirrorCollectPaths(el, depth: depth + 1)) }
                }
            }
        }
        return found
    }

    private func ensureFreshFile(_ pkg: RepoPackage) async -> URL? {
        guard let file = existingFile(for: pkg) else {
            await download(pkg)
            return existingFile(for: pkg)
        }

        // Nếu manifest có SHA256, xác minh file trước khi decode/apply.
        // File cũ/sai repo sẽ bị xoá và tải lại đúng package.
        if let expected = pkg.sha256?.trimmingCharacters(in: .whitespacesAndNewlines).lowercased(), !expected.isEmpty {
            do {
                let actual = try sha256Hex(of: file).lowercased()
                if actual != expected {
                    try? FileManager.default.removeItem(at: file)
                    downloads[pkg.id] = .idle
                    await download(pkg)
                    return existingFile(for: pkg)
                }
            } catch {
                try? FileManager.default.removeItem(at: file)
                downloads[pkg.id] = .idle
                await download(pkg)
                return existingFile(for: pkg)
            }
        }
        return file
    }

    private func normalizedPatchPath(_ path: String) -> String {
        var value = path.trimmingCharacters(in: .whitespacesAndNewlines)
            .replacingOccurrences(of: "\\", with: "/")
        while value.contains("//") { value = value.replacingOccurrences(of: "//", with: "/") }
        while value.hasPrefix("./") { value.removeFirst(2) }
        return value.lowercased()
    }

    /// Dọn các package ID cũ không còn active. Hàm này chỉ làm sạch metadata;
    /// nó KHÔNG chặn patch mới khi path đã có patch khác.
    private func cleanupPathOwners() {
        var changed = false
        for (path, ids) in pathOwners {
            let active = ids.filter { id in
                if let state = patchStates[id], case .applied = state { return true }
                return false
            }
            let unique = Array(Set(active))
            if unique.isEmpty {
                pathOwners.removeValue(forKey: path)
                changed = true
            } else if unique.count != ids.count || Set(ids) != Set(unique) {
                pathOwners[path] = unique
                changed = true
            }
        }
        if changed { savePathOwners() }
    }

    /// Không còn giới hạn 1 patch / 1 path.
    /// Hàm này chỉ kiểm tra path hợp lệ và loại trùng path bên trong cùng package.
    private func preflight(_ pkg: RepoPackage, paths: [String]) -> String? {
        var seen = Set<String>()
        for path in paths {
            let key = normalizedPatchPath(path)
            guard !key.isEmpty else { continue }
            _ = seen.insert(key)
        }
        return nil
    }

    func apply(_ pkg: RepoPackage, openGame: Bool = true) async {
        patchStates[pkg.id] = .applying
        lastApplyMessage = nil
        do {
            if pathOwners.isEmpty { loadPathOwners() }

            guard let archive = await ensureFreshFile(pkg) else {
                throw PatchError.sourceNotFound
            }

            let data = try Data(contentsOf: archive, options: .mappedIfSafe)
            let summary = try PatchPackageCodec.inspect(data)
            guard !summary.isPasswordProtected else {
                throw PatchError.other("Gói .3105 này được bảo vệ bằng mật khẩu.")
            }
            let project = try PatchPackageCodec.decode(data, password: nil).project
            print("[apply] pkg=\(pkg.id) file=\(archive.path) bytes=\(data.count) project=\(project.id)")
            let paths = destinationPaths(for: pkg, project: project)

            // Chỉ kiểm tra tính hợp lệ. Nhiều package được phép dùng cùng path.
            if let conflict = preflight(pkg, paths: paths) {
                throw PatchError.other(conflict)
            }

            _ = try DevicePatchService.apply(project: project)

            // Ghi nhận package vào danh sách owner của từng path thay vì ghi đè
            // package trước đó. Vì vậy path A có thể đồng thời có patch 1, 2, 3...
            for p in paths {
                let key = normalizedPatchPath(p)
                guard !key.isEmpty else { continue }
                var ids = pathOwners[key] ?? []
                if !ids.contains(pkg.id) { ids.append(pkg.id) }
                pathOwners[key] = ids
            }
            patchStates[pkg.id] = .applied
            cleanupPathOwners()
            savePathOwners()
            persistAppliedIDs()
            markRecent(pkg)
            recordPatchUsage(pkg, action: "Applied", success: true)
            lastApplyMessage = paths.isEmpty
                ? "Đã áp dụng \(pkg.name). Đang mở game…"
                : "Đã áp dụng \(pkg.name) với \(paths.count) đường dẫn. Đang mở game…"
            if openGame {
                Task { @MainActor in
                    try? await Task.sleep(nanoseconds: 2_000_000_000)
                    self.openTargetApp(for: pkg)
                }
            }
        } catch {
            let ns = error as NSError
            // In chi tiết ra Xcode Console để chẩn đoán lỗi từ DevicePatchService (module "105"):
            // domain/code cho biết chính xác case nào trong PatchError của module đó bị throw.
            print("[apply] FAILED pkg=\(pkg.id) domain=\(ns.domain) code=\(ns.code) userInfo=\(ns.userInfo) raw=\(error)")
            let detail = "\(error.localizedDescription) [\(ns.domain)#\(ns.code)]"
            patchStates[pkg.id] = .failed(detail)
            recordPatchUsage(pkg, action: "Apply failed", success: false)
            lastApplyMessage = detail
        }
    }

    func restore(_ pkg: RepoPackage) async {
        patchStates[pkg.id] = .restoring
        lastApplyMessage = nil
        do {
            let project = try decodedPatchProject(for: pkg)
            guard let receipt = DevicePatchService.latestReceipt(projectID: project.id) else {
                throw PatchError.restoreFailed
            }
            try DevicePatchService.restore(receipt: receipt)
            // Chỉ giải phóng package này; các patch khác cùng path vẫn được giữ.
            for path in Array(pathOwners.keys) {
                var ids = pathOwners[path] ?? []
                ids.removeAll { $0 == pkg.id }
                if ids.isEmpty {
                    pathOwners.removeValue(forKey: path)
                } else {
                    pathOwners[path] = ids
                }
            }
            savePathOwners()
            patchStates[pkg.id] = .restored
            recordPatchUsage(pkg, action: "Restored", success: true)
            persistAppliedIDs()
            lastApplyMessage = "Đã gỡ patch: \(pkg.name)"
        } catch {
            let ns = error as NSError
            print("[restore] FAILED pkg=\(pkg.id) domain=\(ns.domain) code=\(ns.code) userInfo=\(ns.userInfo) raw=\(error)")
            let detail = "\(error.localizedDescription) [\(ns.domain)#\(ns.code)]"
            patchStates[pkg.id] = .failed(detail)
            recordPatchUsage(pkg, action: "Restore failed", success: false)
            lastApplyMessage = detail
        }
    }

    /// Áp dụng nhiều package. Các package được phép trùng path; không còn
    /// cơ chế reserved path để từ chối patch thứ hai.
    func applyMultiple(_ pkgs: [RepoPackage]) async -> (ok: [String], fail: [(String, String)]) {
        var ok: [String] = []
        var fail: [(String, String)] = []
        var prepared: [(RepoPackage, [String])] = []

        // Preflight toàn bộ danh sách trước khi apply để phát hiện lỗi file/format
        // trước khi bắt đầu apply. Trùng path không còn là lỗi.
        for pkg in pkgs {
            do {
                guard let archive = await ensureFreshFile(pkg) else { throw PatchError.sourceNotFound }
                let data = try Data(contentsOf: archive, options: .mappedIfSafe)
                let summary = try PatchPackageCodec.inspect(data)
                guard !summary.isPasswordProtected else {
                    throw PatchError.other("Gói .3105 này được bảo vệ bằng mật khẩu.")
                }
                let project = try PatchPackageCodec.decode(data, password: nil).project
                let paths = destinationPaths(for: pkg, project: project)

                if let conflict = preflight(pkg, paths: paths) {
                    throw PatchError.other(conflict)
                }
                // Không kiểm tra trùng path giữa các package.
                // Nhiều patch có thể cùng dùng một URL/path.
                prepared.append((pkg, paths))
            } catch {
                fail.append((pkg.name, error.localizedDescription))
            }
        }

        // Chỉ apply các patch đã qua preflight.
        for (pkg, _) in prepared {
            await apply(pkg, openGame: false)
            if case .applied = patchStates[pkg.id] {
                ok.append(pkg.name)
            } else if case .failed(let m) = patchStates[pkg.id] {
                fail.append((pkg.name, m))
            } else {
                fail.append((pkg.name, "Không xác định được trạng thái patch."))
            }
        }

        if !ok.isEmpty, let first = pkgs.first(where: { ok.contains($0.name) }) {
            lastApplyMessage = fail.isEmpty
                ? "Đã áp dụng đồng thời \(ok.count) patch. Đang mở game…"
                : "Đã áp dụng \(ok.count) patch; \(fail.count) patch bị từ chối. Đang mở game…"
            Task { @MainActor in
                try? await Task.sleep(nanoseconds: 2_000_000_000)
                self.openTargetApp(for: first)
            }
        } else if !fail.isEmpty {
            lastApplyMessage = "Không có patch nào được kích hoạt. \(fail.count) patch bị từ chối do lỗi."
        }
        return (ok, fail)
    }

    private let appliedIDsKey = "shinn.patch.appliedIDs"
    private let pendingKillRestoreKey = "shinn.patch.pendingKillRestore"

    private func persistAppliedIDs() {
        let ids = patchStates.compactMap { id, state -> String? in
            if case .applied = state { return id }
            return nil
        }
        UserDefaults.standard.set(ids, forKey: appliedIDsKey)
    }

    /// App đang mở — lần sau không cần khôi phục vì chưa bị vuốt tắt.
    func markSessionAlive() {
        UserDefaults.standard.set(false, forKey: pendingKillRestoreKey)
    }

    /// App vào nền. Nếu user vuốt tắt đa nhiệm thì process bị kill
    /// (không có callback). Lần cold-launch sau sẽ khôi phục patch.
    func markSuspendedPendingKillRestore() {
        persistAppliedIDs()
        let hasApplied = patchStates.contains { _, state in
            if case .applied = state { return true }
            return false
        }
        UserDefaults.standard.set(hasApplied, forKey: pendingKillRestoreKey)
    }

    /// Khôi phục các patch đã bật ở phiên trước, sau khi app bị vuốt tắt đa nhiệm.
    func restoreAfterMultitaskingKillIfNeeded() async {
        let pending = UserDefaults.standard.bool(forKey: pendingKillRestoreKey)
        UserDefaults.standard.set(false, forKey: pendingKillRestoreKey)
        guard pending else { return }

        var ids = Set(UserDefaults.standard.stringArray(forKey: appliedIDsKey) ?? [])
        ids.formUnion(pathOwners.values.flatMap { $0 })
        let targets = packages.filter { ids.contains($0.id) }
        guard !targets.isEmpty else { return }
        for pkg in targets {
            await restore(pkg)
        }
    }

    /// Restore tất cả patch đang bật trong phiên hiện tại.
    func restoreAllAppliedPatches() async {
        let active = packages.filter {
            if case .applied = patchStates[$0.id] { return true }
            return false
        }
        guard !active.isEmpty else { return }
        for pkg in active {
            await restore(pkg)
        }
    }

    func patchState(for pkg: RepoPackage) -> PatchState {
        patchStates[pkg.id] ?? .idle
    }

    func openTargetApp(for pkg: RepoPackage) {
        openTargetApp(using: launchSchemes(for: pkg))
    }

    private func launchSchemes(for pkg: RepoPackage) -> [String] {
        var schemes: [String] = []
        if let raw = pkg.openURL?.trimmingCharacters(in: .whitespacesAndNewlines), !raw.isEmpty {
            schemes.append(raw)
        }

        let blob = [
            pkg.category,
            pkg.name,
            pkg.summary,
            pkg.description,
            pkg.tags?.joined(separator: " ")
        ]
        .compactMap { $0 }
        .joined(separator: " ")
        .lowercased()

        let isMax = blob.contains("free fire max") || blob.contains("ffmax") || blob.contains("ff max")
        let isFF = blob.contains("free fire") || blob.contains("ffth") || blob.contains("freefire")
            || blob.contains("garena") || blob.contains("ff ")
        let isLQM = blob.contains("liên quân") || blob.contains("lien quan") || blob.contains("aov")
            || blob.contains("kgvn")

        if isMax {
            schemes += ["freefiremax://", "com.dts.freefiremax://"]
        } else if isFF {
            schemes += ["freefire://", "com.dts.freefireth://"]
        } else if isLQM {
            schemes += ["com.garena.game.kgvn://"]
        } else {
            // App chủ yếu dùng cho Free Fire — fallback khi category chỉ là "Patch".
            schemes += ["freefire://", "com.dts.freefireth://", "freefiremax://"]
        }

        var seen = Set<String>()
        return schemes.filter { seen.insert($0).inserted }
    }

    private func openTargetApp(using schemes: [String], index: Int = 0) {
        guard index < schemes.count, let url = URL(string: schemes[index]) else {
            lastApplyMessage = "Patch đã áp dụng. Không mở được game — kiểm tra Open URL (freefire:// hoặc freefiremax://)."
            return
        }
        UIApplication.shared.open(url, options: [:]) { success in
            DispatchQueue.main.async {
                if success {
                    self.lastApplyMessage = "Patch đã áp dụng. Đang mở game…"
                } else {
                    self.openTargetApp(using: schemes, index: index + 1)
                }
            }
        }
    }
}

func categoryIcon(_ name: String) -> String {
    switch name {
    case "AIM": return "scope"
    case "ESP": return "eye.fill"
    case "Free Fire": return "flame.fill"
    case "Free Fire Max": return "sparkles"
    case "MOD SKIN": return "paintbrush.fill"
    case "Liên Quân Mobile": return "gamecontroller.fill"
    default: return "shippingbox.fill"
    }
} // ===== SecondaryViews =====
struct LemonTargetApp: Identifiable, Hashable {
    let id: String
    let name: String
    let bundleID: String
    let iconAssetName: String
}

enum FFH4XFeatureCategory: String, CaseIterable, Identifiable, Hashable {
    case aim, chams, modSkin
    var id: String { rawValue }
    var title: String {
        switch self { case .aim: return "Aim"; case .chams: return "Chams"; case .modSkin: return "Mod Skin" }
    }
    var subtitle: String {
        switch self { case .aim: return "Hỗ trợ kéo tâm"; case .chams: return "Định vị nhìn xuyên tường"; case .modSkin: return "Mod skin" }
    }
    var icon: String {
        switch self { case .aim: return "scope"; case .chams: return "eye.fill"; case .modSkin: return "tshirt.fill" }
    }
    var tint: Color {
        switch self { case .aim: return .blue; case .chams: return .purple; case .modSkin: return .orange }
    }
}

struct ProjectAppIcon: View {
    let assetName: String
    let size: CGFloat
    var body: some View {
        Image(assetName).resizable().scaledToFill()
            .frame(width: size, height: size)
            .clipShape(RoundedRectangle(cornerRadius: size * 0.23, style: .continuous))
    }
}

struct InstalledAppIcon: View {
    let bundleID: String
    let size: CGFloat
    @State private var image: UIImage?
    var body: some View {
        Group {
            if let image { Image(uiImage: image).resizable().scaledToFill() }
            else { Image(systemName: "app.fill").font(.system(size: size * 0.38, weight: .semibold)).frame(maxWidth: .infinity, maxHeight: .infinity) }
        }
        .frame(width: size, height: size)
        .clipShape(RoundedRectangle(cornerRadius: size * 0.23, style: .continuous))
        .task(id: bundleID) {
            image = await Task.detached(priority: .userInitiated) { iconForBundleID(bundleID) }.value
        }
    }
}

// ===== UserRole / Session =====
enum UserRole: String, CaseIterable, Identifiable {
    case owner, admin, member
    var id: String { rawValue }
    var title: String {
        switch self { case .owner: return "Owner"; case .admin: return "Admin"; case .member: return "Member" }
    }
    var icon: String {
        switch self { case .owner: return "crown.fill"; case .admin: return "checkmark.shield.fill"; case .member: return "person.fill" }
    }
    /// Owner đỏ · Admin xanh dương · Member xanh lá
    var badgeColor: Color {
        switch self {
        case .owner: return .red
        case .admin: return .blue
        case .member: return .green
        }
    }
    var needsPassword: Bool { self != .member }
}

enum PatchFolder: String, CaseIterable, Identifiable {
    case aim, esp, menu, gunLoc, other
    var id: String { rawValue }
    var title: String {
        switch self {
        case .aim: return "AIM"
        case .esp: return "ESP / Chams"
        case .menu: return "Menu"
        case .gunLoc: return "Định vị súng"
        case .other: return "Khác"
        }
    }
    var icon: String {
        switch self {
        case .aim: return "scope"
        case .esp: return "eye.fill"
        case .menu: return "list.bullet.rectangle"
        case .gunLoc: return "location.viewfinder"
        case .other: return "shippingbox.fill"
        }
    }
    static func folder(for pkg: RepoPackage) -> PatchFolder {
        let c = (pkg.category ?? "").lowercased()
        let n = pkg.name.lowercased()
        let t = (pkg.tags ?? []).joined(separator: " ").lowercased()
        let blob = c + " " + n + " " + t
        if blob.contains("aim") || blob.contains("drag") || blob.contains("neck") || blob.contains("chest") || blob.contains("body") || blob.contains("magic") {
            return .aim
        }
        if blob.contains("esp") || blob.contains("chams") || blob.contains("wall") {
            return .esp
        }
        if blob.contains("menu") || blob.contains("mod menu") {
            return .menu
        }
        if blob.contains("định vị") || blob.contains("dinh vi") || blob.contains("gun") || blob.contains("súng") || blob.contains("sung") || blob.contains("weapon") {
            return .gunLoc
        }
        // category exact
        if c == "aim" { return .aim }
        if c == "esp" { return .esp }
        return .other
    }
}

final class Session: ObservableObject {
    @Published var role: UserRole?
    private static let passwordHash = "a43535812161a1aec35c04f0b6ea63bb4880d581f3d15df9ba7e68befe6b472e"
    func verify(_ input: String) -> Bool {
        let digest = SHA256.hash(data: Data(input.utf8))
        let hex = digest.map { String(format: "%02x", $0) }.joined()
        return hex == Session.passwordHash
    }
}

// ===== Keychain =====
enum KeychainKeyStore {
    private static let service = "shinn.license.biometric"
    private static let account = "activation-key"

    static func save(_ key: String) {
        let data = Data(key.utf8)
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]
        SecItemDelete(query as CFDictionary)
        var add = query
        add[kSecValueData as String] = data
        add[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlockedThisDeviceOnly
        SecItemAdd(add as CFDictionary, nil)
    }

    static func load() -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var out: AnyObject?
        let status = SecItemCopyMatching(query as CFDictionary, &out)
        guard status == errSecSuccess, let data = out as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }

    static func clear() {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]
        SecItemDelete(query as CFDictionary)
    }
}

extension Notification.Name {
    static let shinnKeyNotice = Notification.Name("shinnKeyNotice")
    static let shinnKeyActivatedLED = Notification.Name("shinnKeyActivatedLED")
}

// ===== Supabase =====
enum SupabaseConfig {
    static let projectURL = AppInfo.safeURL("https://efhqbzdnrtifqjqlqseb.supabase.co")
    static let anonKey = "sb_publishable_jnycTCgXRMrluvwJORd_4g_B7ojwi9R"
    /// Owner labels nhận diện trong app
    static let ownerLabels: [String] = ["NgVuMinhHieuu", "ShinnThieuu"]

    /// Dùng string URL trực tiếp — KHÔNG dùng appendingPathComponent (sẽ encode / thành %2F → path invalid)
    static func rpc(_ name: String) -> URL {
        AppInfo.safeURL("https://efhqbzdnrtifqjqlqseb.supabase.co/rest/v1/rpc/\(name)")
    }

    static var activateKeyURL: URL { rpc("activate_key") }
    static var createKeyURL: URL { rpc("create_shinn_key") }
    static var listKeysURL: URL { rpc("list_shinn_keys") }
    static var deleteKeyURL: URL { rpc("delete_shinn_key") }
    static var deleteAllKeysURL: URL { rpc("delete_all_shinn_keys") }
    static var addKeyRepoURL: URL { rpc("add_key_repo") }
}

struct KeyRepoItem: Codable, Hashable, Identifiable {
    var id: String { name + "|" + url }
    var name: String
    var url: String
    var locked: Bool?
}

struct ActivateKeyResponse: Decodable {
    let ok: Bool
    let error: String?
    let role: String?
    let key: String?
    let expires_at: String?
    let label: String?
    let repo_url: String?
    let repo_locked: Bool?
    let repos: [KeyRepoItem]?
}

@MainActor
final class LicenseManager: ObservableObject {
    @Published var isActivated: Bool
    @Published var isBusy = false
    @Published var lastError: String?
    @Published var boundRole: String?
    @Published var expiresAt: Date?
    @Published var savedLicenseKey: String
    @Published var holderName: String

    private let activatedKey = "shinn.license.activated"
    private let roleKey = "shinn.license.role"
    private let deviceKey = "shinn.license.device_id"
    private let savedKey = "shinn.license.key"
    private let expireKey = "shinn.license.expires"

    init() {
        let defaults = UserDefaults.standard
        boundRole = defaults.string(forKey: roleKey)
        savedLicenseKey = defaults.string(forKey: savedKey) ?? ""
        holderName = defaults.string(forKey: "shinn.license.holder") ?? ""
        if defaults.object(forKey: expireKey) != nil {
            expiresAt = Date(timeIntervalSince1970: defaults.double(forKey: expireKey))
        }
        isActivated = false
    }

    var deviceID: String {
        let defaults = UserDefaults.standard
        if let existing = defaults.string(forKey: deviceKey), !existing.isEmpty {
            return existing
        }
        let generated = UIDevice.current.identifierForVendor?.uuidString ?? UUID().uuidString
        defaults.set(generated, forKey: deviceKey)
        return generated
    }

    private static func parseExpiry(_ raw: String) -> Date? {
        let f1 = ISO8601DateFormatter()
        f1.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        if let d = f1.date(from: raw) { return d }
        let f2 = ISO8601DateFormatter()
        f2.formatOptions = [.withInternetDateTime]
        if let d = f2.date(from: raw) { return d }
        return ISO8601DateFormatter().date(from: raw)
    }

    func activate(key raw: String, language: ShinnLanguage) async -> Bool {
        let key = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        lastError = nil
        guard !key.isEmpty else {
            lastError = "Enter an activation key."
            return false
        }
        isBusy = true
        defer { isBusy = false }

        do {
            let result = try await callActivate(key: key)
            if result.ok {
                UserDefaults.standard.set(true, forKey: activatedKey)
                UserDefaults.standard.set(key, forKey: savedKey)
                savedLicenseKey = key
                KeychainKeyStore.save(key)
                if let label = result.label {
                    holderName = label
                    UserDefaults.standard.set(label, forKey: "shinn.license.holder")
                }
                let repo = (result.repo_url ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
                UserDefaults.standard.set(repo, forKey: "shinn.license.repo")
                UserDefaults.standard.set(result.repo_locked ?? false, forKey: "shinn.license.repoLocked")

                var list: [KeyRepoItem] = [
                    KeyRepoItem(name: "Repo ShinnCheat", url: AppInfo.defaultRepoURL.absoluteString, locked: false)
                ]
                if let extra = result.repos {
                    for r in extra where !r.url.isEmpty {
                        if !list.contains(where: { $0.url == r.url }) {
                            list.append(r)
                        }
                    }
                }
                if let one = result.repo_url?.trimmingCharacters(in: .whitespacesAndNewlines),
                   !one.isEmpty,
                   !list.contains(where: { $0.url.trimmingCharacters(in: .whitespacesAndNewlines) == one }) {
                    let isV2 = one.lowercased() == AppInfo.repoV2URL.absoluteString.lowercased()
                    list.append(KeyRepoItem(name: isV2 ? AppInfo.repoV2Name : "Custom", url: one, locked: result.repo_locked))
                }
                if let data = try? JSONEncoder().encode(list) {
                    UserDefaults.standard.set(data, forKey: "shinn.license.repos")
                }

                // Giữ nguyên toàn bộ quyền Repo V1 và Repo V2.
                // V2 có thể được trả về qua repos[] hoặc repo_url bởi server.
                // Chỉ công nhận đúng URL Repo V2; không biến một repo tùy ý thành Premium.
                let v2URL = AppInfo.repoV2URL.absoluteString.lowercased()
                var grantedRepos: [KeyRepoItem] = result.repos?.filter { !$0.url.isEmpty } ?? []
                if let one = result.repo_url?.trimmingCharacters(in: .whitespacesAndNewlines),
                   !one.isEmpty,
                   one.lowercased() == v2URL,
                   !(result.repo_locked ?? false),
                   !grantedRepos.contains(where: { $0.url.trimmingCharacters(in: .whitespacesAndNewlines).lowercased() == v2URL }) {
                    grantedRepos.append(KeyRepoItem(name: AppInfo.repoV2Name, url: AppInfo.repoV2URL.absoluteString, locked: false))
                }
                if let data = try? JSONEncoder().encode(grantedRepos) {
                    UserDefaults.standard.set(data, forKey: "shinn.license.grantedRepos")
                } else {
                    UserDefaults.standard.removeObject(forKey: "shinn.license.grantedRepos")
                }

                if let role = result.role, !role.isEmpty {
                    UserDefaults.standard.set(role, forKey: roleKey)
                    boundRole = role
                }
                if let exp = result.expires_at, let date = Self.parseExpiry(exp) {
                    expiresAt = date
                    UserDefaults.standard.set(date.timeIntervalSince1970, forKey: expireKey)
                } else {
                    expiresAt = nil
                    UserDefaults.standard.removeObject(forKey: expireKey)
                }
                isActivated = true
                return true
            }
            lastError = mappedError(result.error)
            return false
        } catch {
            let msg = error.localizedDescription
            if msg.contains("path") || msg.contains("invalid") {
                lastError = "Key server path invalid. Check Supabase RPC activate_key."
            } else {
                lastError = "Could not reach the key server: \(msg)"
            }
            return false
        }
    }

    func signOutLicense() {
        let defaults = UserDefaults.standard
        defaults.set(false, forKey: activatedKey)
        defaults.removeObject(forKey: roleKey)
        defaults.removeObject(forKey: savedKey)
        defaults.removeObject(forKey: expireKey)
        defaults.removeObject(forKey: "shinn.license.repo")
        defaults.removeObject(forKey: "shinn.license.repoLocked")
        defaults.removeObject(forKey: "shinn.license.repos")
        defaults.removeObject(forKey: "shinn.license.grantedRepos")
        isActivated = false
        boundRole = nil
        savedLicenseKey = ""
        expiresAt = nil
        holderName = ""
        defaults.removeObject(forKey: "shinn.license.holder")
    }

    func restoreIfValid(language: ShinnLanguage) async -> Bool {
        let key = savedLicenseKey.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !key.isEmpty else { return false }
        if let exp = expiresAt, exp < Date(), (boundRole ?? "").lowercased() != "owner" {
            signOutLicense()
            return false
        }
        return await activate(key: key, language: language)
    }

    private func mappedError(_ code: String?) -> String {
        switch code {
        case "invalid_key": return "Invalid key."
        case "used_on_other_device": return "This key is already used on another device."
        case "missing_key": return "Missing key."
        case "missing_device": return "Missing device id."
        default: return "Could not activate the key."
        }
    }

    private func callActivate(key: String) async throws -> ActivateKeyResponse {
        var request = URLRequest(url: SupabaseConfig.activateKeyURL)
        request.httpMethod = "POST"
        request.timeoutInterval = 20
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue(SupabaseConfig.anonKey, forHTTPHeaderField: "apikey")
        request.setValue("Bearer \(SupabaseConfig.anonKey)", forHTTPHeaderField: "Authorization")

        let body: [String: String] = [
            "p_key": key,
            "p_device_id": deviceID
        ]
        request.httpBody = try JSONSerialization.data(withJSONObject: body)

        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else {
            throw URLError(.badServerResponse)
        }
        print("[Supabase] url=\(request.url?.absoluteString ?? "nil")")
        print("[Supabase] status=\(http.statusCode)")
        print("[Supabase] body=\(String(data: data, encoding: .utf8) ?? "nil")")

        guard (200..<300).contains(http.statusCode) else {
            if http.statusCode == 401 || http.statusCode == 403 {
                throw URLError(.userAuthenticationRequired)
            }
            throw URLError(.badServerResponse)
        }
        return try JSONDecoder().decode(ActivateKeyResponse.self, from: data)
    }
}

// ===== AbuseGuard =====
@MainActor
final class AbuseGuard: ObservableObject {
    @Published var lockedUntil: Date?
    private let lockKey = "shinn.abuse.lock"
    private let keyFailsKey = "shinn.abuse.keyFails"
    private let passFailsKey = "shinn.abuse.passFails"
    private let patchTapsKey = "shinn.abuse.patchTaps"
    private let windowKey = "shinn.abuse.window"
    private let faceFailsKey = "shinn.abuse.faceFails"

    init() {
        let d = UserDefaults.standard
        if d.object(forKey: lockKey) != nil {
            let until = Date(timeIntervalSince1970: d.double(forKey: lockKey))
            lockedUntil = until > Date() ? until : nil
        }
    }

    var isLocked: Bool {
        if let until = lockedUntil, until > Date() { return true }
        return false
    }

    func remainText() -> String {
        guard let until = lockedUntil else { return "" }
        let s = max(0, Int(until.timeIntervalSinceNow))
        return String(format: "%d:%02d", s / 60, s % 60)
    }

    private func bump(_ key: String, limit: Int) {
        let d = UserDefaults.standard
        let window = d.double(forKey: windowKey)
        if Date().timeIntervalSince1970 - window > 600 {
            d.set(0, forKey: keyFailsKey)
            d.set(0, forKey: passFailsKey)
            d.set(0, forKey: patchTapsKey)
            d.set(Date().timeIntervalSince1970, forKey: windowKey)
        }
        let n = d.integer(forKey: key) + 1
        d.set(n, forKey: key)
        if n >= limit { lock() }
    }

    func keyFailed() { bump(keyFailsKey, limit: 5) }
    func passFailed() { bump(passFailsKey, limit: 5) }
    func patchToggled() { bump(patchTapsKey, limit: 15) }
    func keyOk() { UserDefaults.standard.set(0, forKey: keyFailsKey) }
    func passOk() { UserDefaults.standard.set(0, forKey: passFailsKey) }

    func faceFailed() -> Int {
        let d = UserDefaults.standard
        let n = d.integer(forKey: faceFailsKey) + 1
        d.set(n, forKey: faceFailsKey)
        return n
    }
    func faceOk() { UserDefaults.standard.set(0, forKey: faceFailsKey) }
    func faceFailCount() -> Int { UserDefaults.standard.integer(forKey: faceFailsKey) }

    private func lock() {
        let until = Date().addingTimeInterval(10 * 60)
        lockedUntil = until
        UserDefaults.standard.set(until.timeIntervalSince1970, forKey: lockKey)
        UserDefaults.standard.set(0, forKey: keyFailsKey)
        UserDefaults.standard.set(0, forKey: passFailsKey)
        UserDefaults.standard.set(0, forKey: patchTapsKey)
    }
} // ===== ContentView =====
struct ContentView: View {
    @Environment(\.scenePhase) private var scenePhase
    @StateObject var session = Session()
    @StateObject private var license = LicenseManager()
    @StateObject private var abuse = AbuseGuard()
    // Injected from App.swift — không tạo instance thứ hai
    @EnvironmentObject var settings: AppSettings
    @EnvironmentObject var store: RepoStore
    /// Store / navigation của 3105 (module sẵn trong project)
    @StateObject private var patchProjectStore = PatchProjectStore()
    private let containerStore = ContainerStore.self
    // AppTabNavigationState là struct (Equatable), không dùng @StateObject / environmentObject
    @State private var tabNav = AppTabNavigationState()
    @State private var path: [Route] = []
    @State private var selectedTab: Int = 0
    // Giữ state của tab Tệp để việc mở thư mục/app hoạt động đúng.
    // Không dùng .constant(...) vì FilesTabSwitcherView cần cập nhật session khi người dùng chạm.
    @State private var filesSession = FilesTabSession()
    @StateObject private var announcements = AnnouncementStore()
    @State private var showEdgeLED = false

    var body: some View {
        // Explicit type erasure fixes SwiftUI's "generic parameter R could not be inferred"
        // at the old Group/ViewBuilder root (ContentView.swift:1067).
        AnyView(
            Group {
                if abuse.isLocked {
                    AnyView(LockoutView(abuse: abuse))
                } else {
                    // Repo 1 is free. Premium key verification happens only inside Repo 2.
                    AnyView(mainTabView)
                }
            }
            .environmentObject(session)
            .environmentObject(license)
            .environmentObject(abuse)
            .environmentObject(patchProjectStore)
            .preferredColorScheme(settings.theme.colorScheme)
            .persistentSystemOverlays(.hidden)
            .task {
                // bootstrap repo nằm ở App.swift — tránh chạy 2 lần
                if !license.isActivated {
                    _ = await license.restoreIfValid(language: .en)
                }
                if license.isActivated,
                   let raw = license.boundRole,
                   let role = UserRole(rawValue: raw.lowercased()) {
                    session.role = role
                    // A valid V2 key opens Repo V2 automatically on app launch.
                    // If there is no V2 grant, the app stays on the free V1 repo.
                    if store.isRepoV2Authorized {
                        await store.selectRepo(v2: true)
                    }
                } else {
                    session.role = nil
                    // Skipping/signing out always returns the app to free Repo V1.
                    if store.usingRepoV2 {
                        await store.selectRepo(v2: false)
                    }
                }
            }
            .animation(.easeInOut(duration: 0.25), value: session.role)
            .animation(.easeInOut(duration: 0.25), value: license.isActivated)
            .onChange(of: scenePhase) { phase in
                switch phase {
                case .active:
                    store.markSessionAlive()
                    if license.isActivated {
                        Task { await announcements.poll() }
                    }
                case .background:
                    store.markSuspendedPendingKillRestore()
                default:
                    break
                }
            }
            .onAppear { ProMotion.enable() }
            .overlay {
                if showEdgeLED {
                    EdgeLEDRunView(accent: settings.accentColor)
                        .transition(.opacity)
                        .allowsHitTesting(false)
                }
            }
            .overlay(alignment: .top) {
                if let a = announcements.current {
                    VStack(alignment: .leading, spacing: 8) {
                        HStack {
                            Image(systemName: "bell.fill").foregroundStyle(ShinnRed)
                            Text(a.title).font(.headline.bold()).foregroundStyle(.white)
                            Spacer()
                            Button { announcements.dismiss() } label: {
                                Image(systemName: "xmark.circle.fill").foregroundStyle(.white.opacity(0.5))
                            }
                            .buttonStyle(.plain)
                        }
                        Text(a.body)
                            .font(.subheadline)
                            .foregroundStyle(.white.opacity(0.88))
                    }
                    .padding(14)
                    .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 16).stroke(ShinnRed.opacity(0.4), lineWidth: 1))
                    .padding(.horizontal, 16)
                    .padding(.top, 8)
                    .transition(.move(edge: .top).combined(with: .opacity))
                }
            }
            .onReceive(NotificationCenter.default.publisher(for: .shinnKeyActivatedLED)) { _ in
                showEdgeLED = true
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                    withAnimation(.easeOut(duration: 0.45)) { showEdgeLED = false }
                }
            }
            .task {
                if license.isActivated {
                    await announcements.poll()
                }
            }
            .onReceive(Timer.publish(every: 45, on: .main, in: .common).autoconnect()) { _ in
                guard license.isActivated else { return }
                Task { await announcements.poll() }
            }
        )
    }

    private var mainTabView: some View {
        Group {
            if license.isActivated {
                ShinnCompleteRootView()
            } else {
                ActivateKeyView()
            }
        }
        .environmentObject(store)
        .environmentObject(license)
        .environmentObject(session)
        .ignoresSafeArea(.keyboard, edges: .bottom)
    }

    @ToolbarContentBuilder
    private var backToHomeButton: some ToolbarContent {
        ToolbarItem(placement: .topBarLeading) {
            Button {
                selectedTab = 0
            } label: {
                Image(systemName: "house.fill")
            }
        }
    }

    @ViewBuilder
    private func shinnDestination(_ route: Route) -> some View {
        switch route {
        case .packages(let category):
            PackagesView(initialCategory: category)
        case .detail(let id):
            PackageDetailView(packageID: id)
        case .settings:
            ShinnSettingsHubView()
        case .about:
            ShinnAboutView()
        case .support:
            SupportView()
        case .aiChat:
            ShinnAIChatView()
        case .premiumRepo:
            PremiumRepoView()
        case .community:
            CommunityView()
        case .repositoryManager:
            RepositoryManagerView()
        case .patchBuilder:
            PatchBuilderView()
        case .patchProjects:
            // Chỉ Owner được mở khu vực tạo/quản lý project patch.
            if session.role == .owner {
                PatchProjectsView()
            } else {
                PatchOwnerOnlyView()
            }
        case .cleanup:
            PhoneCleanupView()
        }
    }
}

// ===== Shinn AI GitHub sync =====
struct ShinnAIManagedConfig: Codable {
    struct SpamPolicy: Codable {
        var maxMessages: Int
        var windowSeconds: Int
        var lockSeconds: Int
    }

    struct Command: Codable, Identifiable, Hashable {
        var id: String { command }
        var command: String
        var aliases: [String]
        var answer: String
        var answerEN: String?
        var imageURLs: [String]

        init(command: String, aliases: [String] = [], answer: String, answerEN: String? = nil, imageURLs: [String] = []) {
            self.command = command
            self.aliases = aliases
            self.answer = answer
            self.answerEN = answerEN
            self.imageURLs = imageURLs
        }

        func answer(for language: ShinnLanguage) -> String {
            if language == .en, let answerEN, !answerEN.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                return answerEN
            }
            return answer
        }
    }

    var version: Int
    var enabled: Bool
    var spamPolicy: SpamPolicy
    var commands: [Command]

    static var fallback: ShinnAIManagedConfig {
        .init(
            version: 2,
            enabled: true,
            spamPolicy: .init(maxMessages: 10, windowSeconds: 60, lockSeconds: 3600),
            commands: [
                .init(command: "/cách bật aim", aliases: ["/cach bat aim", "/bật aim", "/bat aim"], answer: "Cách bật AIM:\n1. Mở game và đứng ở sảnh chờ của game.\n2. Thoát/quay lại App ShinnCheat.\n3. Bật patch AIM cần dùng bằng công tắc.\n4. Quay lại game và kiểm tra hiệu ứng.", answerEN: "How to enable AIM:\n1. Open the game and stay in the lobby.\n2. Return to the ShinnCheat app.\n3. Turn on the AIM patch using its switch.\n4. Return to the game and check the effect."),
                .init(command: "/cách mở menu", aliases: ["/cach mo menu", "/mở menu", "/mo menu"], answer: "Cách mở Menu:\n1. Chọn đúng loại Menu/patch bạn muốn sử dụng.\n2. Áp dụng patch.\n3. Vào game.\n4. Chạm 3–4 ngón tay vào màn hình để gọi Menu.", answerEN: "How to open the Menu:\n1. Choose the correct Menu/patch.\n2. Apply the patch.\n3. Open the game.\n4. Touch the screen with 3–4 fingers to call the Menu."),
                .init(command: "/cách mod skin", aliases: ["/cach mod skin", "/mod skin"], answer: "Cách mod Skin:\n1. Tìm skin cần mod và kiểm tra đúng phiên bản Free Fire.\n2. Chọn patch Skin tương ứng trong ShinnCheat.\n3. Tải patch nếu chưa có.\n4. Bật công tắc để áp dụng patch rồi quay lại game.", answerEN: "How to mod a Skin:\n1. Find the skin and check that it matches your Free Fire version.\n2. Choose the matching Skin patch in ShinnCheat.\n3. Download the patch if needed.\n4. Turn on the patch switch, then return to the game."),
                .init(command: "/help", aliases: ["help", "/menu", "menu"], answer: "🤖 Shinn AI Commands\n\n/start - Bắt đầu\n/help - Danh sách lệnh\n/repo - Kiểm tra Repo\n/key - Kiểm tra Key\n/patch - Tìm patch\n/support - Liên hệ hỗ trợ", answerEN: "🤖 Shinn AI Commands\n\n/start - Start\n/help - Command list\n/repo - Check Repo\n/key - Check Key\n/patch - Find patch\n/support - Support"),
                .init(command: "/repo", aliases: ["repo", "/premium", "premium"], answer: "📦 Repo ShinnCheat\n\nRepo miễn phí: có sẵn trong ứng dụng.\nRepo Premium: nhập key hợp lệ để mở khóa.", answerEN: "📦 ShinnCheat Repo\n\nFree Repo: available in app.\nPremium Repo: enter a valid key to unlock."),
                .init(command: "/key", aliases: ["key", "kiểm tra key"], answer: "🔑 Key được kiểm tra tự động qua hệ thống Shinn. Nếu key hết hạn, quyền truy cập Premium sẽ bị khóa.", answerEN: "🔑 Keys are checked automatically by Shinn system. Expired keys lose Premium access."),
                .init(command: "/patch", aliases: ["patch", "tìm patch"], answer: "🛠 Patch Helper\n\nMở mục Kho Patch để xem danh sách patch mới nhất.", answerEN: "🛠 Patch Helper\n\nOpen Patch Store to see latest patches."),
                .init(command: "/support", aliases: ["support", "hỗ trợ"], answer: "💬 Hỗ trợ ShinnCheat\nTelegram: @ShinnThieuu", answerEN: "💬 ShinnCheat Support\nTelegram: @ShinnThieuu"),
                .init(
                    command: "dnt",
                    aliases: ["donate", "ung-ho", "/dnt"],
                    answer: "💳 THÔNG TIN ỦNG HỘ\n\n🏦 Ngân hàng: MB Bank\n💰 Số tài khoản: 104877777\n\n📱 Quét mã QR bên dưới để chuyển khoản.\n\n❤️ Cảm ơn bạn đã ủng hộ Shinn!",
                    answerEN: "💳 SUPPORT / DONATION INFO\n\n🏦 Bank: MB Bank\n💰 Account number: 104877777\n\n📱 Scan the QR code below to make a transfer.\n\n❤️ Thank you for supporting Shinn!",
                    imageURLs: ["https://raw.githubusercontent.com/ShinnCheatCode/ShinnVip/main/IMG_0335.jpeg"]
                )
            ]
        )
    }
}

@MainActor
final class ShinnAIGitHubManager: ObservableObject {
    @Published var config: ShinnAIManagedConfig = .fallback
    @Published private(set) var isLoading = false
    @Published var errorMessage: String?
    static let defaultRawURL = AppInfo.safeURL("https://raw.githubusercontent.com/ShinnCheatCode/RepoV2/main/ShinnAIConfig.json")
    var rawConfigURL: URL = ShinnAIGitHubManager.defaultRawURL

    func refresh() async {
        isLoading = true
        defer { isLoading = false }
        do {
            var components = URLComponents(url: rawConfigURL, resolvingAgainstBaseURL: false)!
            components.queryItems = [URLQueryItem(name: "v", value: String(Int(Date().timeIntervalSince1970)))]
            var request = URLRequest(url: components.url!)
            request.cachePolicy = .reloadIgnoringLocalCacheData
            request.setValue("no-cache", forHTTPHeaderField: "Cache-Control")
            let (data, response) = try await URLSession.shared.data(for: request)
            guard let http = response as? HTTPURLResponse, 200..<300 ~= http.statusCode else { throw URLError(.badServerResponse) }
            let decoded = try JSONDecoder().decode(ShinnAIManagedConfig.self, from: data)
            config = decoded
            errorMessage = nil
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    func command(for input: String) -> ShinnAIManagedConfig.Command? {
        let n = normalizeCommand(input)
        return config.commands.first { command in
            let candidates = [command.command] + command.aliases
            return candidates.contains { normalizeCommand($0) == n }
        }
    }

    private func normalize(_ value: String) -> String {
        value.folding(options: [.diacriticInsensitive, .caseInsensitive, .widthInsensitive], locale: Locale(identifier: "vi_VN"))
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .replacingOccurrences(of: "  ", with: " ")
            .lowercased()
    }

    private func normalizeCommand(_ value: String) -> String {
        let normalized = normalize(value)
        return normalized.hasPrefix("/") ? String(normalized.dropFirst()) : normalized
    }
}

private enum ShinnAIKeyStore {
    private static let service = "shinn.ai.openai"
    private static let account = "openai-api-key"

    static func save(_ value: String) {
        let data = Data(value.utf8)
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]
        SecItemDelete(query as CFDictionary)

        var item = query
        item[kSecValueData as String] = data
        item[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlockedThisDeviceOnly
        SecItemAdd(item as CFDictionary, nil)
    }

    static func load() -> String {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]

        var result: AnyObject?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
              let data = result as? Data,
              let value = String(data: data, encoding: .utf8) else {
            return ""
        }
        return value
    }
}

private enum ShinnAIConfigKeychain {
    static let service = "shinn.ai.github.admin"
    static let account = "github-token"

    static func save(_ value: String) {
        let data = Data(value.utf8)
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: service, kSecAttrAccount as String: account]
        SecItemDelete(query as CFDictionary)
        var item = query
        item[kSecValueData as String] = data
        item[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlockedThisDeviceOnly
        SecItemAdd(item as CFDictionary, nil)
    }

    static func load() -> String {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: service, kSecAttrAccount as String: account, kSecReturnData as String: true, kSecMatchLimit as String: kSecMatchLimitOne]
        var result: AnyObject?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
              let data = result as? Data,
              let value = String(data: data, encoding: .utf8) else { return "" }
        return value
    }
}

final class ShinnAIGitHubAdminService {
    struct Settings {
        var owner: String
        var repo: String
        var path: String
        var branch: String
        var token: String
    }

    private let session: URLSession
    init(session: URLSession = .shared) { self.session = session }

    private func request(_ settings: Settings, method: String, url: URL, body: [String: Any]? = nil) async throws -> (Data, HTTPURLResponse) {
        var request = URLRequest(url: url)
        request.httpMethod = method
        request.setValue("application/vnd.github+json", forHTTPHeaderField: "Accept")
        request.setValue("Bearer \(settings.token)", forHTTPHeaderField: "Authorization")
        request.setValue("2026-03-10", forHTTPHeaderField: "X-GitHub-Api-Version")
        if let body { request.setValue("application/json", forHTTPHeaderField: "Content-Type"); request.httpBody = try JSONSerialization.data(withJSONObject: body) }
        let (data, response) = try await session.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw URLError(.badServerResponse) }
        guard 200..<300 ~= http.statusCode else {
            let raw = String(decoding: data, as: UTF8.self)
            throw NSError(domain: "ShinnAI.GitHub", code: http.statusCode, userInfo: [NSLocalizedDescriptionKey: raw.prefix(300)])
        }
        return (data, http)
    }

    func fetchSHA(settings: Settings, path: String? = nil) async throws -> String? {
        let filePath = path ?? settings.path
        let url = AppInfo.safeURL("https://api.github.com/repos/\(settings.owner)/\(settings.repo)/contents/\(filePath)?ref=\(settings.branch.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? settings.branch)")
        do {
            let (data, _) = try await request(settings, method: "GET", url: url)
            let obj = try JSONSerialization.jsonObject(with: data) as? [String: Any]
            return obj?["sha"] as? String
        } catch let error as NSError where error.code == 404 { return nil }
    }

    func updateConfig(_ config: ShinnAIManagedConfig, settings: Settings, commitMessage: String) async throws {
        let data = try JSONEncoder.shinnPretty.encode(config)
        let sha = try await fetchSHA(settings: settings)
        var body: [String: Any] = ["message": commitMessage, "content": data.base64EncodedString(), "branch": settings.branch]
        if let sha { body["sha"] = sha }
        let url = AppInfo.safeURL("https://api.github.com/repos/\(settings.owner)/\(settings.repo)/contents/\(settings.path)")
        _ = try await request(settings, method: "PUT", url: url, body: body)
    }

    func uploadImage(data: Data, filename: String, settings: Settings, folder: String = "images") async throws -> String {
        let clean = filename.replacingOccurrences(of: " ", with: "-")
        let path = "\(folder.trimmingCharacters(in: CharacterSet(charactersIn: "/")))/\(clean)"
        let sha = try await fetchSHA(settings: settings, path: path)
        var body: [String: Any] = ["message": "Shinn AI: add/update image \(clean)", "content": data.base64EncodedString(), "branch": settings.branch]
        if let sha { body["sha"] = sha }
        let url = AppInfo.safeURL("https://api.github.com/repos/\(settings.owner)/\(settings.repo)/contents/\(path)")
        _ = try await request(settings, method: "PUT", url: url, body: body)
        return "https://raw.githubusercontent.com/\(settings.owner)/\(settings.repo)/\(settings.branch)/\(path)"
    }
}

private extension JSONEncoder {
    static var shinnPretty: JSONEncoder { let e = JSONEncoder(); e.outputFormatting = [.prettyPrinted, .sortedKeys]; return e }
}

private struct AIChatMessage: Identifiable, Codable, Hashable {
    let id: UUID
    let role: String
    let text: String
    let imageURLs: [String]
    init(id: UUID = UUID(), role: String, text: String, imageURLs: [String] = []) { self.id = id; self.role = role; self.text = text; self.imageURLs = imageURLs }
}

private struct AIChatRequest: Encodable {
    struct Message: Encodable { let role: String; let content: String }
    let model: String
    let messages: [Message]
    let temperature: Double
}

private struct AIChatResponse: Decodable {
    struct Choice: Decodable { struct Message: Decodable { let content: String? }; let message: Message }
    let choices: [Choice]
}

struct ShinnAIChatView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var session: Session
    @StateObject private var githubAI = ShinnAIGitHubManager()
    @State private var input = ""
    @State private var messages: [AIChatMessage] = [
        AIChatMessage(
            role: "assistant",
            text: "Xin chào 👋 Mình là Shinn AI.\nBạn có thể hỏi về patch, lỗi áp dụng, Repo V2 hoặc cách sử dụng app.\n\n⚠️ LƯU Ý: Nếu spam chat bot AI, key của bạn có thể bị ban. Vui lòng không spam AI. Xin cảm ơn!"
        )
    ]
    @State private var isSending = false
    @State private var errorText: String?
    @State private var lockUntil: Date?
    @State private var recentMessageTimes: [Date] = []
    @State private var showAIConfig = false
    @State private var aiLanguage: ShinnLanguage = ShinnLanguage(rawValue: UserDefaults.standard.string(forKey: "shinn.ai.language") ?? "vi") ?? .vi
    @State private var configEndpoint = UserDefaults.standard.string(forKey: "shinn.ai.endpoint") ?? "https://api.openai.com/v1/chat/completions"
    @State private var configModel = UserDefaults.standard.string(forKey: "shinn.ai.model") ?? "gpt-4.1-mini"
    @State private var configKey = ShinnAIKeyStore.load()
    @State private var aiSyncTask: Task<Void, Never>?
    @FocusState private var focused: Bool

    private var endpoint: String { UserDefaults.standard.string(forKey: "shinn.ai.endpoint") ?? "" }
    private var apiKey: String { ShinnAIKeyStore.load() }
    private var model: String { UserDefaults.standard.string(forKey: "shinn.ai.model") ?? "gpt-4.1-mini" }
    private var isLocked: Bool { (lockUntil ?? Date.distantPast) > Date() }
    private var lockText: String {
        let seconds = max(0, Int((lockUntil ?? Date()).timeIntervalSinceNow))
        return "Chat bị khóa còn \(seconds / 60) phút \((seconds % 60)) giây"
    }

    var body: some View {
        ZStack {
            BackgroundView()
            VStack(spacing: 0) {
                header
                if isLocked { Text(lockText).font(.caption.bold()).foregroundStyle(ShinnRed).padding(.horizontal, 16).padding(.vertical, 7).frame(maxWidth: .infinity, alignment: .leading).background(ShinnRed.opacity(0.08)) }
                ScrollViewReader { proxy in
                    ScrollView(showsIndicators: false) {
                        LazyVStack(spacing: 12) {
                            ForEach(messages) { message in messageBubble(message).id(message.id) }
                            if isSending { HStack { ProgressView().tint(ShinnRed); Text("Shinn AI đang suy nghĩ…").font(.system(size: 13, weight: .semibold, design: .rounded)).foregroundStyle(.white.opacity(0.55)); Spacer() }.padding(.horizontal, 4) }
                        }.padding(.horizontal, 16).padding(.vertical, 14)
                    }
                    .onChange(of: messages.count) { _ in if let last = messages.last { withAnimation(.easeOut(duration: 0.25)) { proxy.scrollTo(last.id, anchor: .bottom) } } }
                }
                commandChips
                composer
            }
        }
        .navigationBarHidden(true)
        .task {
            await githubAI.refresh()
            aiSyncTask?.cancel()
            aiSyncTask = Task {
                while !Task.isCancelled {
                    try? await Task.sleep(nanoseconds: 30_000_000_000)
                    if Task.isCancelled { break }
                    await githubAI.refresh()
                }
            }
        }
        .onDisappear {
            aiSyncTask?.cancel()
            aiSyncTask = nil
        }
        .onReceive(Timer.publish(every: 1, on: .main, in: .common).autoconnect()) { _ in _ = isLocked }
        .sheet(isPresented: $showAIConfig) {
            if session.role == .owner {
                aiConfigSheet
                    .presentationDetents([.medium])
                    .presentationDragIndicator(.visible)
            } else {
                Color.clear.onAppear { showAIConfig = false }
            }
        }
    }

    private var header: some View {
        HStack(spacing: 12) {
            Button { dismiss() } label: { Image(systemName: "chevron.left").font(.system(size: 18, weight: .bold)).frame(width: 40, height: 40).background(Color.white.opacity(0.07), in: Circle()) }
            ZStack { Circle().fill(ShinnRed.opacity(0.14)); Image(systemName: "sparkles").foregroundStyle(ShinnRed).font(.system(size: 18, weight: .black)) }.frame(width: 42, height: 42)
            VStack(alignment: .leading, spacing: 1) { Text("Shinn AI").font(.system(size: 18, weight: .black, design: .rounded)); Text("AI Assistant · GitHub Sync").font(.system(size: 10.5, weight: .medium, design: .rounded)).foregroundStyle(.white.opacity(0.45)) }
            Spacer()
            Picker("Language", selection: $aiLanguage) {
                Text("VI").tag(ShinnLanguage.vi)
                Text("EN").tag(ShinnLanguage.en)
            }
            .pickerStyle(.segmented)
            .frame(width: 86)
            .onChange(of: aiLanguage) { value in
                UserDefaults.standard.set(value.rawValue, forKey: "shinn.ai.language")
            }
            if session.role == .owner {
                Button { showAIConfig = true } label: {
                    Image(systemName: "gearshape.fill")
                        .font(.system(size: 14, weight: .bold))
                        .frame(width: 34, height: 34)
                        .background(Color.white.opacity(0.07), in: Circle())
                }
            }
            Circle().fill(Color.green).frame(width: 8, height: 8)
        }.padding(.horizontal, 16).padding(.vertical, 10)
    }

    private var commandChips: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(githubAI.config.commands.prefix(8)) { command in
                    Button(command.command) { input = command.command; send() }
                        .font(.system(size: 10, weight: .black, design: .rounded))
                        .foregroundStyle(ShinnRed)
                        .padding(.horizontal, 10).padding(.vertical, 8)
                        .background(ShinnRed.opacity(0.10), in: Capsule())
                        .overlay(Capsule().stroke(ShinnRed.opacity(0.24), lineWidth: 0.7))
                        .disabled(isLocked || isSending)
                }
            }.padding(.horizontal, 16).padding(.bottom, 7)
        }
    }

    private func messageBubble(_ message: AIChatMessage) -> some View {
        HStack {
            if message.role == "assistant" { Spacer(minLength: 0) }
            VStack(alignment: .leading, spacing: 7) {
                if message.role == "assistant" { Text("SHINN AI").font(.system(size: 9, weight: .black, design: .rounded)).foregroundStyle(ShinnRed) }
                Text(message.text).font(.system(size: 14.5, weight: .medium, design: .rounded)).foregroundStyle(.white.opacity(0.94)).textSelection(.enabled)
                ForEach(message.imageURLs, id: \.self) { raw in
                    if let url = URL(string: raw) {
                        AsyncImage(url: url) { phase in
                            switch phase {
                            case .success(let image): image.resizable().scaledToFit().clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                            case .failure: Label("Không tải được ảnh", systemImage: "photo.badge.exclamationmark").font(.caption).foregroundStyle(.secondary).frame(maxWidth: .infinity, minHeight: 70)
                            default: ProgressView().tint(ShinnRed).frame(maxWidth: .infinity, minHeight: 90)
                            }
                        }
                        .frame(maxWidth: 290)
                    }
                }
            }
            .padding(.horizontal, 14).padding(.vertical, 11)
            .background(message.role == "assistant" ? Color.white.opacity(0.055) : ShinnRed.opacity(0.16), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(message.role == "assistant" ? Color.white.opacity(0.10) : ShinnRed.opacity(0.35), lineWidth: 0.8))
            if message.role != "assistant" { Spacer(minLength: 28) }
        }
    }

    private var composer: some View {
        VStack(spacing: 7) {
            if let errorText, !errorText.isEmpty { Text(errorText).font(.system(size: 11.5, weight: .semibold, design: .rounded)).foregroundStyle(.red.opacity(0.95)).frame(maxWidth: .infinity, alignment: .leading).padding(.horizontal, 18) }
            HStack(spacing: 8) {
                TextField(isLocked ? "Chat đang bị khóa" : "Hỏi Shinn AI…", text: $input, axis: .vertical).lineLimit(1...4).focused($focused).textInputAutocapitalization(.sentences).padding(.horizontal, 13).padding(.vertical, 10).background(Color.white.opacity(0.065), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                Button { send() } label: { Image(systemName: isSending ? "hourglass" : "arrow.up").font(.system(size: 16, weight: .black)).foregroundStyle(.white).frame(width: 44, height: 44).background(ShinnRed, in: Circle()).shadow(color: ShinnRed.opacity(0.35), radius: 10) }.disabled(isSending || isLocked || input.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty).opacity(input.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || isLocked ? 0.45 : 1)
            }.padding(.horizontal, 12).padding(.vertical, 9).background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 22, style: .continuous)).overlay(RoundedRectangle(cornerRadius: 22, style: .continuous).stroke(ShinnRed.opacity(0.30), lineWidth: 0.8))
        }.padding(.horizontal, 12).padding(.bottom, 10)
    }

    private func send() {
        guard !isLocked else { return }
        let text = input.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty, !isSending else { return }
        let now = Date()
        let window = TimeInterval(max(1, githubAI.config.spamPolicy.windowSeconds))
        recentMessageTimes = recentMessageTimes.filter { now.timeIntervalSince($0) < window }
        recentMessageTimes.append(now)
        if recentMessageTimes.count > max(1, githubAI.config.spamPolicy.maxMessages) {
            lockUntil = now.addingTimeInterval(TimeInterval(max(1, githubAI.config.spamPolicy.lockSeconds)))
            input = ""
            errorText = "Bạn đã gửi quá nhanh. Shinn AI tạm khóa chat 1 giờ."
            return
        }
        input = ""
        messages.append(AIChatMessage(role: "user", text: text))
        errorText = nil
        isSending = true
        if let command = githubAI.command(for: text), githubAI.config.enabled {
            messages.append(AIChatMessage(role: "assistant", text: command.answer(for: aiLanguage), imageURLs: command.imageURLs))
            isSending = false
            return
        }
        let endpointConfigured = !endpoint.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
        let apiConfigured = !apiKey.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty

        if endpointConfigured && apiConfigured {
            Task { await requestAI() }
        } else {
            let fallback = aiLanguage == .vi
                ? "Mình chưa có câu trả lời cho câu hỏi này. Owner có thể mở Shinn AI Manager để tạo lệnh mới trên GitHub."
                : "I don't have an answer for this yet. The Owner can open Shinn AI Manager and add a new command on GitHub."
            messages.append(AIChatMessage(role: "assistant", text: fallback))
            isSending = false
        }
    }

    private func requestAI() async {
        guard let url = URL(string: endpoint), !endpoint.isEmpty else { await MainActor.run { isSending = false; errorText = "Chưa cấu hình AI endpoint." }; return }
        guard !apiKey.isEmpty else { await MainActor.run { isSending = false; errorText = "Chưa cấu hình AI API key." }; return }
        let recent = messages.suffix(12).map { AIChatRequest.Message(role: $0.role, content: $0.text) }
        let requestBody = AIChatRequest(model: model, messages: recent, temperature: 0.35)
        do {
            var request = URLRequest(url: url); request.httpMethod = "POST"; request.timeoutInterval = 45; request.setValue("application/json", forHTTPHeaderField: "Content-Type"); request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization"); request.httpBody = try JSONEncoder().encode(requestBody)
            let (data, response) = try await URLSession.shared.data(for: request)
            guard let http = response as? HTTPURLResponse, 200..<300 ~= http.statusCode else { throw NSError(domain: "ShinnAI", code: (response as? HTTPURLResponse)?.statusCode ?? -1, userInfo: [NSLocalizedDescriptionKey: "AI server error"]) }
            let decoded = try JSONDecoder().decode(AIChatResponse.self, from: data)
            guard let answer = decoded.choices.first?.message.content?.trimmingCharacters(in: .whitespacesAndNewlines), !answer.isEmpty else { throw NSError(domain: "ShinnAI", code: -2, userInfo: [NSLocalizedDescriptionKey: "AI không trả về nội dung."]) }
            await MainActor.run { messages.append(AIChatMessage(role: "assistant", text: answer)); isSending = false }
        } catch { await MainActor.run { isSending = false; errorText = error.localizedDescription } }
    }

    private var aiConfigSheet: some View {
        NavigationStack {
            ZStack { BackgroundView(); ScrollView { VStack(alignment: .leading, spacing: 14) {
                Text("SHINN AI").font(.system(size: 28, weight: .black, design: .rounded))
                Text("API key được lưu trong Keychain của máy.").font(.system(size: 13, weight: .medium, design: .rounded)).foregroundStyle(.white.opacity(0.52))
                TextField("https://.../v1/chat/completions", text: $configEndpoint).textInputAutocapitalization(.never).autocorrectionDisabled(true).padding(13).background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 15, style: .continuous))
                TextField("Model", text: $configModel).textInputAutocapitalization(.never).autocorrectionDisabled(true).padding(13).background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 15, style: .continuous))
                SecureField("API key", text: $configKey).textInputAutocapitalization(.never).autocorrectionDisabled(true).padding(13).background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 15, style: .continuous))
                Button { UserDefaults.standard.set(configEndpoint.trimmingCharacters(in: .whitespacesAndNewlines), forKey: "shinn.ai.endpoint"); UserDefaults.standard.set(configModel.trimmingCharacters(in: .whitespacesAndNewlines), forKey: "shinn.ai.model"); ShinnAIKeyStore.save(configKey.trimmingCharacters(in: .whitespacesAndNewlines)); showAIConfig = false } label: { Text("LƯU CẤU HÌNH").font(.system(size: 14, weight: .black, design: .rounded)).frame(maxWidth: .infinity).padding(.vertical, 14).background(ShinnRed, in: RoundedRectangle(cornerRadius: 16, style: .continuous)).foregroundStyle(.white) }.buttonStyle(.plain)
            }.padding(18) } }.toolbar { ToolbarItem(placement: .topBarLeading) { Button("Đóng") { showAIConfig = false } } }
        }
    }
}

// ===== Owner-only GitHub AI Manager =====
struct ShinnAIAdminView: View {
    @EnvironmentObject var session: Session
    @StateObject private var manager = ShinnAIGitHubManager()

    @State private var owner = "ShinnCheatCode"
    @State private var repo = "RepoV2"
    @State private var path = "ShinnAIConfig.json"
    @State private var branch = "main"
    @State private var token = ShinnAIConfigKeychain.load()
    @State private var commitMessage = "Shinn AI: update commands"

    @State private var editing: ShinnAIManagedConfig.Command?
    @State private var showingEditor = false
    @State private var newCommand = ""
    @State private var newAliases = ""
    @State private var newAnswer = ""
    @State private var newAnswerEN = ""
    @State private var newImages = ""
    @State private var status: String?
    @State private var photoItem: PhotosPickerItem?
    @State private var uploadingImage = false

    private var githubSettings: ShinnAIGitHubAdminService.Settings {
        .init(
            owner: owner.trimmingCharacters(in: .whitespacesAndNewlines),
            repo: repo.trimmingCharacters(in: .whitespacesAndNewlines),
            path: path.trimmingCharacters(in: .whitespacesAndNewlines),
            branch: branch.trimmingCharacters(in: .whitespacesAndNewlines),
            token: token.trimmingCharacters(in: .whitespacesAndNewlines)
        )
    }

    var body: some View {
        Group {
            if session.role == .owner {
                ZStack {
                    BackgroundView()
                    ScrollView {
                        VStack(alignment: .leading, spacing: 14) {
                            Text("SHINN AI · OWNER")
                                .font(.system(size: 24, weight: .black, design: .rounded))

                            Text("Tạo / sửa / xóa lệnh, tin nhắn trả lời và ảnh. Mọi key sẽ đồng bộ qua ShinnAIConfig.json trên GitHub.")
                                .font(.caption)
                                .foregroundStyle(.white.opacity(0.55))

                            Text("Nguồn: https://raw.githubusercontent.com/ShinnCheatCode/RepoV2/main/ShinnAIConfig.json")
                                .font(.system(size: 10, weight: .medium, design: .monospaced))
                                .foregroundStyle(.secondary)
                                .textSelection(.enabled)

                            settingsCard

                            HStack(spacing: 10) {
                                Button {
                                    Task { await manager.refresh() }
                                } label: {
                                    Label("ĐỒNG BỘ", systemImage: "arrow.triangle.2.circlepath")
                                }
                                .buttonStyle(ShinnPremiumButtonStyle())

                                Button {
                                    startNewCommand()
                                } label: {
                                    Label("THÊM LỆNH", systemImage: "plus.circle.fill")
                                }
                                .buttonStyle(ShinnMiniGlassButtonStyle())
                            }

                            if let status {
                                Text(status)
                                    .font(.caption.bold())
                                    .foregroundStyle(status.contains("thành công") ? .green : ShinnRed)
                                    .textSelection(.enabled)
                            }

                            if manager.isLoading {
                                HStack(spacing: 8) {
                                    ProgressView().tint(ShinnRed)
                                    Text("Đang tải ShinnAIConfig.json…")
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                }
                            }

                            ForEach(manager.config.commands) { command in
                                commandCard(command)
                            }

                            Button {
                                startNewCommand()
                            } label: {
                                Label("TẠO LỆNH MỚI", systemImage: "plus.circle.fill")
                            }
                            .buttonStyle(ShinnPremiumButtonStyle())
                        }
                        .padding(18)
                    }
                }
            } else {
                PatchOwnerOnlyView()
            }
        }
        .navigationTitle("Shinn AI Manager")
        .navigationBarTitleDisplayMode(.inline)
        .task { await manager.refresh() }
        .sheet(isPresented: $showingEditor) {
            editorSheet
        }
    }

    private var settingsCard: some View {
        VStack(alignment: .leading, spacing: 9) {
            Text("GITHUB")
                .font(.caption.bold())
                .foregroundStyle(ShinnRed)

            TextField("Owner", text: $owner)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled(true)

            TextField("Repository", text: $repo)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled(true)

            TextField("File path", text: $path)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled(true)

            TextField("Branch", text: $branch)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled(true)

            SecureField("GitHub token — lưu Keychain", text: $token)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled(true)

            TextField("Commit message", text: $commitMessage)

            Button("LƯU TOKEN") {
                ShinnAIConfigKeychain.save(token.trimmingCharacters(in: .whitespacesAndNewlines))
                status = "Đã lưu token vào Keychain."
            }
            .buttonStyle(ShinnMiniGlassButtonStyle())

            Text("Token chỉ dùng cho quyền Owner ghi config/ảnh lên GitHub. Không hard-code token vào source.")
                .font(.caption2)
                .foregroundStyle(.secondary)
        }
        .padding(15)
        .shinnGlass(radius: 18)
    }

    private func commandCard(_ command: ShinnAIManagedConfig.Command) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text(command.command)
                    .font(.headline.bold())
                Spacer()
                Button("Sửa") {
                    load(command)
                    showingEditor = true
                }
                .font(.caption.bold())

                Button("Xóa", role: .destructive) {
                    delete(command)
                }
                .font(.caption.bold())
            }

            Text("VI: \(command.answer)")
                .font(.caption)

            if let en = command.answerEN, !en.isEmpty {
                Text("EN: \(en)")
                    .font(.caption)
                    .foregroundStyle(.white.opacity(0.68))
                    .lineLimit(4)
            }

            if !command.aliases.isEmpty {
                Text("Alias: \(command.aliases.joined(separator: ", "))")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            }

            if !command.imageURLs.isEmpty {
                Text("🖼️ \(command.imageURLs.count) ảnh")
                    .font(.caption2)
                    .foregroundStyle(ShinnRed)
            }
        }
        .padding(14)
        .shinnGlass(radius: 16)
    }

    private var editorSheet: some View {
        NavigationStack {
            ZStack {
                BackgroundView()

                ScrollView {
                    VStack(alignment: .leading, spacing: 12) {
                        TextField("/lệnh", text: $newCommand)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled(true)
                            .padding(12)
                            .background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 14, style: .continuous))

                        TextField("Alias, cách nhau bằng dấu phẩy", text: $newAliases)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled(true)
                            .padding(12)
                            .background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 14, style: .continuous))

                        Text("🇻🇳 Câu trả lời Tiếng Việt")
                            .font(.caption.bold())
                            .foregroundStyle(ShinnRed)

                        TextEditor(text: $newAnswer)
                            .frame(minHeight: 140)
                            .scrollContentBackground(.hidden)
                            .padding(8)
                            .background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 14, style: .continuous))

                        Text("🇬🇧 English answer")
                            .font(.caption.bold())
                            .foregroundStyle(ShinnRed)

                        TextEditor(text: $newAnswerEN)
                            .frame(minHeight: 140)
                            .scrollContentBackground(.hidden)
                            .padding(8)
                            .background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 14, style: .continuous))

                        VStack(alignment: .leading, spacing: 8) {
                            Text("Ảnh trả lời")
                                .font(.caption.bold())
                                .foregroundStyle(ShinnRed)

                            PhotosPicker(selection: $photoItem, matching: .images) {
                                Label(
                                    uploadingImage ? "Đang tải ảnh lên GitHub…" : "Chọn ảnh → tải lên GitHub",
                                    systemImage: uploadingImage ? "hourglass" : "photo.badge.plus"
                                )
                                .frame(maxWidth: .infinity, minHeight: 48)
                            }
                            .buttonStyle(ShinnMiniGlassButtonStyle())
                            .disabled(uploadingImage)

                            TextField("Hoặc URL ảnh, mỗi URL cách nhau bằng dấu phẩy", text: $newImages, axis: .vertical)
                                .textInputAutocapitalization(.never)
                                .autocorrectionDisabled(true)
                                .lineLimit(2...5)
                                .padding(12)
                                .background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 14, style: .continuous))

                            if !newImages.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                                Text(newImages)
                                    .font(.caption2.monospaced())
                                    .foregroundStyle(.secondary)
                                    .lineLimit(4)
                            }
                        }

                        Button {
                            saveCommand()
                        } label: {
                            Text("LƯU LỆNH LÊN GITHUB")
                        }
                        .buttonStyle(ShinnPremiumButtonStyle())
                        .disabled(uploadingImage)
                    }
                    .padding(18)
                }
            }
            .navigationTitle(editing == nil ? "Thêm lệnh" : "Sửa lệnh")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button("Đóng") {
                        showingEditor = false
                    }
                }
            }
        }
        .onChange(of: photoItem) { item in
            guard let item else { return }
            Task { await uploadSelectedImage(item) }
        }
    }

    private func startNewCommand() {
        newCommand = "/"
        newAliases = ""
        newAnswer = ""
        newAnswerEN = ""
        newImages = ""
        editing = nil
        photoItem = nil
        showingEditor = true
    }

    private func load(_ command: ShinnAIManagedConfig.Command) {
        editing = command
        newCommand = command.command
        newAliases = command.aliases.joined(separator: ", ")
        newAnswer = command.answer
        newAnswerEN = command.answerEN ?? ""
        newImages = command.imageURLs.joined(separator: ",")
        photoItem = nil
    }

    private func saveCommand() {
        let command = ShinnAIManagedConfig.Command(
            command: newCommand.trimmingCharacters(in: .whitespacesAndNewlines),
            aliases: newAliases
                .split(separator: ",")
                .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
                .filter { !$0.isEmpty },
            answer: newAnswer,
            answerEN: newAnswerEN.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? nil : newAnswerEN,
            imageURLs: newImages
                .split(separator: ",")
                .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
                .filter { !$0.isEmpty }
        )

        guard !command.command.isEmpty,
              !command.answer.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            status = "Lệnh không được để trống và phải có nội dung trả lời."
            return
        }

        if let old = editing,
           let index = manager.config.commands.firstIndex(where: { $0.command == old.command }) {
            manager.config.commands[index] = command
        } else {
            manager.config.commands.append(command)
        }

        showingEditor = false
        Task { await saveToGitHub() }
    }

    private func delete(_ command: ShinnAIManagedConfig.Command) {
        manager.config.commands.removeAll { $0.command == command.command }
        Task { await saveToGitHub() }
    }

    private func uploadSelectedImage(_ item: PhotosPickerItem) async {
        guard !token.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            await MainActor.run { status = "Chưa có GitHub token Owner." }
            return
        }

        await MainActor.run { uploadingImage = true }

        defer {
            Task { @MainActor in
                uploadingImage = false
                photoItem = nil
            }
        }

        do {
            guard let data = try await item.loadTransferable(type: Data.self) else {
                throw NSError(domain: "ShinnAI.Image", code: -1, userInfo: [NSLocalizedDescriptionKey: "Không đọc được ảnh."])
            }

            let filename = "shinn_ai_\(Int(Date().timeIntervalSince1970)).jpg"
            let url = try await ShinnAIGitHubAdminService().uploadImage(
                data: data,
                filename: filename,
                settings: githubSettings
            )

            await MainActor.run {
                let urls = newImages
                    .split(separator: ",")
                    .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
                    .filter { !$0.isEmpty }

                newImages = (urls + [url]).joined(separator: ", ")
                status = "Đã upload ảnh lên GitHub."
            }
        } catch {
            await MainActor.run {
                status = "Upload ảnh lỗi: \(error.localizedDescription)"
            }
        }
    }

    private func saveToGitHub() async {
        let t = token.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !t.isEmpty else {
            await MainActor.run { status = "Chưa có GitHub token." }
            return
        }

        do {
            try await ShinnAIGitHubAdminService().updateConfig(
                manager.config,
                settings: githubSettings,
                commitMessage: commitMessage
            )

            await manager.refresh()
            await MainActor.run {
                status = "Đồng bộ thành công. Lệnh đã được cập nhật trên server — không cần build IPA lại."
            }
        } catch {
            await MainActor.run {
                status = "GitHub lỗi: \(error.localizedDescription)"
            }
        }
    }
}

// ===== PatchOwnerOnlyView =====
struct PatchOwnerOnlyView: View {
    var body: some View {
        ZStack {
            BackgroundView()
            VStack(spacing: 12) {
                Image(systemName: "lock.fill")
                    .font(.system(size: 42, weight: .semibold))
                    .foregroundStyle(.secondary)
                Text("Owner only")
                    .font(.title2.bold())
                Text("Chỉ Owner mới có quyền tạo hoặc chỉnh sửa Patch.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
            }
            .padding(24)
        }
        .navigationTitle("Patch")
        .navigationBarTitleDisplayMode(.inline)
    }
}

// ===== LockoutView =====
struct LockoutView: View {
    @ObservedObject var abuse: AbuseGuard
    let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()

    var body: some View {
        ZStack {
            BackgroundView()
            VStack(spacing: 16) {
                Image(systemName: "lock.fill").font(.system(size: 44))
                Text("Temporarily locked").font(.title2.bold())
                Text("Try again in \(abuse.remainText())")
                    .font(.headline)
                    .foregroundStyle(.secondary)
            }
        }
        .onReceive(timer) { _ in
            if !abuse.isLocked { abuse.lockedUntil = nil }
            abuse.objectWillChange.send()
        }
    }
}

// ===== ActivateKeyView =====
struct ActivateKeyView: View {
    @EnvironmentObject var settings: AppSettings
    @EnvironmentObject var session: Session
    @EnvironmentObject var license: LicenseManager
    @EnvironmentObject var abuse: AbuseGuard

    @State private var keyText = ""
    @State private var isBiometricRunning = false
    @State private var didAutoStartBiometric = false
    @FocusState private var focused: Bool

    private var hasSavedKey: Bool {
        (KeychainKeyStore.load() ?? "").isEmpty == false
    }

    var body: some View {
        ZStack {
            BackgroundView()
            ScreenPrivacyGuard()

            ScrollView(showsIndicators: false) {
                VStack(spacing: 18) {
                    ZStack(alignment: .bottomLeading) {
                        if let hero = HeroBanner.image {
                            Image(uiImage: hero)
                                .resizable()
                                .scaledToFill()
                                .frame(height: 205)
                                .clipped()
                                .overlay(LinearGradient(colors: [.clear, Color.black.opacity(0.92)], startPoint: .top, endPoint: .bottom))
                        } else {
                            LinearGradient(colors: [Color.black, ShinnRed.opacity(0.22), Color.black], startPoint: .topLeading, endPoint: .bottomTrailing)
                                .frame(height: 205)
                        }
                        VStack(alignment: .leading, spacing: 6) {
                            HStack(spacing: 7) {
                                Image(systemName: "crown.fill").foregroundStyle(ShinnRed)
                                Text("APP").font(.caption.bold()).foregroundStyle(ShinnRed)
                            }
                            Text("SHINN CHEAT")
                                .font(.system(size: 35, weight: .black, design: .rounded))
                                .tracking(-1.2)
                            Text("FREE FIRE  •  ALL PATCH  •  ALL DEVICE")
                                .font(.system(size: 9, weight: .bold, design: .rounded))
                                .foregroundStyle(.secondary)
                                .tracking(0.4)
                        }
                        .padding(18)
                    }
                    .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 24, style: .continuous).stroke(ShinnRed.opacity(0.38), lineWidth: 1))
                    .shadow(color: ShinnRed.opacity(0.14), radius: 20, y: 7)
                    .padding(.top, 8)

                    VStack(alignment: .leading, spacing: 12) {
                        Label("Activation key", systemImage: "lock.fill")
                            .font(.headline)

                        SecureField("Enter key manually or use Face ID", text: $keyText)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled(true)
                            .focused($focused)
                            .padding(14)
                            .background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                            .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous).stroke(ShinnRed.opacity(0.20), lineWidth: 0.7))

                        if let err = license.lastError, !err.isEmpty {
                            Text(err).font(.footnote.bold()).foregroundStyle(.red)
                        }

                        if hasSavedKey {
                            Text("No Face ID or broken Face ID? You can still enter your key manually above.")
                                .font(.footnote)
                                .foregroundStyle(.secondary)

                            Button {
                                Task { await biometricUnlock() }
                            } label: {
                                Label("Retry Face ID", systemImage: "faceid")
                                    .font(.system(size: 15, weight: .bold))
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical, 13)
                                    .background(Color.primary.opacity(0.08), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                            }
                            .buttonStyle(.plain)
                            .disabled(license.isBusy || isBiometricRunning)
                        }

                        Button {
                            Task { await submit() }
                        } label: {
                            HStack {
                                if license.isBusy {
                                    ProgressView().tint(Color(.systemBackground))
                                }
                                Text("Activate").font(.system(size: 15, weight: .bold))
                            }
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 13)
                            .background(LinearGradient(colors: [ShinnRed, Color(red: 0.65, green: 0.01, blue: 0.05)], startPoint: .topLeading, endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                            .foregroundStyle(.white)
                        }
                        .buttonStyle(.plain)
                        .disabled(license.isBusy || keyText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                    }
                    .padding(16)
                    .shinnGlass()
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 30)
            }
            .scrollDismissesKeyboard(.interactively)

            VStack {
                Spacer()
                HStack {
                    Spacer()
                    Button {
                        UIApplication.shared.open(AppInfo.telegramLinkURL)
                    } label: {
                        HStack(spacing: 10) {
                            ZStack {
                                Circle()
                                    .fill(Color(red: 0.15, green: 0.65, blue: 0.95))
                                    .frame(width: 44, height: 44)
                                Image(systemName: "paperplane.fill")
                                    .font(.system(size: 18, weight: .bold))
                                    .foregroundStyle(.white)
                                    .offset(x: -1, y: 1)
                            }
                            VStack(alignment: .leading, spacing: 2) {
                                Text(settings.language == .vi ? "Cần hỗ trợ?" : "Need help?")
                                    .font(.system(size: 12, weight: .bold, design: .rounded))
                                    .foregroundStyle(.white)
                                Text("@ShinnThieuu")
                                    .font(.system(size: 11, weight: .semibold, design: .rounded))
                                    .foregroundStyle(.white.opacity(0.7))
                            }
                            .padding(.trailing, 4)
                        }
                        .padding(.leading, 6)
                        .padding(.trailing, 14)
                        .padding(.vertical, 6)
                        .background(Color.white.opacity(0.08), in: Capsule())
                        .overlay(Capsule().stroke(Color.white.opacity(0.14), lineWidth: 0.8))
                    }
                    .buttonStyle(.plain)
                    .padding(.trailing, 18)
                    .padding(.bottom, 28)
                }
            }
        }
        .onAppear {
            keyText = ""
            if hasSavedKey {
                guard !didAutoStartBiometric else { return }
                didAutoStartBiometric = true
                Task { await biometricUnlock() }
            } else {
                DispatchQueue.main.async { focused = true }
            }
        }
    }

    private func quitApp() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) { exit(0) }
    }

    private func biometricUnlock() async {
        guard !isBiometricRunning else { return }
        guard let stored = KeychainKeyStore.load(), !stored.isEmpty else { return }

        isBiometricRunning = true
        defer { isBiometricRunning = false }

        let role = (license.boundRole ?? "").lowercased()
        if role != "owner", let exp = license.expiresAt, exp <= Date() {
            KeychainKeyStore.clear()
            return
        }

        keyText = ""

        let ctx = LAContext()
        var evalError: NSError?
        guard ctx.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &evalError) else {
            license.lastError = "This device has no Face ID / Touch ID."
            return
        }

        do {
            let ok = try await ctx.evaluatePolicy(
                .deviceOwnerAuthenticationWithBiometrics,
                localizedReason: "Scan Face ID to fill your key"
            )
            guard ok else { await handleFaceFail(); return }
            abuse.faceOk()
            license.lastError = nil
            keyText = stored
            await submit()
        } catch let error as LAError {
            switch error.code {
            case .authenticationFailed: await handleFaceFail()
            case .biometryLockout:
                license.lastError = "Face ID locked."
                quitApp()
            case .userCancel, .systemCancel, .appCancel:
                license.lastError = "Cancelled. Tap Retry Face ID."
            default: await handleFaceFail()
            }
        } catch {
            await handleFaceFail()
        }
    }

    private func handleFaceFail() async {
        let n = abuse.faceFailed()
        license.lastError = "Face ID failed (\(n)/3)"
        keyText = ""
        if n >= 3 { quitApp() }
    }

    private func submit() async {
        let raw = keyText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !raw.isEmpty else { return }

        let ok = await license.activate(key: raw, language: .en)
        if ok {
            abuse.keyOk()
            abuse.faceOk()
            KeychainKeyStore.save(raw)
            NotificationCenter.default.post(name: .shinnKeyActivatedLED, object: nil)
        } else {
            abuse.keyFailed()
            if hasSavedKey { keyText = "" }
        }
        guard ok else { return }

        if let rawRole = license.boundRole,
           let role = UserRole(rawValue: rawRole.lowercased()) {
            session.role = role
        } else {
            session.role = .member
        }
    }
}

// ===== RoleGateView =====
struct RoleGateView: View {
    @EnvironmentObject var settings: AppSettings
    @EnvironmentObject var session: Session
    @EnvironmentObject var abuse: AbuseGuard
    @State private var pending: UserRole?
    @State private var password = ""
    @State private var attempts = 0
    @State private var closing = false
    @FocusState private var focused: Bool

    var body: some View {
        ZStack {
            BackgroundView()
            ScreenPrivacyGuard()

            ScrollView(showsIndicators: false) {
                VStack(spacing: 22) {
                    if pending == nil {
                        VStack(spacing: 22) {
                            Image(systemName: "crown.fill").font(.system(size: 46))
                            VStack(spacing: 6) {
                                Text("SHINN CHEAT")
                                    .font(.system(size: 32, weight: .black, design: .rounded))
                                    .tracking(-0.8)
                                Text("Choose a role to activate")
                                    .font(.subheadline)
                                    .foregroundStyle(.secondary)
                            }
                        }
                        .padding(.top, 40)
                    } else {
                        Color.clear.frame(height: 12)
                    }

                    VStack(spacing: 12) {
                        ForEach(UserRole.allCases) { role in
                            roleCard(role)
                        }
                    }
                    .padding(.top, 8)

                    if let role = pending {
                        passwordCard(role)
                    }
                }
                .animation(.easeInOut(duration: 0.2), value: pending)
                .padding(.horizontal, 20)
                .padding(.bottom, 30)
            }
            .scrollDismissesKeyboard(.interactively)
        }
    }

    private func roleCard(_ role: UserRole) -> some View {
        Button(action: { select(role) }) {
            HStack(spacing: 16) {
                IconBox(systemName: role.icon, size: 52)
                Text(role.title).font(.system(size: 20, weight: .bold, design: .rounded))
                Spacer(minLength: 0)
            }
            .padding(14)
            .contentShape(Rectangle())
            .shinnGlass()
        }
        .buttonStyle(.plain)
    }

    private func passwordCard(_ role: UserRole) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Label("Password for " + role.title, systemImage: "lock.fill")
                .font(.headline)

            SecureField("Enter password", text: $password)
                .focused($focused)
                .keyboardType(.numberPad)
                .padding(14)
                .background(Color.primary.opacity(0.08), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                .onSubmit { submit() }
                .disabled(closing)

            if closing {
                Text("Wrong password. The app will close.")
                    .font(.footnote.bold())
                    .foregroundStyle(.red)
            } else if attempts > 0 {
                Text("You are a cow")
                    .font(.footnote.bold())
                    .foregroundStyle(.red)
            }

            HStack(spacing: 10) {
                Button(action: cancel) {
                    Text("Cancel")
                        .font(.system(size: 15, weight: .semibold))
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 13)
                        .background(Color.primary.opacity(0.08), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                }
                .buttonStyle(.plain)

                Button(action: submit) {
                    Text("Confirm")
                        .font(.system(size: 15, weight: .bold))
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 13)
                        .background(
                            LinearGradient(
                                colors: [ShinnRed, ShinnRed.opacity(0.72)],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            ),
                            in: RoundedRectangle(cornerRadius: 14, style: .continuous)
                        )
                        .foregroundStyle(.white)
                        .overlay(
                            RoundedRectangle(cornerRadius: 14, style: .continuous)
                                .stroke(ShinnRed.opacity(0.75), lineWidth: 1)
                        )
                        .shadow(color: ShinnRed.opacity(0.25), radius: 9, y: 3)
                }
                .buttonStyle(.plain)
            }
        }
        .padding(16)
        .shinnGlass()
    }

    private func select(_ role: UserRole) {
        if closing { return }
        if role.needsPassword {
            pending = role
            password = ""
            DispatchQueue.main.async { focused = true }
        } else {
            session.role = role
        }
    }

    private func cancel() {
        if closing { return }
        pending = nil
        password = ""
        focused = false
    }

    private func submit() {
        guard let role = pending, !closing else { return }
        if session.verify(password) {
            session.role = role
            pending = nil
            password = ""
            attempts = 0
            abuse.passOk()
        } else {
            attempts += 1
            password = ""
            abuse.passFailed()
            if attempts >= 5 { focused = false }
        }
    }
}

// ===== OwnerKeyManager =====
struct CreateKeyResponse: Codable {
    let key: String
}

struct ShinnKeyRow: Codable, Identifiable {
    let key: String
    let role: String?
    let expires_at: String?
    let is_vip: Bool?
    let device_id: String?
    let label: String?
    let max_devices: Int?
    let unlimited_devices: Bool?
    let repo_v2_enabled: Bool?
    var id: String { key }
}

@MainActor
final class OwnerKeyManager: ObservableObject {
    @Published var createdKey = ""
    @Published var keys: [ShinnKeyRow] = []
    @Published var isLoading = false
    @Published var error: String?
    @Published var selectedRole = "member"
    @Published var selectedDays = 30
    @Published var selectedHours = 0
    @Published var createCount = 1
    @Published var lifetime = false
    @Published var keyLabel = "Feedback@ShinnThieuu"
    @Published var customKey = ""

    private var actorKey: String {
        UserDefaults.standard.string(forKey: "shinn.license.key")?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
    }
    private var actorRole: String {
        UserDefaults.standard.string(forKey: "shinn.license.role")?.lowercased() ?? ""
    }

    private func actorPayload() -> [String: String] {
        ["p_created_by_key": actorKey, "p_creator_role": actorRole]
    }

    func createKey() async {
        isLoading = true
        error = nil
        defer { isLoading = false }
        do {
            var request = URLRequest(url: SupabaseConfig.createKeyURL)
            request.httpMethod = "POST"
            request.timeoutInterval = 20
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            request.setValue(SupabaseConfig.anonKey, forHTTPHeaderField: "apikey")
            request.setValue("Bearer \(SupabaseConfig.anonKey)", forHTTPHeaderField: "Authorization")
            // Khớp trực tiếp với RPC create_shinn_key hiện tại trên Supabase.
            // RPC dùng p_type / p_duration_days / p_duration_hours, không dùng p_role / p_days / p_hours.
            var body: [String: Any] = actorPayload()
            body["p_type"] = selectedRole == "owner" ? "owner" : (selectedRole == "admin" ? "admin" : "vip")
            body["p_duration_days"] = lifetime ? 0 : (selectedHours == 1 ? 0 : selectedDays)
            body["p_duration_hours"] = lifetime ? 0 : selectedHours
            body["p_label"] = keyLabel.trimmingCharacters(in: .whitespacesAndNewlines)
            body["p_max_devices"] = 1
            body["p_unlimited_devices"] = true
            body["p_repo_v2_enabled"] = false
            body["p_count"] = 1
            let custom = customKey.trimmingCharacters(in: .whitespacesAndNewlines)
            if !custom.isEmpty { body["p_custom_key"] = custom }
            guard !actorKey.isEmpty, !actorRole.isEmpty else {
                error = "Missing active Owner/Admin key."
                return
            }
            request.httpBody = try JSONSerialization.data(withJSONObject: body)
            let (data, response) = try await URLSession.shared.data(for: request)
            let raw = String(decoding: data, as: UTF8.self)
            guard let http = response as? HTTPURLResponse, 200...299 ~= http.statusCode else {
                let code = (response as? HTTPURLResponse)?.statusCode ?? -1
                self.error = "HTTP \(code): \(raw.isEmpty ? "bad response" : raw)"
                return
            }
            // RPCs may return a string array, {key: ...}, {keys: [...]}, or a row object.
            // The label is metadata only; never treat Feedback@ShinnThieuu as the activation key.
            var parsedKeys: [String] = []
            if let list = try? JSONDecoder().decode([String].self, from: data) {
                parsedKeys = list.filter { !$0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
            } else if let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
                let candidates = ["key", "activation_key", "license_key", "generated_key"]
                for name in candidates {
                    if let value = obj[name] as? String, !value.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                        parsedKeys.append(value)
                        break
                    }
                }
                if parsedKeys.isEmpty, let values = obj["keys"] as? [String] {
                    parsedKeys = values
                }
                if parsedKeys.isEmpty, let rows = obj["data"] as? [[String: Any]] {
                    parsedKeys = rows.compactMap { row in
                        for name in candidates { if let value = row[name] as? String, !value.isEmpty { return value } }
                        return nil
                    }
                }
            }
            // create_shinn_key hiện trả về SETOF shinn_keys -> JSON array các object.
            if parsedKeys.isEmpty, let rows = try? JSONSerialization.jsonObject(with: data) as? [[String: Any]] {
                let candidates = ["key", "activation_key", "license_key", "generated_key"]
                parsedKeys = rows.compactMap { row in
                    for name in candidates {
                        if let value = row[name] as? String, !value.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                            return value
                        }
                    }
                    return nil
                }
            }
            if parsedKeys.isEmpty {
                let fallback = String(decoding: data, as: UTF8.self).trimmingCharacters(in: .whitespacesAndNewlines)
                if !fallback.isEmpty, !fallback.contains("Feedback@ShinnThieuu"), !fallback.contains("Could not") {
                    parsedKeys = [fallback.replacingOccurrences(of: "\"", with: "")]
                }
            }
            createdKey = parsedKeys.joined(separator: "\n")
            createdKey = createdKey
                .replacingOccurrences(of: "\\n", with: "\n")
                .replacingOccurrences(of: "\r", with: "")

            // Newly created keys are V1-only by default. Repo V2 is granted explicitly.
            if createdKey.isEmpty { error = "Could not create key" }
            await listKeys()
        } catch {
            if let urlErr = error as? URLError {
                self.error = "Network: \(urlErr.localizedDescription)"
            } else {
                self.error = error.localizedDescription.isEmpty ? "Could not create key" : error.localizedDescription
            }
        }
    }

    var prettyCreated: String {
        createdKey
            .replacingOccurrences(of: "\\n", with: "\n")
            .replacingOccurrences(of: "\r", with: "")
    }

    /// Đồng bộ Repo V2 cho toàn bộ key do Owner đang quản lý.
    func syncAllKeysToV2() async {
        await listKeys()
        await autoGrantRepoV2(for: keys.map(\.key))
        await listKeys()
    }

    /// Explicit V2 grant helper. New keys remain V1-only until this is called.
    private func autoGrantRepoV2(for createdKeys: [String]) async {
        guard !createdKeys.isEmpty else { return }

        let currentActorKey = self.actorKey
        let currentActorRole = self.actorRole.lowercased()
        guard !currentActorKey.isEmpty, currentActorRole == "owner" else { return }

        for key in createdKeys {
            let cleanKey = key.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !cleanKey.isEmpty else { continue }

            do {
                var request = URLRequest(url: SupabaseConfig.addKeyRepoURL)
                request.httpMethod = "POST"
                request.timeoutInterval = 20
                request.setValue("application/json", forHTTPHeaderField: "Content-Type")
                request.setValue("application/json", forHTTPHeaderField: "Accept")
                request.setValue(SupabaseConfig.anonKey, forHTTPHeaderField: "apikey")
                request.setValue("Bearer \(SupabaseConfig.anonKey)", forHTTPHeaderField: "Authorization")

                let ownerLabel = UserDefaults.standard.string(forKey: "shinn.license.holder") ?? "ShinnThieuu"
                let body: [String: Any] = [
                    "p_created_by_key": actorKey,
                    "p_creator_role": actorRole,
                    "p_key": cleanKey,
                    "p_name": AppInfo.repoV2Name,
                    "p_url": AppInfo.repoV2URL.absoluteString,
                    "p_locked": false,
                    "p_label": ownerLabel
                ]
                request.httpBody = try JSONSerialization.data(withJSONObject: body)
                let (data, response) = try await URLSession.shared.data(for: request)

                guard let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode) else {
                    error = "Tạo key thành công nhưng chưa cấp Repo V2 cho \(cleanKey)."
                    continue
                }

                let json = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any]
                if (json?["ok"] as? Bool) != true {
                    error = "Key \(cleanKey) chưa nhận được quyền Repo V2."
                }
            } catch {
                self.error = "Không thể đồng bộ Repo V2 cho key \(cleanKey)."
            }
        }
    }

    func deleteAllKeys() async {
        do {
            var request = URLRequest(url: SupabaseConfig.deleteAllKeysURL)
            request.httpMethod = "POST"
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            request.setValue(SupabaseConfig.anonKey, forHTTPHeaderField: "apikey")
            request.setValue("Bearer \(SupabaseConfig.anonKey)", forHTTPHeaderField: "Authorization")
            guard !actorKey.isEmpty, !actorRole.isEmpty else {
                error = "Missing active Owner/Admin key."
                return
            }
            request.httpBody = try JSONSerialization.data(withJSONObject: actorPayload())
            let (_, response) = try await URLSession.shared.data(for: request)
            guard let http = response as? HTTPURLResponse, 200...299 ~= http.statusCode else {
                error = "Server rejected delete-all request."
                return
            }
            createdKey = ""
            await listKeys()
        } catch {
            self.error = "Could not delete keys"
        }
    }

    func listKeys() async {
        isLoading = true
        defer { isLoading = false }
        do {
            var request = URLRequest(url: SupabaseConfig.listKeysURL)
            request.httpMethod = "POST"
            request.timeoutInterval = 20
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            request.setValue(SupabaseConfig.anonKey, forHTTPHeaderField: "apikey")
            request.setValue("Bearer \(SupabaseConfig.anonKey)", forHTTPHeaderField: "Authorization")
            guard !actorKey.isEmpty, !actorRole.isEmpty else {
                error = "Missing active Owner/Admin key."
                return
            }
            // Khớp SQL list_shinn_keys(p_label, p_created_by_key, p_creator_role)
            var body = actorPayload()
            let holder = UserDefaults.standard.string(forKey: "shinn.license.holder")?
                .trimmingCharacters(in: .whitespacesAndNewlines) ?? actorKey
            body["p_label"] = holder
            request.httpBody = try JSONSerialization.data(withJSONObject: body)
            let (data, response) = try await URLSession.shared.data(for: request)
            let raw = String(decoding: data, as: UTF8.self)
            guard let http = response as? HTTPURLResponse, 200...299 ~= http.statusCode else {
                let code = (response as? HTTPURLResponse)?.statusCode ?? -1
                error = "List keys HTTP \(code): \(raw.prefix(200))"
                return
            }
            // Hỗ trợ cả mảng trực tiếp và { ok, keys: [...] }
            if let decoded = try? JSONDecoder().decode([ShinnKeyRow].self, from: data) {
                keys = decoded
                if !keys.isEmpty { error = nil }
            } else if let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                      let arr = obj["keys"] as? [[String: Any]],
                      let arrData = try? JSONSerialization.data(withJSONObject: arr),
                      let decoded = try? JSONDecoder().decode([ShinnKeyRow].self, from: arrData) {
                keys = decoded
                if !keys.isEmpty { error = nil }
            } else {
                keys = []
                error = "Không parse được danh sách key."
            }
        } catch {
            self.error = "List keys: \(error.localizedDescription)"
        }
    }

    func addTime(to key: String, days: Int, hours: Int) async {
        let cleanKey = key.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleanKey.isEmpty, (days > 0 || hours > 0) else {
            error = "Hãy chọn ít nhất 1 ngày hoặc 1 giờ."
            return
        }
        guard actorRole == "owner" else {
            error = "Chỉ Owner mới được cộng thêm thời gian cho key."
            return
        }
        do {
            var request = URLRequest(url: SupabaseConfig.rpc("add_key_time"))
            request.httpMethod = "POST"
            request.timeoutInterval = 20
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            request.setValue(SupabaseConfig.anonKey, forHTTPHeaderField: "apikey")
            request.setValue("Bearer \(SupabaseConfig.anonKey)", forHTTPHeaderField: "Authorization")
            request.httpBody = try JSONSerialization.data(withJSONObject: [
                "p_key": cleanKey,
                "p_add_days": max(0, days),
                "p_add_hours": max(0, hours),
                "p_created_by_key": actorKey,
                "p_creator_role": actorRole
            ])
            let (data, response) = try await URLSession.shared.data(for: request)
            let raw = String(decoding: data, as: UTF8.self)
            guard let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode) else {
                error = "Cộng thời gian thất bại: HTTP \((response as? HTTPURLResponse)?.statusCode ?? -1) \(raw.prefix(180))"
                return
            }
            error = nil
            await listKeys()
        } catch {
            self.error = "Cộng thời gian: \(error.localizedDescription)"
        }
    }

    func deleteKey(_ key: String) async {
        do {
            var request = URLRequest(url: SupabaseConfig.deleteKeyURL)
            request.httpMethod = "POST"
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            request.setValue(SupabaseConfig.anonKey, forHTTPHeaderField: "apikey")
            request.setValue("Bearer \(SupabaseConfig.anonKey)", forHTTPHeaderField: "Authorization")
            guard !actorKey.isEmpty, !actorRole.isEmpty else {
                error = "Missing active Owner/Admin key."
                return
            }
            if ["NgVuMinhHieuu", "ShinnThieuu"].contains(key) {
                error = "Không xoá được key Owner cố định."
                return
            }
            var body = actorPayload()
            body["p_key"] = key
            request.httpBody = try JSONSerialization.data(withJSONObject: body)
            let (data, response) = try await URLSession.shared.data(for: request)
            guard let http = response as? HTTPURLResponse, 200...299 ~= http.statusCode else {
                error = "Delete failed: \(String(decoding: data, as: UTF8.self).prefix(180))"
                return
            }
            if createdKey.contains(key) {
                createdKey = createdKey
                    .split(separator: "\n")
                    .map(String.init)
                    .filter { $0 != key }
                    .joined(separator: "\n")
            }
            await listKeys()
        } catch {
            self.error = "Could not delete key"
        }
    }
}

// MARK: - Key status indicator
// Test = green, official/member = blue, owner = red.
private struct ShinnKeyStatusBadge: View {
    let row: ShinnKeyRow

    private var normalizedRole: String { (row.role ?? "member").trimmingCharacters(in: .whitespacesAndNewlines).lowercased() }
    private var isOwner: Bool { normalizedRole == "owner" }
    private var isTest: Bool {
        if ["test", "tester", "trial"].contains(normalizedRole) { return true }
        let key = row.key.lowercased()
        return key.hasPrefix("shinn-cheat-app") || key.contains("-test-") || key.hasSuffix("-test")
    }
    private var tint: Color {
        if isOwner { return .red }
        if isTest { return .green }
        return .blue
    }
    private var title: String {
        if isOwner { return "OWNER" }
        if isTest { return "TEST" }
        return "OFFICIAL"
    }

    var body: some View {
        HStack(spacing: 5) {
            Image(systemName: "checkmark.circle.fill")
                .font(.system(size: 13, weight: .black))
            Text(title)
                .font(.system(size: 9, weight: .black, design: .rounded))
                .tracking(0.5)
        }
        .foregroundStyle(tint)
        .padding(.horizontal, 8)
        .padding(.vertical, 4)
        .background(tint.opacity(0.12), in: Capsule())
        .overlay(Capsule().stroke(tint.opacity(0.25), lineWidth: 0.8))
    }
}

private func shinnKeyTimeText(_ raw: String?) -> String {
    guard let raw, !raw.isEmpty else { return "Lifetime" }
    let iso = ISO8601DateFormatter()
    iso.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
    var date = iso.date(from: raw)
    if date == nil {
        iso.formatOptions = [.withInternetDateTime]
        date = iso.date(from: raw)
    }
    guard let date else { return "Expiry unavailable" }
    let remaining = Int(date.timeIntervalSinceNow)
    if remaining <= 0 { return "Expired" }
    let d = remaining / 86400
    let h = (remaining % 86400) / 3600
    let m = (remaining % 3600) / 60
    if d > 0 { return "Remaining: \(d)d \(h)h" }
    if h > 0 { return "Remaining: \(h)h \(m)m" }
    return "Remaining: \(max(1, m))m"
}

// ===== RepositoryManagerView =====
// Repo V2 cố định — Owner chỉ chọn key được phép dùng.
// Key chưa được gán → không nhận repo khi activate.
struct RepositoryManagerView: View {
    private static let fixedRepoName = AppInfo.repoV2Name
    private static let fixedRepoURL  = AppInfo.repoV2URL.absoluteString

    @StateObject private var manager = OwnerKeyManager()
    @State private var selectedKeys: Set<String> = []
    @State private var locked = false
    @State private var status = ""

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                Text("REPOSITORY MANAGER").font(.title.bold())
                Text("Chọn một hoặc nhiều key để gán ShinnCheat Repo V2.")
                    .font(.caption)
                    .foregroundStyle(.secondary)

                VStack(alignment: .leading, spacing: 6) {
                    Text("Repo cố định").font(.caption.bold()).foregroundStyle(.secondary)
                    HStack {
                        Image(systemName: "lock.doc.fill")
                        Text(Self.fixedRepoName).font(.headline.bold())
                        Spacer()
                        Text("V2").font(.caption.bold())
                            .padding(.horizontal, 8).padding(.vertical, 4)
                            .background(Color.green.opacity(0.2), in: Capsule())
                    }
                    Text("URL gắn trên server — key chưa được Owner cấp sẽ không nhận repo.")
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                }
                .padding(14)
                .background(LinearGradient(colors: [Color.white.opacity(0.075), Color.black.opacity(0.42)], startPoint: .topLeading, endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 22, style: .continuous).stroke(LinearGradient(colors: [ShinnRed.opacity(0.72), Color.white.opacity(0.10)], startPoint: .topLeading, endPoint: .bottomTrailing), lineWidth: 1))
                .shadow(color: ShinnRed.opacity(0.14), radius: 18, y: 6)

                Toggle("Lock repo for this key", isOn: $locked)

                Button {
                    Task { await save() }
                } label: {
                    Text(selectedKeys.isEmpty
                         ? "Chọn key bên dưới rồi Save"
                         : "Gán Repo V2 cho \(selectedKeys.count) key")
                        .font(.headline.bold())
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                }
                .buttonStyle(ShinnPremiumButtonStyle())
                .disabled(selectedKeys.isEmpty)

                if !status.isEmpty {
                    Text(status)
                        .font(.footnote)
                        .foregroundStyle(status.contains("✅") ? .green : .red)
                }

                Text("Chọn key được phép dùng ShinnCheat Repo V2")
                    .font(.subheadline.bold())
                    .padding(.top, 4)

                ForEach(manager.keys) { row in
                    Button {
                        if selectedKeys.contains(row.key) { selectedKeys.remove(row.key) } else { selectedKeys.insert(row.key) }
                    } label: {
                        HStack(spacing: 12) {
                            ZStack {
                                Circle()
                                    .fill(selectedKeys.contains(row.key) ? ShinnRed.opacity(0.16) : Color.white.opacity(0.06))
                                    .frame(width: 42, height: 42)
                                Image(systemName: selectedKeys.contains(row.key) ? "checkmark" : "key.fill")
                                    .font(.system(size: 15, weight: .black))
                                    .foregroundStyle(selectedKeys.contains(row.key) ? ShinnRed : .white.opacity(0.55))
                            }
                            VStack(alignment: .leading, spacing: 4) {
                                Text(row.key).font(.system(size: 16, weight: .bold, design: .rounded))
                                Text((row.label ?? "").isEmpty ? (row.role ?? "member") : (row.label ?? ""))
                                    .font(.system(size: 11, weight: .medium, design: .rounded))
                                    .foregroundStyle(.white.opacity(0.48))
                            }
                            Spacer()
                            if selectedKeys.contains(row.key) {
                                Text("SELECTED")
                                    .font(.system(size: 9, weight: .black, design: .rounded))
                                    .tracking(0.5)
                                    .foregroundStyle(ShinnRed)
                            }
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(13)
                        .background(Color.white.opacity(selectedKeys.contains(row.key) ? 0.075 : 0.045), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
                        .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).stroke((selectedKeys.contains(row.key) ? ShinnRed : Color.white).opacity(selectedKeys.contains(row.key) ? 0.55 : 0.08), lineWidth: 0.9))
                        .shadow(color: selectedKeys.contains(row.key) ? ShinnRed.opacity(0.16) : .clear, radius: 12, y: 5)
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding()
        }
        .navigationTitle("Repos")
        .task { await manager.listKeys() }
    }

    func save() async {
        status = "Saving…"
        do {
            var request = URLRequest(url: SupabaseConfig.addKeyRepoURL)
            request.httpMethod = "POST"
            request.timeoutInterval = 20
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            request.setValue("application/json", forHTTPHeaderField: "Accept")
            request.setValue(SupabaseConfig.anonKey, forHTTPHeaderField: "apikey")
            request.setValue("Bearer \(SupabaseConfig.anonKey)", forHTTPHeaderField: "Authorization")

            // Actor thật (key + role đang đăng nhập) — SQL mới xác thực dựa vào đây,
            // KHÔNG còn tin p_label tự khai như trước (tránh giả mạo Owner).
            let actorKey = UserDefaults.standard.string(forKey: "shinn.license.key")?
                .trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
            let actorRole = UserDefaults.standard.string(forKey: "shinn.license.role")?
                .lowercased() ?? ""
            let ownerLabel = UserDefaults.standard.string(forKey: "shinn.license.holder")?
                .trimmingCharacters(in: .whitespacesAndNewlines) ?? ""

            guard !actorKey.isEmpty, actorRole == "owner",
                  ["ShinnThieuu", "NgVuMinhHieuu"].contains(ownerLabel) else {
                status = "❌ Only Owner can grant Repo V2."
                return
            }

            let keysToSave = selectedKeys
                .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
                .filter { !$0.isEmpty }
                .sorted()

            guard !keysToSave.isEmpty else {
                status = "❌ Chọn ít nhất 1 key trong list."
                return
            }

            var successCount = 0
            for key in keysToSave {
                var req = request
                let body: [String: Any] = [
                    "p_created_by_key": actorKey,
                    "p_creator_role": actorRole,
                    "p_key": key,
                    "p_name": Self.fixedRepoName,
                    "p_url": Self.fixedRepoURL,
                    "p_locked": locked,
                    "p_label": ownerLabel
                ]
                req.httpBody = try JSONSerialization.data(withJSONObject: body)

                let (data, response) = try await URLSession.shared.data(for: req)
                guard let http = response as? HTTPURLResponse else {
                    status = "❌ No response from Supabase."
                    return
                }

                let raw = String(decoding: data, as: UTF8.self)
                print("[add_key_repo] key=\(key) status=\(http.statusCode) body=\(raw)")

                guard (200...299).contains(http.statusCode) else {
                    status = "❌ Key \(key): HTTP \(http.statusCode)"
                    return
                }

                let parsed = try? JSONSerialization.jsonObject(with: data)
                let json = parsed as? [String: Any]
                let ok = json?["ok"] as? Bool ?? false

                if ok {
                    successCount += 1
                } else {
                    let err = json?["error"] as? String ?? "unknown"
                    status = "❌ Key \(key): \(err)"
                    return
                }
            }

            status = "✅ Đã gán ShinnCheat Repo V2 cho \(successCount) key"
            await manager.listKeys()
        } catch {
            status = "❌ Failed: \(error.localizedDescription)"
        }
    }
}

// ===== OwnerPanelView =====
struct OwnerPanelView: View {
    @EnvironmentObject var license: LicenseManager
    @EnvironmentObject var session: Session
    @StateObject private var manager = OwnerKeyManager()
    @State private var copied = false
    @State private var announceTitle = "Shinn Cheat"
    @State private var announceBody = ""
    @State private var announceStatus = ""
    @State private var announceSending = false

    private let durations = [1, 3, 7, 30, 90, 365]

    var body: some View {
        ZStack {
            BackgroundView()
            ScrollView(showsIndicators: false) {
                VStack(spacing: 16) {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("OWNER PANEL").font(.system(size: 28, weight: .black, design: .rounded))
                        Text("Create keys, set role and duration, delete keys")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)

                    VStack(alignment: .leading, spacing: 14) {
                        Text("Assigned to (tên người dùng)").font(.headline)
                        TextField("NgVuMinhHieuu / ShinnThieuu / tên khác", text: $manager.keyLabel)
                            .padding(12)
                            .background(Color.primary.opacity(0.08), in: RoundedRectangle(cornerRadius: 12, style: .continuous))

                        Text("Custom key (tuỳ chọn)").font(.headline)
                        TextField("Để trống = server tự tạo key", text: $manager.customKey)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled(true)
                            .padding(12)
                            .background(Color.primary.opacity(0.08), in: RoundedRectangle(cornerRadius: 12, style: .continuous))

                        Text("Role").font(.headline)
                        Picker("Role", selection: $manager.selectedRole) {
                            Text("Member").tag("member")
                            Text("Admin").tag("admin")
                        }
                        .pickerStyle(.segmented)

                        Text("Duration").font(.headline)
                        Picker("Duration", selection: $manager.selectedHours) {
                            Text("1 hour (Test)").tag(1)
                            Text("Use days").tag(0)
                        }
                        .pickerStyle(.segmented)
                        .onChange(of: manager.selectedHours) { v in
                            if v == 1 { manager.lifetime = false }
                        }

                        if manager.selectedHours == 0 {
                            Toggle("Lifetime / unlimited", isOn: $manager.lifetime)
                            if !manager.lifetime {
                                Picker("Days", selection: $manager.selectedDays) {
                                    ForEach(durations, id: \.self) { d in
                                        Text(d == 365 ? "1 year" : "\(d) days").tag(d)
                                    }
                                }
                                .pickerStyle(.menu)
                            }
                        } else {
                            Text("Key name: Shinn-Cheat-TestN")
                                .font(.caption)
                                .foregroundStyle(.secondary)

                            Button {
                                Task {
                                    copied = false
                                    manager.selectedHours = 1
                                    manager.lifetime = false
                                    manager.selectedRole = "member"
                                    manager.customKey = "Shinn-Test"
                                    manager.createCount = 99
                                    await manager.createKey()
                                }
                            } label: {
                                Label("Tạo 99 key test Shinn-Test-1..99 (1h)", systemImage: "wand.and.stars")
                                    .font(.caption.bold())
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical, 10)
                            }
                            .buttonStyle(.plain)
                            .background(Color.primary.opacity(0.08), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                            .disabled(manager.isLoading)
                        }

                        Stepper("How many: \(manager.createCount)", value: $manager.createCount, in: 1...99)

                        if manager.createdKey.isEmpty {
                            Text("No key created yet")
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        } else {
                            Text(manager.prettyCreated)
                                .font(.system(.body, design: .monospaced).weight(.bold))
                                .textSelection(.enabled)
                            Button {
                                UIPasteboard.general.string = manager.prettyCreated
                                copied = true
                            } label: {
                                Label(copied ? "Copied" : "Copy", systemImage: copied ? "checkmark" : "doc.on.doc")
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical, 12)
                            }
                            .buttonStyle(.plain)
                            .background(Color.primary.opacity(0.08), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                        }

                        Button {
                            Task {
                                copied = false
                                await manager.createKey()
                            }
                        } label: {
                            Group {
                                if manager.isLoading {
                                    ProgressView().tint(Color(.systemBackground))
                                } else {
                                    Text("CREATE KEY")
                                        .font(.system(size: 16, weight: .bold, design: .rounded))
                                }
                            }
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 15)
                            .background(Color.primary, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                            .foregroundStyle(Color(.systemBackground))
                        }
                        .buttonStyle(.plain)
                        .disabled(manager.isLoading)

                        if let error = manager.error {
                            Text(error).font(.caption.bold()).foregroundStyle(.red)
                        }
                    }
                    .padding(16)
                    .shinnGlass()

                    // —— Gửi thông báo tới tất cả key ——
                    VStack(alignment: .leading, spacing: 12) {
                        HStack {
                            Image(systemName: "bell.badge.fill")
                                .foregroundStyle(ShinnRed)
                            Text("Thông báo tất cả key")
                                .font(.headline)
                        }
                        Text("Mọi user đang mở app (hoặc mở lại app) sẽ thấy banner.")
                            .font(.caption)
                            .foregroundStyle(.secondary)

                        TextField("Tiêu đề", text: $announceTitle)
                            .padding(12)
                            .background(Color.primary.opacity(0.08), in: RoundedRectangle(cornerRadius: 12, style: .continuous))

                        TextField("Nội dung thông báo…", text: $announceBody, axis: .vertical)
                            .lineLimit(3...6)
                            .padding(12)
                            .background(Color.primary.opacity(0.08), in: RoundedRectangle(cornerRadius: 12, style: .continuous))

                        Button {
                            Task { await sendAnnouncement() }
                        } label: {
                            HStack {
                                if announceSending {
                                    ProgressView().tint(.white)
                                } else {
                                    Image(systemName: "paperplane.fill")
                                }
                                Text(announceSending ? "Đang gửi…" : "GỬI TẤT CẢ KEY")
                                    .font(.system(size: 15, weight: .bold, design: .rounded))
                            }
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 14)
                            .background(ShinnRed, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                            .foregroundStyle(.white)
                        }
                        .buttonStyle(.plain)
                        .disabled(announceSending || announceBody.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)

                        if !announceStatus.isEmpty {
                            Text(announceStatus)
                                .font(.caption.bold())
                                .foregroundStyle(announceStatus.contains("Đã gửi") ? .green : .secondary)
                        }
                    }
                    .padding(16)
                    .shinnGlass()

                    VStack(alignment: .leading, spacing: 12) {
                        HStack {
                            Text("Key đã tạo (\(manager.keys.count))")
                                .font(.headline)
                            Spacer()
                            Button {
                                Task { await manager.listKeys() }
                            } label: {
                                Label(manager.isLoading ? "…" : "Refresh", systemImage: "arrow.clockwise")
                                    .font(.caption.bold())
                            }
                            .buttonStyle(.plain)
                            .disabled(manager.isLoading)
                        }

                        if manager.keys.isEmpty {
                            Text(manager.isLoading ? "Đang tải…" : "Chưa có key / chưa load được")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        } else {
                            ForEach(manager.keys) { row in
                                VStack(alignment: .leading, spacing: 8) {
                                    HStack(alignment: .top) {
                                        VStack(alignment: .leading, spacing: 3) {
                                            Text(row.key)
                                                .font(.system(.footnote, design: .monospaced).weight(.bold))
                                                .textSelection(.enabled)
                                            HStack(spacing: 6) {
                                                ShinnKeyStatusBadge(row: row)
                                                if let label = row.label, !label.isEmpty {
                                                    Text(label)
                                                        .font(.caption2)
                                                        .foregroundStyle(.secondary)
                                                        .lineLimit(1)
                                                }
                                            }
                                            HStack(spacing: 6) {
                                                Image(systemName: "clock.fill")
                                                    .font(.system(size: 9, weight: .bold))
                                                    .foregroundStyle(.secondary)
                                                Text(shinnKeyTimeText(row.expires_at))
                                                    .font(.caption2.weight(.semibold))
                                                    .foregroundStyle(.secondary)
                                            }
                                            if let did = row.device_id, !did.isEmpty {
                                                Text("Device: \(did.prefix(12))…")
                                                    .font(.caption2)
                                                    .foregroundStyle(.tertiary)
                                            }
                                        }
                                        Spacer(minLength: 8)
                                        VStack(spacing: 6) {
                                            Button {
                                                UIPasteboard.general.string = row.key
                                            } label: {
                                                Image(systemName: "doc.on.doc")
                                                    .font(.caption.bold())
                                                    .frame(width: 32, height: 32)
                                                    .background(Color.primary.opacity(0.08), in: Circle())
                                            }
                                            .buttonStyle(.plain)

                                            if session.role == .owner,
                                               !["NgVuMinhHieuu", "ShinnThieuu"].contains(row.key) {
                                                Button {
                                                    Task { await manager.deleteKey(row.key) }
                                                } label: {
                                                    Image(systemName: "trash")
                                                        .font(.caption.bold())
                                                        .foregroundStyle(.red)
                                                        .frame(width: 32, height: 32)
                                                        .background(Color.red.opacity(0.12), in: Circle())
                                                }
                                                .buttonStyle(.plain)
                                            }
                                        }
                                    }
                                }
                                .padding(12)
                                .background(Color.primary.opacity(0.05), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                            }
                        }
                    }
                    .padding(16)
                    .shinnGlass()

                    if session.role == .owner {
                        Button {
                            Task { await manager.deleteAllKeys() }
                        } label: {
                            Label("Delete all keys", systemImage: "trash")
                                .font(.subheadline.bold())
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 12)
                                .foregroundStyle(.red)
                        }
                        .buttonStyle(.plain)
                    }

                    if session.role == .owner {
                        NavigationLink(value: Route.patchProjects) {
                            Label("Tạo Patch (3105)", systemImage: "plus.app.fill")
                                .font(.subheadline.bold())
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 13)
                                .background(Color.primary, in: RoundedRectangle(cornerRadius: 15, style: .continuous))
                                .foregroundStyle(Color(.systemBackground))
                        }
                        .buttonStyle(.plain)

                        NavigationLink(value: Route.patchBuilder) {
                            Label("Xuất JSON repo", systemImage: "doc.text")
                                .font(.subheadline.bold())
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 12)
                        }
                        .buttonStyle(.plain)

                        NavigationLink(value: Route.cleanup) {
                            Label("Dọn dẹp máy", systemImage: "trash.circle.fill")
                                .font(.subheadline.bold())
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 12)
                                .foregroundStyle(.orange)
                        }
                        .buttonStyle(.plain)
                    }

                    Button {
                        session.role = nil
                        license.signOutLicense()
                    } label: {
                        Label("Sign out / Change key", systemImage: "rectangle.portrait.and.arrow.right")
                            .font(.subheadline.bold())
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 12)
                    }
                    .buttonStyle(.plain)
                }
                .padding(.horizontal, 18)
                .padding(.vertical, 16)
            }
        }
        .navigationTitle("Owner")
        .navigationBarTitleDisplayMode(.inline)
        .task { await manager.listKeys() }
    }

    private func sendAnnouncement() async {
        let body = announceBody.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !body.isEmpty else { return }
        announceSending = true
        announceStatus = "Đang gửi…"
        defer { announceSending = false }
        let title = announceTitle.trimmingCharacters(in: .whitespacesAndNewlines)
        let ok = await AnnouncementStore.broadcast(
            title: title.isEmpty ? "Shinn Cheat" : title,
            body: body,
            actorKey: license.savedLicenseKey
        )
        if ok {
            announceStatus = "Đã gửi — user sẽ thấy khi mở / đang dùng app"
            announceBody = ""
        } else {
            announceStatus = "Gửi thất bại — kiểm tra RPC broadcast_announcement trên Supabase"
        }
    }
}

// ===== PatchBuilderView (Enhanced, Owner only, preset FF Max / FF) =====
struct PatchBuilderView: View {
    @EnvironmentObject var session: Session
    @State private var identifier = ""
    @State private var name = ""
    @State private var author = "Shinn Cheat"
    @State private var version = "3105"
    @State private var summary = ""
    @State private var description = "1. Bật Patch trong app\n2. Mở game\n3. Kiểm tra hiệu ứng"
    @State private var category = "Patch"
    @State private var tags = ""
    @State private var download = ""
    @State private var sha256 = ""
    @State private var size = ""
    @State private var icon = "https://raw.githubusercontent.com/ShinnCheatCode/Mhieuu/main/IMG_0621.jpeg"
    @State private var patchPath = ""
    @State private var openURL = ""
    @State private var copied = false
    @State private var saved = false

    @State private var showImporter = false
    @State private var isHashing = false
    @State private var hashError: String?
    @State private var isTestingURL = false
    @State private var urlTestStatus: String?
    @State private var urlTestOK = false
    @State private var localPackageURL: URL?
    @State private var isLocalTesting = false
    @State private var localTestStatus: String?
    @State private var localTestOK = false
    @State private var drafts: [PatchDraft] = PatchDraft.loadAll()
    @State private var showDrafts = false
    @State private var shareURL: URL?
    @State private var selectedPreset: PresetBundle?

    struct PresetBundle: Identifiable, Hashable {
        let id: String
        let label: String
        let bundleID: String
        let openURL: String
        let category: String
        let tags: String

        static let all: [PresetBundle] = [
            PresetBundle(id: "ffmax", label: "Free Fire Max", bundleID: "com.dts.freefiremax", openURL: "freefiremax://", category: "Free Fire Max", tags: "Free Fire Max, Patch"),
            PresetBundle(id: "ffth", label: "Free Fire", bundleID: "com.dts.freefireth", openURL: "freefire://", category: "Free Fire", tags: "Free Fire, Patch")
        ]
    }

    private var isOwner: Bool { session.role == .owner }

    struct PatchDraft: Identifiable, Codable {
        var id = UUID()
        var identifier: String
        var json: String
        var savedAt: Date

        static func loadAll() -> [PatchDraft] {
            guard let data = UserDefaults.standard.data(forKey: "shinn.patch.drafts"),
                  let list = try? JSONDecoder().decode([PatchDraft].self, from: data) else { return [] }
            return list
        }
        static func saveAll(_ list: [PatchDraft]) {
            if let data = try? JSONEncoder().encode(list) {
                UserDefaults.standard.set(data, forKey: "shinn.patch.drafts")
            }
        }
    }

    private var normalizedHash: String {
        sha256.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
    }
    private var hashIsValid: Bool {
        normalizedHash.isEmpty || (normalizedHash.count == 64 && normalizedHash.allSatisfy { $0.isHexDigit })
    }

    private var generated: String {
        var object: [String: Any] = [
            "identifier": identifier.trimmingCharacters(in: .whitespacesAndNewlines),
            "name": name.trimmingCharacters(in: .whitespacesAndNewlines),
            "download": download.trimmingCharacters(in: .whitespacesAndNewlines)
        ]

        func put(_ key: String, _ value: String) {
            let v = value.trimmingCharacters(in: .whitespacesAndNewlines)
            if !v.isEmpty { object[key] = v }
        }

        put("author", author)
        put("version", version)
        put("summary", summary)
        put("description", description)
        put("category", category)
        put("icon", icon)
        put("patchPath", patchPath)
        put("openURL", openURL)

        let parsedTags = tags.split(separator: ",").map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }.filter { !$0.isEmpty }
        if !parsedTags.isEmpty { object["tags"] = parsedTags }

        if let n = Int(size.trimmingCharacters(in: .whitespacesAndNewlines)), n >= 0 {
            object["size"] = n
        }
        if !normalizedHash.isEmpty { object["sha256"] = normalizedHash }

        guard let data = try? JSONSerialization.data(withJSONObject: object, options: [.prettyPrinted, .sortedKeys]) else { return "{}" }
        return String(data: data, encoding: .utf8) ?? "{}"
    }

    private var valid: Bool {
        isOwner &&
        !identifier.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty &&
        !name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty &&
        !download.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty &&
        hashIsValid
    }

    var body: some View {
        Group {
            if !isOwner {
                VStack(spacing: 14) {
                    Image(systemName: "lock.fill").font(.system(size: 44, weight: .semibold)).foregroundStyle(.secondary)
                    Text("Owner only").font(.title3.bold())
                    Text("Only the Owner can create patch entries.")
                        .font(.subheadline).foregroundStyle(.secondary)
                        .multilineTextAlignment(.center).padding(.horizontal, 30)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .padding(40)
            } else {
                ScrollView(showsIndicators: false) {
                    VStack(alignment: .leading, spacing: 14) {
                        VStack(alignment: .leading, spacing: 5) {
                            Text("CREATE PATCH").font(.system(size: 28, weight: .black, design: .rounded))
                            Text("Import .3105 từ Files → Test trên máy → Copy JSON up repo. Không cần app 3105 riêng.")
                                .font(.subheadline).foregroundStyle(.secondary)
                        }

                        formSection("Preset Bundle ID") {
                            HStack(spacing: 10) {
                                ForEach(PresetBundle.all) { preset in
                                    Button { applyPreset(preset) } label: {
                                        VStack(spacing: 6) {
                                            Image(systemName: preset.id == "ffmax" ? "sparkles" : "flame.fill").font(.title3)
                                            Text(preset.label).font(.caption.bold())
                                            Text(preset.bundleID).font(.caption2.monospaced())
                                                .foregroundStyle(.secondary).lineLimit(1).minimumScaleFactor(0.6)
                                        }
                                        .frame(maxWidth: .infinity)
                                        .padding(.vertical, 12)
                                        .background((selectedPreset == preset ? Color.primary : Color.primary.opacity(0.08)), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                                        .foregroundStyle(selectedPreset == preset ? Color(.systemBackground) : Color.primary)
                                    }
                                    .buttonStyle(.plain)
                                }
                            }
                        }

                        HStack(spacing: 10) {
                            Button { showImporter = true } label: {
                                Label(isHashing ? "Đang tính…" : "Import .3105", systemImage: "doc.badge.plus")
                                    .font(.subheadline.bold()).frame(maxWidth: .infinity).padding(.vertical, 12)
                                    .background(Color.primary.opacity(0.08), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                            }
                            .buttonStyle(.plain).disabled(isHashing)

                            Button { Task { await testDownloadURL() } } label: {
                                Label(isTestingURL ? "Đang test…" : "Test URL", systemImage: "network")
                                    .font(.subheadline.bold()).frame(maxWidth: .infinity).padding(.vertical, 12)
                                    .background(Color.primary.opacity(0.08), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                            }
                            .buttonStyle(.plain).disabled(isTestingURL || download.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                        }

                        HStack(spacing: 10) {
                            Button {
                                Task { await testApplyLocal() }
                            } label: {
                                Label(isLocalTesting ? "Đang apply…" : "Test Apply", systemImage: "bolt.fill")
                                    .font(.subheadline.bold()).frame(maxWidth: .infinity).padding(.vertical, 12)
                                    .background(Color.green.opacity(0.18), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                                    .foregroundStyle(.green)
                            }
                            .buttonStyle(.plain)
                            .disabled(isLocalTesting || localPackageURL == nil)

                            Button {
                                Task { await testRestoreLocal() }
                            } label: {
                                Label("Restore", systemImage: "arrow.uturn.backward")
                                    .font(.subheadline.bold()).frame(maxWidth: .infinity).padding(.vertical, 12)
                                    .background(Color.orange.opacity(0.18), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                                    .foregroundStyle(.orange)
                            }
                            .buttonStyle(.plain)
                            .disabled(isLocalTesting || localPackageURL == nil)
                        }

                        if localPackageURL != nil {
                            Text("Đã import: \(localPackageURL!.lastPathComponent)")
                                .font(.caption2)
                                .foregroundStyle(.secondary)
                        }
                        if let hashError { Text(hashError).font(.caption.bold()).foregroundStyle(.red) }
                        if let urlTestStatus { Text(urlTestStatus).font(.caption.bold()).foregroundStyle(urlTestOK ? .green : .red) }
                        if let localTestStatus {
                            Text(localTestStatus)
                                .font(.caption.bold())
                                .foregroundStyle(localTestOK ? .green : .red)
                        }

                        formSection("Thông tin cơ bản") {
                            field("Identifier", text: $identifier, placeholder: "com.shinn.patchname")
                            field("Name", text: $name, placeholder: "Patch name")
                            field("Author", text: $author, placeholder: "Shinn")
                            field("Version", text: $version, placeholder: "3105")
                            field("Category", text: $category, placeholder: "Free Fire Max / Free Fire / Patch")
                            field("Tags", text: $tags, placeholder: "Free Fire Max, Patch")
                        }

                        formSection("File") {
                            field("Download URL", text: $download, placeholder: "https://raw.githubusercontent.com/...")
                            field("SHA-256", text: $sha256, placeholder: "64 ký tự hex")
                            if !hashIsValid {
                                Text("SHA256 phải là 64 ký tự hex").font(.caption2.bold()).foregroundStyle(.red)
                            }
                            field("Size (bytes)", text: $size, placeholder: "1048576")
                        }

                        formSection("Hiển thị (tuỳ chọn)") {
                            field("Summary", text: $summary, placeholder: "Mô tả ngắn")
                            field("Cách sử dụng / ghi chú", text: $description, placeholder: "Bật patch → mở game → …")
                            field("Icon / ảnh patch (URL)", text: $icon, placeholder: "https://raw.githubusercontent.com/.../icon.png")
                            field("Patch path", text: $patchPath, placeholder: "relative/path")
                            field("Open URL", text: $openURL, placeholder: "freefire:// hoặc freefiremax://")
                        }

                        Button {
                            UIPasteboard.general.string = generated
                            copied = true
                            saved = false
                        } label: {
                            Label(copied ? "Đã copy JSON" : "Copy JSON", systemImage: copied ? "checkmark" : "doc.on.doc")
                                .font(.headline).frame(maxWidth: .infinity).padding(.vertical, 14)
                                .background(Color.primary, in: RoundedRectangle(cornerRadius: 15, style: .continuous))
                                .foregroundStyle(Color(.systemBackground))
                        }
                        .buttonStyle(.plain).disabled(!valid)

                        HStack(spacing: 10) {
                            Button { saveDraft() } label: {
                                Label(saved ? "Đã lưu" : "Lưu draft", systemImage: saved ? "checkmark.circle" : "square.and.arrow.down")
                                    .frame(maxWidth: .infinity).padding(.vertical, 13)
                                    .background(Color.primary.opacity(0.08), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                            }
                            .buttonStyle(.plain).disabled(!valid)

                            if let shareURL {
                                ShareLink(item: shareURL) {
                                    Label("Share", systemImage: "square.and.arrow.up")
                                        .frame(maxWidth: .infinity).padding(.vertical, 13)
                                        .background(Color.primary.opacity(0.08), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                                }
                            } else {
                                Button { exportJSON() } label: {
                                    Label("Export", systemImage: "square.and.arrow.up")
                                        .frame(maxWidth: .infinity).padding(.vertical, 13)
                                        .background(Color.primary.opacity(0.08), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                                }
                                .buttonStyle(.plain).disabled(!valid)
                            }
                        }

                        if !drafts.isEmpty {
                            formSection("Drafts (\(drafts.count))") {
                                Button { showDrafts.toggle() } label: {
                                    HStack {
                                        Text(showDrafts ? "Ẩn drafts" : "Xem drafts")
                                        Spacer()
                                        Image(systemName: showDrafts ? "chevron.up" : "chevron.down")
                                    }
                                    .font(.subheadline.bold())
                                }
                                .buttonStyle(.plain)

                                if showDrafts {
                                    ForEach(drafts) { d in
                                        Button { loadDraft(d) } label: {
                                            HStack {
                                                VStack(alignment: .leading, spacing: 2) {
                                                    Text(d.identifier).font(.footnote.bold())
                                                    Text(d.savedAt.formatted(date: .abbreviated, time: .shortened))
                                                        .font(.caption2).foregroundStyle(.secondary)
                                                }
                                                Spacer()
                                                Image(systemName: "arrow.down.doc")
                                            }
                                            .padding(.vertical, 6)
                                        }
                                        .buttonStyle(.plain)
                                    }

                                    Button(role: .destructive) {
                                        drafts.removeAll()
                                        PatchDraft.saveAll(drafts)
                                    } label: {
                                        Label("Xoá tất cả drafts", systemImage: "trash").font(.caption.bold())
                                    }
                                    .buttonStyle(.plain)
                                }
                            }
                        }

                        VStack(alignment: .leading, spacing: 8) {
                            Text("Generated JSON").font(.headline)
                            ScrollView(.horizontal, showsIndicators: false) {
                                Text(generated)
                                    .font(.system(.caption, design: .monospaced))
                                    .textSelection(.enabled)
                                    .padding(12)
                            }
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .background(Color.primary.opacity(0.06), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                        }
                    }
                    .padding(18)
                }
            }
        }
        .navigationTitle("Create Patch")
        .navigationBarTitleDisplayMode(.inline)
        .sheet(isPresented: $showImporter) {
            ShinnDocumentPicker(
                allowsMultipleSelection: false,
                onSelection: { result in
                    showImporter = false
                    if case .success(let urls) = result, let url = urls.first {
                        Task { await importPackage(url) }
                    }
                },
                onCancel: { showImporter = false }
            )
            .ignoresSafeArea()
        }
    }

    private func applyPreset(_ preset: PresetBundle) {
        selectedPreset = preset
        identifier = "com.shinn.\(preset.id).patch"
        if name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            name = "\(preset.label) Patch"
        }
        category = preset.category
        tags = preset.tags
        openURL = preset.openURL
        if summary.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            summary = "\(preset.label) patch"
        }
    }

    @ViewBuilder
    private func formSection<Content: View>(_ title: String, @ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(title).font(.headline)
            content()
        }
        .padding(15)
        .shinnGlass()
    }

    private func field(_ title: String, text: Binding<String>, placeholder: String) -> some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(title).font(.caption.bold()).foregroundStyle(.secondary)
            TextField(placeholder, text: text)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled(true)
                .padding(12)
                .background(Color.primary.opacity(0.07), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
        }
    }

    private func importPackage(_ url: URL) async {
        isHashing = true
        hashError = nil
        localTestStatus = nil
        localPackageURL = nil
        defer { isHashing = false }

        let hasAccess = url.startAccessingSecurityScopedResource()
        defer { if hasAccess { url.stopAccessingSecurityScopedResource() } }

        do {
            let data = try Data(contentsOf: url, options: .mappedIfSafe)
            // Kiểm tra gói .3105 hợp lệ (nếu codec có sẵn)
            do {
                let summary = try PatchPackageCodec.inspect(data)
                if summary.isPasswordProtected {
                    hashError = "Gói .3105 có mật khẩu — chưa hỗ trợ test local."
                }
            } catch {
                // Không chặn: vẫn cho import để hash + JSON
            }

            size = "\(data.count)"
            let digest = SHA256.hash(data: data)
            sha256 = digest.map { String(format: "%02x", $0) }.joined()

            // Lưu bản local để Test Apply (không cần URL)
            let dir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
                .appendingPathComponent("ShinnOwnerImports", isDirectory: true)
            try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
            let dest = dir.appendingPathComponent(url.lastPathComponent)
            if FileManager.default.fileExists(atPath: dest.path) {
                try? FileManager.default.removeItem(at: dest)
            }
            try data.write(to: dest, options: .atomic)
            localPackageURL = dest

            if identifier.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                let base = url.deletingPathExtension().lastPathComponent
                identifier = "com.shinn." + base
                    .lowercased()
                    .folding(options: .diacriticInsensitive, locale: .current)
                    .replacingOccurrences(of: " ", with: "")
            }
            if name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                name = url.deletingPathExtension().lastPathComponent
            }
            localTestStatus = "Đã import. Bấm Test Apply để thử trên máy."
            localTestOK = true
        } catch {
            hashError = "Không đọc được file: \(error.localizedDescription)"
            localTestOK = false
        }
    }

    private func testApplyLocal() async {
        guard let fileURL = localPackageURL else {
            localTestStatus = "Chưa import file .3105"
            localTestOK = false
            return
        }
        isLocalTesting = true
        localTestStatus = "Đang apply…"
        defer { isLocalTesting = false }
        do {
            let data = try Data(contentsOf: fileURL, options: .mappedIfSafe)
            let summary = try PatchPackageCodec.inspect(data)
            if summary.isPasswordProtected {
                localTestStatus = "Gói có mật khẩu — không apply được."
                localTestOK = false
                return
            }
            let project = try PatchPackageCodec.decode(data, password: nil).project
            _ = try DevicePatchService.apply(project: project)
            localTestStatus = "Apply OK — kiểm tra trong game rồi Restore nếu cần."
            localTestOK = true
            // Mở app đích nếu có openURL
            let raw = openURL.trimmingCharacters(in: .whitespacesAndNewlines)
            if !raw.isEmpty, let u = URL(string: raw) {
                await MainActor.run { UIApplication.shared.open(u) }
            }
        } catch {
            localTestStatus = "Apply lỗi: \(error.localizedDescription)"
            localTestOK = false
        }
    }

    private func testRestoreLocal() async {
        guard let fileURL = localPackageURL else {
            localTestStatus = "Chưa import file .3105"
            localTestOK = false
            return
        }
        isLocalTesting = true
        localTestStatus = "Đang restore…"
        defer { isLocalTesting = false }
        do {
            let data = try Data(contentsOf: fileURL, options: .mappedIfSafe)
            let project = try PatchPackageCodec.decode(data, password: nil).project
            guard let receipt = DevicePatchService.latestReceipt(projectID: project.id) else {
                localTestStatus = "Không có receipt để restore."
                localTestOK = false
                return
            }
            try DevicePatchService.restore(receipt: receipt)
            localTestStatus = "Restore OK."
            localTestOK = true
        } catch {
            localTestStatus = "Restore lỗi: \(error.localizedDescription)"
            localTestOK = false
        }
    }

    private func testDownloadURL() async {
        let raw = download.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let url = URL(string: raw), url.scheme != nil else {
            urlTestStatus = "URL không hợp lệ"
            urlTestOK = false
            return
        }
        isTestingURL = true
        urlTestStatus = nil
        defer { isTestingURL = false }

        var request = URLRequest(url: url)
        request.httpMethod = "HEAD"
        request.timeoutInterval = 15

        do {
            let (_, response) = try await URLSession.shared.data(for: request)
            guard let http = response as? HTTPURLResponse else {
                urlTestStatus = "Không có phản hồi"
                urlTestOK = false
                return
            }
            if (200..<300).contains(http.statusCode) {
                let len = http.value(forHTTPHeaderField: "Content-Length") ?? "?"
                urlTestStatus = "OK — HTTP \(http.statusCode), size=\(len)"
                urlTestOK = true
            } else {
                urlTestStatus = "HTTP \(http.statusCode)"
                urlTestOK = false
            }
        } catch {
            urlTestStatus = "Lỗi: \(error.localizedDescription)"
            urlTestOK = false
        }
    }

    private func saveDraft() {
        let draft = PatchDraft(identifier: identifier.trimmingCharacters(in: .whitespacesAndNewlines), json: generated, savedAt: Date())
        drafts.removeAll { $0.identifier == draft.identifier }
        drafts.insert(draft, at: 0)
        if drafts.count > 20 { drafts = Array(drafts.prefix(20)) }
        PatchDraft.saveAll(drafts)
        saved = true
        copied = false
    }

    private func loadDraft(_ draft: PatchDraft) {
        guard let data = draft.json.data(using: .utf8),
              let dict = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { return }

        identifier = dict["identifier"] as? String ?? ""
        name = dict["name"] as? String ?? ""
        author = dict["author"] as? String ?? ""
        version = dict["version"] as? String ?? "3105"
        summary = dict["summary"] as? String ?? ""
        description = dict["description"] as? String ?? ""
        category = dict["category"] as? String ?? "Patch"
        download = dict["download"] as? String ?? ""
        sha256 = dict["sha256"] as? String ?? ""
        size = (dict["size"] as? Int).map { "\($0)" } ?? ""
        icon = dict["icon"] as? String ?? ""
        patchPath = dict["patchPath"] as? String ?? ""
        openURL = dict["openURL"] as? String ?? ""
        if let tagList = dict["tags"] as? [String] {
            tags = tagList.joined(separator: ", ")
        }
        showDrafts = false
    }

    private func exportJSON() {
        let tmp = FileManager.default.temporaryDirectory
            .appendingPathComponent("\(identifier.isEmpty ? "patch" : identifier).json")
        do {
            try generated.write(to: tmp, atomically: true, encoding: .utf8)
            shareURL = tmp
        } catch {
            hashError = "Không export được: \(error.localizedDescription)"
        }
    }
} // ===== Placeholder views (tối giản để build pass) =====


// ===== Avatar (mọi key đều đổi được) =====
enum ProfileAvatarStore {
    private static var fileURL: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("shinn_profile_avatar.jpg")
    }
    static func load() -> UIImage? {
        guard let data = try? Data(contentsOf: fileURL),
              let img = UIImage(data: data) else { return defaultCat() }
        return img
    }
    static func save(_ image: UIImage) {
        guard let data = image.jpegData(compressionQuality: 0.88) else { return }
        try? data.write(to: fileURL, options: .atomic)
    }
    static func clear() {
        try? FileManager.default.removeItem(at: fileURL)
    }
    /// Ảnh mèo mặc định từ bundle (nếu có)
    static func defaultCat() -> UIImage? {
        let names: [(String, String)] = [
            ("cat", "jpg"), ("cat", "png"), ("Cat", "jpg"),
            ("IMG_1253", "jpeg"), ("IMG_1253", "jpg"),
            ("avatar", "jpg"), ("avatar", "png"),
            ("AppIcon", "png")
        ]
        for (n, e) in names {
            if let p = Bundle.main.path(forResource: n, ofType: e),
               let img = UIImage(contentsOfFile: p) { return img }
        }
        // fallback: generated soft placeholder
        let size = CGSize(width: 200, height: 200)
        let r = UIGraphicsImageRenderer(size: size)
        return r.image { ctx in
            UIColor.secondarySystemFill.setFill()
            ctx.fill(CGRect(origin: .zero, size: size))
            let paragraph = NSMutableParagraphStyle()
            paragraph.alignment = .center
            let attrs: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(ofSize: 64),
                .paragraphStyle: paragraph,
                .foregroundColor: UIColor.secondaryLabel
            ]
            "🐱".draw(in: CGRect(x: 0, y: 60, width: 200, height: 80), withAttributes: attrs)
        }
    }
}

func formatKeyExpiry(_ raw: String?) -> String {
    guard let raw, !raw.isEmpty else { return "Lifetime / không hết hạn" }
    let iso = ISO8601DateFormatter()
    iso.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
    var date = iso.date(from: raw)
    if date == nil {
        iso.formatOptions = [.withInternetDateTime]
        date = iso.date(from: raw)
    }
    guard let date else { return "Hết hạn: \(raw)" }
    let s = Int(date.timeIntervalSinceNow)
    if s <= 0 { return "Đã hết hạn" }
    let d = s / 86400
    let h = (s % 86400) / 3600
    if d > 0 { return "Còn \(d) ngày \(h) giờ" }
    let m = (s % 3600) / 60
    if h > 0 { return "Còn \(h) giờ \(m) phút" }
    return "Còn \(m) phút"
}

func remainingKeyText(_ exp: Date) -> String {

    let s = Int(exp.timeIntervalSinceNow)
    if s <= 0 { return "Key đã hết hạn" }
    let d = s / 86400
    let h = (s % 86400) / 3600
    let m = (s % 3600) / 60
    if d > 0 { return "Còn \(d) ngày \(h) giờ" }
    if h > 0 { return "Còn \(h) giờ \(m) phút" }
    return "Còn \(m) phút"
}


struct HomeBrandCard: View {
    let avatar: UIImage?
    let onTapAvatar: () -> Void
    var body: some View {
        HStack(spacing: 14) {
            Button(action: onTapAvatar) {
                ZStack(alignment: .bottomTrailing) {
                    Group {
                        if let avatar {
                            Image(uiImage: avatar).resizable().scaledToFill()
                        } else {
                            Image(systemName: "person.crop.circle.fill")
                                .resizable().scaledToFit()
                                .foregroundStyle(.secondary)
                                .padding(10)
                        }
                    }
                    .frame(width: 64, height: 64)
                    .clipShape(Circle())
                    .overlay(Circle().strokeBorder(ShinnRed.opacity(0.55), lineWidth: 1.2))
                    Image(systemName: "camera.fill")
                        .font(.system(size: 9, weight: .bold))
                        .padding(5)
                        .background(ShinnRed, in: Circle())
                        .foregroundStyle(.white)
                        .offset(x: 2, y: 2)
                }
            }
            .buttonStyle(.plain)
            VStack(alignment: .leading, spacing: 4) {
                HStack(spacing: 6) {
                    Image(systemName: "crown.fill").font(.caption)
                    Text("APP").font(.caption.bold()).foregroundStyle(.secondary)
                }
                Text("SHINN CHEAT")
                    .font(.system(size: 22, weight: .black, design: .rounded))
            }
            Spacer(minLength: 0)
        }
        .padding(14)
        .shinnGlass(radius: 20)
    }
}

struct HomeAccountCard: View {
    @EnvironmentObject var session: Session
    @EnvironmentObject var license: LicenseManager
    var body: some View {
        VStack(spacing: 12) {
            HStack {
                Image(systemName: "checkmark.shield.fill")
                    .foregroundStyle(session.role?.badgeColor ?? .green)
                VStack(alignment: .leading, spacing: 2) {
                    Text(license.holderName.isEmpty ? (session.role?.title ?? "Member") : license.holderName)
                        .font(.headline.bold())
                        .foregroundStyle(session.role == .owner ? ShinnRed : (session.role?.badgeColor ?? .primary))
                    Text(session.role?.title ?? "Member")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Spacer()
                Image(systemName: "checkmark.seal.fill")
                    .foregroundStyle(session.role?.badgeColor ?? .green)
            }
            HStack {
                Label("Expires", systemImage: "clock")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                Spacer()
                if session.role == .owner {
                    Text("Lifetime")
                        .font(.subheadline.bold())
                        .foregroundStyle(ShinnRed)
                        .padding(.horizontal, 11).padding(.vertical, 6)
                        .background(ShinnRed.opacity(0.13), in: Capsule())
                        .overlay(Capsule().stroke(ShinnRed.opacity(0.35), lineWidth: 0.7))
                } else if let exp = license.expiresAt {
                    Text(shortRemain(exp))
                        .font(.subheadline.bold())
                        .foregroundStyle(exp < Date() ? .red : .orange)
                } else {
                    Text("—").font(.subheadline).foregroundStyle(.secondary)
                }
            }
            Button {
                session.role = nil
                license.signOutLicense()
            } label: {
                Label("Sign out / Change key", systemImage: "rectangle.portrait.and.arrow.right")
                    .font(.subheadline.bold())
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 12)
                    .background(Color.primary.opacity(0.08), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
            }
            .buttonStyle(.plain)
        }
        .padding(14)
        .shinnGlass(radius: 20)
    }
    private func statusChip(_ label: String, _ value: String) -> some View {
        HStack(spacing: 4) {
            Text(label)
                .font(.system(size: 9, weight: .bold, design: .rounded))
                .foregroundStyle(.white.opacity(0.4))
            Text(value)
                .font(.system(size: 9, weight: .black, design: .rounded))
                .foregroundStyle(ShinnRed)
        }
        .padding(.horizontal, 8)
        .padding(.vertical, 5)
        .background(Color.white.opacity(0.04), in: RoundedRectangle(cornerRadius: 8, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 8, style: .continuous)
                .stroke(Color.white.opacity(0.08), lineWidth: 0.6)
        )
    }

    private func shortRemain(_ exp: Date) -> String {
        let s = Int(exp.timeIntervalSinceNow)
        if s <= 0 { return "Expired" }
        let d = s / 86400
        if d > 0 { return "\(d)d left" }
        let h = s / 3600
        if h > 0 { return "\(h)h left" }
        return "\(max(1, s / 60))m left"
    }
}


// ===== Settings hub =====
// Giữ nguyên SettingsView hiện có và thêm khu vực tùy chỉnh giao diện.
struct ShinnSettingsHubView: View {
    var body: some View {
        List {
            Section {
                NavigationLink {
                    ShinnAppearanceSettingsView()
                } label: {
                    Label {
                        VStack(alignment: .leading, spacing: 3) {
                            Text("Giao diện")
                                .font(.headline)
                            Text("Màu sắc, độ mạnh nền, chủ đề và ngôn ngữ")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    } icon: {
                        Image(systemName: "paintpalette.fill")
                            .foregroundStyle(ShinnRed)
                    }
                }
            } header: {
                Text("Cá nhân hóa")
            }

            Section {
                NavigationLink {
                    SettingsView()
                } label: {
                    Label("Cài đặt khác", systemImage: "gearshape.fill")
                }
            }
        }
        .navigationTitle("Cài đặt")
        .navigationBarTitleDisplayMode(.inline)
        .scrollContentBackground(.hidden)
        .background(BackgroundView())
        .tint(ShinnRed)
    }
}

// ===== Appearance settings =====
// Tùy chỉnh ngay trong app: màu accent, độ mạnh màu nền, theme và language.
// ColorPicker của iOS cho phép chọn toàn bộ dải màu, không giới hạn preset.
struct ShinnAppearanceSettingsView: View {
    @EnvironmentObject private var settings: AppSettings
    @State private var customHex = ""
    @State private var customBgHex = ""

    private let presets = [
        "#F70A1F", "#FF7A00", "#FFD400", "#22C55E",
        "#00C2FF", "#3B82F6", "#7C3AED", "#EC4899",
        "#FFFFFF", "#A78BFA", "#14B8A6", "#F43F5E"
    ]

    var body: some View {
        ZStack {
            BackgroundView()

            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 16) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Giao diện")
                            .font(.system(size: 28, weight: .black, design: .rounded))
                        Text("Tự chọn màu và phong cách hiển thị cho app.")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }

                    VStack(alignment: .leading, spacing: 14) {
                        HStack(spacing: 12) {
                            Image(systemName: "paintpalette.fill")
                                .foregroundStyle(settings.accentColor)
                                .frame(width: 34, height: 34)
                                .background(settings.accentColor.opacity(0.15), in: RoundedRectangle(cornerRadius: 10))
                            VStack(alignment: .leading, spacing: 2) {
                                Text("Màu chủ đạo")
                                    .font(.headline.bold())
                                Text("Chọn bất kỳ màu nào")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                            Spacer()
                            ColorPicker(
                                "",
                                selection: Binding(
                                    get: { settings.accentColor },
                                    set: { settings.setAccent($0) }
                                ),
                                supportsOpacity: false
                            )
                            .labelsHidden()
                            .frame(width: 44, height: 44)
                        }

                        LazyVGrid(
                            columns: Array(repeating: GridItem(.flexible(), spacing: 10), count: 6),
                            spacing: 10
                        ) {
                            ForEach(presets, id: \.self) { hex in
                                Button {
                                    settings.accentHex = hex
                                } label: {
                                    Circle()
                                        .fill(ShinnColor(hex: hex) ?? .red)
                                        .frame(width: 34, height: 34)
                                        .overlay(
                                            Circle().stroke(
                                                settings.accentHex.uppercased() == hex
                                                    ? Color.white
                                                    : Color.white.opacity(0.12),
                                                lineWidth: settings.accentHex.uppercased() == hex ? 2.5 : 1
                                            )
                                        )
                                }
                                .buttonStyle(.plain)
                                .frame(minWidth: 44, minHeight: 44)
                            }
                        }

                        HStack(spacing: 8) {
                            TextField("#RRGGBB", text: $customHex)
                                .textInputAutocapitalization(.characters)
                                .autocorrectionDisabled()
                                .font(.system(.body, design: .monospaced))
                                .padding(.horizontal, 12)
                                .frame(height: 44)
                                .background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 12))
                                .overlay(
                                    RoundedRectangle(cornerRadius: 12)
                                        .stroke(Color.white.opacity(0.10), lineWidth: 1)
                                )

                            Button("Áp dụng") {
                                let value = customHex.trimmingCharacters(in: .whitespacesAndNewlines)
                                if ShinnColor(hex: value) != nil {
                                    settings.accentHex = value
                                    customHex = settings.accentHex
                                }
                            }
                            .buttonStyle(ShinnMiniGlassButtonStyle())
                        }
                    }
                    .padding(16)
                    .shinnGlass()

                    VStack(alignment: .leading, spacing: 10) {
                        HStack {
                            Label("Độ mạnh màu nền", systemImage: "circle.lefthalf.filled")
                                .font(.headline.bold())
                            Spacer()
                            Text("\(Int(settings.accentIntensity * 100))%")
                                .font(.caption.bold())
                                .foregroundStyle(settings.accentColor)
                        }

                        Slider(value: $settings.accentIntensity, in: 0.02...0.18)
                            .tint(settings.accentColor)
                    }
                    .padding(16)
                    .shinnGlass()

                    VStack(alignment: .leading, spacing: 12) {
                        Text("Màu nền app")
                            .font(.headline.bold())
                        Text("Đổi nền toàn app (Home, Settings, …)")
                            .font(.caption)
                            .foregroundStyle(.secondary)

                        let bgPresets = ["#000000", "#0A0A0F", "#0B1220", "#120808", "#0A1628", "#101010", "#1A0A0A", "#050505"]
                        LazyVGrid(columns: [GridItem(.adaptive(minimum: 44), spacing: 10)], spacing: 10) {
                            ForEach(bgPresets, id: \.self) { hex in
                                Button {
                                    settings.bgHex = hex
                                    customBgHex = hex
                                } label: {
                                    Circle()
                                        .fill(ShinnColor(hex: hex) ?? .black)
                                        .frame(width: 40, height: 40)
                                        .overlay(
                                            Circle().stroke(
                                                settings.bgHex.uppercased() == hex ? settings.accentColor : Color.white.opacity(0.2),
                                                lineWidth: settings.bgHex.uppercased() == hex ? 2.5 : 1
                                            )
                                        )
                                }
                                .buttonStyle(.plain)
                            }
                        }

                        HStack {
                            TextField("#000000", text: $customBgHex)
                                .textInputAutocapitalization(.characters)
                                .autocorrectionDisabled()
                                .padding(10)
                                .background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 10))
                            Button("Áp dụng") {
                                settings.bgHex = customBgHex
                                customBgHex = settings.bgHex
                            }
                            .buttonStyle(.borderedProminent)
                            .tint(settings.accentColor)
                        }
                        RoundedRectangle(cornerRadius: 12, style: .continuous)
                            .fill(settings.backgroundColor)
                            .frame(height: 36)
                            .overlay(
                                Text(settings.bgHex)
                                    .font(.caption.monospaced())
                                    .foregroundStyle(.white.opacity(0.7))
                            )
                    }
                    .padding(16)
                    .shinnGlass()

                    VStack(alignment: .leading, spacing: 10) {
                        Text("Chủ đề")
                            .font(.headline.bold())

                        Picker("Chủ đề", selection: $settings.theme) {
                            ForEach(ShinnTheme.allCases) { theme in
                                Text(theme.titleKey.text.en).tag(theme)
                            }
                        }
                        .pickerStyle(.segmented)
                        .tint(settings.accentColor)
                    }
                    .padding(16)
                    .shinnGlass()

                    VStack(alignment: .leading, spacing: 10) {
                        Text("Ngôn ngữ")
                            .font(.headline.bold())

                        Picker("Ngôn ngữ", selection: $settings.language) {
                            ForEach(ShinnLanguage.allCases) { language in
                                Text(language.title).tag(language)
                            }
                        }
                        .pickerStyle(.segmented)
                        .tint(settings.accentColor)

                        Toggle("Tự động cập nhật repo", isOn: $settings.autoRefresh)
                            .tint(settings.accentColor)
                    }
                    .padding(16)
                    .shinnGlass()

                    Button {
                        settings.resetAppearance()
                        customHex = settings.accentHex
                        customBgHex = settings.bgHex
                    } label: {
                        Label("Khôi phục giao diện mặc định", systemImage: "arrow.counterclockwise")
                    }
                    .buttonStyle(ShinnPremiumButtonStyle(destructive: true))
                }
                .padding(.horizontal, 18)
                .padding(.top, 10)
                .padding(.bottom, 30)
            }
        }
        .navigationTitle("Giao diện")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            customHex = settings.accentHex
            customBgHex = settings.bgHex
        }
    }
}

struct HomeView: View {
    @EnvironmentObject var settings: AppSettings
    @EnvironmentObject var store: RepoStore
    @EnvironmentObject var session: Session
    @EnvironmentObject var license: LicenseManager
    let open: (Route) -> Void
    var selectTab: (Int) -> Void = { _ in }

    @State private var avatar: UIImage? = ProfileAvatarStore.load()
    @State private var photoItem: PhotosPickerItem?
    @State private var showAvatarOptions = false
    @State private var showPhotoPicker = false
    @State private var showCommunityIntro = false
    @AppStorage("shinn.didShowCommunityIntro") private var didShowCommunityIntro = false

    private var featured: [RepoPackage] { Array(store.packages.prefix(4)) }

    var body: some View {
        ZStack {
            BackgroundView()
            ScrollView(showsIndicators: false) {
                VStack(spacing: 14) {
                    header
                    heroBanner

                    HStack(spacing: 10) {
                        dashboardButton("Kho Patch", "Repo miễn phí", "square.grid.2x2.fill") { open(.packages(nil)) }
                        dashboardButton("Tải tất cả", "Tải toàn bộ patch", "arrow.down.to.line.compact") {
                            Task { await store.downloadAll() }
                        }
                    }

                    premiumCard
                    aiCard
                    communityCard

                    if !featured.isEmpty {
                        HStack {
                            Text("Patch nổi bật")
                                .font(.system(size: 18, weight: .black, design: .rounded))
                            Spacer()
                            Text("\(store.packages.count) patch")
                                .font(.system(size: 10, weight: .bold, design: .rounded))
                                .foregroundStyle(.white.opacity(0.38))
                        }
                        .foregroundStyle(.white)

                        LazyVGrid(columns: [GridItem(.flexible(), spacing: 10), GridItem(.flexible(), spacing: 10)], spacing: 10) {
                            ForEach(featured) { pkg in
                                Button { open(.detail(pkg.id)) } label: {
                                    patchMiniCard(pkg)
                                }
                                .buttonStyle(.plain)
                            }
                        }
                    }

                    HStack(spacing: 10) {
                        dashboardButton("Tệp", "File manager", "folder.fill") { selectTab(1) }
                        dashboardButton("Cài đặt", "Giao diện", "slider.horizontal.3") { open(.settings) }
                    }

                    if session.role == .owner {
                        Button { open(.repositoryManager) } label: {
                            HStack {
                                Image(systemName: "lock.shield.fill").foregroundStyle(ShinnRed)
                                VStack(alignment: .leading, spacing: 2) {
                                    Text("Admin Tools").font(.system(size: 14, weight: .bold, design: .rounded))
                                    Text("Quản lý key và quyền Premium").font(.caption).foregroundStyle(.white.opacity(0.42))
                                }
                                Spacer()
                                Image(systemName: "chevron.right").foregroundStyle(.white.opacity(0.3))
                            }
                            .padding(13)
                            .shinnGlass(radius: 17)
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(.horizontal, 16)
                .padding(.top, 12)
                .padding(.bottom, 30)
            }
            .refreshable { await store.refresh() }
            .tint(ShinnRed)
        }
        .toolbar(.hidden, for: .navigationBar)
        .onAppear {
            if avatar == nil { avatar = ProfileAvatarStore.load() }
            if !didShowCommunityIntro {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.45) {
                    showCommunityIntro = true
                }
            }
        }
        .sheet(isPresented: $showCommunityIntro) {
            CommunityView(firstLaunch: true) {
                didShowCommunityIntro = true
            }
            .presentationDetents([.large])
            .presentationDragIndicator(.visible)
        }
        .confirmationDialog("Ảnh đại diện", isPresented: $showAvatarOptions, titleVisibility: .visible) {
            Button("Chọn từ thư viện") { showPhotoPicker = true }
            Button("Khôi phục mặc định", role: .destructive) {
                ProfileAvatarStore.clear()
                avatar = ProfileAvatarStore.defaultCat()
            }
            Button("Huỷ", role: .cancel) {}
        }
        .photosPicker(isPresented: $showPhotoPicker, selection: $photoItem, matching: .images)
        .onChange(of: photoItem) { item in
            guard let item else { return }
            Task {
                if let data = try? await item.loadTransferable(type: Data.self), let img = UIImage(data: data) {
                    ProfileAvatarStore.save(img)
                    await MainActor.run { avatar = img }
                }
            }
        }
    }

    private var header: some View {
        HStack(spacing: 12) {
            Button { showAvatarOptions = true } label: {
                Group {
                    if let avatar {
                        Image(uiImage: avatar).resizable().scaledToFill()
                    } else {
                        Image("ShinnCatAvatar").resizable().scaledToFill()
                    }
                }
                .frame(width: 48, height: 48)
                .clipShape(RoundedRectangle(cornerRadius: 15, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 15).stroke(Color.white.opacity(0.12), lineWidth: 0.8))
            }
            .buttonStyle(.plain)

            VStack(alignment: .leading, spacing: 2) {
                Text("Shinn Cheat")
                    .font(.system(size: 23, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                Text("Play Smarter · Win Easier")
                    .font(.system(size: 10.5, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.42))
            }
            Spacer()
            HStack(spacing: 5) {
                Circle().fill(.green).frame(width: 7, height: 7)
                Text("ONLINE")
                    .font(.system(size: 9, weight: .black, design: .rounded))
            }
            .foregroundStyle(.white.opacity(0.75))
            .padding(.horizontal, 9)
            .padding(.vertical, 7)
            .background(Color.white.opacity(0.055), in: Capsule())
        }
    }

    private var heroBanner: some View {
        ZStack(alignment: .bottomLeading) {
            Image("ShinnCatHero")
                .resizable()
                .scaledToFill()
                .frame(height: 190)
                .clipped()
            LinearGradient(colors: [.clear, Color.black.opacity(0.94)], startPoint: .top, endPoint: .bottom)
            VStack(alignment: .leading, spacing: 5) {
                Text("WELCOME TO")
                    .font(.system(size: 9, weight: .black, design: .rounded))
                    .foregroundStyle(ShinnRed)
                    .tracking(1.2)
                Text("Shinn Cheat")
                    .font(.system(size: 28, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                Text("Tối ưu · An toàn · Ổn định")
                    .font(.system(size: 11, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.62))
            }
            .padding(17)
        }
        .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 24).stroke(Color.white.opacity(0.12), lineWidth: 0.8))
        .shadow(color: ShinnRed.opacity(0.12), radius: 20, y: 8)
    }

    private var premiumCard: some View {
        Button { open(.premiumRepo) } label: {
            HStack(spacing: 13) {
                ZStack {
                    RoundedRectangle(cornerRadius: 15, style: .continuous)
                        .fill(LinearGradient(colors: [Color.purple.opacity(0.55), ShinnRed.opacity(0.18)], startPoint: .topLeading, endPoint: .bottomTrailing))
                    Image(systemName: store.isRepoV2Authorized ? "crown.fill" : "lock.fill")
                        .font(.system(size: 20, weight: .black))
                        .foregroundStyle(.white)
                }
                .frame(width: 52, height: 52)
                VStack(alignment: .leading, spacing: 3) {
                    Text("Premium Repo")
                        .font(.system(size: 16, weight: .black, design: .rounded))
                    Text(store.isRepoV2Authorized ? "Đã mở khóa Repo 2" : "Mở khóa bằng key Premium")
                        .font(.system(size: 10.5, weight: .medium, design: .rounded))
                        .foregroundStyle(.white.opacity(0.5))
                }
                Spacer()
                Text(store.isRepoV2Authorized ? "OPEN" : "KEY")
                    .font(.system(size: 10, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 8)
                    .background(Color.purple.opacity(0.55), in: Capsule())
            }
            .padding(13)
            .shinnGlass(radius: 20)
            .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.purple.opacity(0.38), lineWidth: 0.9))
        }
        .buttonStyle(.plain)
    }

    private var aiCard: some View {
        Button { open(.aiChat) } label: {
            HStack(spacing: 13) {
                ZStack {
                    RoundedRectangle(cornerRadius: 15, style: .continuous).fill(ShinnRed.opacity(0.15))
                    Image("ShinnCatAvatar").resizable().scaledToFill().clipShape(RoundedRectangle(cornerRadius: 15, style: .continuous))
                }
                .frame(width: 52, height: 52)
                VStack(alignment: .leading, spacing: 3) {
                    Text("Shinn AI").font(.system(size: 16, weight: .black, design: .rounded))
                    Text("Commands · Support · Patch helper")
                        .font(.system(size: 10.5, weight: .medium, design: .rounded))
                        .foregroundStyle(.white.opacity(0.5))
                }
                Spacer()
                Image(systemName: "chevron.right").foregroundStyle(.white.opacity(0.3))
            }
            .padding(13)
            .shinnGlass(radius: 20)
        }
        .buttonStyle(.plain)
    }

    private var communityCard: some View {
        Button { open(.community) } label: {
            HStack(spacing: 13) {
                Image(systemName: "paperplane.fill")
                    .font(.system(size: 21, weight: .bold))
                    .foregroundStyle(.white)
                    .frame(width: 52, height: 52)
                    .background(Color.blue.opacity(0.6), in: RoundedRectangle(cornerRadius: 15, style: .continuous))
                VStack(alignment: .leading, spacing: 3) {
                    Text("Community").font(.system(size: 16, weight: .black, design: .rounded))
                    Text("Join groups · English chat · Support")
                        .font(.system(size: 10.5, weight: .medium, design: .rounded))
                        .foregroundStyle(.white.opacity(0.5))
                }
                Spacer()
                Image(systemName: "chevron.right").foregroundStyle(.white.opacity(0.3))
            }
            .padding(13)
            .shinnGlass(radius: 20)
        }
        .buttonStyle(.plain)
    }

    private func dashboardButton(_ title: String, _ subtitle: String, _ icon: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 10) {
                Image(systemName: icon).font(.system(size: 18, weight: .bold)).foregroundStyle(ShinnRed)
                VStack(alignment: .leading, spacing: 2) {
                    Text(title).font(.system(size: 13, weight: .bold, design: .rounded)).foregroundStyle(.white)
                    Text(subtitle).font(.system(size: 9.5, weight: .medium, design: .rounded)).foregroundStyle(.white.opacity(0.4))
                }
                Spacer(minLength: 0)
            }
            .padding(12)
            .frame(maxWidth: .infinity, minHeight: 62)
            .shinnGlass(radius: 17)
        }
        .buttonStyle(.plain)
    }

    private func patchMiniCard(_ pkg: RepoPackage) -> some View {
        HStack(spacing: 10) {
            Image("ShinnCatPatch")
                .resizable()
                .scaledToFill()
                .frame(width: 42, height: 42)
                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
            VStack(alignment: .leading, spacing: 3) {
                Text(pkg.name).font(.system(size: 12.5, weight: .bold, design: .rounded)).foregroundStyle(.white).lineLimit(1)
                Text(pkg.version ?? "Patch").font(.system(size: 9.5, weight: .medium, design: .rounded)).foregroundStyle(.white.opacity(0.4))
            }
            Spacer(minLength: 0)
        }
        .padding(11)
        .shinnGlass(radius: 16)
    }
}

// ===== Premium Repo / Community =====
struct PremiumRepoView: View {
    @EnvironmentObject var license: LicenseManager
    @EnvironmentObject var store: RepoStore
    @State private var key = ""
    @State private var message = ""
    @State private var busy = false

    var body: some View {
        ZStack {
            BackgroundView()
            ScrollView(showsIndicators: false) {
                VStack(spacing: 14) {
                    VStack(spacing: 10) {
                        Image("ShinnCatHero")
                            .resizable().scaledToFill()
                            .frame(height: 170)
                            .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
                        Image(systemName: store.isRepoV2Authorized ? "crown.fill" : "lock.fill")
                            .font(.system(size: 32, weight: .black))
                            .foregroundStyle(.white)
                        Text("Repo 2 - Premium")
                            .font(.system(size: 27, weight: .black, design: .rounded))
                        Text("Exclusive patches require a valid Premium key.")
                            .font(.subheadline)
                            .foregroundStyle(.white.opacity(0.55))
                            .multilineTextAlignment(.center)
                    }
                    .padding(16)
                    .shinnGlass(radius: 24)

                    if store.isRepoV2Authorized {
                        Button {
                            Task { await store.selectRepo(v2: true) }
                        } label: {
                            Label("Open Premium Patches", systemImage: "lock.open.fill")
                        }
                        .buttonStyle(ShinnPremiumButtonStyle())

                        Button {
                            Task { await store.downloadAll() }
                        } label: {
                            Label("Download All Premium Patches", systemImage: "arrow.down.to.line.compact")
                        }
                        .buttonStyle(ShinnMiniGlassButtonStyle())
                    } else {
                        VStack(alignment: .leading, spacing: 12) {
                            Label("Premium Key", systemImage: "key.fill").font(.headline)
                            SecureField("Enter your key", text: $key)
                                .textInputAutocapitalization(.never)
                                .autocorrectionDisabled(true)
                                .padding(14)
                                .background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                            if !message.isEmpty { Text(message).font(.footnote.bold()).foregroundStyle(.red) }
                            Button {
                                Task { await activate() }
                            } label: {
                                if busy { ProgressView().tint(.white) }
                                else { Label("Unlock Premium", systemImage: "key.fill") }
                            }
                            .buttonStyle(ShinnPremiumButtonStyle())
                            .disabled(busy || key.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                        }
                        .padding(16)
                        .shinnGlass(radius: 20)

                        Button { UIApplication.shared.open(AppInfo.telegramLinkURL) } label: {
                            HStack {
                                Image(systemName: "paperplane.fill")
                                Text("Need a key? Contact @ShinnThieuu")
                                Spacer()
                                Image(systemName: "chevron.right")
                            }
                            .padding(14)
                            .shinnGlass(radius: 18)
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(16)
            }
        }
        .navigationTitle("Premium Repo")
        .navigationBarTitleDisplayMode(.inline)
    }

    private func activate() async {
        busy = true
        defer { busy = false }
        let ok = await license.activate(key: key, language: .en)
        if ok && store.isRepoV2Authorized {
            message = ""
            await store.selectRepo(v2: true)
            key = ""
        } else if ok {
            message = "This key is not authorized for Premium Repo."
        } else {
            message = license.lastError ?? "Invalid key."
        }
    }
}

struct CommunityView: View {
    var firstLaunch = false
    var onDone: (() -> Void)? = nil

    var body: some View {
        ZStack {
            BackgroundView()
            ScrollView(showsIndicators: false) {
                VStack(spacing: 14) {
                    VStack(spacing: 8) {
                        Image("ShinnCatHero").resizable().scaledToFill().frame(height: 150).clipped()
                        Text(firstLaunch ? "Welcome to Shinn Cheat" : "Community")
                            .font(.system(size: 27, weight: .black, design: .rounded))
                        Text("Join the official groups for updates, support and chat.")
                            .font(.subheadline)
                            .foregroundStyle(.white.opacity(0.55))
                            .multilineTextAlignment(.center)
                    }
                    .shinnGlass(radius: 24)

                    communityLink("Main Group", "ShinnCheatShare", "Updates · Announcements · Resources", AppInfo.telegramMainGroupURL)
                    communityLink("English Chat", "ShinnCheatChat", "English only · Discussion · Support", AppInfo.telegramEnglishChatURL)
                    communityLink("Support", "@ShinnThieuu", "Questions · Key support · Direct contact", AppInfo.telegramLinkURL)

                    if firstLaunch {
                        Button {
                            onDone?()
                        } label: {
                            Text("Continue to Shinn Cheat")
                        }
                        .buttonStyle(ShinnPremiumButtonStyle())
                    }
                }
                .padding(16)
            }
        }
        .navigationTitle("Community")
        .navigationBarTitleDisplayMode(.inline)
    }

    private func communityLink(_ title: String, _ name: String, _ subtitle: String, _ url: URL) -> some View {
        Button { UIApplication.shared.open(url) } label: {
            HStack(spacing: 13) {
                Image(systemName: "paperplane.fill")
                    .font(.system(size: 19, weight: .bold))
                    .foregroundStyle(.white)
                    .frame(width: 48, height: 48)
                    .background(Color.blue.opacity(0.62), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                VStack(alignment: .leading, spacing: 3) {
                    Text(title).font(.system(size: 15, weight: .black, design: .rounded))
                    Text(name).font(.system(size: 12, weight: .bold, design: .rounded)).foregroundStyle(.white.opacity(0.82))
                    Text(subtitle).font(.system(size: 10, weight: .medium, design: .rounded)).foregroundStyle(.white.opacity(0.45))
                }
                Spacer()
                Image(systemName: "arrow.up.right").foregroundStyle(.white.opacity(0.35))
            }
            .padding(13)
            .shinnGlass(radius: 19)
        }
        .buttonStyle(.plain)
    }
}

struct QuickActionCard: View {
    let title: String
    let subtitle: String
    let icon: String

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Image(systemName: icon)
                .font(.title2.weight(.semibold))
            Text(title)
                .font(.headline.bold())
            Text(subtitle)
                .font(.caption)
                .foregroundStyle(.secondary)
                .lineLimit(1)
        }
        .frame(maxWidth: .infinity, minHeight: 118, alignment: .leading)
        .padding(18)
        .contentShape(Rectangle())
        .shinnGlass()
    }
}

struct QuickAction: View {
    let title: String
    let subtitle: String
    let icon: String
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 12) {
                Image(systemName: icon).font(.title2)
                Text(title).font(.headline.bold())
                Text(subtitle).font(.caption).foregroundStyle(.secondary)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(18).contentShape(Rectangle()).shinnGlass()
        }
        .buttonStyle(.plain)
    }
}

enum HeroBanner {
    static let image: UIImage? = {
        let names: [(String, String)] = [
            ("IMG_1253", "jpeg"), ("IMG_1253", "jpg"), ("IMG_1253", "JPG"), ("IMG_1253", "JPEG"), ("HeroBanner", "jpg")
        ]
        for (name, ext) in names {
            if let path = Bundle.main.path(forResource: name, ofType: ext),
               let img = UIImage(contentsOfFile: path) { return img }
        }
        return nil
    }()
}

struct PackagesView: View {
    @EnvironmentObject var store: RepoStore
    @State private var searchText = ""
    @State private var category: String?
    @State private var expanded: Set<String> = Set(PatchFolder.allCases.map(\.rawValue))
    @State private var selectedIDs: Set<String> = []
    @State private var isSelectionMode = false
    @State private var isApplyingSelected = false
    @State private var showApplyToast = false
    @State private var applyToastMessage = ""
    @State private var applyToastIsError = false

    init(initialCategory: String?) {
        _category = State(initialValue: initialCategory)
    }

    private var filtered: [RepoPackage] {
        var result = store.packages
        if let category { result = result.filter { $0.category == category } }
        let q = searchText.trimmingCharacters(in: .whitespacesAndNewlines)
        if !q.isEmpty {
            result = result.filter {
                $0.name.localizedCaseInsensitiveContains(q) ||
                ($0.summary ?? "").localizedCaseInsensitiveContains(q) ||
                ($0.category ?? "").localizedCaseInsensitiveContains(q)
            }
        }
        return result
    }

    private var grouped: [PackageFolderGroup] {
        var map: [PatchFolder: [RepoPackage]] = [:]
        for p in filtered {
            let f = PatchFolder.folder(for: p)
            map[f, default: []].append(p)
        }
        return PatchFolder.allCases.compactMap { f in
            guard let list = map[f], !list.isEmpty else { return nil }
            return PackageFolderGroup(folder: f, items: list)
        }
    }

    private var selectedPackages: [RepoPackage] {
        store.packages.filter { selectedIDs.contains($0.id) }
    }

    private var recentPackages: [RepoPackage] {
        store.recentPackages
    }

    var body: some View {
        ScrollView {
            LazyVStack(spacing: 14, pinnedViews: []) {
                if !recentPackages.isEmpty {
                    VStack(alignment: .leading, spacing: 10) {
                        HStack {
                            Label("Dùng gần đây", systemImage: "clock.arrow.circlepath")
                                .font(.headline.bold())
                            Spacer()
                            Text("\(recentPackages.count)").font(.caption).foregroundStyle(.secondary)
                        }
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 10) {
                                ForEach(recentPackages) { package in
                                    Button {
                                        if !isSelectionMode { isSelectionMode = true }
                                        if selectedIDs.contains(package.id) { selectedIDs.remove(package.id) }
                                        else { selectedIDs.insert(package.id) }
                                    } label: {
                                        HStack(spacing: 7) {
                                            Image(systemName: categoryIcon(package.category ?? ""))
                                            Text(package.name).lineLimit(1)
                                        }
                                        .font(.caption.bold())
                                        .padding(.horizontal, 12).padding(.vertical, 9)
                                        .background(selectedIDs.contains(package.id) ? Color.primary.opacity(0.16) : Color.primary.opacity(0.07), in: Capsule())
                                    }
                                    .buttonStyle(.plain)
                                }
                            }
                        }
                    }
                    .padding(14).shinnGlass(radius: 16)
                }

                // Premium multi-select control
                VStack(alignment: .leading, spacing: 13) {
                    HStack(spacing: 12) {
                        ZStack {
                            Circle()
                                .fill(ShinnRed.opacity(0.16))
                                .frame(width: 46, height: 46)
                            Image(systemName: isSelectionMode ? "checkmark.seal.fill" : "hand.tap.fill")
                                .font(.system(size: 19, weight: .black))
                                .foregroundStyle(ShinnRed)
                        }
                        VStack(alignment: .leading, spacing: 3) {
                            Text(isSelectionMode ? "CHẾ ĐỘ CHỌN NHIỀU" : "CHỌN NHIỀU PATCH")
                                .font(.system(size: 14, weight: .black, design: .rounded))
                                .tracking(0.45)
                            Text(isSelectionMode
                                 ? "Đã chọn \(selectedIDs.count) patch · chạm để bật / tắt"
                                 : "Giữ một patch 2 giây để bắt đầu")
                                .font(.system(size: 11, weight: .medium, design: .rounded))
                                .foregroundStyle(.white.opacity(0.48))
                        }
                        Spacer()
                        Button {
                            if isSelectionMode {
                                isSelectionMode = false
                                selectedIDs.removeAll()
                            } else {
                                isSelectionMode = true
                            }
                        } label: {
                            Text(isSelectionMode ? "THOÁT" : "CHỌN")
                                .font(.system(size: 10, weight: .black, design: .rounded))
                                .tracking(0.6)
                                .foregroundStyle(isSelectionMode ? .white.opacity(0.70) : ShinnRed)
                                .padding(.horizontal, 12)
                                .padding(.vertical, 9)
                                .background((isSelectionMode ? Color.white : ShinnRed).opacity(0.09), in: Capsule())
                                .overlay(Capsule().stroke((isSelectionMode ? Color.white : ShinnRed).opacity(0.20), lineWidth: 0.8))
                        }
                        .buttonStyle(.plain)
                    }

                    if isSelectionMode {
                        HStack(spacing: 9) {
                            Button {
                                let visibleIDs = Set(filtered.map(\.id))
                                if visibleIDs.isSubset(of: selectedIDs) {
                                    selectedIDs.subtract(visibleIDs)
                                } else {
                                    selectedIDs.formUnion(visibleIDs)
                                }
                            } label: {
                                Label("TẤT CẢ", systemImage: "checkmark.circle.fill")
                                    .frame(maxWidth: .infinity)
                            }
                            .buttonStyle(ShinnMiniGlassButtonStyle())

                            Button {
                                selectedIDs.removeAll()
                            } label: {
                                Label("BỎ CHỌN", systemImage: "xmark.circle")
                                    .frame(maxWidth: .infinity)
                            }
                            .buttonStyle(ShinnMiniGlassButtonStyle())
                            .disabled(selectedIDs.isEmpty)
                        }

                        Button {
                            isApplyingSelected = true
                            let targets = selectedPackages
                            Task {
                                let result = await store.applyMultiple(targets)
                                await MainActor.run {
                                    isApplyingSelected = false
                                    isSelectionMode = false
                                    selectedIDs.removeAll()
                                    applyToastIsError = result.ok.isEmpty
                                    applyToastMessage = store.lastApplyMessage ?? (result.fail.isEmpty ? "Đã áp dụng patch." : "Có patch bị từ chối.")
                                    withAnimation(.spring(response: 0.40, dampingFraction: 0.80)) { showApplyToast = true }
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 5.0) {
                                        withAnimation(.easeOut(duration: 0.25)) { showApplyToast = false }
                                    }
                                }
                            }
                        } label: {
                            HStack(spacing: 9) {
                                if isApplyingSelected {
                                    ProgressView().tint(.white)
                                } else {
                                    Image(systemName: "bolt.fill")
                                    Text("ÁP DỤNG")
                                    Text("\(selectedIDs.count)")
                                        .font(.system(size: 11, weight: .black, design: .rounded))
                                        .padding(.horizontal, 7).padding(.vertical, 4)
                                        .background(Color.white.opacity(0.14), in: Capsule())
                                }
                            }
                            .frame(maxWidth: .infinity, minHeight: 52)
                        }
                        .buttonStyle(ShinnPremiumButtonStyle())
                        .disabled(isApplyingSelected || selectedPackages.isEmpty)
                    }
                }
                .padding(14)
                .background(
                    LinearGradient(colors: [Color.white.opacity(0.075), Color.black.opacity(0.48)], startPoint: .topLeading, endPoint: .bottomTrailing),
                    in: RoundedRectangle(cornerRadius: 24, style: .continuous)
                )
                .overlay(
                    RoundedRectangle(cornerRadius: 24, style: .continuous)
                        .stroke(LinearGradient(colors: [ShinnRed.opacity(0.70), Color.white.opacity(0.10)], startPoint: .topLeading, endPoint: .bottomTrailing), lineWidth: 1)
                )
                .shadow(color: ShinnRed.opacity(0.14), radius: 20, y: 7)

                if store.packages.isEmpty {
                    ProgressView().padding(.top, 40)
                } else if filtered.isEmpty {
                    Text("No results").font(.headline).padding(.top, 40)
                } else {
                    ForEach(grouped, id: \.folder.id) { section in
                        PackageFolderSection(
                            folder: section.folder,
                            items: section.items,
                            isExpanded: expanded.contains(section.folder.id),
                            onToggle: {
                                if expanded.contains(section.folder.id) { expanded.remove(section.folder.id) }
                                else { expanded.insert(section.folder.id) }
                            },
                            selectedIDs: $selectedIDs,
                            isSelectionMode: $isSelectionMode,
                            onSelect: { package in
                                if selectedIDs.contains(package.id) { selectedIDs.remove(package.id) }
                                else { selectedIDs.insert(package.id) }
                            }
                        )
                    }
                }
            }
            .padding(.horizontal, 18).padding(.vertical, 12)
        }
        .background(BackgroundView())
        .overlay(alignment: .top) {
            if showApplyToast {
                ApplyToastView(message: applyToastMessage, isError: applyToastIsError)
                    .padding(.horizontal, 16)
                    .padding(.top, 8)
                    .transition(.move(edge: .top).combined(with: .opacity))
                    .zIndex(50)
            }
        }
        .navigationTitle("Kho Patch")
        .navigationBarTitleDisplayMode(.inline)
        .searchable(text: $searchText, prompt: "Tìm patch")
        .refreshable { await store.refresh() }
    }
}


struct ApplyToastView: View {
    let message: String
    let isError: Bool

    var body: some View {
        HStack(spacing: 14) {
            ZStack {
                Circle()
                    .fill((isError ? Color.red : ShinnRed).opacity(0.16))
                    .frame(width: 48, height: 48)
                Image(systemName: isError ? "xmark" : "checkmark")
                    .font(.system(size: 19, weight: .black))
                    .foregroundStyle(isError ? .red : ShinnRed)
            }
            VStack(alignment: .leading, spacing: 4) {
                Text(isError ? "KHÔNG THỂ ÁP DỤNG" : "PATCH ĐÃ SẴN SÀNG")
                    .font(.system(size: 13, weight: .black, design: .rounded))
                    .tracking(0.7)
                Text(message)
                    .font(.system(size: 12, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.68))
                    .lineLimit(3)
            }
            Spacer(minLength: 0)
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 12)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
        .background(
            LinearGradient(colors: [ShinnRed.opacity(0.10), Color.black.opacity(0.48)], startPoint: .topLeading, endPoint: .bottomTrailing),
            in: RoundedRectangle(cornerRadius: 20, style: .continuous)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .stroke(LinearGradient(colors: [ShinnRed.opacity(0.8), Color.white.opacity(0.12)], startPoint: .topLeading, endPoint: .bottomTrailing), lineWidth: 1)
        )
        .shadow(color: ShinnRed.opacity(isError ? 0.12 : 0.28), radius: 20, y: 8)
    }
}

struct PackageFolderGroup: Identifiable {
    var id: String { folder.id }
    let folder: PatchFolder
    let items: [RepoPackage]
}

struct PackageFolderSection: View {
    let folder: PatchFolder
    let items: [RepoPackage]
    let isExpanded: Bool
    let onToggle: () -> Void
    @Binding var selectedIDs: Set<String>
    @Binding var isSelectionMode: Bool
    let onSelect: (RepoPackage) -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 11) {
            Button(action: onToggle) {
                HStack(spacing: 11) {
                    ZStack {
                        Circle().fill(ShinnRed.opacity(0.13)).frame(width: 40, height: 40)
                        Image(systemName: folder.icon).font(.system(size: 17, weight: .bold)).foregroundStyle(ShinnRed)
                    }
                    VStack(alignment: .leading, spacing: 2) {
                        Text(folder.title).font(.system(size: 16, weight: .black, design: .rounded))
                        Text("\(items.count) PATCH")
                            .font(.system(size: 9, weight: .bold, design: .rounded))
                            .tracking(0.8)
                            .foregroundStyle(.white.opacity(0.38))
                    }
                    Spacer()
                    Image(systemName: isExpanded ? "chevron.up" : "chevron.down")
                        .font(.system(size: 13, weight: .black))
                        .foregroundStyle(.white.opacity(0.45))
                }
                .padding(.horizontal, 13).padding(.vertical, 9)
                .background(Color.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(Color.white.opacity(0.07), lineWidth: 0.7))
            }
            .buttonStyle(.plain)

            if isExpanded {
                ForEach(items) { package in
                    HStack(spacing: 9) {
                        Button {
                            if !isSelectionMode { isSelectionMode = true }
                            onSelect(package)
                        } label: {
                            ZStack {
                                Circle()
                                    .fill(selectedIDs.contains(package.id) ? ShinnRed : Color.white.opacity(0.04))
                                    .frame(width: 34, height: 34)
                                Circle()
                                    .stroke(selectedIDs.contains(package.id) ? ShinnRed : Color.white.opacity(0.28), lineWidth: 1.5)
                                    .frame(width: 34, height: 34)
                                if selectedIDs.contains(package.id) {
                                    Image(systemName: "checkmark")
                                        .font(.system(size: 14, weight: .black))
                                        .foregroundStyle(.white)
                                }
                            }
                        }
                        .buttonStyle(.plain)
                        .frame(width: 42, height: 66)
                        .contentShape(Rectangle())

                        Group {
                            if isSelectionMode {
                                Button { onSelect(package) } label: { PackageRow(pkg: package) }
                                    .buttonStyle(.plain)
                            } else {
                                NavigationLink(value: Route.detail(package.id)) { PackageRow(pkg: package) }
                                    .buttonStyle(.plain)
                            }
                        }
                        .contentShape(Rectangle())
                        .simultaneousGesture(
                            LongPressGesture(minimumDuration: 2.0)
                                .onEnded { _ in
                                    isSelectionMode = true
                                    if !selectedIDs.contains(package.id) { selectedIDs.insert(package.id) }
                                }
                        )
                    }
                }
            }
        }
    }
}


struct PackageRow: View {
    let pkg: RepoPackage
    @EnvironmentObject var store: RepoStore

    @ViewBuilder
    private var packageThumb: some View {
        let s = (pkg.icon ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        if let url = URL(string: s), url.scheme != nil {
            AsyncImage(url: url) { phase in
                switch phase {
                case .success(let img):
                    img.resizable().scaledToFill()
                default:
                    IconBox(systemName: categoryIcon(pkg.category ?? ""), size: 58)
                }
            }
            .frame(width: 58, height: 58)
            .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(Color.white.opacity(0.10), lineWidth: 0.8))
        } else {
            IconBox(systemName: categoryIcon(pkg.category ?? ""), size: 58)
        }
    }

    private func tag(_ text: String, accent: Bool = false) -> some View {
        Text(text)
            .font(.system(size: 11, weight: .bold, design: .rounded))
            .foregroundStyle(accent ? ShinnRed : .white.opacity(0.68))
            .padding(.horizontal, 9).padding(.vertical, 5)
            .background((accent ? ShinnRed : Color.white).opacity(accent ? 0.13 : 0.07), in: Capsule())
            .overlay(Capsule().stroke((accent ? ShinnRed : Color.white).opacity(0.14), lineWidth: 0.6))
    }

    var body: some View {
        HStack(spacing: 13) {
            packageThumb
            VStack(alignment: .leading, spacing: 6) {
                Text(pkg.name)
                    .font(.system(size: 17, weight: .bold, design: .rounded))
                    .foregroundStyle(.white)
                    .lineLimit(1)
                Text(pkg.summary ?? "Shinn Cheat Resource")
                    .font(.system(size: 12, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.52))
                    .lineLimit(1)
                HStack(spacing: 6) {
                    if let version = pkg.version { tag("v\(version)", accent: true) }
                    if let size = pkg.size { tag(formatBytes(size)) }
                }
            }
            Spacer(minLength: 0)
            Image(systemName: "chevron.right")
                .font(.system(size: 13, weight: .black))
                .foregroundStyle(.white.opacity(0.35))
        }
        .padding(13)
        .contentShape(Rectangle())
        .background(
            LinearGradient(colors: [Color.white.opacity(0.075), Color.black.opacity(0.38)], startPoint: .topLeading, endPoint: .bottomTrailing),
            in: RoundedRectangle(cornerRadius: 22, style: .continuous)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .stroke(LinearGradient(colors: [ShinnRed.opacity(0.60), Color.white.opacity(0.08)], startPoint: .topLeading, endPoint: .bottomTrailing), lineWidth: 0.9)
        )
        .shadow(color: ShinnRed.opacity(0.10), radius: 12, y: 5)
    }
}


struct FlowTags: View {
    let tags: [String]
    var body: some View {
        // Simple wrap via flexible HStacks
        VStack(alignment: .leading, spacing: 6) {
            ForEach(Array(stride(from: 0, to: tags.count, by: 3)), id: \.self) { start in
                HStack(spacing: 6) {
                    ForEach(tags[start..<min(start + 3, tags.count)], id: \.self) { t in
                        Text(t)
                            .font(.caption2.weight(.medium))
                            .padding(.horizontal, 8)
                            .padding(.vertical, 4)
                            .background(Color.primary.opacity(0.08), in: Capsule())
                    }
                }
            }
        }
    }
}

struct PackageDetailView: View {
    @EnvironmentObject var store: RepoStore
    @EnvironmentObject var abuse: AbuseGuard
    let packageID: String

    @State private var alertTitle = ""
    @State private var alertMessage = ""
    @State private var showAlert = false
    @State private var showPatchToast = false
    @State private var patchToastMessage = ""
    @State private var patchToastIsError = false
    @State private var isApplying = false

    private var pkg: RepoPackage? {
        store.packages.first { $0.id == packageID }
    }

    var body: some View {
        ZStack {
            BackgroundView()
            if let pkg { content(pkg) } else { ProgressView().tint(ShinnRed) }
        }
        .overlay(alignment: .top) {
            if showPatchToast {
                ApplyToastView(message: patchToastMessage, isError: patchToastIsError)
                    .padding(.horizontal, 16)
                    .padding(.top, 8)
                    .transition(.move(edge: .top).combined(with: .opacity))
                    .zIndex(50)
            }
        }
        .navigationTitle(pkg?.name ?? "")
        .navigationBarTitleDisplayMode(.inline)
        .alert(alertTitle, isPresented: $showAlert) {
            Button("OK", role: .cancel) {}
        } message: { Text(alertMessage) }
    }

    private func content(_ pkg: RepoPackage) -> some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 12) {
                HStack(alignment: .top, spacing: 14) {
                    hero(pkg)
                    VStack(alignment: .leading, spacing: 6) {
                        Text(pkg.name)
                            .font(.system(size: 20, weight: .heavy, design: .rounded))
                            .foregroundStyle(.white)
                            .lineLimit(2)
                            .multilineTextAlignment(.leading)
                        if let summary = pkg.summary, !summary.isEmpty {
                            Text(summary)
                                .font(.system(size: 13, weight: .medium, design: .rounded))
                                .foregroundStyle(.white.opacity(0.52))
                                .lineLimit(2)
                        }
                    }
                    Spacer(minLength: 0)
                }
                .frame(maxWidth: .infinity, alignment: .leading)

                infoCard(pkg)

                if let desc = pkg.description, !desc.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                    VStack(alignment: .leading, spacing: 9) {
                        Label("Cách sử dụng", systemImage: "book.closed.fill")
                            .font(.system(size: 17, weight: .bold, design: .rounded))
                        Text(desc)
                            .font(.system(size: 14, weight: .medium, design: .rounded))
                            .foregroundStyle(.white.opacity(0.54))
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(18)
                    .shinnGlass(radius: 22)
                }

                if let tags = pkg.tags, !tags.isEmpty {
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Tags")
                            .font(.system(size: 17, weight: .bold, design: .rounded))
                        FlowTags(tags: tags)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(18)
                    .shinnGlass(radius: 22)
                }

                patchActionCard(pkg)
            }
            .padding(.horizontal, 18)
            .padding(.top, 8)
            .padding(.bottom, 22)
        }
    }

    private func hero(_ pkg: RepoPackage) -> some View {
        let urlString = (pkg.icon ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        return Group {
            if let url = URL(string: urlString), url.scheme != nil {
                AsyncImage(url: url) { phase in
                    switch phase {
                    case .success(let image):
                        image.resizable().scaledToFill()
                    case .failure:
                        placeholderIcon(pkg)
                    case .empty:
                        ZStack {
                            Color.white.opacity(0.04)
                            ProgressView().tint(ShinnRed)
                        }
                    @unknown default:
                        placeholderIcon(pkg)
                    }
                }
            } else {
                placeholderIcon(pkg)
            }
        }
        .frame(width: 64, height: 64)
        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .stroke(LinearGradient(colors: [Color.white.opacity(0.24), ShinnRed.opacity(0.72), Color.white.opacity(0.08)], startPoint: .topLeading, endPoint: .bottomTrailing), lineWidth: 1)
        )
        .shadow(color: ShinnRed.opacity(0.12), radius: 8, y: 4)
    }

    private func placeholderIcon(_ pkg: RepoPackage) -> some View {
        ZStack {
            LinearGradient(colors: [Color.white.opacity(0.07), Color.black.opacity(0.34)], startPoint: .topLeading, endPoint: .bottomTrailing)
            Image(systemName: categoryIcon(pkg.category ?? ""))
                .font(.system(size: 22, weight: .bold))
                .foregroundStyle(ShinnRed)
        }
    }

    private func infoCard(_ pkg: RepoPackage) -> some View {
        VStack(spacing: 0) {
            infoRow("Version", pkg.version ?? "-")
            infoRow("Author", pkg.author ?? "-")
            infoRow("Category", pkg.category ?? "-")
            infoRow("Size", pkg.size.map { formatBytes($0) } ?? "-")
        }
        .padding(.horizontal, 18)
        .padding(.vertical, 4)
        .shinnGlass(radius: 24)
    }

    private func infoRow(_ label: String, _ value: String) -> some View {
        HStack(spacing: 12) {
            Text(label)
                .foregroundStyle(.white.opacity(0.48))
            Spacer()
            Text(value)
                .fontWeight(.semibold)
                .foregroundStyle(.white.opacity(0.94))
                .multilineTextAlignment(.trailing)
        }
        .font(.system(size: 15, weight: .medium, design: .rounded))
        .padding(.vertical, 15)
    }

    @ViewBuilder
    private func patchActionCard(_ pkg: RepoPackage) -> some View {
        switch store.state(for: pkg) {
        case .idle:
            Button {
                abuse.patchToggled()
                Task { await store.download(pkg) }
            } label: {
                Label("DOWNLOAD", systemImage: "arrow.down.circle.fill")
            }
            .buttonStyle(ShinnPremiumButtonStyle())

        case .downloading:
            HStack(spacing: 12) {
                ProgressView().tint(.white)
                Text("ĐANG TẢI PATCH…")
                    .font(.system(size: 15, weight: .black, design: .rounded))
            }
            .frame(maxWidth: .infinity, minHeight: 58)
            .shinnGlass(radius: 19)

        case .done:
            applyCard(pkg)

        case .failed(let error):
            VStack(spacing: 12) {
                Text(error.message)
                    .font(.system(size: 14, weight: .semibold, design: .rounded))
                    .foregroundStyle(.red)
                    .frame(maxWidth: .infinity, alignment: .leading)
                Button {
                    Task { await store.download(pkg) }
                } label: {
                    Label("THỬ LẠI", systemImage: "arrow.clockwise")
                }
                .buttonStyle(ShinnPremiumButtonStyle())
            }
            .padding(18)
            .shinnGlass(radius: 22)
        }
    }

    private func applyCard(_ pkg: RepoPackage) -> some View {
        let state = store.patchState(for: pkg)
        let isOn: Bool = {
            if case .applied = state { return true }
            return false
        }()
        let busy: Bool = {
            if case .applying = state { return true }
            if case .restoring = state { return true }
            return isApplying
        }()

        return VStack(spacing: 10) {
            HStack(spacing: 14) {
                ZStack {
                    Circle()
                        .fill(isOn ? ShinnRed.opacity(0.16) : Color.white.opacity(0.055))
                    Image(systemName: isOn ? "bolt.fill" : "bolt")
                        .font(.system(size: 19, weight: .bold))
                        .foregroundStyle(isOn ? ShinnRed : .white.opacity(0.82))
                }
                .frame(width: 46, height: 46)

                VStack(alignment: .leading, spacing: 3) {
                    Text("Patch")
                        .font(.system(size: 17, weight: .bold, design: .rounded))
                    Text(busy ? "Đang xử lý…" : (isOn ? "Patch đang hoạt động" : "Bật / tắt patch"))
                        .font(.system(size: 12.5, weight: .medium, design: .rounded))
                        .foregroundStyle(.white.opacity(0.48))
                        .lineLimit(1)
                }

                Spacer(minLength: 8)

                if busy {
                    ProgressView()
                        .tint(ShinnRed)
                        .frame(width: 48, height: 32)
                } else {
                    Toggle("", isOn: Binding(
                        get: { isOn },
                        set: { newValue in
                            abuse.patchToggled()
                            isApplying = true
                            Task {
                                if newValue {
                                    await store.apply(pkg, openGame: true)
                                } else {
                                    await store.restore(pkg)
                                }
                                await MainActor.run {
                                    isApplying = false
                                    switch store.patchState(for: pkg) {
                                    case .applied:
                                        showToast(store.lastApplyMessage ?? "Patch đã được áp dụng. Đang mở game…", error: false)
                                    case .failed(let message):
                                        showToast(message, error: true)
                                    case .restored:
                                        showToast("Đã tắt và khôi phục patch.", error: false)
                                    default:
                                        break
                                    }
                                }
                            }
                        }
                    ))
                    .labelsHidden()
                    .toggleStyle(ShinnPremiumToggleStyle())
                    .disabled(busy)
                }
            }
            .frame(minHeight: 58)

            if case .failed(let message) = state {
                Text(message)
                    .font(.system(size: 12, weight: .medium, design: .rounded))
                    .foregroundStyle(.red.opacity(0.9))
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .shinnGlass(radius: 20)
        .overlay(
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .stroke(isOn ? ShinnRed.opacity(0.62) : Color.white.opacity(0.10), lineWidth: 1)
        )
        .shadow(color: isOn ? ShinnRed.opacity(0.20) : .clear, radius: 18, y: 7)
    }

    private func stateTitle(_ state: PatchState) -> String {
        switch state {
        case .applied: return "Patch đang hoạt động"
        case .applying: return "Đang áp dụng"
        case .failed: return "Không thể áp dụng"
        default: return "Sẵn sàng áp dụng"
        }
    }

    private func stateSubtitle(_ state: PatchState) -> String {
        switch state {
        case .applied: return "Patch đã được áp dụng. Game sẽ được mở tự động nếu Open URL của patch hợp lệ."
        case .failed(let message): return message
        default: return "Patch đã tải xong. Nhấn ÁP DỤNG PATCH để bắt đầu."
        }
    }

    private func stateIcon(_ state: PatchState) -> String {
        switch state {
        case .applied: return "checkmark"
        case .failed: return "xmark"
        case .applying: return "bolt.fill"
        default: return "bolt.fill"
        }
    }

    private func stateColor(_ state: PatchState) -> Color {
        switch state {
        case .applied: return .green
        case .failed: return .red
        default: return ShinnRed
        }
    }

    private func showToast(_ message: String, error: Bool) {
        patchToastIsError = error
        patchToastMessage = message
        withAnimation(.spring(response: 0.35, dampingFraction: 0.82)) { showPatchToast = true }
        DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
            withAnimation(.easeOut(duration: 0.25)) { showPatchToast = false }
        }
    }
}


private struct ShinnPremiumToggleStyle: ToggleStyle {
    func makeBody(configuration: Configuration) -> some View {
        Button {
            withAnimation(.spring(response: 0.28, dampingFraction: 0.78)) {
                configuration.isOn.toggle()
            }
        } label: {
            ZStack(alignment: configuration.isOn ? .trailing : .leading) {
                Capsule()
                    .fill(configuration.isOn ? ShinnRed : Color.white.opacity(0.12))
                    .frame(width: 58, height: 34)
                    .overlay(
                        Capsule().stroke(
                            configuration.isOn ? ShinnRed.opacity(0.8) : Color.white.opacity(0.16),
                            lineWidth: 1
                        )
                    )
                    .shadow(color: configuration.isOn ? ShinnRed.opacity(0.45) : .clear, radius: 10)

                Circle()
                    .fill(.white)
                    .frame(width: 27, height: 27)
                    .padding(3.5)
                    .shadow(color: .black.opacity(0.35), radius: 4, y: 2)
            }
        }
        .buttonStyle(.plain)
        .accessibilityLabel(configuration.isOn ? "Tắt patch" : "Bật patch")
    }
}


struct ShinnAboutView: View {
    @EnvironmentObject var settings: AppSettings
    @EnvironmentObject var session: Session
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                Text("Giới thiệu").font(.title.bold())
                Text("Shinn Cheat — quản lý & áp dụng patch qua Repo ShinnCheat.")
                    .foregroundStyle(.secondary)
                Text("Version \(AppInfo.shinnVersion)").font(.footnote).foregroundStyle(.secondary)
                Text("App by Shinn · Owner: NgVuMinhHieuu / ShinnThieuu")
                    .font(.footnote)

                if session.role == .owner {
                    NavigationLink(value: Route.patchProjects) {
                        Label("Tạo Patch (3105)", systemImage: "plus.app.fill")
                            .font(.headline)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 14)
                            .background(Color.primary, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                            .foregroundStyle(Color(.systemBackground))
                    }
                    .buttonStyle(.plain)
                    .padding(.top, 8)
                }

                Link(destination: AppInfo.telegramLinkURL) {
                    Label("Support · @ShinnThieuu", systemImage: "paperplane.fill")
                }
                .padding(.top, 6)
            }
            .padding(18)
        }
        .background(BackgroundView())
        .navigationTitle("About")
        .navigationBarTitleDisplayMode(.inline)
    }
}


// ===== Dọn dẹp máy =====

/// Hub tạo patch — không crash (tránh mở PatchProjectsView thiếu EnvironmentObject)
struct CreatePatchSafeHubView: View {
    @EnvironmentObject var session: Session

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                Text("Tạo Patch").font(.title.bold())
                Text("Dùng tab Tệp hoặc tab Patch phía dưới màn hình (giao diện 3105 gốc).")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)

                VStack(alignment: .leading, spacing: 10) {
                    Label("Cách tạo", systemImage: "1.circle.fill")
                        .font(.headline)
                    Text("• Tab Tệp → container game → Documents → giữ file → Tạo patch\n• Hoặc tab Patch → tạo / sửa dự án patch")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
                .padding(14)
                .shinnGlass()

                if session.role == .owner {
                    NavigationLink(value: Route.patchBuilder) {
                        Label("Xuất JSON / Import .3105 (Owner)", systemImage: "doc.badge.plus")
                            .font(.headline)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 14)
                            .background(Color.primary, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                            .foregroundStyle(Color(.systemBackground))
                    }
                    .buttonStyle(.plain)
                }

                NavigationLink(value: Route.cleanup) {
                    Label("Dọn dẹp máy", systemImage: "trash.circle")
                        .font(.subheadline.bold())
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                }
                .buttonStyle(.plain)
            }
            .padding(18)
        }
        .background(BackgroundView())
        .navigationTitle("Tạo Patch")
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct PhoneCleanupView: View {
    @State private var isWorking = false
    @State private var log: [String] = []
    @State private var lastFreed: Int64 = 0

    private var documents: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }
    private var caches: URL {
        FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0]
    }
    private var tmp: URL {
        FileManager.default.temporaryDirectory
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                Text("Dọn dẹp").font(.title.bold())
                Text("Xoá cache tải patch, file import tạm, URLCache — không xoá key hay cài đặt.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)

                if lastFreed > 0 {
                    Text("Đã giải phóng ~\(ByteCountFormatter.string(fromByteCount: lastFreed, countStyle: .file))")
                        .font(.subheadline.bold())
                        .foregroundStyle(.green)
                }

                Button {
                    Task { await runCleanup() }
                } label: {
                    Group {
                        if isWorking {
                            ProgressView().tint(Color(.systemBackground))
                        } else {
                            Label("Dọn dẹp ngay", systemImage: "trash.circle.fill")
                                .font(.headline.bold())
                        }
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)
                    .background(Color.orange, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                    .foregroundStyle(.white)
                }
                .buttonStyle(.plain)
                .disabled(isWorking)

                if !log.isEmpty {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("Chi tiết").font(.headline)
                        ForEach(log, id: \.self) { line in
                            Text("• \(line)")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    }
                    .padding(14)
                    .shinnGlass(radius: 14)
                }
            }
            .padding(18)
        }
        .background(BackgroundView())
        .navigationTitle("Dọn dẹp")
        .navigationBarTitleDisplayMode(.inline)
    }

    @MainActor
    private func runCleanup() async {
        isWorking = true
        log = []
        lastFreed = 0
        defer { isWorking = false }

        var freed: Int64 = 0
        let fm = FileManager.default

        func clearDir(_ url: URL, label: String, keepRoot: Bool = true) {
            guard fm.fileExists(atPath: url.path) else {
                log.append("\(label): không có")
                return
            }
            var total: Int64 = 0
            if let items = try? fm.contentsOfDirectory(at: url, includingPropertiesForKeys: [.fileSizeKey], options: [.skipsHiddenFiles]) {
                for item in items {
                    total += (try? item.resourceValues(forKeys: [.fileSizeKey]).fileSize).map(Int64.init) ?? 0
                    try? fm.removeItem(at: item)
                }
            }
            freed += total
            log.append("\(label): \(ByteCountFormatter.string(fromByteCount: total, countStyle: .file))")
        }

        // Patch downloads (RepoStore)
        clearDir(documents.appendingPathComponent("ShinnDownloads", isDirectory: true), label: "ShinnDownloads")
        clearDir(documents.appendingPathComponent("Downloads", isDirectory: true), label: "Downloads")
        clearDir(documents.appendingPathComponent("ShinnOwnerImports", isDirectory: true), label: "Owner imports")
        clearDir(caches, label: "Caches")
        // Temp files of app
        if let items = try? fm.contentsOfDirectory(at: tmp, includingPropertiesForKeys: [.fileSizeKey]) {
            var total: Int64 = 0
            for item in items {
                total += (try? item.resourceValues(forKeys: [.fileSizeKey]).fileSize).map(Int64.init) ?? 0
                try? fm.removeItem(at: item)
            }
            freed += total
            log.append("tmp: \(ByteCountFormatter.string(fromByteCount: total, countStyle: .file))")
        }

        URLCache.shared.removeAllCachedResponses()
        log.append("URLCache: đã xoá")

        lastFreed = freed
        log.append("Xong.")
    }
}


func iconForBundleID(_ bundleID: String) -> UIImage? {
    nil
}

struct ShinnDocumentPicker: UIViewControllerRepresentable {
    var allowsMultipleSelection = false
    var onSelection: (Result<[URL], Error>) -> Void
    var onCancel: () -> Void

    func makeCoordinator() -> Coordinator { Coordinator(self) }

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: [.data, .item], asCopy: true)
        picker.allowsMultipleSelection = allowsMultipleSelection
        picker.delegate = context.coordinator
        return picker
    }

    func updateUIViewController(_ uiViewController: UIDocumentPickerViewController, context: Context) {}

    final class Coordinator: NSObject, UIDocumentPickerDelegate {
        let parent: ShinnDocumentPicker
        init(_ parent: ShinnDocumentPicker) { self.parent = parent }
        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            parent.onSelection(.success(urls))
        }
        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
            parent.onCancel()
        }
    }
}


// MARK: - ProMotion 120Hz
enum ProMotion {
    /// 120Hz: bật bằng Info.plist CADisableMinimumFrameDurationOnPhone = YES.
    /// Không gọi API không tồn tại trên UIWindow.
    static func enable() {
        // no-op an toàn — hệ thống tự dùng ProMotion khi plist cho phép
        _ = UIScreen.main.maximumFramesPerSecond
    }
}

// MARK: - Edge LED khi activate key thành công
struct EdgeLEDRunView: View {
    var accent: Color = ShinnRed
    /// Tốc độ chạy (giây / 1 vòng)
    var duration: Double = 1.15
    @State private var phase: CGFloat = 0

    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 120.0, paused: false)) { context in
            let t = context.date.timeIntervalSinceReferenceDate
            let p = CGFloat((t / duration).truncatingRemainder(dividingBy: 1.0))
            GeometryReader { geo in
                let h = geo.size.height
                let w = geo.size.width
                ZStack {
                    // Glow nền dọc cạnh (luôn sáng nhẹ — tech frame)
                    edgeGlowBar(side: .leading, height: h)
                    edgeGlowBar(side: .trailing, height: h)

                    // Hạt LED chính + hạt phụ lệch pha
                    ledHead(phase: p, height: h)
                        .position(x: 3.5, y: h * p)
                    ledHead(phase: p, height: h)
                        .position(x: w - 3.5, y: h * p)

                    ledHead(phase: p, height: h, secondary: true)
                        .position(x: 3.5, y: h * ((p + 0.42).truncatingRemainder(dividingBy: 1)))
                    ledHead(phase: p, height: h, secondary: true)
                        .position(x: w - 3.5, y: h * ((p + 0.42).truncatingRemainder(dividingBy: 1)))
                }
                .allowsHitTesting(false)
            }
        }
        .ignoresSafeArea()
    }

    private enum EdgeSide { case leading, trailing }

    private func edgeGlowBar(side: EdgeSide, height: CGFloat) -> some View {
        HStack(spacing: 0) {
            if side == .trailing { Spacer(minLength: 0) }
            RoundedRectangle(cornerRadius: 2, style: .continuous)
                .fill(
                    LinearGradient(
                        colors: [
                            accent.opacity(0.0),
                            accent.opacity(0.55),
                            accent.opacity(0.85),
                            accent.opacity(0.55),
                            accent.opacity(0.0)
                        ],
                        startPoint: .top,
                        endPoint: .bottom
                    )
                )
                .frame(width: 2.5, height: height)
                .blur(radius: 0.3)
                .shadow(color: accent.opacity(0.9), radius: 8)
                .shadow(color: accent.opacity(0.55), radius: 16)
            if side == .leading { Spacer(minLength: 0) }
        }
    }

    private func ledHead(phase: CGFloat, height: CGFloat, secondary: Bool = false) -> some View {
        let core: CGFloat = secondary ? 10 : 16
        let glow: CGFloat = secondary ? 28 : 42
        let opacity: Double = secondary ? 0.75 : 1.0
        return ZStack {
            // Quầng ngoài
            Capsule()
                .fill(accent.opacity(0.35 * opacity))
                .frame(width: 10, height: glow)
                .blur(radius: 8)
            // Thân LED
            Capsule()
                .fill(
                    LinearGradient(
                        colors: [
                            accent.opacity(0.1),
                            accent,
                            Color.white.opacity(0.95),
                            accent,
                            accent.opacity(0.1)
                        ],
                        startPoint: .top,
                        endPoint: .bottom
                    )
                )
                .frame(width: secondary ? 4 : 5.5, height: core + 18)
                .shadow(color: accent.opacity(1), radius: 10)
                .shadow(color: Color.white.opacity(0.7), radius: 4)
            // Điểm trắng giữa (cảm giác diode)
            Circle()
                .fill(Color.white)
                .frame(width: secondary ? 3 : 4, height: secondary ? 3 : 4)
                .shadow(color: .white, radius: 3)
        }
        .opacity(opacity)
    }
}

// MARK: - Owner broadcast → tất cả key
struct AppAnnouncement: Codable, Identifiable {
    let id: UUID
    let title: String
    let body: String
    let created_at: String
}

@MainActor
final class AnnouncementStore: ObservableObject {
    @Published var current: AppAnnouncement?
    private let seenKey = "shinn.announce.lastSeen"

    private var lastSeen: Date {
        get {
            let t = UserDefaults.standard.double(forKey: seenKey)
            return t > 0 ? Date(timeIntervalSince1970: t) : Date.distantPast
        }
        set { UserDefaults.standard.set(newValue.timeIntervalSince1970, forKey: seenKey) }
    }

    func poll() async {
        var request = URLRequest(
            url: SupabaseConfig.projectURL.appendingPathComponent("/rest/v1/rpc/fetch_announcements")
        )
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue(SupabaseConfig.anonKey, forHTTPHeaderField: "apikey")
        request.setValue("Bearer \(SupabaseConfig.anonKey)", forHTTPHeaderField: "Authorization")

        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]

        if lastSeen == Date.distantPast {
            request.httpBody = Data("{\"p_after\": null}".utf8)
        } else {
            request.httpBody = try? JSONSerialization.data(withJSONObject: [
                "p_after": formatter.string(from: lastSeen)
            ])
        }

        guard let (data, response) = try? await URLSession.shared.data(for: request),
              let http = response as? HTTPURLResponse, 200...299 ~= http.statusCode,
              let list = try? JSONDecoder().decode([AppAnnouncement].self, from: data),
              let newest = list.last else { return }

        current = newest
        if let date = formatter.date(from: newest.created_at)
            ?? ISO8601DateFormatter().date(from: newest.created_at) {
            lastSeen = date
        }
    }

    func dismiss() { current = nil }

    static func broadcast(title: String, body: String, actorKey: String) async -> Bool {
        var request = URLRequest(
            url: SupabaseConfig.projectURL.appendingPathComponent("/rest/v1/rpc/broadcast_announcement")
        )
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue(SupabaseConfig.anonKey, forHTTPHeaderField: "apikey")
        request.setValue("Bearer \(SupabaseConfig.anonKey)", forHTTPHeaderField: "Authorization")
        request.httpBody = try? JSONSerialization.data(withJSONObject: [
            "p_title": title,
            "p_body": body,
            "p_actor_key": actorKey
        ])
        guard let (_, response) = try? await URLSession.shared.data(for: request),
              let http = response as? HTTPURLResponse else { return false }
        return (200...299).contains(http.statusCode)
    }
}



