import SwiftUI
import UIKit
import PhotosUI

// MARK: - Shinn Command Center V6
// New visual shell. It reuses the existing server-backed LicenseManager,
// RepoStore and OwnerKeyManager so the backend remains the source of truth.

struct ShinnCompleteRootView: View {
    @EnvironmentObject private var store: RepoStore
    @EnvironmentObject private var license: LicenseManager
    @EnvironmentObject private var session: Session
    @State private var tab = 0
    @State private var destination: ShinnCompleteDestination?
    @StateObject private var personalization = ShinnPersonalizationStore.shared

    var body: some View {
        ZStack {
            // Home background is fixed like the demo. Only the avatar is user-editable.
            ShinnCompleteBackground(backgroundImage: nil)
            TabView(selection: $tab) {
                ShinnCompleteHome(license: license, session: session, personalization: personalization, destination: $destination)
                    .tag(0)
                ShinnPatchCenterView()
                    .tag(1)
                ShinnAIChatView()
                    .tag(2)
                ShinnCompleteAccount(license: license, session: session, destination: $destination)
                    .tag(3)
            }
            .tabViewStyle(.page(indexDisplayMode: .never))
        }
        .safeAreaInset(edge: .bottom, spacing: 0) {
            ShinnCompleteTabBar(tab: $tab, isOwner: session.role == .owner)
        }
        .sheet(item: $destination) { d in
            NavigationStack {
                switch d {
                case .owner: ShinnCompleteOwnerHub()
                case .personalize: ShinnCompletePersonalizationView(store: personalization, initialTarget: 0)
                case .personalizeAvatar: ShinnCompletePersonalizationView(store: personalization, initialTarget: 0)
                case .personalizeBackground: ShinnCompletePersonalizationView(store: personalization, initialTarget: 0)
                case .key: ActivateKeyView()
                case .history: ShinnCompleteHistoryView(title: "Patch History")
                case .downloadHistory: ShinnCompleteHistoryView(title: "Download History")
                case .settings: ShinnSettingsHubView()
                case .repository: RepositoryManagerView()
                case .about: AboutView()
                case .terms: ShinnCompleteTermsView()
                case .logout: ShinnCompleteLogoutView(license: license)
                }
            }
            .preferredColorScheme(.dark)
        }
    }
}

private enum ShinnCompleteDestination: String, Identifiable {
    case owner, personalize, personalizeAvatar, personalizeBackground, key, history, downloadHistory, settings, repository, about, terms, logout
    var id: String { rawValue }
}

private struct ShinnCompleteBackground: View {
    let backgroundImage: UIImage?
    @State private var animate = false
    init(backgroundImage: UIImage? = nil) { self.backgroundImage = backgroundImage }
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            if let backgroundImage {
                Image(uiImage: backgroundImage)
                    .resizable()
                    .scaledToFill()
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .clipped()
                    .ignoresSafeArea()
                Color.black.opacity(0.72).ignoresSafeArea()
            } else {
                LinearGradient(colors: [Color(red: 0.025, green: 0.035, blue: 0.075), .black, Color(red: 0.035, green: 0.015, blue: 0.055)], startPoint: .topLeading, endPoint: .bottomTrailing).ignoresSafeArea()
            }
            Circle().fill(Color.cyan.opacity(0.10)).frame(width: 300).blur(radius: 80).offset(x: animate ? 120 : 50, y: -270)
            Circle().fill(Color.purple.opacity(0.08)).frame(width: 340).blur(radius: 90).offset(x: animate ? -130 : -60, y: 330)
        }
        .onAppear { withAnimation(.easeInOut(duration: 7).repeatForever(autoreverses: true)) { animate = true } }
    }
}

private struct ShinnCompleteHome: View {
    @ObservedObject var license: LicenseManager
    @ObservedObject var session: Session
    @ObservedObject var personalization: ShinnPersonalizationStore
    @Binding var destination: ShinnCompleteDestination?
    @EnvironmentObject private var store: RepoStore

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 16) {
                HStack(alignment: .center) {
                    VStack(alignment: .leading, spacing: 3) {
                        Text("SHINNCHEAT").font(.system(size: 13, weight: .black, design: .rounded)).tracking(2.0).foregroundStyle(.cyan)
                        Text(license.holderName.isEmpty ? "ShinnThieuu" : license.holderName)
                            .font(.system(size: 29, weight: .black, design: .rounded))
                            .foregroundStyle(.white)
                    }
                    Spacer()
                    ZStack(alignment: .bottomTrailing) {
                        Group {
                            if let image = personalization.sImage {
                                Image(uiImage: image).resizable().scaledToFill()
                            } else {
                                Circle()
                                    .fill(.ultraThinMaterial)
                                    .overlay(Image(systemName: session.role == .owner ? "crown.fill" : "person.fill")
                                        .foregroundStyle(session.role == .owner ? .red : .cyan))
                            }
                        }
                        .frame(width: 44, height: 44)
                        .clipShape(Circle())
                        .overlay(Circle().stroke(.white.opacity(0.14), lineWidth: 1))

                        Image(systemName: "checkmark.seal.fill")
                            .font(.system(size: 13, weight: .bold))
                            .foregroundStyle(session.role == .owner ? .red : ((license.boundRole ?? "").lowercased().contains("test") ? .green : .blue))
                            .background(Circle().fill(Color.black).frame(width: 16, height: 16))
                    }
                }
                .padding(.top, 14)

                licenseCard
                accessGrid
                recentPatches
                quickTools
            }
            .padding(.horizontal, 16)
            .padding(.bottom, 20)
        }
    }

    private var licenseCard: some View {
        HStack(spacing: 13) {
            Group {
                if let image = personalization.sImage {
                    Image(uiImage: image).resizable().scaledToFill()
                } else {
                    Image(systemName: "key.fill").font(.system(size: 23, weight: .bold)).foregroundStyle(.cyan)
                }
            }
            .frame(width: 58, height: 58)
            .clipShape(RoundedRectangle(cornerRadius: 17, style: .continuous))
            .background(Color.cyan.opacity(0.10), in: RoundedRectangle(cornerRadius: 17))
            .overlay(alignment: .bottomTrailing) {
                Image(systemName: "checkmark.seal.fill")
                    .font(.system(size: 14, weight: .bold))
                    .foregroundStyle(session.role == .owner ? .red : ((license.boundRole ?? "").lowercased().contains("test") ? .green : .blue))
                    .background(Circle().fill(Color.black).frame(width: 17, height: 17))
                    .offset(x: 3, y: 3)
            }

            VStack(alignment: .leading, spacing: 5) {
                Text(license.savedLicenseKey.isEmpty ? "No active key" : license.savedLicenseKey)
                    .font(.system(size: 15, weight: .bold, design: .rounded))
                    .lineLimit(1)
                if let expiry = license.expiresAt {
                    Text("Expires: \(expiry.formatted(date: .abbreviated, time: .shortened))")
                        .font(.system(size: 11, weight: .medium))
                        .foregroundStyle(.white.opacity(0.55))
                    Text("Remaining: \(remainingKeyText(expiry))")
                        .font(.system(size: 12, weight: .bold))
                        .foregroundStyle(.cyan)
                } else {
                    Text("No expiry information")
                        .font(.caption)
                        .foregroundStyle(.white.opacity(0.45))
                }
            }
            Spacer()
            Text("ACTIVE")
                .font(.system(size: 9, weight: .black))
                .foregroundStyle(.green)
                .padding(.horizontal, 8).padding(.vertical, 5)
                .background(.green.opacity(0.12), in: Capsule())
        }
        .padding(15)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 22).stroke(Color.white.opacity(0.08)))
    }

    private var accessGrid: some View {
        HStack(spacing: 10) {
            accessCard("Repo V1", "AVAILABLE", "square.stack.3d.up.fill", .cyan)
            accessCard("Repo V2", store.isRepoV2Authorized ? "AVAILABLE" : "LOCKED", "crown.fill",
                       store.isRepoV2Authorized ? .yellow : .orange)
        }
    }

    private func accessCard(_ title: String, _ value: String, _ icon: String, _ tint: Color) -> some View {
        VStack(alignment: .leading, spacing: 7) {
            Image(systemName: icon).foregroundStyle(tint)
            Text(title).font(.caption.bold()).foregroundStyle(.white.opacity(0.55))
            Text(value).font(.headline.bold())
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(15)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 20))
        .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.white.opacity(0.08)))
    }

    private var recentPatches: some View {
        VStack(alignment: .leading, spacing: 9) {
            HStack {
                Text("RECENTLY USED").font(.caption.bold()).tracking(1.4).foregroundStyle(.white.opacity(0.45))
                Spacer()
                Button("View all") { destination = .history }
                    .font(.caption.bold()).foregroundStyle(.cyan)
            }

            if store.patchUsageHistory.isEmpty {
                HStack {
                    Image(systemName: "clock.arrow.circlepath").foregroundStyle(.white.opacity(0.4))
                    Text("Patches you use will appear here.")
                        .font(.caption)
                        .foregroundStyle(.white.opacity(0.42))
                    Spacer()
                }
                .padding(14)
                .background(Color.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 18))
            } else {
                ForEach(Array(store.patchUsageHistory.prefix(4))) { item in
                    HStack(spacing: 10) {
                        Image(systemName: "shippingbox.fill")
                            .foregroundStyle(item.repo == "Repo V2" ? .purple : .cyan)
                            .frame(width: 34, height: 34)
                            .background(Color.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 11))
                        VStack(alignment: .leading, spacing: 2) {
                            Text(item.name).font(.subheadline.bold()).lineLimit(1)
                            Text("\(item.repo) · \(item.action)")
                                .font(.caption2).foregroundStyle(.white.opacity(0.42))
                        }
                        Spacer()
                        Text(item.success ? "OK" : "FAILED")
                            .font(.system(size: 9, weight: .black))
                            .foregroundStyle(item.success ? .green : .red)
                    }
                    .padding(11)
                    .background(Color.white.opacity(0.035), in: RoundedRectangle(cornerRadius: 17))
                }
            }
        }
    }

    private var quickTools: some View {
        VStack(alignment: .leading, spacing: 9) {
            Text("QUICK TOOLS").font(.caption.bold()).tracking(1.4).foregroundStyle(.white.opacity(0.45))
            tool("Avatar", "Change profile image only", "person.crop.circle", .cyan) { destination = .personalizeAvatar }
            tool("Patch History", "Applied / restored activity", "clock.arrow.circlepath", .purple) { destination = .history }
            if session.role == .owner {
                tool("Owner Keys", "Create and manage keys", "key.fill", .yellow) { destination = .owner }
            }
        }
    }

    private func tool(_ title: String, _ subtitle: String, _ icon: String, _ tint: Color, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 13) {
                Image(systemName: icon)
                    .frame(width: 40, height: 40)
                    .background(tint.opacity(0.13), in: RoundedRectangle(cornerRadius: 13))
                    .foregroundStyle(tint)
                VStack(alignment: .leading, spacing: 3) {
                    Text(title).font(.headline.bold())
                    Text(subtitle).font(.caption).foregroundStyle(.white.opacity(0.43))
                }
                Spacer()
                Image(systemName: "chevron.right").foregroundStyle(.white.opacity(0.22))
            }
            .padding(13)
            .background(Color.white.opacity(0.04), in: RoundedRectangle(cornerRadius: 19))
            .overlay(RoundedRectangle(cornerRadius: 19).stroke(Color.white.opacity(0.06)))
        }
        .buttonStyle(.plain)
    }
}

private struct ShinnCompleteAccount: View {
    @ObservedObject var license: LicenseManager
    @ObservedObject var session: Session
    @Binding var destination: ShinnCompleteDestination?

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 13) {
                Text("ACCOUNT")
                    .font(.system(size: 13, weight: .black, design: .rounded))
                    .tracking(2)
                    .foregroundStyle(.cyan)
                    .padding(.top, 18)

                HStack(spacing: 12) {
                    Circle()
                        .fill(Color.cyan.opacity(0.13))
                        .frame(width: 62, height: 62)
                        .overlay(Image(systemName: "person.fill").font(.title2).foregroundStyle(.cyan))
                        .overlay(alignment: .bottomTrailing) {
                            Image(systemName: "camera.fill")
                                .font(.system(size: 9, weight: .bold))
                                .frame(width: 23, height: 23)
                                .background(.cyan, in: Circle())
                                .foregroundStyle(.black)
                        }
                    VStack(alignment: .leading, spacing: 3) {
                        Text(license.holderName.isEmpty ? "ShinnThieuu" : license.holderName)
                            .font(.system(size: 24, weight: .black, design: .rounded))
                        Text(session.role == .owner ? "OWNER" : (license.boundRole?.uppercased() ?? "MEMBER"))
                            .font(.caption.bold()).foregroundStyle(.cyan)
                    }
                }

                accountCard

                accountButton("Owner Control", "Create and manage keys", "crown.fill", .yellow) {
                    destination = .owner
                }
                .opacity(session.role == .owner ? 1 : 0.45)
                .disabled(session.role != .owner)

                accountButton("Downloaded Patches", "View patches saved on this device", "arrow.down.circle.fill", .cyan) {
                    destination = .downloadHistory
                }

                accountButton("Patch History", "Applied and restored activity", "clock.arrow.circlepath", .purple) {
                    destination = .history
                }

                accountButton("Repository V2", "Grant or lock V2 access", "lock.doc.fill", .purple) {
                    destination = .repository
                }
                .opacity(session.role == .owner ? 1 : 0.45)
                .disabled(session.role != .owner)

                accountButton("Settings", "Appearance and app preferences", "gearshape.fill", .cyan) {
                    destination = .settings
                }

                accountButton("Terms of Use", "Read the app usage terms", "doc.text.fill", .white) {
                    destination = .terms
                }

                accountButton("About", "ShinnCheat information", "info.circle.fill", .white) {
                    destination = .about
                }

                Button {
                    destination = .logout
                } label: {
                    HStack {
                        Image(systemName: "rectangle.portrait.and.arrow.right")
                            .foregroundStyle(.red)
                            .frame(width: 42, height: 42)
                            .background(Color.red.opacity(0.12), in: RoundedRectangle(cornerRadius: 14))
                        VStack(alignment: .leading) {
                            Text("Logout Key").font(.headline.bold()).foregroundStyle(.red)
                            Text("Remove the current activation from this device")
                                .font(.caption).foregroundStyle(.white.opacity(0.42))
                        }
                        Spacer()
                        Image(systemName: "chevron.right").foregroundStyle(.white.opacity(0.22))
                    }
                    .padding(14)
                    .background(Color.red.opacity(0.035), in: RoundedRectangle(cornerRadius: 20))
                }
                .buttonStyle(.plain)
            }
            .padding(.horizontal, 16)
        }
    }

    private var accountCard: some View {
        VStack(alignment: .leading, spacing: 9) {
            Text("LICENSE").font(.caption.bold()).foregroundStyle(.white.opacity(0.45))
            Text(license.savedLicenseKey.isEmpty ? "No active key" : license.savedLicenseKey)
                .font(.headline.monospaced()).lineLimit(1)
            if let d = license.expiresAt {
                Text("Expires: \(d.formatted(date: .abbreviated, time: .shortened))")
                    .font(.caption).foregroundStyle(.white.opacity(0.55))
                Text("Remaining: \(remainingKeyText(d))")
                    .font(.caption.bold()).foregroundStyle(.cyan)
            }
            Text("Device access: Unlimited")
                .font(.caption2.bold()).foregroundStyle(.green)
        }
        .padding(17)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 22))
        .overlay(RoundedRectangle(cornerRadius: 22).stroke(Color.white.opacity(0.08)))
    }

    private func accountButton(_ title: String, _ sub: String, _ icon: String, _ tint: Color, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack {
                Image(systemName: icon)
                    .foregroundStyle(tint)
                    .frame(width: 42, height: 42)
                    .background(tint.opacity(0.12), in: RoundedRectangle(cornerRadius: 14))
                VStack(alignment: .leading) {
                    Text(title).font(.headline.bold())
                    Text(sub).font(.caption).foregroundStyle(.white.opacity(0.42))
                }
                Spacer()
                Image(systemName: "chevron.right").foregroundStyle(.white.opacity(0.25))
            }
            .padding(14)
            .background(Color.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 20))
            .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.white.opacity(0.06)))
        }
        .buttonStyle(.plain)
    }
}

private struct ShinnCompleteTabBar: View {
    @Binding var tab: Int
    let isOwner: Bool
    let items = [("house.fill", "Home"), ("square.grid.2x2.fill", "Patch"), ("sparkles", "Chat"), ("person.crop.circle.fill", "Account")]
    var body: some View { HStack { ForEach(items.indices, id: \.self) { i in Button { withAnimation(.easeInOut(duration: 0.2)) { tab = i } } label: { VStack(spacing: 4) { Image(systemName: items[i].0).font(.system(size: 17, weight: .bold)); Text(items[i].1).font(.system(size: 9, weight: .bold)) }.foregroundStyle(tab == i ? .cyan : .white.opacity(0.42)).frame(maxWidth: .infinity).padding(.vertical, 9).background(tab == i ? Color.cyan.opacity(0.10) : .clear, in: RoundedRectangle(cornerRadius: 15)) }.buttonStyle(.plain) } }.padding(8).background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 24)).overlay(RoundedRectangle(cornerRadius: 24).stroke(Color.white.opacity(0.10))).padding(.horizontal, 12).padding(.bottom, 6) }
}

private struct ShinnCompleteTermsView: View {
    var body: some View {
        List {
            Section("Usage") {
                Text("Use only patches and repository content that you are authorized to use. Check compatibility before applying a patch.")
            }
            Section("Keys") {
                Text("Keys, expiration and repository permissions are controlled by the ShinnCheat key system. Do not share private activation keys.")
            }
            Section("Repository") {
                Text("Repo V1 is available to keys that have V1 access. Repo V2 requires an explicit permission from the Owner.")
            }
            Section("Updates") {
                Text("These terms may change when the application or repository system changes.")
            }
        }
        .navigationTitle("Terms of Use")
    }
}

private struct ShinnCompleteLogoutView: View {
    @ObservedObject var license: LicenseManager
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        VStack(spacing: 18) {
            Image(systemName: "rectangle.portrait.and.arrow.right")
                .font(.system(size: 46))
                .foregroundStyle(.red)
            Text("Logout Key")
                .font(.title.bold())
            Text("The current activation will be removed from this device. You can activate the key again later.")
                .multilineTextAlignment(.center)
                .foregroundStyle(.secondary)
            Button("Logout") {
                license.signOutLicense()
                dismiss()
            }
            .buttonStyle(.borderedProminent)
            .tint(.red)
            Button("Cancel") { dismiss() }
                .buttonStyle(.bordered)
        }
        .padding(24)
        .navigationTitle("Logout")
    }
}

// MARK: Owner control
private struct ShinnCompleteOwnerHub: View {
    @StateObject private var manager = OwnerKeyManager()
    @State private var command = "/keys"
    @State private var showCreate = false
    var body: some View {
        ScrollView { VStack(alignment: .leading, spacing: 16) {
            HStack { VStack(alignment: .leading) { Text("OWNER CONTROL").font(.caption.bold()).tracking(2).foregroundStyle(.yellow); Text("Key Command Center").font(.largeTitle.bold()) }; Spacer(); Image(systemName: "crown.fill").foregroundStyle(.yellow).font(.title) }
            stats
            HStack(spacing: 10) { ownerAction("Create Key", "plus", .cyan) { showCreate = true }; ownerAction("Refresh", "arrow.clockwise", .purple) { Task { await manager.listKeys() } } }
            Text("KEYS").font(.caption.bold()).tracking(1.5).foregroundStyle(.white.opacity(0.45))
            ForEach(manager.keys) { row in keyRow(row) }
            Text("BOT COMMANDS").font(.caption.bold()).tracking(1.5).foregroundStyle(.white.opacity(0.45)).padding(.top, 8)
            commandBox
        }.padding(16) }
        .navigationTitle("Owner")
        .sheet(isPresented: $showCreate) { NavigationStack { ShinnCompleteCreateKey(manager: manager) } }
        .task { await manager.listKeys() }
    }
    private var stats: some View { HStack { stat("TOTAL", "\(manager.keys.count)"); stat("ACTIVE", "\(manager.keys.filter { expiry($0.expires_at) > Date() }.count)"); stat("VIP", "\(manager.keys.filter { $0.is_vip == true }.count)") }.padding(16).background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 22)) }
    private func stat(_ a: String, _ b: String) -> some View { VStack(alignment: .leading) { Text(a).font(.caption2).foregroundStyle(.white.opacity(0.4)); Text(b).font(.title3.bold()) }.frame(maxWidth: .infinity, alignment: .leading) }
    private func ownerAction(_ t: String, _ icon: String, _ c: Color, action: @escaping () -> Void) -> some View { Button(action: action) { Label(t, systemImage: icon).font(.headline.bold()).frame(maxWidth: .infinity).padding(14).background(c.opacity(0.13), in: RoundedRectangle(cornerRadius: 18)).overlay(RoundedRectangle(cornerRadius: 18).stroke(c.opacity(0.3))) }.buttonStyle(.plain) }
    private func keyRow(_ row: ShinnKeyRow) -> some View { VStack(alignment: .leading, spacing: 8) { HStack { Text(row.key).font(.headline.monospaced()); Spacer(); Text(row.role?.uppercased() ?? "MEMBER").font(.caption2.bold()).foregroundStyle(.cyan) }; Text(row.label ?? "No username").font(.caption).foregroundStyle(.white.opacity(0.55)); HStack { Text(formatKeyExpiry(row.expires_at)).font(.caption2); Spacer(); let exp = expiry(row.expires_at); Text(exp > Date() ? remainingKeyText(exp) : "EXPIRED").font(.caption2.bold()).foregroundStyle(exp > Date() ? .green : .red) }; HStack { Button("Delete") { Task { await manager.deleteKey(row.key) } }.font(.caption.bold()).foregroundStyle(.red); Spacer(); Button("Lock V2") { command = "/lockv2 \(row.key)" }.font(.caption.bold()).foregroundStyle(.orange) } }.padding(15).background(Color.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 20)).overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.white.opacity(0.07))) }
    private var commandBox: some View { VStack(alignment: .leading, spacing: 10) { Picker("Command", selection: $command) { Text("/keys").tag("/keys"); Text("/createkey").tag("/createkey"); Text("/deletekey").tag("/deletekey"); Text("/lockkey").tag("/lockkey"); Text("/grantv2").tag("/grantv2") }.pickerStyle(.menu); Text(command).font(.system(.body, design: .monospaced)).foregroundStyle(.cyan).textSelection(.enabled); Button { UIPasteboard.general.string = command } label: { Label("Copy command", systemImage: "doc.on.doc").frame(maxWidth: .infinity).padding(11).background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 14)) }.buttonStyle(.plain) }.padding(15).background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 20)) }
    private func expiry(_ raw: String?) -> Date { guard let raw, let d = ISO8601DateFormatter().date(from: raw) else { return .distantPast }; return d }
}

private struct ShinnCompleteCreateKey: View {
    @ObservedObject var manager: OwnerKeyManager
    @Environment(\.dismiss) private var dismiss
    @State private var duration = "30d"

    var body: some View {
        Form {
            Section("Key name") {
                Text("Feedback@ShinnThieuu")
                    .font(.headline)
                Text("This is the key name/label, not the activation key. The activation key is generated by Supabase after creation.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Section("Duration") {
                Picker("Time", selection: $duration) {
                    Text("1 Hour").tag("1h")
                    Text("1 Day").tag("1d")
                    Text("3 Days").tag("3d")
                    Text("7 Days").tag("7d")
                    Text("30 Days").tag("30d")
                }
                .pickerStyle(.menu)
            }

            Section("Devices") {
                HStack {
                    Text("Device limit")
                    Spacer()
                    Text("Unlimited")
                        .foregroundStyle(.green)
                        .font(.headline)
                }
                Text("This key is intended for Repo V1 only.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Section("Quantity") {
                Stepper("Create \(manager.createCount) key(s)", value: $manager.createCount, in: 1...99)
            }

            Section {
                Button {
                    manager.keyLabel = "Feedback@ShinnThieuu"
                    switch duration {
                    case "1h":
                        manager.selectedDays = 0
                        manager.selectedHours = 1
                    case "1d":
                        manager.selectedDays = 1
                        manager.selectedHours = 0
                    case "3d":
                        manager.selectedDays = 3
                        manager.selectedHours = 0
                    case "7d":
                        manager.selectedDays = 7
                        manager.selectedHours = 0
                    default:
                        manager.selectedDays = 30
                        manager.selectedHours = 0
                    }
                    manager.lifetime = false
                    Task {
                        let success = await manager.createKey()
                        if success { dismiss() }
                    }
                } label: {
                    Text("Create Key").frame(maxWidth: .infinity)
                }
            }
        }
        .navigationTitle("Create Key")
    }
}

// MARK: V6 compatibility views
private struct ShinnCompletePersonalizationView: View {
    @ObservedObject var store: ShinnPersonalizationStore
    let initialTarget: Int
    @State private var picker: PhotosPickerItem?
    var body: some View {
        Form {
            Section("Profile") {
                HStack(spacing: 12) {
                    Group {
                        if let image = store.sImage {
                            Image(uiImage: image).resizable().scaledToFill()
                        } else {
                            Image(systemName: "person.crop.circle.fill").resizable().scaledToFit().padding(8)
                        }
                    }
                    .frame(width: 58, height: 58)
                    .clipShape(Circle())

                    VStack(alignment: .leading, spacing: 3) {
                        Text("Avatar only").font(.headline)
                        Text("The Home background is fixed and cannot be uploaded.")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                }
                PhotosPicker(selection: $picker, matching: .images) {
                    Label("Choose Avatar", systemImage: "person.crop.circle")
                }
                if store.sImage != nil {
                    Button("Reset Avatar", role: .destructive) {
                        store.save(nil, key: "shinn.custom.sImage")
                    }
                }
            }
        }
        .navigationTitle("Avatar")
        .onChange(of: picker) { item in
            guard let item else { return }
            Task {
                if let data = try? await item.loadTransferable(type: Data.self), let image = UIImage(data: data) {
                    store.save(image, key: "shinn.custom.sImage")
                }
            }
        }
    }
}

private struct ShinnCompleteHistoryView: View {
    let title: String
    var body: some View {
        List {
            VStack(spacing: 10) {
                Image(systemName: "clock.arrow.circlepath")
                    .font(.system(size: 30))
                Text(title)
                    .font(.headline)
                Text("No history entries are available yet.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 40)
            .listRowBackground(Color.clear)
        }
        .navigationTitle(title)
    }
}


// MARK: - Patch Center (new catalog UI)
private struct ShinnPatchCenterView: View {
    @EnvironmentObject private var store: RepoStore
    @State private var searchText = ""
    @State private var selectedFilter = "All"
    @State private var showingBulkProgress = false
    @State private var selectedPackage: RepoPackage?
    @State private var selectedPackageIsV2 = false
    @State private var v1Packages: [RepoPackage] = []
    @State private var v2Packages: [RepoPackage] = []
    @State private var loadingRepos = false

    private let filters = ["All", "AIM", "Character", "Visual"]
    private let accent = Color(red: 0.16, green: 0.78, blue: 0.96)

    private func matches(_ package: RepoPackage) -> Bool {
        let searchable = ([package.name, package.summary ?? "", package.description ?? "", package.category ?? ""] + (package.tags ?? []))
            .joined(separator: " ").lowercased()
        let q = searchText.trimmingCharacters(in: .whitespacesAndNewlines)
        let matchesSearch = q.isEmpty || searchable.localizedCaseInsensitiveContains(q)
        let matchesFilter: Bool
        switch selectedFilter {
        case "AIM": matchesFilter = containsAny(searchable, ["aim", "drag", "neck", "chest", "body", "magic", "scope"])
        case "Character": matchesFilter = containsAny(searchable, ["character", "skin", "alok", "kelly", "chron", "model", "costume"])
        case "Visual": matchesFilter = containsAny(searchable, ["visual", "esp", "chams", "wall", "graphic", "effect", "color", "glow"])
        default: matchesFilter = true
        }
        return matchesSearch && matchesFilter
    }

    private var v1Filtered: [RepoPackage] { v1Packages.filter(matches) }
    private var v2Filtered: [RepoPackage] { v2Packages.filter(matches) }
    private var totalFiltered: Int { v1Filtered.count + v2Filtered.count }

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 15) {
                header
                searchBar
                filterBar
                repoSummary

                if loadingRepos && v1Packages.isEmpty && v2Packages.isEmpty {
                    ProgressView("Loading repositories…").tint(accent).frame(maxWidth: .infinity).padding(.vertical, 50)
                } else if totalFiltered == 0 {
                    emptyState
                } else {
                    repoSection("REPO V1", "Free / standard repository", v1Filtered, false, .cyan)
                    if store.isRepoV2Authorized {
                        repoSection("REPO V2", "Owner-authorized repository", v2Filtered, true, .purple)
                    }
                }
            }
            .padding(.horizontal, 16)
            .padding(.top, 10)
            .padding(.bottom, 24)
        }
        .background(Color.black.ignoresSafeArea())
        .preferredColorScheme(.dark)
        .refreshable { await loadBothRepos() }
        .task { await loadBothRepos() }
        .sheet(item: $selectedPackage) { package in
            ShinnPatchCompactDetailSheet(package: package, repoV2: selectedPackageIsV2, accent: accent)
                .presentationDetents([.height(330), .medium])
                .presentationDragIndicator(.visible)
                .preferredColorScheme(.dark)
        }
    }

    private var header: some View {
        HStack {
            VStack(alignment: .leading, spacing: 3) {
                Text("PATCH CENTER").font(.system(size: 25, weight: .black, design: .rounded)).tracking(2.1)
                Text("\(totalFiltered) available").font(.system(size: 13, weight: .medium, design: .rounded)).foregroundStyle(.white.opacity(0.43))
            }
            Spacer()
            Button {
                guard !showingBulkProgress else { return }
                showingBulkProgress = true
                Task {
                    await downloadAllBoth()
                    await MainActor.run { showingBulkProgress = false }
                }
            } label: {
                Group {
                    if showingBulkProgress { ProgressView().tint(accent) }
                    else { Image(systemName: "bolt.fill").font(.system(size: 22, weight: .bold)).foregroundStyle(accent) }
                }
                .frame(width: 42, height: 42)
            }
            .buttonStyle(.plain)
            .disabled(v1Packages.isEmpty && v2Packages.isEmpty)
        }
        .padding(.top, 6)
    }

    private var repoSummary: some View {
        HStack(spacing: 8) {
            repoPill("V1", "\(v1Packages.count)", .cyan)
            repoPill("V2", store.isRepoV2Authorized ? "\(v2Packages.count)" : "LOCKED", .purple)
            Spacer()
        }
    }

    private func repoPill(_ title: String, _ value: String, _ tint: Color) -> some View {
        HStack(spacing: 5) {
            Circle().fill(tint).frame(width: 6, height: 6)
            Text("\(title) · \(value)").font(.caption.bold()).foregroundStyle(.white.opacity(0.72))
        }
        .padding(.horizontal, 10).padding(.vertical, 7)
        .background(tint.opacity(0.10), in: Capsule())
        .overlay(Capsule().stroke(tint.opacity(0.22)))
    }

    private var searchBar: some View {
        HStack(spacing: 12) {
            Image(systemName: "magnifyingglass").foregroundStyle(.white.opacity(0.42))
            TextField("Search patches", text: $searchText)
                .font(.system(size: 16, weight: .medium, design: .rounded))
                .tint(accent).autocorrectionDisabled().textInputAutocapitalization(.never)
            if !searchText.isEmpty {
                Button { searchText = "" } label: { Image(systemName: "xmark.circle.fill").foregroundStyle(.white.opacity(0.4)) }.buttonStyle(.plain)
            }
        }
        .padding(.horizontal, 16).frame(height: 48)
        .background(Color(red: 0.055, green: 0.06, blue: 0.075), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 18).stroke(Color.white.opacity(0.045)))
    }

    private var filterBar: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 10) {
                ForEach(filters, id: \.self) { filter in
                    Button { withAnimation(.easeInOut(duration: 0.16)) { selectedFilter = filter } } label: {
                        Text(filter).font(.system(size: 13, weight: .bold, design: .rounded))
                            .foregroundStyle(selectedFilter == filter ? accent : .white.opacity(0.64))
                            .padding(.horizontal, 17).frame(height: 34)
                            .background(selectedFilter == filter ? accent.opacity(0.16) : Color(red: 0.055, green: 0.06, blue: 0.075), in: Capsule())
                    }.buttonStyle(.plain)
                }
            }
        }
    }

    private func repoSection(_ title: String, _ subtitle: String, _ packages: [RepoPackage], _ isV2: Bool, _ tint: Color) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text(title).font(.headline.bold()).foregroundStyle(tint)
                    Text(subtitle).font(.caption2).foregroundStyle(.white.opacity(0.40))
                }
                Spacer()
                Text("\(packages.count)").font(.caption.bold()).foregroundStyle(.white.opacity(0.55))
            }
            if packages.isEmpty {
                Text(searchText.isEmpty ? "No packages in this repository." : "No matching patches.")
                    .font(.caption).foregroundStyle(.white.opacity(0.35))
                    .padding(.vertical, 10)
            } else {
                LazyVStack(spacing: 8) {
                    ForEach(packages) { package in
                        ShinnPatchCenterCard(package: package, repoV2: isV2, accent: isV2 ? .purple : accent) {
                            selectedPackageIsV2 = isV2
                            selectedPackage = package
                        }
                    }
                }
            }
        }
    }

    private var emptyState: some View {
        VStack(spacing: 12) {
            Image(systemName: "square.grid.2x2").font(.system(size: 30))
            Text("No patches available")
            Button("Refresh") { Task { await loadBothRepos() } }.foregroundStyle(accent)
        }
        .font(.system(size: 14, weight: .medium, design: .rounded))
        .foregroundStyle(.white.opacity(0.55))
        .frame(maxWidth: .infinity).padding(.vertical, 50)
    }

    private func loadBothRepos() async {
        guard !loadingRepos else { return }
        loadingRepos = true
        defer { loadingRepos = false }

        // IMPORTANT: load each manifest explicitly. The old code could read the
        // currently selected V2 manifest into the V1 array when selectRepo(false)
        // returned early because V1 was already selected.
        v1Packages = await store.loadPackages(forV2: false)

        if store.isRepoV2Authorized {
            v2Packages = await store.loadPackages(forV2: true)
        } else {
            v2Packages = []
        }
    }

    private func downloadAllBoth() async {
        let originalV2 = store.usingRepoV2
        _ = await store.loadPackages(forV2: false)
        await store.downloadAll()
        if store.isRepoV2Authorized {
            _ = await store.loadPackages(forV2: true)
            await store.downloadAll()
        }
        _ = await store.loadPackages(forV2: originalV2 && store.isRepoV2Authorized)
    }

    private func containsAny(_ text: String, _ terms: [String]) -> Bool {
        terms.contains { text.localizedCaseInsensitiveContains($0) }
    }
}

private struct ShinnPatchCenterCard: View {
    @EnvironmentObject private var store: RepoStore
    let package: RepoPackage
    let repoV2: Bool
    let accent: Color
    let onSelect: () -> Void

    private var applied: Bool {
        if case .applied = store.patchState(for: package) { return true }
        return false
    }
    private var busy: Bool {
        switch store.patchState(for: package) {
        case .applying, .restoring: return true
        default: return false
        }
    }
    private var isDownloading: Bool {
        if case .downloading = store.state(for: package) { return true }
        return false
    }

    var body: some View {
        HStack(spacing: 9) {
            HStack(spacing: 10) {
                thumbnail
                VStack(alignment: .leading, spacing: 3) {
                    Text(package.name).font(.system(size: 14, weight: .bold, design: .rounded)).foregroundStyle(.white).lineLimit(1)
                    Text((package.summary ?? "").isEmpty ? "\(package.name) resource" : (package.summary ?? ""))
                        .font(.system(size: 11, weight: .medium, design: .rounded)).foregroundStyle(.white.opacity(0.48)).lineLimit(1)
                    Text(repoV2 ? "Repo V2" : "Repo V1")
                        .font(.system(size: 9, weight: .bold)).foregroundStyle(repoV2 ? .purple : .cyan)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            .contentShape(Rectangle()).onTapGesture(perform: onSelect)

            Button(action: togglePatch) {
                Group {
                    if busy { ProgressView().tint(.white).scaleEffect(0.8) }
                    else { Image(systemName: "power").font(.system(size: 15, weight: .bold)).foregroundStyle(applied ? accent : .white.opacity(0.52)) }
                }
                .frame(width: 32, height: 32)
                .background(applied ? accent.opacity(0.14) : Color.white.opacity(0.04), in: Circle())
                .overlay(Circle().stroke(applied ? accent : Color.white.opacity(0.16), lineWidth: applied ? 1.5 : 1))
            }.buttonStyle(.plain).disabled(busy)

            Button(action: downloadPatch) {
                Group {
                    switch store.state(for: package) {
                    case .downloading: ProgressView().tint(.black).scaleEffect(0.8)
                    case .done: Image(systemName: "checkmark").font(.system(size: 13, weight: .black))
                    case .failed: Image(systemName: "arrow.clockwise").font(.system(size: 13, weight: .black))
                    case .idle: Image(systemName: "arrow.down").font(.system(size: 14, weight: .black))
                    }
                }
                .foregroundStyle(.black).frame(width: 30, height: 30).background(accent, in: Circle())
            }.buttonStyle(.plain).disabled(isDownloading)
        }
        .padding(.horizontal, 10).padding(.vertical, 8).frame(minHeight: 70)
        .background(Color(red: 0.035, green: 0.04, blue: 0.055), in: RoundedRectangle(cornerRadius: 17, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 17, style: .continuous).stroke(Color.white.opacity(0.065)))
    }

    private var thumbnail: some View {
        Group {
            if let raw = package.icon, let url = URL(string: raw), url.scheme != nil {
                AsyncImage(url: url) { phase in
                    if let image = phase.image { image.resizable().scaledToFill() } else { placeholder }
                }
            } else { placeholder }
        }
        .frame(width: 48, height: 48)
        .clipShape(RoundedRectangle(cornerRadius: 10))
        .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.white.opacity(0.08), lineWidth: 0.7))
    }

    private var placeholder: some View {
        ZStack {
            Color(red: 0.045, green: 0.08, blue: 0.13)
            Image(systemName: categoryIcon(package.category ?? "")).font(.system(size: 19, weight: .semibold)).foregroundStyle(accent)
        }
    }

    private func togglePatch() {
        Task {
            await store.selectRepo(v2: repoV2)
            if applied { await store.restore(package) } else { await store.apply(package, openGame: true) }
        }
    }

    private func downloadPatch() {
        Task {
            await store.selectRepo(v2: repoV2)
            await store.download(package)
        }
    }
}

private struct ShinnPatchCompactDetailSheet: View {
    @EnvironmentObject private var store: RepoStore
    @Environment(\.dismiss) private var dismiss
    let package: RepoPackage
    let repoV2: Bool
    let accent: Color

    private var applied: Bool {
        if case .applied = store.patchState(for: package) { return true }
        return false
    }
    private var busy: Bool {
        switch store.patchState(for: package) {
        case .applying, .restoring: return true
        default: return false
        }
    }
    private var downloading: Bool {
        if case .downloading = store.state(for: package) { return true }
        return false
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 13) {
            HStack(spacing: 12) {
                patchImage.frame(width: 58, height: 58).clipShape(RoundedRectangle(cornerRadius: 13))
                VStack(alignment: .leading, spacing: 4) {
                    Text(package.name).font(.system(size: 18, weight: .bold, design: .rounded)).foregroundStyle(.white).lineLimit(2)
                    HStack(spacing: 8) {
                        Text(repoV2 ? "Repo V2" : "Repo V1").foregroundStyle(repoV2 ? .purple : .cyan)
                        if let version = package.version { Label(version, systemImage: "tag.fill") }
                        if let size = package.size { Label(ByteCountFormatter.string(fromByteCount: Int64(size), countStyle: .file), systemImage: "doc.fill") }
                    }.font(.system(size: 10, weight: .medium))
                }
                Spacer()
                Button { dismiss() } label: { Image(systemName: "xmark").font(.system(size: 12, weight: .bold)).foregroundStyle(.white.opacity(0.65)).frame(width: 30, height: 30).background(Color.white.opacity(0.08), in: Circle()) }.buttonStyle(.plain)
            }
            if let description = package.description, !description.isEmpty {
                ScrollView { Text(description).font(.system(size: 12)).foregroundStyle(.white.opacity(0.7)).frame(maxWidth: .infinity, alignment: .leading) }
                    .frame(maxHeight: 75)
            }
            HStack(spacing: 10) {
                Button {
                    Task {
                        await store.selectRepo(v2: repoV2)
                        if applied { await store.restore(package) } else { await store.apply(package, openGame: true) }
                    }
                } label: {
                    Label(busy ? "Processing…" : (applied ? "Turn Off" : "Apply"), systemImage: applied ? "power" : "checkmark")
                        .font(.system(size: 13, weight: .bold)).frame(maxWidth: .infinity).padding(.vertical, 12)
                        .background(applied ? Color.orange.opacity(0.16) : accent, in: RoundedRectangle(cornerRadius: 13))
                        .foregroundStyle(applied ? .orange : .black)
                }.buttonStyle(.plain).disabled(busy)
                Button {
                    Task {
                        await store.selectRepo(v2: repoV2)
                        await store.download(package)
                    }
                } label: {
                    Label(downloading ? "Downloading" : "Download", systemImage: "arrow.down.to.line")
                        .font(.system(size: 13, weight: .bold)).frame(maxWidth: .infinity).padding(.vertical, 12)
                        .background(Color.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 13))
                        .foregroundStyle(.white)
                }.buttonStyle(.plain).disabled(downloading)
            }
        }
        .padding(18)
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
        .background(Color(red: 0.025, green: 0.03, blue: 0.045).ignoresSafeArea())
    }

    @ViewBuilder private var patchImage: some View {
        if let raw = package.icon, let url = URL(string: raw), url.scheme != nil {
            AsyncImage(url: url) { phase in
                if let image = phase.image { image.resizable().scaledToFill() } else { imagePlaceholder }
            }
        } else { imagePlaceholder }
    }
    private var imagePlaceholder: some View {
        ZStack { Color(red: 0.045, green: 0.08, blue: 0.13); Image(systemName: "square.grid.2x2.fill").foregroundStyle(accent).font(.title2) }
    }
}

// Keeps the original HomeView navigation intact inside the new V6 shell.
private struct ShinnCompleteLegacyHomeHost: View {
    @State private var path: [Route] = []
    @EnvironmentObject private var session: Session

    var body: some View {
        NavigationStack(path: $path) {
            HomeView(open: { route in
                path.append(route)
            })
            .navigationDestination(for: Route.self) { route in
                destination(route)
            }
        }
    }

    @ViewBuilder
    private func destination(_ route: Route) -> some View {
        switch route {
        case .packages(let category): PackagesView(initialCategory: category)
        case .detail(let id): PackageDetailView(packageID: id)
        case .settings: ShinnSettingsHubView()
        case .about: ShinnAboutView()
        case .support: SupportView()
        case .aiChat: ShinnAIChatView()
        case .premiumRepo: PremiumRepoView()
        case .community: CommunityView()
        case .repositoryManager: RepositoryManagerView()
        case .patchBuilder: PatchBuilderView()
        case .patchProjects:
            if session.role == .owner { PatchProjectsView() } else { PatchOwnerOnlyView() }
        case .cleanup: PhoneCleanupView()
        }
    }
}

// MARK: Activation gate
private struct ShinnCompleteActivationGate: View {
    @EnvironmentObject private var license: LicenseManager
    @State private var key = "ShinnCheat"
    @State private var busy = false
    @State private var message = ""
    @FocusState private var focused: Bool

    var body: some View {
        ZStack {
            ShinnCompleteBackground()
            ScrollView(showsIndicators: false) {
                VStack(spacing: 22) {
                    Spacer(minLength: 70)
                    logo
                    VStack(spacing: 7) {
                        Text("SHINNCHEAT")
                            .font(.system(size: 31, weight: .black, design: .rounded))
                        Text("Secure Command Center")
                            .font(.subheadline)
                            .foregroundStyle(.white.opacity(0.45))
                    }
                    activationCard
                    Text("Default access: ShinnCheat • 1 year • unlimited devices\nVIP access is controlled by the server and Owner permissions.")
                        .font(.caption2)
                        .multilineTextAlignment(.center)
                        .foregroundStyle(.white.opacity(0.35))
                }
                .padding(.horizontal, 18)
            }
        }
    }

    @ViewBuilder private var logo: some View {
        if let image = HeroBanner.image {
            Image(uiImage: image)
                .resizable().scaledToFill()
                .frame(width: 112, height: 112)
                .clipShape(RoundedRectangle(cornerRadius: 30))
                .overlay(RoundedRectangle(cornerRadius: 30).stroke(Color.white.opacity(0.18)))
        } else {
            Text("S")
                .font(.system(size: 58, weight: .black, design: .rounded))
                .frame(width: 112, height: 112)
                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 30))
                .overlay(RoundedRectangle(cornerRadius: 30).stroke(Color.cyan.opacity(0.35)))
        }
    }

    private var activationCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("ACTIVATION REQUIRED")
                .font(.caption.bold())
                .tracking(1.5)
                .foregroundStyle(.cyan)
            TextField("Enter activation key", text: $key)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled(true)
                .focused($focused)
                .padding(15)
                .background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 17))
                .overlay(RoundedRectangle(cornerRadius: 17).stroke(Color.white.opacity(0.10)))
            Text("The app verifies the key before opening the command center. Repo V2 requires a VIP grant.")
                .font(.caption)
                .foregroundStyle(.white.opacity(0.42))
            if !message.isEmpty {
                Text(message).font(.caption.bold()).foregroundStyle(.orange)
            }
            Button { Task { await activate() } } label: {
                HStack {
                    if busy { ProgressView().tint(.white) }
                    Text(busy ? "VERIFYING…" : "VERIFY & ENTER").font(.headline.bold())
                }
                .frame(maxWidth: .infinity)
                .padding(15)
                .background(
                    LinearGradient(colors: [.cyan.opacity(0.9), .blue.opacity(0.75)], startPoint: .leading, endPoint: .trailing),
                    in: RoundedRectangle(cornerRadius: 17)
                )
            }
            .buttonStyle(.plain)
            .disabled(busy)
        }
        .padding(20)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 28))
        .overlay(RoundedRectangle(cornerRadius: 28).stroke(Color.white.opacity(0.10)))
    }

    private func activate() async {
        focused = false
        busy = true
        message = ""
        let ok = await license.activate(key: key, language: .en)
        busy = false
        if !ok { message = license.lastError ?? "Activation failed" }
    }
}
