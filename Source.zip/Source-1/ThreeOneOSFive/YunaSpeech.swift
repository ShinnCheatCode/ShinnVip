import Foundation
import Combine
import Speech
import AVFoundation

@MainActor
final class YunaSpeech: NSObject, ObservableObject {
    @Published var transcript = ""
    @Published var isListening = false
    @Published var errorMessage: String?

    private let recognizer = SFSpeechRecognizer(locale: Locale(identifier: "vi-VN"))
    private let audioEngine = AVAudioEngine()
    private var request: SFSpeechAudioBufferRecognitionRequest?
    private var task: SFSpeechRecognitionTask?
    private var tapInstalled = false

    var onCommand: ((String) -> Void)?

    // MARK: - Nonisolated helpers
    // Các callback của iOS được gọi trên thread nền / audio thread.
    // Nếu tạo closure ngay trong class @MainActor, Swift sẽ gắn nhãn MainActor cho closure
    // và app crash (dispatch_assert_queue_fail). Vì vậy tạo closure ở hàm nonisolated.

    private nonisolated static func askSpeech(_ done: @escaping @Sendable (SFSpeechRecognizerAuthorizationStatus) -> Void) {
        SFSpeechRecognizer.requestAuthorization { status in done(status) }
    }

    private nonisolated static func askMic(_ done: @escaping @Sendable (Bool) -> Void) {
        if #available(iOS 17.0, *) {
            AVAudioApplication.requestRecordPermission { granted in done(granted) }
        } else {
            AVAudioSession.sharedInstance().requestRecordPermission { granted in done(granted) }
        }
    }

    private nonisolated static func installTap(on node: AVAudioInputNode,
                                               format: AVAudioFormat,
                                               request: SFSpeechAudioBufferRecognitionRequest) {
        node.installTap(onBus: 0, bufferSize: 1024, format: format) { buffer, _ in
            request.append(buffer)
        }
    }

    private nonisolated static func makeTask(recognizer: SFSpeechRecognizer,
                                             request: SFSpeechAudioBufferRecognitionRequest,
                                             handler: @escaping @Sendable (String?, Bool, Bool) -> Void) -> SFSpeechRecognitionTask {
        recognizer.recognitionTask(with: request) { result, error in
            handler(result?.bestTranscription.formattedString,
                    result?.isFinal ?? false,
                    error != nil)
        }
    }

    private nonisolated static func micGranted() -> Bool {
        if #available(iOS 17.0, *) {
            return AVAudioApplication.shared.recordPermission == .granted
        } else {
            return AVAudioSession.sharedInstance().recordPermission == .granted
        }
    }

    // MARK: - Permissions

    func requestPermissions() {
        errorMessage = nil
        Self.askSpeech { [weak self] status in
            Task { @MainActor in
                guard let self else { return }
                guard status == .authorized else {
                    self.errorMessage = self.speechPermissionMessage(status)
                    return
                }
                Self.askMic { granted in
                    Task { @MainActor [weak self] in
                        if !granted {
                            self?.errorMessage = "Microphone chưa được cho phép. Hãy bật Microphone trong Cài đặt > Quyền riêng tư & Bảo mật."
                        }
                    }
                }
            }
        }
    }

    // MARK: - Start / Stop

    func startListening() {
        guard !isListening else { return }
        errorMessage = nil
        transcript = ""

        guard SFSpeechRecognizer.authorizationStatus() == .authorized, Self.micGranted() else {
            requestPermissions()
            return
        }
        beginListening()
    }

    func stopListening() {
        if audioEngine.isRunning { audioEngine.stop() }
        if tapInstalled {
            audioEngine.inputNode.removeTap(onBus: 0)
            tapInstalled = false
        }
        request?.endAudio()
        task?.cancel()
        task = nil
        request = nil
        isListening = false
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
    }

    private func beginListening() {
        guard !isListening else { return }

        guard let recognizer, recognizer.isAvailable else {
            errorMessage = "Nhận dạng giọng nói hiện không khả dụng."
            return
        }

        do {
            let session = AVAudioSession.sharedInstance()
            try session.setCategory(.playAndRecord, mode: .measurement, options: [.duckOthers, .defaultToSpeaker])
            try session.setActive(true, options: .notifyOthersOnDeactivation)

            // Dọn engine cũ
            if audioEngine.isRunning { audioEngine.stop() }
            if tapInstalled {
                audioEngine.inputNode.removeTap(onBus: 0)
                tapInstalled = false
            }

            let inputNode = audioEngine.inputNode
            let format = inputNode.outputFormat(forBus: 0)

            // sampleRate = 0 hoặc 0 channel => installTap sẽ crash
            guard format.sampleRate > 0, format.channelCount > 0 else {
                errorMessage = "Không đọc được định dạng microphone. Thử lại trên máy thật."
                try? session.setActive(false)
                return
            }

            let speechRequest = SFSpeechAudioBufferRecognitionRequest()
            speechRequest.shouldReportPartialResults = true
            request = speechRequest

            Self.installTap(on: inputNode, format: format, request: speechRequest)
            tapInstalled = true

            task = Self.makeTask(recognizer: recognizer, request: speechRequest) { [weak self] text, isFinal, hasError in
                Task { @MainActor in
                    guard let self, self.isListening else { return }

                    if let text {
                        let clean = text.trimmingCharacters(in: .whitespacesAndNewlines)
                        self.transcript = clean
                        if isFinal, !clean.isEmpty {
                            self.stopListening()
                            self.onCommand?(clean)
                            return
                        }
                    }

                    if hasError {
                        let heard = self.transcript
                        self.stopListening()
                        if !heard.isEmpty {
                            self.onCommand?(heard)
                        } else {
                            self.errorMessage = "Không nhận được giọng nói. Hãy thử lại."
                        }
                    }
                }
            }

            audioEngine.prepare()
            try audioEngine.start()
            isListening = true
        } catch {
            stopListening()
            errorMessage = "Không thể khởi động microphone: \(error.localizedDescription)"
        }
    }

    private func speechPermissionMessage(_ status: SFSpeechRecognizerAuthorizationStatus) -> String {
        switch status {
        case .denied: return "Nhận dạng giọng nói đã bị từ chối. Hãy bật Speech Recognition trong Cài đặt."
        case .restricted: return "Nhận dạng giọng nói đang bị giới hạn trên thiết bị này."
        case .notDetermined: return "Chưa cấp quyền nhận dạng giọng nói. Hãy thử bấm mic lại."
        case .authorized: return ""
        @unknown default: return "Không xác định được trạng thái quyền nhận dạng giọng nói."
        }
    }
    // Không dùng deinit chạm vào audioEngine: class là @MainActor, deinit không chạy trên main actor.
}
