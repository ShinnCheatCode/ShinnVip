Make By Minh Hiếu
@ShinnThieuu

## Repository access
Every valid, non-expired activation key can use Repo V1 and Repo V2. Repository-specific lock fields are not used to hide or block either repository.
