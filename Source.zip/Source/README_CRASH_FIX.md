# 3105 – Crash Fix

This build keeps the existing Repo V2 multi-key changes and fixes the startup crash reported by the `.ips` crash log.

## Crash fixed
The crash was `EXC_BREAKPOINT (SIGTRAP)` during static URL initialization while `RepoStore.refresh()` accessed `AppInfo` URL values.

The affected URL constants now use `AppInfo.safeURL(...)` instead of force-unwrapping `URL(string:)` with `!`.

Protected URLs include:
- Telegram URL
- Default repository URL
- Repo V2 URL
- Supabase/RPC URLs
- GitHub API URLs

A malformed URL can now fail as a normal network/request failure instead of terminating the app during initialization.

## Build
Open `Source/ThreeOneOSFive.xcodeproj` and build normally. The existing GitHub Actions workflow can continue using `macos-14`.
