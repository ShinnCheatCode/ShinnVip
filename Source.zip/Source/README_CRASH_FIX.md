# 3105 – Crash Fix / Repository Update

This build keeps the existing patch, key, file and repository workflows while removing the Yuna Voice and Shinn AI features.

## Repository
- Default repository: `https://raw.githubusercontent.com/ShinnCheatCode/Repo-V3/main/ShinnCheatV3.json`
- Legacy persisted default repository URLs are automatically migrated to Repo-V3.
- The existing secondary Repo V2 support remains available where configured.

## Bulk download
Packages now include a **Download All Patches** action for the currently opened repository. Downloads continue to use the existing HTTP status and SHA-256 verification logic.

## Key LED
The key-activation edge LED is smaller and uses a 1.5-second cycle/display duration.

## Crash protection
Remote URL construction uses `AppInfo.safeURL(...)` instead of force-unwrapping `URL(string:)`.

## Build
Open `Source/ThreeOneOSFive.xcodeproj` and build normally. The existing GitHub Actions workflow can continue using `macos-14`.
