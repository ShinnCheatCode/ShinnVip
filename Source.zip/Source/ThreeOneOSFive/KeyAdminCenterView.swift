import SwiftUI
import UIKit

// =====================================================================
//  KeyAdminCenterView — màn quản lý key cho Owner (1 màn hình, chia tab)
//
//  • Tab "Keys"     : xem key trên server, tìm/lọc, chọn nhiều → xoá hàng loạt,
//                     xoá từng key, copy, thêm giờ, sửa tên, reset thiết bị.
//  • Tab "Tạo key"  : tạo ngay trong tab, key vừa tạo hiện ngay bên dưới
//                     (không nhảy sang trang khác).
//  • Tab "Công cụ"  : dọn key hết hạn / key Test / tất cả, copy hàng loạt.
//
//  File này TỰ CHỨA (không phụ thuộc code khác trong app).
//  Cách dùng: ở màn Owner hiện tại, hiển thị  KeyAdminCenterView()
//  Mặc định tự đọc key Owner + device id đã kích hoạt từ UserDefaults
//  ("shinn.license.key", "shinn.license.device_id"); có thể truyền tay:
//      KeyAdminCenterView(licenseKey: "...", deviceID: "...")
// =====================================================================

// MARK: - Cấu hình
private enum KACConfig {
    static let rpcBase = "https://efhqbzdnrtifqjqlqseb.supabase.co/rest/v1/rpc/"
    static let anonKey = "sb_publishable_jnycTCgXRMrluvwJORd_4g_B7ojwi9R"
    static let testLabel = "Feedback @ShinnThieuu"
}

struct KACError: LocalizedError {
    let text: String
    var errorDescription: String? { text }
}

// MARK: - Model
struct KACKey: Codable, Identifiable, Hashable {
    let key: String
    let role: String?
    let kind: String?
    let expires_at: String?
    let label: String?
    let max_devices: Int?
    let unlimited_devices: Bool?
    let device_count: Int?

    var id: String { key }
    var isOwner: Bool { (role ?? "").lowercased() == "owner" }
    var isTest: Bool { kind == "test" }
    var isVIP: Bool { kind == "vip" }
    var isLifetime: Bool { (expires_at ?? "").isEmpty }

    var expiryDate: Date? {
        guard let raw = expires_at, !raw.isEmpty else { return nil }
        let f = ISO8601DateFormatter()
        f.formatOptions = [.withInternetDateTime]
        if let d = f.date(from: raw) { return d }
        f.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        return f.date(from: raw)
    }

    var isExpired: Bool {
        if let d = expiryDate { return d <= Date() }
        return false
    }

    var remainingText: String {
        if isLifetime { return "Vĩnh viễn" }
        guard let d = expiryDate else { return "Không rõ hạn" }
        let s = Int(d.timeIntervalSinceNow)
        if s <= 0 { return "Đã hết hạn" }
        let days = s / 86400
        let hours = (s % 86400) / 3600
        let mins = (s % 3600) / 60
        if days > 0 { return "Còn \(days) ngày \(hours) giờ" }
        if hours > 0 { return "Còn \(hours) giờ \(mins) phút" }
        return "Còn \(max(1, mins)) phút"
    }

    var devicesText: String {
        let used = device_count ?? 0
        let maxText = (unlimited_devices ?? false) ? "∞" : String(max_devices ?? 1)
        return "\(used)/\(maxText) thiết bị"
    }
}

// MARK: - Store (gọi Supabase RPC)
@MainActor
final class KACStore: ObservableObject {
    @Published var keys: [KACKey] = []
    @Published var isLoading = false
    @Published var created: [String] = []
    @Published var toast: String?
    @Published var toastIsError = false

    let licenseKey: String
    let deviceID: String
    private var toastToken = 0

    init(licenseKey: String, deviceID: String) {
        self.licenseKey = licenseKey
        self.deviceID = deviceID
    }

    func show(_ text: String, error: Bool = false) {
        toast = text
        toastIsError = error
        toastToken += 1
        let token = toastToken
        Task {
            try? await Task.sleep(nanoseconds: 3_000_000_000)
            if token == toastToken { toast = nil }
        }
    }

    func copy(_ text: String, message: String = "Đã copy") {
        UIPasteboard.general.string = text
        show(message)
    }

    private static func friendly(_ data: Data, status: Int) -> String {
        var msg = String(decoding: data, as: UTF8.self)
        if let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
           let m = obj["message"] as? String {
            msg = m
        }
        switch msg {
        case "forbidden":
            return "Không có quyền — key Owner chưa kích hoạt trên máy này. Đăng xuất rồi nhập lại key Owner."
        case "key_expired": return "Key Owner đã hết hạn."
        case "label_required": return "Hãy nhập tên hiển thị (key này của ai)."
        case "key_exists": return "Key này đã tồn tại."
        case "not_found": return "Không tìm thấy key."
        case "lifetime_key": return "Key vĩnh viễn không cần thêm giờ."
        case "protected_key": return "Không thể thao tác trên key Owner."
        case "invalid_duration": return "Thời hạn không hợp lệ."
        default:
            if msg.contains("Could not find the function") {
                return "Supabase chưa có hàm này — hãy chạy lại supabase_setup.sql."
            }
            return "HTTP \(status): \(msg.prefix(160))"
        }
    }

    private func call(_ name: String, _ extra: [String: Any] = [:]) async throws -> Data {
        guard !licenseKey.isEmpty else {
            throw KACError(text: "Chưa có key Owner đang kích hoạt. Hãy nhập key Owner trước.")
        }
        guard let url = URL(string: KACConfig.rpcBase + name) else {
            throw KACError(text: "URL không hợp lệ")
        }
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.timeoutInterval = 20
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.setValue("application/json", forHTTPHeaderField: "Accept")
        req.setValue(KACConfig.anonKey, forHTTPHeaderField: "apikey")

        var body: [String: Any] = [
            "p_created_by_key": licenseKey,
            "p_creator_role": UserDefaults.standard.string(forKey: "shinn.license.role") ?? "owner",
            "p_device_id": deviceID
        ]
        for (k, v) in extra { body[k] = v }
        req.httpBody = try JSONSerialization.data(withJSONObject: body)

        let result: (Data, URLResponse)
        do {
            result = try await URLSession.shared.data(for: req)
        } catch {
            throw KACError(text: "Không kết nối được Supabase: \(error.localizedDescription)")
        }
        let (data, resp) = result
        guard let http = resp as? HTTPURLResponse else {
            throw KACError(text: "Không có phản hồi từ server")
        }
        guard (200...299).contains(http.statusCode) else {
            throw KACError(text: Self.friendly(data, status: http.statusCode))
        }
        return data
    }

    private func deletedCount(_ data: Data) -> Int {
        let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any]
        return (obj?["deleted"] as? Int) ?? 0
    }

    // MARK: Actions
    func refresh() async {
        isLoading = true
        defer { isLoading = false }
        do {
            let data = try await call("list_shinn_keys")
            keys = try JSONDecoder().decode([KACKey].self, from: data)
        } catch {
            show(error.localizedDescription, error: true)
        }
    }

    func create(kind: String, days: Int, label: String, count: Int,
                maxDevices: Int, custom: String) async -> Bool {
        isLoading = true
        var extra: [String: Any] = [
            "p_role": "member",
            "p_kind": kind,
            "p_days": kind == "test" ? 0 : days,
            "p_hours": kind == "test" ? 1 : 0,
            "p_count": count,
            "p_label": label,
            "p_max_devices": maxDevices
        ]
        if !custom.isEmpty { extra["p_custom_key"] = custom }
        do {
            let data = try await call("create_shinn_key", extra)
            let list = try JSONDecoder().decode([String].self, from: data)
            created = list
            isLoading = false
            show("Đã tạo \(list.count) key")
            await refresh()
            return true
        } catch {
            isLoading = false
            show(error.localizedDescription, error: true)
            return false
        }
    }

    func delete(_ list: [String]) async {
        guard !list.isEmpty else {
            show("Chưa có key nào để xoá", error: true)
            return
        }
        isLoading = true
        do {
            let data = try await call("delete_shinn_keys_bulk", ["p_keys": list])
            isLoading = false
            show("Đã xoá \(deletedCount(data)) key")
            await refresh()
        } catch {
            isLoading = false
            show(error.localizedDescription, error: true)
        }
    }

    func deleteAll() async {
        isLoading = true
        do {
            let data = try await call("delete_all_shinn_keys")
            isLoading = false
            show("Đã xoá \(deletedCount(data)) key")
            await refresh()
        } catch {
            isLoading = false
            show(error.localizedDescription, error: true)
        }
    }

    func extend(_ key: String, days: Int = 0, hours: Int = 0) async {
        do {
            _ = try await call("extend_shinn_key",
                               ["p_key": key, "p_add_days": days, "p_add_hours": hours])
            show("Đã thêm thời gian")
            await refresh()
        } catch {
            show(error.localizedDescription, error: true)
        }
    }

    func resetDevices(_ key: String) async {
        do {
            _ = try await call("reset_shinn_key_devices", ["p_key": key])
            show("Đã reset thiết bị")
            await refresh()
        } catch {
            show(error.localizedDescription, error: true)
        }
    }

    func updateLabel(_ key: String, label: String) async {
        do {
            _ = try await call("update_shinn_key", ["p_key": key, "p_label": label])
            show("Đã đổi tên hiển thị")
            await refresh()
        } catch {
            show(error.localizedDescription, error: true)
        }
    }
}

// MARK: - View
private enum KACTab: String, CaseIterable, Identifiable {
    case keys, create, tools
    var id: String { rawValue }
    var title: String {
        switch self {
        case .keys: return "Keys"
        case .create: return "Tạo key"
        case .tools: return "Công cụ"
        }
    }
    var icon: String {
        switch self {
        case .keys: return "key.fill"
        case .create: return "plus.circle.fill"
        case .tools: return "wrench.and.screwdriver.fill"
        }
    }
}

private enum KACFilter: String, CaseIterable, Identifiable {
    case all, active, expired, vip, test
    var id: String { rawValue }
    var title: String {
        switch self {
        case .all: return "Tất cả"
        case .active: return "Còn hạn"
        case .expired: return "Hết hạn"
        case .vip: return "VIP"
        case .test: return "Test"
        }
    }
}

private enum KACKind: String {
    case test, vip
}

private enum KACConfirm {
    case deleteSelected
    case deleteOne(String)
    case deleteExpired
    case deleteTests
    case deleteAll
}

struct KeyAdminCenterView: View {
    @StateObject private var store: KACStore
    var accent: Color = Color(red: 0.25, green: 0.78, blue: 0.95)

    @State private var tab: KACTab = .keys
    @State private var search = ""
    @State private var filter: KACFilter = .all
    @State private var selecting = false
    @State private var selected = Set<String>()
    @State private var confirm: KACConfirm?
    @State private var editing: KACKey?
    @State private var editText = ""

    // Form tạo key
    @State private var kind: KACKind = .vip
    @State private var days = 7
    @State private var label = ""
    @State private var quantity = 1
    @State private var maxDevices = 1
    @State private var customKey = ""

    init(licenseKey: String? = nil, deviceID: String? = nil, accent: Color = Color(red: 0.25, green: 0.78, blue: 0.95)) {
        let d = UserDefaults.standard
        let key = (licenseKey ?? d.string(forKey: "shinn.license.key") ?? "")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        let dev = deviceID ?? d.string(forKey: "shinn.license.device_id") ?? ""
        _store = StateObject(wrappedValue: KACStore(licenseKey: key, deviceID: dev))
        self.accent = accent
    }

    var body: some View {
        ZStack(alignment: .bottom) {
            LinearGradient(
                colors: [Color(red: 0.05, green: 0.05, blue: 0.07), Color.black],
                startPoint: .top, endPoint: .bottom
            )
            .ignoresSafeArea()

            VStack(spacing: 0) {
                header
                tabBar
                Group {
                    switch tab {
                    case .keys: keysTab
                    case .create: createTab
                    case .tools: toolsTab
                    }
                }
            }
            .alert("Sửa tên hiển thị", isPresented: Binding(
                get: { editing != nil },
                set: { if !$0 { editing = nil } }
            )) {
                TextField("Tên hiển thị", text: $editText)
                Button("Huỷ", role: .cancel) { editing = nil }
                Button("Lưu") {
                    if let k = editing {
                        let text = editText
                        Task { await store.updateLabel(k.key, label: text) }
                    }
                    editing = nil
                }
            } message: {
                Text(editing?.key ?? "")
            }

            toastView
        }
        .environment(\.colorScheme, .dark)
        .task { await store.refresh() }
        .alert(confirmTitle, isPresented: Binding(
            get: { confirm != nil },
            set: { if !$0 { confirm = nil } }
        )) {
            Button("Xoá", role: .destructive) {
                if let c = confirm { runConfirmed(c) }
                confirm = nil
            }
            Button("Huỷ", role: .cancel) { confirm = nil }
        } message: {
            Text(confirmMessage)
        }
    }

    // MARK: Header
    private var header: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text("OWNER CONTROL")
                        .font(.caption2.weight(.black))
                        .tracking(2)
                        .foregroundStyle(.yellow)
                    Text("Key Center")
                        .font(.system(size: 28, weight: .black, design: .rounded))
                        .foregroundStyle(.white)
                }
                Spacer()
                Button {
                    Task { await store.refresh() }
                } label: {
                    Group {
                        if store.isLoading {
                            ProgressView().tint(.white)
                        } else {
                            Image(systemName: "arrow.clockwise")
                                .font(.system(size: 16, weight: .bold))
                        }
                    }
                    .foregroundStyle(.white)
                    .frame(width: 42, height: 42)
                    .background(Color.white.opacity(0.08), in: Circle())
                }
                .buttonStyle(.plain)
                .disabled(store.isLoading)
            }

            HStack(spacing: 8) {
                statBox("TOTAL", store.keys.count)
                statBox("ACTIVE", store.keys.filter { !$0.isExpired }.count)
                statBox("VIP", store.keys.filter { $0.isVIP }.count)
                statBox("TEST", store.keys.filter { $0.isTest }.count)
            }
        }
        .padding(.horizontal, 16)
        .padding(.top, 8)
    }

    private func statBox(_ title: String, _ value: Int) -> some View {
        VStack(alignment: .leading, spacing: 3) {
            Text(title)
                .font(.system(size: 9, weight: .bold))
                .tracking(1)
                .foregroundStyle(.white.opacity(0.5))
            Text("\(value)")
                .font(.system(size: 22, weight: .black, design: .rounded))
                .foregroundStyle(.white)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.horizontal, 12)
        .padding(.vertical, 10)
        .background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
    }

    private var tabBar: some View {
        HStack(spacing: 8) {
            ForEach(KACTab.allCases) { t in
                Button {
                    withAnimation(.easeOut(duration: 0.15)) { tab = t }
                } label: {
                    Label(t.title, systemImage: t.icon)
                        .font(.footnote.weight(.bold))
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity, minHeight: 40)
                        .background(
                            tab == t ? accent.opacity(0.25) : Color.white.opacity(0.06),
                            in: RoundedRectangle(cornerRadius: 12, style: .continuous)
                        )
                        .overlay(
                            RoundedRectangle(cornerRadius: 12, style: .continuous)
                                .stroke(tab == t ? accent : Color.white.opacity(0.08), lineWidth: 1)
                        )
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 10)
    }

    // MARK: Tab Keys
    private var filtered: [KACKey] {
        store.keys.filter { k in
            switch filter {
            case .all: return true
            case .active: return !k.isExpired
            case .expired: return k.isExpired
            case .vip: return k.isVIP
            case .test: return k.isTest
            }
        }
        .filter { k in
            let q = search.trimmingCharacters(in: .whitespacesAndNewlines)
            if q.isEmpty { return true }
            return k.key.localizedCaseInsensitiveContains(q)
                || (k.label ?? "").localizedCaseInsensitiveContains(q)
        }
    }

    private var keysTab: some View {
        ScrollView {
            LazyVStack(spacing: 10) {
                searchField
                filterChips
                selectionBar
                if filtered.isEmpty {
                    Text(store.isLoading ? "Đang tải…" : "Không có key nào")
                        .font(.footnote)
                        .foregroundStyle(.white.opacity(0.5))
                        .frame(maxWidth: .infinity)
                        .padding(.top, 30)
                } else {
                    ForEach(filtered) { k in
                        rowView(k)
                    }
                }
            }
            .padding(.horizontal, 16)
            .padding(.bottom, 80)
        }
        .refreshable { await store.refresh() }
    }

    private var searchField: some View {
        HStack(spacing: 8) {
            Image(systemName: "magnifyingglass")
                .foregroundStyle(.white.opacity(0.5))
            TextField("Tìm key hoặc tên hiển thị", text: $search)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled(true)
            if !search.isEmpty {
                Button { search = "" } label: {
                    Image(systemName: "xmark.circle.fill")
                        .foregroundStyle(.white.opacity(0.4))
                }
                .buttonStyle(.plain)
            }
        }
        .padding(12)
        .background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 13, style: .continuous))
    }

    private var filterChips: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(KACFilter.allCases) { f in
                    Button { filter = f } label: {
                        Text(f.title)
                            .font(.caption.weight(.bold))
                            .foregroundStyle(.white)
                            .padding(.horizontal, 14)
                            .padding(.vertical, 8)
                            .background(
                                filter == f ? accent.opacity(0.28) : Color.white.opacity(0.06),
                                in: Capsule()
                            )
                            .overlay(Capsule().stroke(filter == f ? accent : Color.clear, lineWidth: 1))
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }

    private func pill(_ title: String, icon: String? = nil, tint: Color = .white,
                      action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 5) {
                if let icon { Image(systemName: icon) }
                Text(title)
            }
            .font(.caption.weight(.bold))
            .foregroundStyle(tint)
            .padding(.horizontal, 12)
            .padding(.vertical, 8)
            .background(tint.opacity(0.14), in: Capsule())
        }
        .buttonStyle(.plain)
    }

    private var selectionBar: some View {
        HStack(spacing: 8) {
            pill(selecting ? "Xong" : "Chọn", icon: selecting ? "checkmark" : "checklist", tint: accent) {
                selecting.toggle()
                if !selecting { selected.removeAll() }
            }
            if selecting {
                pill("Chọn tất cả") {
                    selected = Set(filtered.filter { !$0.isOwner }.map { $0.key })
                }
                if !selected.isEmpty {
                    pill("Bỏ chọn") { selected.removeAll() }
                }
            }
            Spacer()
            if selecting && !selected.isEmpty {
                pill("Copy", icon: "doc.on.doc") {
                    let text = filtered.filter { selected.contains($0.key) }.map { $0.key }.joined(separator: "\n")
                    store.copy(text, message: "Đã copy \(selected.count) key")
                }
                pill("Xoá (\(selected.count))", icon: "trash", tint: .red) {
                    confirm = .deleteSelected
                }
            } else {
                Text("\(filtered.count) key")
                    .font(.caption)
                    .foregroundStyle(.white.opacity(0.5))
            }
        }
    }

    private func badge(_ text: String, _ color: Color) -> some View {
        Text(text)
            .font(.system(size: 9, weight: .black, design: .rounded))
            .tracking(0.5)
            .foregroundStyle(color)
            .padding(.horizontal, 7)
            .padding(.vertical, 3)
            .background(color.opacity(0.14), in: Capsule())
    }

    private func rowView(_ k: KACKey) -> some View {
        let isSel = selected.contains(k.key)
        return HStack(alignment: .top, spacing: 10) {
            if selecting {
                Image(systemName: k.isOwner ? "lock.fill" : (isSel ? "checkmark.circle.fill" : "circle"))
                    .font(.system(size: 20))
                    .foregroundStyle(isSel ? accent : .white.opacity(0.35))
                    .padding(.top, 2)
            }
            VStack(alignment: .leading, spacing: 6) {
                Text(k.key)
                    .font(.system(.footnote, design: .monospaced).weight(.bold))
                    .foregroundStyle(.white)
                    .textSelection(.enabled)
                HStack(spacing: 6) {
                    if k.isOwner {
                        badge("OWNER", .yellow)
                    } else if k.isTest {
                        badge("TEST", .green)
                    } else if k.isVIP {
                        badge("VIP", accent)
                    } else {
                        badge("KEY", .blue)
                    }
                    if k.isExpired { badge("HẾT HẠN", .red) }
                    if let l = k.label, !l.isEmpty {
                        Text(l)
                            .font(.caption2)
                            .foregroundStyle(.white.opacity(0.6))
                            .lineLimit(1)
                    }
                }
                HStack(spacing: 6) {
                    Image(systemName: "clock.fill")
                        .font(.system(size: 9))
                    Text(k.remainingText)
                    Text("·")
                    Text(k.devicesText)
                }
                .font(.caption2.weight(.semibold))
                .foregroundStyle(k.isExpired ? Color.red.opacity(0.85) : Color.white.opacity(0.5))
            }
            Spacer(minLength: 6)
            if !selecting {
                HStack(spacing: 6) {
                    Button { store.copy(k.key) } label: {
                        Image(systemName: "doc.on.doc")
                            .font(.caption.bold())
                            .foregroundStyle(.white)
                            .frame(width: 34, height: 34)
                            .background(Color.white.opacity(0.08), in: Circle())
                    }
                    .buttonStyle(.plain)
                    rowMenu(k)
                }
            }
        }
        .padding(12)
        .background(
            (isSel ? accent.opacity(0.12) : Color.white.opacity(0.05)),
            in: RoundedRectangle(cornerRadius: 16, style: .continuous)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .stroke(isSel ? accent.opacity(0.7) : Color.white.opacity(0.07), lineWidth: 1)
        )
        .contentShape(Rectangle())
        .onTapGesture {
            guard selecting, !k.isOwner else { return }
            if isSel { selected.remove(k.key) } else { selected.insert(k.key) }
        }
    }

    private func rowMenu(_ k: KACKey) -> some View {
        Menu {
            if !k.isLifetime {
                Button("+1 giờ") { Task { await store.extend(k.key, hours: 1) } }
                Button("+1 ngày") { Task { await store.extend(k.key, days: 1) } }
                Button("+3 ngày") { Task { await store.extend(k.key, days: 3) } }
                Button("+7 ngày") { Task { await store.extend(k.key, days: 7) } }
                Button("+15 ngày") { Task { await store.extend(k.key, days: 15) } }
                Button("+30 ngày") { Task { await store.extend(k.key, days: 30) } }
                Divider()
            }
            Button {
                editText = k.label ?? ""
                editing = k
            } label: {
                Label("Sửa tên hiển thị", systemImage: "pencil")
            }
            if !k.isOwner {
                Button {
                    Task { await store.resetDevices(k.key) }
                } label: {
                    Label("Reset thiết bị", systemImage: "iphone.slash")
                }
                Divider()
                Button(role: .destructive) {
                    confirm = .deleteOne(k.key)
                } label: {
                    Label("Xoá key", systemImage: "trash")
                }
            }
        } label: {
            Image(systemName: "ellipsis")
                .font(.caption.bold())
                .foregroundStyle(.white)
                .frame(width: 34, height: 34)
                .background(Color.white.opacity(0.08), in: Circle())
        }
    }

    // MARK: Tab Tạo key
    private func card<Content: View>(_ title: String, @ViewBuilder _ content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(title)
                .font(.caption2.weight(.black))
                .tracking(1.2)
                .foregroundStyle(accent)
            content()
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(14)
        .background(Color.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .stroke(Color.white.opacity(0.07), lineWidth: 1)
        )
    }

    private func typeButton(_ k: KACKind, title: String, sub: String) -> some View {
        Button { kind = k } label: {
            VStack(spacing: 3) {
                Text(title).font(.subheadline.weight(.bold))
                Text(sub).font(.caption2).foregroundStyle(.white.opacity(0.6))
            }
            .foregroundStyle(.white)
            .frame(maxWidth: .infinity, minHeight: 56)
            .background(
                kind == k ? accent.opacity(0.25) : Color.white.opacity(0.06),
                in: RoundedRectangle(cornerRadius: 13, style: .continuous)
            )
            .overlay(
                RoundedRectangle(cornerRadius: 13, style: .continuous)
                    .stroke(kind == k ? accent : Color.white.opacity(0.08), lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
    }

    private func stepperRow(_ title: String, value: Binding<Int>, range: ClosedRange<Int>) -> some View {
        HStack {
            Text(title).font(.subheadline.weight(.semibold)).foregroundStyle(.white)
            Spacer()
            Text("\(value.wrappedValue)")
                .font(.system(.title3, design: .rounded).bold())
                .foregroundStyle(.white)
                .frame(minWidth: 34)
            Stepper("", value: value, in: range).labelsHidden()
        }
    }

    private var createTab: some View {
        ScrollView {
            VStack(spacing: 12) {
                card("LOẠI KEY") {
                    HStack(spacing: 10) {
                        typeButton(.test, title: "Test", sub: "1 giờ · Shinn-Test-…")
                        typeButton(.vip, title: "VIP", sub: "theo ngày · Shinn-Vip-…")
                    }
                }

                if kind == .vip {
                    card("THỜI HẠN") {
                        LazyVGrid(columns: [GridItem(.adaptive(minimum: 90), spacing: 8)], spacing: 8) {
                            ForEach([1, 3, 7, 15, 30], id: \.self) { d in
                                Button { days = d } label: {
                                    Text("\(d) ngày")
                                        .font(.subheadline.weight(.bold))
                                        .foregroundStyle(.white)
                                        .frame(maxWidth: .infinity, minHeight: 44)
                                        .background(
                                            days == d ? accent.opacity(0.25) : Color.white.opacity(0.06),
                                            in: RoundedRectangle(cornerRadius: 12, style: .continuous)
                                        )
                                        .overlay(
                                            RoundedRectangle(cornerRadius: 12, style: .continuous)
                                                .stroke(days == d ? accent : Color.white.opacity(0.08), lineWidth: 1)
                                        )
                                }
                                .buttonStyle(.plain)
                            }
                        }
                    }
                }

                card("TÊN HIỂN THỊ") {
                    if kind == .test {
                        HStack(spacing: 8) {
                            Image(systemName: "lock.fill")
                            Text(KACConfig.testLabel).font(.subheadline.weight(.bold))
                            Spacer()
                        }
                        .foregroundStyle(.white.opacity(0.6))
                        .padding(13)
                        .background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                    } else {
                        TextField("Key này của ai? (bắt buộc)", text: $label)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled(true)
                            .padding(13)
                            .background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                    }
                }

                card("SỐ LƯỢNG & THIẾT BỊ") {
                    stepperRow("Số key", value: $quantity, range: 1...99)
                    stepperRow("Thiết bị tối đa / key", value: $maxDevices, range: 1...50)
                }

                DisclosureGroup {
                    TextField("Key tuỳ chỉnh (để trống = tự sinh)", text: $customKey)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled(true)
                        .padding(13)
                        .background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                        .padding(.top, 6)
                } label: {
                    Text("Nâng cao")
                        .font(.footnote.weight(.bold))
                        .foregroundStyle(.white.opacity(0.7))
                }
                .padding(14)
                .background(Color.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 18, style: .continuous))

                Button { createTapped() } label: {
                    HStack(spacing: 8) {
                        if store.isLoading {
                            ProgressView().tint(.white)
                        } else {
                            Image(systemName: "key.fill")
                            Text("TẠO \(quantity) KEY \(kind == .test ? "TEST" : "VIP")")
                        }
                    }
                    .font(.system(size: 15, weight: .bold, design: .rounded))
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity, minHeight: 52)
                    .background(accent.opacity(0.8), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                }
                .buttonStyle(.plain)
                .disabled(store.isLoading)

                if !store.created.isEmpty {
                    card("VỪA TẠO (\(store.created.count))") {
                        HStack {
                            Spacer()
                            pill("Copy tất cả", icon: "doc.on.doc", tint: accent) {
                                store.copy(store.created.joined(separator: "\n"),
                                           message: "Đã copy \(store.created.count) key")
                            }
                            pill("Ẩn", tint: .white) { store.created = [] }
                        }
                        ForEach(store.created, id: \.self) { k in
                            HStack {
                                Text(k)
                                    .font(.system(.footnote, design: .monospaced).weight(.bold))
                                    .foregroundStyle(.white)
                                    .textSelection(.enabled)
                                Spacer()
                                Button { store.copy(k) } label: {
                                    Image(systemName: "doc.on.doc")
                                        .font(.caption.bold())
                                        .foregroundStyle(.white)
                                        .frame(width: 32, height: 32)
                                        .background(Color.white.opacity(0.08), in: Circle())
                                }
                                .buttonStyle(.plain)
                            }
                        }
                    }
                }
            }
            .padding(.horizontal, 16)
            .padding(.bottom, 80)
        }
    }

    private func createTapped() {
        let lbl = label.trimmingCharacters(in: .whitespacesAndNewlines)
        if kind == .vip && lbl.isEmpty {
            store.show("Hãy nhập tên hiển thị (key này của ai)", error: true)
            return
        }
        let custom = customKey.trimmingCharacters(in: .whitespacesAndNewlines)
        Task {
            let ok = await store.create(
                kind: kind.rawValue,
                days: days,
                label: kind == .test ? KACConfig.testLabel : lbl,
                count: quantity,
                maxDevices: maxDevices,
                custom: custom
            )
            if ok { customKey = "" }
        }
    }

    // MARK: Tab Công cụ
    private var expiredKeys: [KACKey] { store.keys.filter { $0.isExpired && !$0.isOwner } }
    private var testKeys: [KACKey] { store.keys.filter { $0.isTest && !$0.isOwner } }
    private var nonOwnerKeys: [KACKey] { store.keys.filter { !$0.isOwner } }

    private func toolButton(_ title: String, count: Int, icon: String, tint: Color,
                            action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 10) {
                Image(systemName: icon).frame(width: 24)
                Text(title).font(.subheadline.weight(.semibold))
                Spacer()
                Text("\(count)")
                    .font(.caption.weight(.black))
                    .padding(.horizontal, 9)
                    .padding(.vertical, 4)
                    .background(tint.opacity(0.2), in: Capsule())
            }
            .foregroundStyle(count == 0 ? Color.white.opacity(0.3) : tint)
            .padding(13)
            .background(Color.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 13, style: .continuous))
        }
        .buttonStyle(.plain)
        .disabled(count == 0)
    }

    private var toolsTab: some View {
        ScrollView {
            VStack(spacing: 12) {
                card("DỌN DẸP SERVER") {
                    toolButton("Xoá key đã hết hạn", count: expiredKeys.count,
                               icon: "clock.badge.xmark", tint: .orange) { confirm = .deleteExpired }
                    toolButton("Xoá tất cả key Test", count: testKeys.count,
                               icon: "flask", tint: .yellow) { confirm = .deleteTests }
                    toolButton("Xoá TẤT CẢ key (trừ Owner)", count: nonOwnerKeys.count,
                               icon: "trash.fill", tint: .red) { confirm = .deleteAll }
                }
                card("SAO CHÉP") {
                    let active = store.keys.filter { !$0.isExpired && !$0.isOwner }
                    toolButton("Copy tất cả key còn hạn", count: active.count,
                               icon: "doc.on.doc", tint: accent) {
                        store.copy(active.map { $0.key }.joined(separator: "\n"),
                                   message: "Đã copy \(active.count) key")
                    }
                    toolButton("Copy tất cả key hết hạn", count: expiredKeys.count,
                               icon: "doc.on.doc", tint: .white) {
                        store.copy(expiredKeys.map { $0.key }.joined(separator: "\n"),
                                   message: "Đã copy \(expiredKeys.count) key")
                    }
                }
                Text("Key Owner luôn được bảo vệ, không bị xoá bởi các nút trên.")
                    .font(.caption)
                    .foregroundStyle(.white.opacity(0.45))
                    .padding(.top, 4)
            }
            .padding(.horizontal, 16)
            .padding(.bottom, 80)
        }
    }

    // MARK: Xác nhận xoá
    private var confirmTitle: String {
        guard let c = confirm else { return "" }
        switch c {
        case .deleteSelected: return "Xoá \(selected.count) key đã chọn?"
        case .deleteOne(let k): return "Xoá key \(k)?"
        case .deleteExpired: return "Xoá \(expiredKeys.count) key hết hạn?"
        case .deleteTests: return "Xoá \(testKeys.count) key Test?"
        case .deleteAll: return "Xoá TẤT CẢ \(nonOwnerKeys.count) key?"
        }
    }

    private var confirmMessage: String {
        guard let c = confirm else { return "" }
        switch c {
        case .deleteAll: return "Mọi key (trừ Owner) sẽ bị xoá khỏi server. Không thể hoàn tác."
        default: return "Key bị xoá khỏi server và không dùng được nữa. Không thể hoàn tác."
        }
    }

    @MainActor
    private func runConfirmed(_ c: KACConfirm) {
        Task { @MainActor in
            switch c {
            case .deleteOne(let k):
                await store.delete([k])
            case .deleteSelected:
                await store.delete(Array(selected))
                selected = selected.intersection(Set(store.keys.map { $0.key }))
                if selected.isEmpty { selecting = false }
            case .deleteExpired:
                await store.delete(expiredKeys.map { $0.key })
            case .deleteTests:
                await store.delete(testKeys.map { $0.key })
            case .deleteAll:
                await store.deleteAll()
            }
        }
    }

    // MARK: Toast
    @ViewBuilder
    private var toastView: some View {
        if let t = store.toast {
            Text(t)
                .font(.footnote.weight(.semibold))
                .foregroundStyle(.white)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 16)
                .padding(.vertical, 11)
                .background(
                    store.toastIsError ? Color.red.opacity(0.92) : Color.green.opacity(0.88),
                    in: RoundedRectangle(cornerRadius: 16, style: .continuous)
                )
                .padding(.horizontal, 24)
                .padding(.bottom, 28)
                .transition(.move(edge: .bottom).combined(with: .opacity))
                .onTapGesture { store.toast = nil }
        }
    }
}
