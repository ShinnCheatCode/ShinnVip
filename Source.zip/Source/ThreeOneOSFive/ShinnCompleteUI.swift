import SwiftUI
import UIKit
import PhotosUI

// MARK: - ShinnCheat compact command center
// UI-only shell. Existing Supabase/license/repository services remain the source of truth.

struct ShinnCompleteRootView: View {
    @EnvironmentObject private var store: RepoStore
    @EnvironmentObject private var license: LicenseManager
    @EnvironmentObject private var session: Session
    @StateObject private var personalization = ShinnPersonalizationStore()
    @State private var tab: Tab = .home
    @State private var sheet: Sheet?

    enum Tab: Hashable { case home, patch, chat, account }
    enum Sheet: String, Identifiable {
        case owner, activate, settings, about, repository, history, announcement
        var id: String { rawValue }
    }

    var body: some View {
        ZStack {
            CompactBackground()
            Group {
                switch tab {
                case .home:
                    CompactHome(
                        store: store,
                        license: license,
                        session: session,
                        personalization: personalization,
                        open: { sheet = $0 },
                        openPatch: { tab = .patch }
                    )
                case .patch:
                    CompactPatchView(store: store)
                case .chat:
                    ShinnAIChatView()
                case .account:
                    CompactAccount(license: license, session: session, open: { sheet = $0 })
                }
            }
        }
        .safeAreaInset(edge: .bottom, spacing: 0) {
            CompactTabBar(tab: $tab)
        }
        .sheet(item: $sheet) { item in
            NavigationStack {
                switch item {
                case .owner: CompactOwnerView()
                case .activate: ActivateKeyView()
                case .settings: ShinnSettingsHubView()
                case .about: ShinnAboutView()
                case .repository: RepositoryManagerView()
                case .history: CompactHistoryView(store: store)
                case .announcement: CompactAnnouncementView()
                }
            }
            .preferredColorScheme(.dark)
        }
    }
}

private struct CompactBackground: View {
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            LinearGradient(
                colors: [Color(red: 0.015, green: 0.025, blue: 0.065), .black, Color(red: 0.035, green: 0.012, blue: 0.05)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            ).ignoresSafeArea()
        }
    }
}

private struct CompactHome: View {
    @ObservedObject var store: RepoStore
    @ObservedObject var license: LicenseManager
    @ObservedObject var session: Session
    @ObservedObject var personalization: ShinnPersonalizationStore
    let open: (ShinnCompleteRootView.Sheet) -> Void
    let openPatch: () -> Void
    @State private var avatarPicker: PhotosPickerItem?
    @State private var backgroundPicker: PhotosPickerItem?
    @State private var showAvatarPicker = false
    @State private var showBackgroundPicker = false
    @State private var showImageControls = false

    private var avatar: UIImage { personalization.sImage ?? UIImage(named: "WhiteCat") ?? UIImage(named: "ShinnCatAvatar") ?? UIImage() }
    private var recent: [RepoPackage] { Array(store.recentPackages.prefix(4)) }
    private var role: String { session.role == .owner ? "OWNER" : (license.boundRole?.uppercased() ?? "MEMBER") }

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 12) {
                header
                hero
                sessionRow

                HStack(spacing: 8) {
                    compactAction("Patch", "square.grid.2x2.fill", .cyan) { openPatch() }
                    compactAction("AI", "sparkles", .purple) { openPatch(); }
                    if session.role == .owner {
                        compactAction("Owner", "crown.fill", .yellow) { open(.owner) }
                    }
                }

                if session.role == .owner {
                    ownerPanel
                }

                if !recent.isEmpty {
                    sectionTitle("RECENT PATCHES", trailing: "\(recent.count)")
                    ForEach(recent) { pkg in
                        CompactRecentPatch(pkg: pkg, store: store)
                    }
                }

                if showImageControls { imageControls }

                sectionTitle("ACCOUNT", trailing: nil)
                HStack(spacing: 8) {
                    miniButton("Key", "key.fill") { open(.activate) }
                    miniButton("Settings", "gearshape.fill") { open(.settings) }
                    miniButton("About", "info.circle.fill") { open(.about) }
                }
            }
            .padding(.horizontal, 13)
            .padding(.top, 10)
            .padding(.bottom, 16)
        }
        .photosPicker(isPresented: $showAvatarPicker, selection: $avatarPicker, matching: .images)
        .photosPicker(isPresented: $showBackgroundPicker, selection: $backgroundPicker, matching: .images)
        .onChange(of: avatarPicker) { item in
            load(item, key: "shinn.custom.sImage")
        }
        .onChange(of: backgroundPicker) { item in
            load(item, key: "shinn.custom.background")
        }
    }

    private var header: some View {
        HStack(spacing: 10) {
            Image(uiImage: avatar)
                .resizable().scaledToFill()
                .frame(width: 40, height: 40)
                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.white.opacity(0.12)))
                .onLongPressGesture(minimumDuration: 2) { withAnimation(.easeInOut(duration: 0.18)) { showImageControls = true } }

            VStack(alignment: .leading, spacing: 2) {
                Text("SHINNCHEAT").font(.system(size: 18, weight: .black, design: .rounded)).tracking(1.2)
                Text(role + " • ACTIVE").font(.system(size: 9, weight: .bold, design: .rounded)).foregroundStyle(.cyan)
            }
            Spacer()
            Image(systemName: "bell.fill").font(.system(size: 15, weight: .bold)).foregroundStyle(.white.opacity(0.65))
        }
    }

    private var hero: some View {
        ZStack(alignment: .bottomLeading) {
            if let bg = personalization.backgroundImage {
                Image(uiImage: bg).resizable().scaledToFill()
            } else {
                Image("WhiteCat").resizable().scaledToFill()
            }
            LinearGradient(colors: [.clear, .black.opacity(0.9)], startPoint: .center, endPoint: .bottom)
            VStack(alignment: .leading, spacing: 3) {
                Text("SHINN COMMAND").font(.system(size: 9, weight: .black, design: .rounded)).tracking(1.5).foregroundStyle(.cyan)
                Text("Control Center").font(.system(size: 22, weight: .black, design: .rounded))
                Text("Long-press the avatar or background for 2 seconds to change it.")
                    .font(.system(size: 9, weight: .medium, design: .rounded)).foregroundStyle(.white.opacity(0.55))
            }
            .padding(13)
        }
        .frame(height: 142)
        .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.white.opacity(0.10)))
        .onLongPressGesture(minimumDuration: 2) { withAnimation(.easeInOut(duration: 0.18)) { showImageControls = true } }
    }

    private var imageControls: some View {
        VStack(alignment: .leading, spacing: 7) {
            HStack {
                Text("IMAGE CONTROLS").font(.system(size: 9, weight: .black, design: .rounded)).foregroundStyle(.cyan)
                Spacer()
                Button("Done") { withAnimation(.easeInOut(duration: 0.18)) { showImageControls = false } }
                    .font(.system(size: 9, weight: .bold, design: .rounded))
            }
            HStack(spacing: 7) {
                Button { showAvatarPicker = true } label: {
                    Label("Upload Avatar", systemImage: "person.crop.circle.badge.plus")
                        .frame(maxWidth: .infinity).padding(.vertical, 9)
                }.buttonStyle(.plain)
                Button { showBackgroundPicker = true } label: {
                    Label("Upload Cover", systemImage: "photo.badge.plus")
                        .frame(maxWidth: .infinity).padding(.vertical, 9)
                }.buttonStyle(.plain)
            }
            .font(.system(size: 9, weight: .bold, design: .rounded))
            .background(Color.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 11))
        }
        .padding(9)
        .background(Color.white.opacity(0.04), in: RoundedRectangle(cornerRadius: 13))
    }

    private var sessionRow: some View {
        HStack(spacing: 8) {
            Circle().fill(.green).frame(width: 7, height: 7)
            Text(license.savedLicenseKey.isEmpty ? "No active key" : license.holderName.isEmpty ? "Feedback@ShinnThieuu" : license.holderName)
                .font(.system(size: 11, weight: .bold, design: .rounded)).lineLimit(1)
            Spacer()
            if let expiry = license.expiresAt {
                Text(remainingKeyText(expiry)).font(.system(size: 10, weight: .bold, design: .rounded)).foregroundStyle(.cyan)
            }
        }
        .padding(.horizontal, 11).padding(.vertical, 9)
        .background(Color.white.opacity(0.045), in: Capsule())
    }

    private var ownerPanel: some View {
        VStack(alignment: .leading, spacing: 8) {
            sectionTitle("OWNER TOOLS", trailing: nil)
            HStack(spacing: 8) {
                ownerTool("Create Keys", "key.fill") { open(.owner) }
                ownerTool("Announcement", "megaphone.fill") { open(.announcement) }
            }
        }
    }

    private func compactAction(_ title: String, _ icon: String, _ tint: Color, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 7) {
                Image(systemName: icon).font(.system(size: 12, weight: .bold)).foregroundStyle(tint)
                Text(title).font(.system(size: 10, weight: .bold, design: .rounded))
            }
            .frame(maxWidth: .infinity).padding(.vertical, 10)
            .background(Color.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 13))
        }.buttonStyle(.plain)
    }

    private func ownerTool(_ title: String, _ icon: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Label(title, systemImage: icon).font(.system(size: 10, weight: .bold, design: .rounded))
                .frame(maxWidth: .infinity).padding(.vertical, 10)
                .background(Color.yellow.opacity(0.08), in: RoundedRectangle(cornerRadius: 13))
        }.buttonStyle(.plain)
    }

    private func miniButton(_ title: String, _ icon: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(spacing: 5) {
                Image(systemName: icon).font(.system(size: 13, weight: .bold)).foregroundStyle(.cyan)
                Text(title).font(.system(size: 9, weight: .bold, design: .rounded))
            }.frame(maxWidth: .infinity).padding(.vertical, 9)
                .background(Color.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 13))
        }.buttonStyle(.plain)
    }

    private func sectionTitle(_ title: String, trailing: String?) -> some View {
        HStack {
            Text(title).font(.system(size: 9, weight: .black, design: .rounded)).tracking(1.4).foregroundStyle(.white.opacity(0.42))
            Spacer()
            if let trailing { Text(trailing).font(.system(size: 9, weight: .bold, design: .rounded)).foregroundStyle(.cyan) }
        }
    }

    private func load(_ item: PhotosPickerItem?, key: String) {
        guard let item else { return }
        Task {
            if let data = try? await item.loadTransferable(type: Data.self), let image = UIImage(data: data) {
                await MainActor.run { personalization.save(image, key: key) }
            }
        }
    }
}

private struct CompactRecentPatch: View {
    let pkg: RepoPackage
    @ObservedObject var store: RepoStore
    var body: some View {
        HStack(spacing: 9) {
            Image("ShinnPatchArt").resizable().scaledToFill().frame(width: 38, height: 38).clipShape(RoundedRectangle(cornerRadius: 10))
            VStack(alignment: .leading, spacing: 2) {
                Text(pkg.name).font(.system(size: 11, weight: .bold, design: .rounded)).lineLimit(1)
                Text(pkg.version ?? pkg.category ?? "Patch").font(.system(size: 8.5, weight: .medium, design: .rounded)).foregroundStyle(.white.opacity(0.42))
            }
            Spacer()
            Button {
                Task { await store.apply(pkg, openGame: false) }
            } label: {
                Image(systemName: "power.circle.fill").font(.system(size: 21, weight: .bold)).foregroundStyle(.cyan)
            }.buttonStyle(.plain)
        }
        .padding(9)
        .background(Color.white.opacity(0.04), in: RoundedRectangle(cornerRadius: 14))
    }
}

private struct CompactPatchView: View {
    @ObservedObject var store: RepoStore
    @State private var query = ""
    @State private var selected: RepoPackage?
    @State private var category = "All"

    private var filtered: [RepoPackage] {
        let base = store.packages.filter { category == "All" || ($0.category ?? "Other") == category }
        guard !query.isEmpty else { return base }
        return base.filter { "\($0.name) \($0.summary ?? "") \($0.category ?? "")".localizedCaseInsensitiveContains(query) }
    }

    private var categories: [String] { ["All"] + Array(Set(store.packages.compactMap(\.category))).sorted() }

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 10) {
                HStack {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("PATCH CENTER").font(.system(size: 18, weight: .black, design: .rounded)).tracking(1)
                        Text("\(filtered.count) available").font(.system(size: 9, weight: .medium, design: .rounded)).foregroundStyle(.white.opacity(0.4))
                    }
                    Spacer()
                    Image(systemName: "bolt.fill").foregroundStyle(.cyan)
                }
                HStack(spacing: 7) {
                    Image(systemName: "magnifyingglass").foregroundStyle(.white.opacity(0.35))
                    TextField("Search patches", text: $query).font(.system(size: 11, weight: .medium, design: .rounded))
                }.padding(10).background(Color.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 13))
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 6) {
                        ForEach(categories, id: \.self) { item in
                            Button { category = item } label: {
                                Text(item).font(.system(size: 9, weight: .bold, design: .rounded))
                                    .padding(.horizontal, 10).padding(.vertical, 7)
                                    .background(category == item ? Color.cyan.opacity(0.18) : Color.white.opacity(0.045), in: Capsule())
                                    .foregroundStyle(category == item ? .cyan : .white.opacity(0.55))
                            }.buttonStyle(.plain)
                        }
                    }
                }
                ForEach(filtered) { pkg in
                    CompactPatchRow(pkg: pkg, store: store) { selected = pkg }
                }
            }.padding(.horizontal, 13).padding(.top, 10).padding(.bottom, 16)
        }
        .refreshable { await store.refresh() }
        .sheet(item: $selected) { pkg in CompactPatchDetail(pkg: pkg, store: store).preferredColorScheme(.dark) }
    }
}

private struct CompactPatchRow: View {
    let pkg: RepoPackage
    @ObservedObject var store: RepoStore
    let open: () -> Void
    private var applied: Bool { if case .applied = store.patchState(for: pkg) { return true }; return false }
    private var busy: Bool { switch store.patchState(for: pkg) { case .applying, .restoring: return true; default: return false } }
    var body: some View {
        HStack(spacing: 8) {
            Button(action: open) {
                Image("ShinnPatchArt").resizable().scaledToFill().frame(width: 39, height: 39).clipShape(RoundedRectangle(cornerRadius: 10))
            }.buttonStyle(.plain)
            Button(action: open) {
                VStack(alignment: .leading, spacing: 2) {
                    Text(pkg.name).font(.system(size: 11, weight: .bold, design: .rounded)).lineLimit(1)
                    Text(pkg.summary ?? pkg.category ?? "Patch").font(.system(size: 8.5, weight: .medium, design: .rounded)).foregroundStyle(.white.opacity(0.4)).lineLimit(1)
                }
            }.buttonStyle(.plain)
            Spacer(minLength: 0)
            Button {
                Task { if applied { await store.restore(pkg) } else { await store.apply(pkg, openGame: false) } }
            } label: {
                if busy { ProgressView().tint(.white).frame(width: 28, height: 28) }
                else { Image(systemName: applied ? "power.circle.fill" : "power.circle").font(.system(size: 25, weight: .bold)).foregroundStyle(applied ? .green : .white.opacity(0.5)) }
            }.buttonStyle(.plain).disabled(busy)
            Button { Task { await store.download(pkg) } } label: {
                Image(systemName: "arrow.down.circle.fill").font(.system(size: 19, weight: .bold)).foregroundStyle(.cyan)
            }.buttonStyle(.plain)
        }
        .padding(9)
        .background(Color.white.opacity(0.04), in: RoundedRectangle(cornerRadius: 14))
        .overlay(RoundedRectangle(cornerRadius: 14).stroke(applied ? Color.green.opacity(0.28) : Color.white.opacity(0.05)))
    }
}

private struct CompactPatchDetail: View {
    let pkg: RepoPackage
    @ObservedObject var store: RepoStore
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 10) {
                    Image("ShinnPatchArt").resizable().scaledToFill().frame(height: 150).clipShape(RoundedRectangle(cornerRadius: 18))
                    Text(pkg.name).font(.title2.bold())
                    Text(pkg.summary ?? pkg.description ?? "Patch").foregroundStyle(.white.opacity(0.55))
                    HStack { Text(pkg.category ?? "Other"); Spacer(); Text(pkg.version ?? "—") }.font(.caption).foregroundStyle(.cyan)
                    Button { Task { await store.download(pkg) } } label: { Label("Download", systemImage: "arrow.down.circle.fill").frame(maxWidth: .infinity) }.buttonStyle(.borderedProminent)
                }.padding(14)
            }.navigationTitle("Patch")
        }
    }
}

private struct CompactAccount: View {
    @ObservedObject var license: LicenseManager
    @ObservedObject var session: Session
    let open: (ShinnCompleteRootView.Sheet) -> Void
    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 10) {
                Text("ACCOUNT").font(.system(size: 18, weight: .black, design: .rounded)).tracking(1)
                HStack(spacing: 10) {
                    Image("WhiteCat").resizable().scaledToFill().frame(width: 48, height: 48).clipShape(RoundedRectangle(cornerRadius: 13))
                    VStack(alignment: .leading, spacing: 2) {
                        Text(license.holderName.isEmpty ? "ShinnThieuu" : license.holderName).font(.headline.bold())
                        Text(session.role == .owner ? "OWNER" : (license.boundRole?.uppercased() ?? "MEMBER")).font(.caption2.bold()).foregroundStyle(.cyan)
                    }
                    Spacer()
                }.padding(11).background(Color.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 16))
                accountRow("License", license.savedLicenseKey.isEmpty ? "Not activated" : license.savedLicenseKey, "key.fill") { open(.activate) }
                accountRow("Settings", "App preferences", "gearshape.fill") { open(.settings) }
                accountRow("About", "App info, terms and contact", "info.circle.fill") { open(.about) }
                if session.role == .owner { accountRow("Repository", "Repository management", "square.stack.3d.up.fill") { open(.repository) } }
            }.padding(13).padding(.top, 10)
        }
    }
    private func accountRow(_ title: String, _ sub: String, _ icon: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 10) {
                Image(systemName: icon).font(.system(size: 13, weight: .bold)).foregroundStyle(.cyan).frame(width: 34, height: 34).background(Color.cyan.opacity(0.10), in: RoundedRectangle(cornerRadius: 10))
                VStack(alignment: .leading, spacing: 2) { Text(title).font(.system(size: 11, weight: .bold, design: .rounded)); Text(sub).font(.system(size: 8.5, weight: .medium, design: .rounded)).foregroundStyle(.white.opacity(0.4)).lineLimit(1) }
                Spacer(); Image(systemName: "chevron.right").font(.caption2).foregroundStyle(.white.opacity(0.25))
            }.padding(9).background(Color.white.opacity(0.04), in: RoundedRectangle(cornerRadius: 14))
        }.buttonStyle(.plain)
    }
}

private struct CompactTabBar: View {
    @Binding var tab: ShinnCompleteRootView.Tab
    var body: some View {
        HStack(spacing: 3) {
            item(.home, "house.fill", "Home")
            item(.patch, "square.grid.2x2.fill", "Patch")
            item(.chat, "sparkles", "Chat")
            item(.account, "person.crop.circle.fill", "Account")
        }.padding(6).background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 19)).overlay(RoundedRectangle(cornerRadius: 19).stroke(Color.white.opacity(0.08))).padding(.horizontal, 10).padding(.bottom, 5)
    }
    private func item(_ value: ShinnCompleteRootView.Tab, _ icon: String, _ title: String) -> some View {
        Button { withAnimation(.easeInOut(duration: 0.18)) { tab = value } } label: {
            VStack(spacing: 3) { Image(systemName: icon).font(.system(size: 15, weight: .bold)); Text(title).font(.system(size: 8, weight: .bold, design: .rounded)) }
                .foregroundStyle(tab == value ? .cyan : .white.opacity(0.42)).frame(maxWidth: .infinity).padding(.vertical, 7).background(tab == value ? Color.cyan.opacity(0.09) : .clear, in: RoundedRectangle(cornerRadius: 13))
        }.buttonStyle(.plain)
    }
}

private struct CompactOwnerView: View {
    @StateObject private var manager = OwnerKeyManager()
    @State private var duration = "7D"
    @State private var quantity = 1
    @State private var label = "Feedback@ShinnThieuu"
    @State private var created = ""
    @State private var busy = false
    @State private var error = ""
    @State private var showDeleteConfirm = false
    @State private var keyToDelete: String?

    private let durations: [(String, Int, Int)] = [
        ("1H", 1, 0), ("1D", 0, 1), ("3D", 0, 3), ("7D", 0, 7), ("30D", 0, 30)
    ]

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 12) {
                Text("OWNER CONTROL")
                    .font(.system(size: 19, weight: .black, design: .rounded))

                VStack(alignment: .leading, spacing: 9) {
                    Text("CREATE KEYS").font(.caption.bold()).foregroundStyle(.cyan)
                    TextField("Key label", text: $label)
                        .textInputAutocapitalization(.never)
                        .padding(10)
                        .background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 10))

                    HStack(spacing: 5) {
                        ForEach(durations, id: \.0) { item in
                            Button {
                                duration = item.0
                                manager.selectedHours = item.1
                                manager.selectedDays = item.2
                                manager.lifetime = false
                            } label: {
                                Text(item.0)
                                    .font(.system(size: 10, weight: .black, design: .rounded))
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical, 9)
                                    .foregroundStyle(duration == item.0 ? .black : .white.opacity(0.72))
                                    .background(duration == item.0 ? Color.cyan : Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 9))
                            }
                            .buttonStyle(.plain)
                        }
                    }

                    Text("Selected: \(duration)")
                        .font(.system(size: 9, weight: .bold, design: .rounded))
                        .foregroundStyle(.white.opacity(0.45))

                    Stepper("Quantity: \(quantity)", value: $quantity, in: 1...99)
                        .font(.system(size: 11, weight: .bold, design: .rounded))

                    Button {
                        let selected = durations.first(where: { $0.0 == duration }) ?? ("7D", 0, 7)
                        manager.selectedHours = selected.1
                        manager.selectedDays = selected.2
                        manager.lifetime = false
                        manager.createCount = quantity
                        manager.keyLabel = label
                        busy = true
                        Task {
                            await manager.createKey()
                            await MainActor.run {
                                created = manager.prettyCreated
                                error = manager.error ?? ""
                                busy = false
                            }
                        }
                    } label: {
                        HStack {
                            Spacer()
                            if busy { ProgressView() } else { Label("CREATE \(quantity) KEY\(quantity == 1 ? "" : "S")", systemImage: "key.fill") }
                            Spacer()
                        }
                        .font(.system(size: 11, weight: .black, design: .rounded))
                        .padding(.vertical, 11)
                        .background(Color.cyan, in: RoundedRectangle(cornerRadius: 11))
                        .foregroundStyle(.black)
                    }
                    .buttonStyle(.plain)
                    .disabled(busy)
                }
                .padding(11)
                .background(Color.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 15))

                if !created.isEmpty {
                    VStack(alignment: .leading, spacing: 7) {
                        Text("CREATED").font(.caption.bold()).foregroundStyle(.green)
                        Text(created)
                            .font(.system(size: 10, design: .monospaced))
                            .textSelection(.enabled)
                        Button("COPY ALL") { UIPasteboard.general.string = created }
                            .font(.caption.bold())
                    }
                    .padding(11)
                    .background(Color.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 15))
                }

                HStack {
                    Text("KEY MANAGEMENT").font(.caption.bold()).foregroundStyle(.cyan)
                    Spacer()
                    Button { Task { await manager.listKeys() } } label: {
                        Image(systemName: manager.isLoading ? "hourglass" : "arrow.clockwise")
                    }
                    .buttonStyle(.plain)
                }

                if !manager.keys.isEmpty {
                    ForEach(manager.keys.prefix(50)) { row in
                        HStack(spacing: 8) {
                            VStack(alignment: .leading, spacing: 3) {
                                Text(row.key).font(.system(size: 10, weight: .bold, design: .monospaced)).lineLimit(1)
                                Text(row.label ?? "Member")
                                    .font(.system(size: 8.5, weight: .medium, design: .rounded))
                                    .foregroundStyle(.white.opacity(0.4))
                                Text(formatKeyExpiry(row.expires_at))
                                    .font(.system(size: 8.5, weight: .bold, design: .rounded))
                                    .foregroundStyle(.cyan)
                            }
                            Spacer()
                            Button(role: .destructive) {
                                keyToDelete = row.key
                                showDeleteConfirm = true
                            } label: {
                                Image(systemName: "trash")
                                    .font(.system(size: 12, weight: .bold))
                                    .foregroundStyle(.red)
                                    .frame(width: 32, height: 32)
                                    .background(Color.red.opacity(0.10), in: RoundedRectangle(cornerRadius: 9))
                            }
                            .buttonStyle(.plain)
                        }
                        .padding(9)
                        .background(Color.white.opacity(0.04), in: RoundedRectangle(cornerRadius: 13))
                    }
                } else {
                    Text(manager.error ?? "No keys found.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                if !error.isEmpty {
                    Text(error).font(.caption).foregroundStyle(.red)
                }
            }
            .padding(13)
        }
        .navigationTitle("Owner")
        .confirmationDialog("Delete this key?", isPresented: $showDeleteConfirm, titleVisibility: .visible) {
            Button("Delete Key", role: .destructive) {
                guard let key = keyToDelete else { return }
                Task { await manager.deleteKey(key) }
            }
            Button("Cancel", role: .cancel) {}
        }
        .task { await manager.listKeys() }
    }
}

private struct CompactAnnouncementView: View {
    @State private var title = ""
    @State private var announcementText = ""
    @State private var status = ""
    @State private var busy = false
    var bodyView: some View { EmptyView() }
    var body: some View {
        Form {
            Section("NEW ANNOUNCEMENT") {
                TextField("Title", text: $title)
                TextEditor(text: $announcementText).frame(minHeight: 120)
                Button {
                    busy = true
                    Task {
                        let actor = UserDefaults.standard.string(forKey: "shinn.license.key") ?? ""
                        let ok = await AnnouncementStore.broadcast(title: title, body: announcementText, actorKey: actor)
                        await MainActor.run { busy = false; status = ok ? "Sent to all app users." : "Failed to send." }
                    }
                } label: { HStack { Spacer(); if busy { ProgressView() } else { Text("Publish") }; Spacer() } }.disabled(title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || announcementText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || busy)
            }
            if !status.isEmpty { Section { Text(status).foregroundStyle(status.hasPrefix("Sent") ? .green : .red) } }
        }.navigationTitle("Announcement")
    }
}

private struct CompactHistoryView: View {
    @ObservedObject var store: RepoStore
    var body: some View {
        List {
            if store.patchUsageHistory.isEmpty { Text("No patch history yet.").foregroundStyle(.secondary) }
            ForEach(store.patchUsageHistory.prefix(50)) { item in
                HStack { VStack(alignment: .leading) { Text(item.name).font(.headline); Text(item.action).font(.caption).foregroundStyle(.secondary) }; Spacer(); Text(item.success ? "OK" : "Failed").font(.caption.bold()).foregroundStyle(item.success ? .green : .red) }
            }
        }.navigationTitle("Patch History")
    }
}
