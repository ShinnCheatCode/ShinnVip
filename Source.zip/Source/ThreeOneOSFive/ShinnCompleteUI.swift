import SwiftUI
import UIKit
import PhotosUI

// MARK: - Shinn Command Center V6
// New visual shell. It reuses the existing server-backed LicenseManager,
// RepoStore and OwnerKeyManager so the backend remains the source of truth.

struct ShinnCompleteRootView: View {
    @EnvironmentObject private var store: RepoStore
    @EnvironmentObject private var license: LicenseManager
    @EnvironmentObject private var session: Session
    @State private var tab = 0
    @State private var destination: ShinnCompleteDestination?
    @StateObject private var personalization = ShinnPersonalizationStore()

    var body: some View {
        ZStack {
            ShinnCompleteBackground()
            TabView(selection: $tab) {
                ShinnCompleteHome(license: license, session: session, personalization: personalization, destination: $destination)
                    .tag(0)
                HomeView()
                    .tag(1)
                ShinnAIChatView()
                    .tag(2)
                ShinnCompleteAccount(license: license, session: session, destination: $destination)
                    .tag(3)
            }
            .tabViewStyle(.page(indexDisplayMode: .never))
        }
        .safeAreaInset(edge: .bottom, spacing: 0) {
            ShinnCompleteTabBar(tab: $tab, isOwner: session.role == .owner)
        }
        .sheet(item: $destination) { d in
            NavigationStack {
                switch d {
                case .owner: ShinnCompleteOwnerHub()
                case .personalize: ShinnCompletePersonalizationView(store: personalization)
                case .key: ActivateKeyView()
                case .history: ShinnCompleteHistoryView(title: "Patch History")
                case .downloadHistory: ShinnCompleteHistoryView(title: "Download History")
                case .settings: ShinnSettingsHubView()
                case .repository: RepositoryManagerView()
                case .about: AboutView()
                }
            }
            .preferredColorScheme(.dark)
        }
    }
}

private enum ShinnCompleteDestination: String, Identifiable {
    case owner, personalize, key, history, downloadHistory, settings, repository, about
    var id: String { rawValue }
}

private struct ShinnCompleteBackground: View {
    @State private var animate = false
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            LinearGradient(colors: [Color(red: 0.025, green: 0.035, blue: 0.075), .black, Color(red: 0.035, green: 0.015, blue: 0.055)], startPoint: .topLeading, endPoint: .bottomTrailing).ignoresSafeArea()
            Circle().fill(Color.cyan.opacity(0.12)).frame(width: 300).blur(radius: 80).offset(x: animate ? 120 : 50, y: -270)
            Circle().fill(Color.purple.opacity(0.10)).frame(width: 340).blur(radius: 90).offset(x: animate ? -130 : -60, y: 330)
        }
        .onAppear { withAnimation(.easeInOut(duration: 7).repeatForever(autoreverses: true)) { animate = true } }
    }
}

private struct ShinnCompleteHome: View {
    @ObservedObject var license: LicenseManager
    @ObservedObject var session: Session
    @ObservedObject var personalization: ShinnPersonalizationStore
    @Binding var destination: ShinnCompleteDestination?
    @EnvironmentObject private var store: RepoStore

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 18) {
                HStack(alignment: .center) {
                    VStack(alignment: .leading, spacing: 3) {
                        Text("SHINN COMMAND").font(.system(size: 13, weight: .black, design: .rounded)).tracking(2.2).foregroundStyle(.cyan)
                        Text("Control Center").font(.system(size: 31, weight: .black, design: .rounded)).foregroundStyle(.white)
                    }
                    Spacer()
                    Circle().fill(.ultraThinMaterial).frame(width: 46, height: 46).overlay(Image(systemName: session.role == .owner ? "crown.fill" : "person.fill").foregroundStyle(session.role == .owner ? .yellow : .cyan))
                }
                .padding(.top, 16)

                hero
                accessGrid
                statusCard
                quickTools
            }
            .padding(.horizontal, 16)
            .padding(.bottom, 20)
        }
    }

    private var hero: some View {
        ZStack(alignment: .bottomLeading) {
            if let bg = personalization.backgroundImage {
                Image(uiImage: bg).resizable().scaledToFill()
            } else {
                LinearGradient(colors: [.cyan.opacity(0.22), .purple.opacity(0.18), .black], startPoint: .topLeading, endPoint: .bottomTrailing)
            }
            Color.black.opacity(0.30)
            HStack(spacing: 16) {
                Group {
                    if let image = personalization.sImage { Image(uiImage: image).resizable().scaledToFill() }
                    else { Text("S").font(.system(size: 38, weight: .black, design: .rounded)) }
                }
                .frame(width: 76, height: 76)
                .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 22).stroke(Color.white.opacity(0.28), lineWidth: 1))
                VStack(alignment: .leading, spacing: 6) {
                    Text(license.holderName.isEmpty ? "ShinnCheat" : license.holderName).font(.title2.bold()).foregroundStyle(.white)
                    Text(session.role == .owner ? "OWNER ACCESS" : (license.boundRole?.uppercased() ?? "MEMBER")).font(.caption.bold()).foregroundStyle(.cyan)
                    if let expiry = license.expiresAt { Text("Expires \(expiry.formatted(date: .abbreviated, time: .shortened))").font(.caption2).foregroundStyle(.white.opacity(0.72)) }
                }
                Spacer()
            }
            .padding(18)
        }
        .frame(height: 190)
        .clipShape(RoundedRectangle(cornerRadius: 30, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 30).stroke(Color.white.opacity(0.12), lineWidth: 1))
    }

    private var accessGrid: some View {
        HStack(spacing: 12) {
            accessCard("Repo V1", store.isRepoV2Authorized ? "READY" : "FREE", "square.stack.3d.up.fill", .cyan)
            accessCard("Repo V2", store.isRepoV2Authorized ? "VIP OPEN" : "LOCKED", "crown.fill", store.isRepoV2Authorized ? .yellow : .orange)
        }
    }

    private func accessCard(_ title: String, _ value: String, _ icon: String, _ tint: Color) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Image(systemName: icon).foregroundStyle(tint)
            Text(title).font(.caption.bold()).foregroundStyle(.white.opacity(0.58))
            Text(value).font(.headline.bold()).foregroundStyle(.white)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(16)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 22))
        .overlay(RoundedRectangle(cornerRadius: 22).stroke(Color.white.opacity(0.08)))
    }

    private var statusCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack { Text("SESSION").font(.caption.bold()).tracking(1.5).foregroundStyle(.white.opacity(0.45)); Spacer(); Circle().fill(.green).frame(width: 8, height: 8); Text("ONLINE").font(.caption2.bold()).foregroundStyle(.green) }
            HStack {
                status("Key", license.savedLicenseKey.isEmpty ? "Not activated" : "Activated")
                status("Role", license.boundRole?.uppercased() ?? "MEMBER")
                status("Device", "1")
            }
        }
        .padding(18)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 24))
        .overlay(RoundedRectangle(cornerRadius: 24).stroke(Color.white.opacity(0.08)))
    }

    private func status(_ a: String, _ b: String) -> some View { VStack(alignment: .leading, spacing: 3) { Text(a).font(.caption2).foregroundStyle(.white.opacity(0.4)); Text(b).font(.caption.bold()).foregroundStyle(.white) }.frame(maxWidth: .infinity, alignment: .leading) }

    private var quickTools: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("QUICK TOOLS").font(.caption.bold()).tracking(1.5).foregroundStyle(.white.opacity(0.45))
            tool("Personalize", "Upload S, background and splash", "photo.on.rectangle", .cyan) { destination = .personalize }
            tool("Patch History", "Applied / restored activity", "clock.arrow.circlepath", .purple) { destination = .history }
            tool("Account", "Key and activation", "key.fill", .yellow) { destination = .key }
        }
    }

    private func tool(_ title: String, _ subtitle: String, _ icon: String, _ tint: Color, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 14) {
                Image(systemName: icon).frame(width: 42, height: 42).background(tint.opacity(0.14), in: RoundedRectangle(cornerRadius: 14)).foregroundStyle(tint)
                VStack(alignment: .leading, spacing: 3) { Text(title).font(.headline.bold()); Text(subtitle).font(.caption).foregroundStyle(.white.opacity(0.45)) }
                Spacer(); Image(systemName: "chevron.right").foregroundStyle(.white.opacity(0.25))
            }.padding(14).background(Color.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 20)).overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.white.opacity(0.06)))
        }.buttonStyle(.plain)
    }
}

private struct ShinnCompleteAccount: View {
    @ObservedObject var license: LicenseManager
    @ObservedObject var session: Session
    @Binding var destination: ShinnCompleteDestination?
    var body: some View {
        ScrollView { VStack(alignment: .leading, spacing: 16) {
            Text("ACCOUNT").font(.system(size: 13, weight: .black, design: .rounded)).tracking(2).foregroundStyle(.cyan).padding(.top, 18)
            Text(license.holderName.isEmpty ? "ShinnCheat" : license.holderName).font(.system(size: 34, weight: .black, design: .rounded))
            accountCard
            accountButton("Owner Control", "Create and manage keys", "crown.fill", .yellow) { destination = .owner }
                .opacity(session.role == .owner ? 1 : 0.45)
                .disabled(session.role != .owner)
            accountButton("Repository V2", "Grant or lock V2 access", "lock.doc.fill", .purple) { destination = .repository }
            accountButton("Settings", "Appearance and app preferences", "gearshape.fill", .cyan) { destination = .settings }
            accountButton("About", "ShinnCheat information", "info.circle.fill", .white) { destination = .about }
        }.padding(.horizontal, 16) }
    }
    private var accountCard: some View { VStack(alignment: .leading, spacing: 10) { Text("LICENSE").font(.caption.bold()).foregroundStyle(.white.opacity(0.45)); Text(license.savedLicenseKey.isEmpty ? "No active key" : license.savedLicenseKey).font(.headline.monospaced()).lineLimit(1); if let d = license.expiresAt { Text("Remaining: \(remainingKeyText(d))").font(.caption).foregroundStyle(.cyan) } }.padding(18).background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 24)).overlay(RoundedRectangle(cornerRadius: 24).stroke(Color.white.opacity(0.08))) }
    private func accountButton(_ title: String, _ sub: String, _ icon: String, _ tint: Color, action: @escaping () -> Void) -> some View { Button(action: action) { HStack { Image(systemName: icon).foregroundStyle(tint).frame(width: 42, height: 42).background(tint.opacity(0.12), in: RoundedRectangle(cornerRadius: 14)); VStack(alignment: .leading) { Text(title).font(.headline.bold()); Text(sub).font(.caption).foregroundStyle(.white.opacity(0.42)) }; Spacer(); Image(systemName: "chevron.right").foregroundStyle(.white.opacity(0.25)) }.padding(14).background(Color.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 20)) }.buttonStyle(.plain) }
}

private struct ShinnCompleteTabBar: View {
    @Binding var tab: Int
    let isOwner: Bool
    let items = [("house.fill", "Home"), ("square.grid.2x2.fill", "Patch"), ("sparkles", "AI"), ("person.crop.circle.fill", "Account")]
    var body: some View { HStack { ForEach(items.indices, id: \.self) { i in Button { withAnimation(.easeInOut(duration: 0.2)) { tab = i } } label: { VStack(spacing: 4) { Image(systemName: items[i].0).font(.system(size: 17, weight: .bold)); Text(items[i].1).font(.system(size: 9, weight: .bold)) }.foregroundStyle(tab == i ? .cyan : .white.opacity(0.42)).frame(maxWidth: .infinity).padding(.vertical, 9).background(tab == i ? Color.cyan.opacity(0.10) : .clear, in: RoundedRectangle(cornerRadius: 15)) }.buttonStyle(.plain) } }.padding(8).background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 24)).overlay(RoundedRectangle(cornerRadius: 24).stroke(Color.white.opacity(0.10))).padding(.horizontal, 12).padding(.bottom, 6) }
}

// MARK: Owner control
private struct ShinnCompleteOwnerHub: View {
    @StateObject private var manager = OwnerKeyManager()
    @State private var command = "/keys"
    @State private var showCreate = false
    var body: some View {
        ScrollView { VStack(alignment: .leading, spacing: 16) {
            HStack { VStack(alignment: .leading) { Text("OWNER CONTROL").font(.caption.bold()).tracking(2).foregroundStyle(.yellow); Text("Key Command Center").font(.largeTitle.bold()) }; Spacer(); Image(systemName: "crown.fill").foregroundStyle(.yellow).font(.title) }
            stats
            HStack(spacing: 10) { ownerAction("Create Key", "plus", .cyan) { showCreate = true }; ownerAction("Refresh", "arrow.clockwise", .purple) { Task { await manager.listKeys() } } }
            Text("KEYS").font(.caption.bold()).tracking(1.5).foregroundStyle(.white.opacity(0.45))
            ForEach(manager.keys) { row in keyRow(row) }
            Text("BOT COMMANDS").font(.caption.bold()).tracking(1.5).foregroundStyle(.white.opacity(0.45)).padding(.top, 8)
            commandBox
        }.padding(16) }
        .navigationTitle("Owner")
        .sheet(isPresented: $showCreate) { NavigationStack { ShinnCompleteCreateKey(manager: manager) } }
        .task { await manager.listKeys() }
    }
    private var stats: some View { HStack { stat("TOTAL", "\(manager.keys.count)"); stat("ACTIVE", "\(manager.keys.filter { expiry($0.expires_at) > Date() }.count)"); stat("VIP", "\(manager.keys.filter { $0.is_vip == true }.count)") }.padding(16).background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 22)) }
    private func stat(_ a: String, _ b: String) -> some View { VStack(alignment: .leading) { Text(a).font(.caption2).foregroundStyle(.white.opacity(0.4)); Text(b).font(.title3.bold()) }.frame(maxWidth: .infinity, alignment: .leading) }
    private func ownerAction(_ t: String, _ icon: String, _ c: Color, action: @escaping () -> Void) -> some View { Button(action: action) { Label(t, systemImage: icon).font(.headline.bold()).frame(maxWidth: .infinity).padding(14).background(c.opacity(0.13), in: RoundedRectangle(cornerRadius: 18)).overlay(RoundedRectangle(cornerRadius: 18).stroke(c.opacity(0.3))) }.buttonStyle(.plain) }
    private func keyRow(_ row: ShinnKeyRow) -> some View { VStack(alignment: .leading, spacing: 8) { HStack { Text(row.key).font(.headline.monospaced()); Spacer(); Text(row.role?.uppercased() ?? "MEMBER").font(.caption2.bold()).foregroundStyle(.cyan) }; Text(row.label ?? "No username").font(.caption).foregroundStyle(.white.opacity(0.55)); HStack { Text(formatKeyExpiry(row.expires_at)).font(.caption2); Spacer(); let exp = expiry(row.expires_at); Text(exp > Date() ? remainingKeyText(exp) : "EXPIRED").font(.caption2.bold()).foregroundStyle(exp > Date() ? .green : .red) }; HStack { Button("Delete") { Task { await manager.deleteKey(row.key) } }.font(.caption.bold()).foregroundStyle(.red); Spacer(); Button("Lock V2") { command = "/lockv2 \(row.key)" }.font(.caption.bold()).foregroundStyle(.orange) } }.padding(15).background(Color.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 20)).overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.white.opacity(0.07))) }
    private var commandBox: some View { VStack(alignment: .leading, spacing: 10) { Picker("Command", selection: $command) { Text("/keys").tag("/keys"); Text("/createkey").tag("/createkey"); Text("/deletekey").tag("/deletekey"); Text("/lockkey").tag("/lockkey"); Text("/grantv2").tag("/grantv2") }.pickerStyle(.menu); Text(command).font(.system(.body, design: .monospaced)).foregroundStyle(.cyan).textSelection(.enabled); Button { UIPasteboard.general.string = command } label: { Label("Copy command", systemImage: "doc.on.doc").frame(maxWidth: .infinity).padding(11).background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 14)) }.buttonStyle(.plain) }.padding(15).background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 20)) }
    private func expiry(_ raw: String?) -> Date { guard let raw, let d = ISO8601DateFormatter().date(from: raw) else { return .distantPast }; return d }
}

private struct ShinnCompleteCreateKey: View {
    @ObservedObject var manager: OwnerKeyManager
    @Environment(\.dismiss) private var dismiss
    @State private var username = ""
    var body: some View { Form { Section("Identity") { TextField("Username / label", text: $username); Picker("Role", selection: $manager.selectedRole) { Text("Member").tag("member"); Text("VIP").tag("vip"); Text("Admin").tag("admin") } }; Section("Duration") { Stepper("Days: \(manager.selectedDays)", value: $manager.selectedDays, in: 1...3650); Toggle("1 year / unlimited devices", isOn: $manager.lifetime) }; Section { Button { manager.keyLabel = username; Task { await manager.createKey(); dismiss() } } label: { Text("Create key").frame(maxWidth: .infinity) } } }.navigationTitle("Create Key") }
}

// MARK: V6 compatibility views
private struct ShinnCompletePersonalizationView: View {
    @ObservedObject var store: ShinnPersonalizationStore
    @State private var picker: PhotosPickerItem?
    @State private var target: Int = 0
    var body: some View {
        Form {
            Section("Personalization") {
                Picker("Image", selection: $target) {
                    Text("S image").tag(0); Text("Background").tag(1); Text("Splash").tag(2)
                }.pickerStyle(.segmented)
                PhotosPicker(selection: $picker, matching: .images) { Label("Choose image", systemImage: "photo") }
                Button("Reset") {
                    let keys = ["shinn.custom.sImage", "shinn.custom.background", "shinn.custom.splash"]
                    store.save(nil, key: keys[target])
                }
            }
        }
        .navigationTitle("Personalize")
        .onChange(of: picker) { item in
            guard let item else { return }
            Task {
                if let data = try? await item.loadTransferable(type: Data.self), let image = UIImage(data: data) {
                    let keys = ["shinn.custom.sImage", "shinn.custom.background", "shinn.custom.splash"]
                    store.save(image, key: keys[target])
                }
            }
        }
    }
}

private struct ShinnCompleteHistoryView: View {
    let title: String
    var body: some View {
        List {
            ContentUnavailableView(title, systemImage: "clock.arrow.circlepath", description: Text("No history entries are available yet."))
        }.navigationTitle(title)
    }
}

// MARK: Activation gate
private struct ShinnCompleteActivationGate: View {
    @EnvironmentObject private var license: LicenseManager
    @State private var key = "ShinnCheat"
    @State private var busy = false
    @State private var message = ""
    @FocusState private var focused: Bool

    var body: some View {
        ZStack {
            ShinnCompleteBackground()
            ScrollView(showsIndicators: false) {
                VStack(spacing: 22) {
                    Spacer(minLength: 70)
                    logo
                    VStack(spacing: 7) {
                        Text("SHINNCHEAT")
                            .font(.system(size: 31, weight: .black, design: .rounded))
                        Text("Secure Command Center")
                            .font(.subheadline)
                            .foregroundStyle(.white.opacity(0.45))
                    }
                    activationCard
                    Text("Default access: ShinnCheat • 1 year • unlimited devices\nVIP access is controlled by the server and Owner permissions.")
                        .font(.caption2)
                        .multilineTextAlignment(.center)
                        .foregroundStyle(.white.opacity(0.35))
                }
                .padding(.horizontal, 18)
            }
        }
    }

    @ViewBuilder private var logo: some View {
        if let image = HeroBanner.image {
            Image(uiImage: image)
                .resizable().scaledToFill()
                .frame(width: 112, height: 112)
                .clipShape(RoundedRectangle(cornerRadius: 30))
                .overlay(RoundedRectangle(cornerRadius: 30).stroke(Color.white.opacity(0.18)))
        } else {
            Text("S")
                .font(.system(size: 58, weight: .black, design: .rounded))
                .frame(width: 112, height: 112)
                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 30))
                .overlay(RoundedRectangle(cornerRadius: 30).stroke(Color.cyan.opacity(0.35)))
        }
    }

    private var activationCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("ACTIVATION REQUIRED")
                .font(.caption.bold())
                .tracking(1.5)
                .foregroundStyle(.cyan)
            TextField("Enter activation key", text: $key)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled(true)
                .focused($focused)
                .padding(15)
                .background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 17))
                .overlay(RoundedRectangle(cornerRadius: 17).stroke(Color.white.opacity(0.10)))
            Text("The app verifies the key before opening the command center. Repo V2 requires a VIP grant.")
                .font(.caption)
                .foregroundStyle(.white.opacity(0.42))
            if !message.isEmpty {
                Text(message).font(.caption.bold()).foregroundStyle(.orange)
            }
            Button { Task { await activate() } } label: {
                HStack {
                    if busy { ProgressView().tint(.white) }
                    Text(busy ? "VERIFYING…" : "VERIFY & ENTER").font(.headline.bold())
                }
                .frame(maxWidth: .infinity)
                .padding(15)
                .background(
                    LinearGradient(colors: [.cyan.opacity(0.9), .blue.opacity(0.75)], startPoint: .leading, endPoint: .trailing),
                    in: RoundedRectangle(cornerRadius: 17)
                )
            }
            .buttonStyle(.plain)
            .disabled(busy)
        }
        .padding(20)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 28))
        .overlay(RoundedRectangle(cornerRadius: 28).stroke(Color.white.opacity(0.10)))
    }

    private func activate() async {
        focused = false
        busy = true
        message = ""
        let ok = await license.activate(key: key, language: .en)
        busy = false
        if !ok { message = license.lastError ?? "Activation failed" }
    }
}
