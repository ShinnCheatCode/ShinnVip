import SwiftUI
import UIKit
import PhotosUI


// MARK: - Nova/Nexus UI compatibility primitives

/// Navigation destinations used by the redesigned UI. These are UI-only routes;
/// existing feature logic remains owned by the original views/services.
enum ShinnModernDestination: Hashable {
    case core
    case library
    case premium
    case key
    case repository
    case history
    case files
    case settings
    case terms
    case about
    case ai
    case admin
    case member
    case owner
    case support
    case community
    case system
    case applied
    case cleanup
    case patchBuilder
    case patchProjects
}

private enum ShinnModernPalette {
    static let blue = Color(red: 0.22, green: 0.48, blue: 1.00)
    static let cyan = Color(red: 0.18, green: 0.88, blue: 1.00)
    static let purple = Color(red: 0.62, green: 0.28, blue: 1.00)
    static let green = Color(red: 0.16, green: 0.88, blue: 0.60)
    static let card = Color.white.opacity(0.075)
}

private struct ShinnModernBackground: View {
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            LinearGradient(
                colors: [
                    ShinnModernPalette.purple.opacity(0.12),
                    Color.black,
                    ShinnModernPalette.blue.opacity(0.08)
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            ).ignoresSafeArea()
        }
    }
}

private struct ShinnModernCard<Content: View>: View {
    let radius: CGFloat
    let stroke: Color
    @ViewBuilder let content: () -> Content

    init(radius: CGFloat = 20, stroke: Color = Color.white.opacity(0.08), @ViewBuilder content: @escaping () -> Content) {
        self.radius = radius
        self.stroke = stroke
        self.content = content
    }

    var body: some View {
        content()
            .padding(14)
            .background(
                RoundedRectangle(cornerRadius: radius, style: .continuous)
                    .fill(ShinnModernPalette.card)
                    .overlay(RoundedRectangle(cornerRadius: radius, style: .continuous).stroke(stroke, lineWidth: 1))
            )
    }
}

private struct ShinnModernIcon: View {
    let systemName: String
    let tint: Color
    let size: CGFloat

    var body: some View {
        Image(systemName: systemName)
            .font(.system(size: max(14, size * 0.42), weight: .bold))
            .foregroundStyle(tint)
            .frame(width: size, height: size)
            .background(tint.opacity(0.13), in: RoundedRectangle(cornerRadius: size * 0.28, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: size * 0.28, style: .continuous).stroke(tint.opacity(0.25), lineWidth: 1))
    }
}

private struct ShinnModernPill: View {
    let text: String
    let tint: Color

    var body: some View {
        Text(text)
            .font(.system(size: 10, weight: .bold, design: .rounded))
            .foregroundStyle(tint)
            .padding(.horizontal, 9)
            .padding(.vertical, 5)
            .background(tint.opacity(0.13), in: Capsule())
            .overlay(Capsule().stroke(tint.opacity(0.28), lineWidth: 1))
    }
}

// MARK: - SHINN // NEXUS UI
// A new visual shell. Existing services, licensing, repositories, patch engine,
// DNS controls, history, settings and AI are intentionally reused.

private enum NexusTab: Int, CaseIterable {
    case core, library, ai, system
    var title: String {
        switch self { case .core: "Nexus"; case .library: "Library"; case .ai: "Shinn AI"; case .system: "System" }
    }
    var icon: String {
        switch self { case .core: "circle.hexagongrid.fill"; case .library: "square.stack.3d.up.fill"; case .ai: "sparkles"; case .system: "slider.horizontal.3.square" }
    }
}

private enum NexusDestination: String, Identifiable {
    case key, premium, settings, files, community, repository, history, terms, about, support, patchBuilder, patchProjects, cleanup
    var id: String { rawValue }
}

private enum NexusColor {
    static let void = Color(red: 0.008, green: 0.010, blue: 0.018)
    static let blue = Color(red: 0.12, green: 0.54, blue: 1.0)
    static let cyan = Color(red: 0.08, green: 0.92, blue: 1.0)
    static let purple = Color(red: 0.58, green: 0.20, blue: 1.0)
    static let magenta = Color(red: 1.0, green: 0.16, blue: 0.72)
    static let green = Color(red: 0.18, green: 0.95, blue: 0.64)
}

private struct NexusBackdrop: View {
    @State private var animate = false
    var body: some View {
        ZStack {
            NexusColor.void.ignoresSafeArea()
            Circle().fill(NexusColor.blue.opacity(0.13)).frame(width: 360).blur(radius: 100)
                .offset(x: animate ? 145 : -125, y: -290)
            Circle().fill(NexusColor.purple.opacity(0.12)).frame(width: 330).blur(radius: 110)
                .offset(x: animate ? -130 : 120, y: 270)
            LinearGradient(colors: [.clear, NexusColor.blue.opacity(0.035), .clear], startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()
            NexusScanlines()
        }
        .animation(.easeInOut(duration: 8).repeatForever(autoreverses: true), value: animate)
        .onAppear { animate = true }
    }
}

private struct NexusScanlines: View {
    var body: some View {
        Canvas { ctx, size in
            var p = Path()
            let gap: CGFloat = 34
            var y: CGFloat = 0
            while y < size.height {
                p.move(to: CGPoint(x: 0, y: y)); p.addLine(to: CGPoint(x: size.width, y: y)); y += gap
            }
            ctx.stroke(p, with: .color(.white.opacity(0.014)), lineWidth: 0.5)
        }
        .ignoresSafeArea()
        .allowsHitTesting(false)
    }
}

private struct NexusPanel<Content: View>: View {
    var radius: CGFloat = 24
    @ViewBuilder var content: Content
    var body: some View {
        content
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: radius, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: radius).stroke(
                LinearGradient(colors: [NexusColor.blue.opacity(0.42), .white.opacity(0.06), NexusColor.purple.opacity(0.35)], startPoint: .topLeading, endPoint: .bottomTrailing), lineWidth: 0.8))
    }
}

private struct NexusOrb: View {
    var active: Bool
    @State private var spin = false
    var body: some View {
        ZStack {
            Circle().fill((active ? NexusColor.cyan : NexusColor.purple).opacity(0.15)).blur(radius: 24)
            Circle().stroke((active ? NexusColor.cyan : NexusColor.purple).opacity(0.25), lineWidth: 1)
                .padding(12).rotationEffect(.degrees(spin ? 360 : 0))
            Circle().stroke(NexusColor.blue.opacity(0.35), lineWidth: 1).padding(28)
            Image(systemName: active ? "bolt.fill" : "crown.fill")
                .font(.system(size: 28, weight: .black))
                .foregroundStyle(.white)
                .shadow(color: (active ? NexusColor.cyan : NexusColor.purple), radius: 16)
        }
        .onAppear { spin = true }
        .animation(.linear(duration: 9).repeatForever(autoreverses: false), value: spin)
    }
}

struct ShinnNovaRootView: View {
    @EnvironmentObject private var store: RepoStore
    @EnvironmentObject private var license: LicenseManager
    @EnvironmentObject private var session: Session
    @State private var tab: NexusTab = .core
    @State private var destination: NexusDestination?
    @State private var showLaunch = true

    var body: some View {
        ZStack {
            NexusBackdrop()
            Group {
                switch tab {
                case .core: NexusCoreView(destination: $destination, tab: $tab)
                case .library: NexusPatchLibrary()
                case .ai: NexusAIView()
                case .system: NexusSystemView(destination: $destination)
                }
            }
            .transition(.opacity)
            if showLaunch {
                NexusLaunchView()
                    .transition(.opacity)
                    .zIndex(100)
            }
        }
        .safeAreaInset(edge: .bottom, spacing: 0) {
            NexusDock(selection: $tab)
                .opacity(showLaunch ? 0 : 1)
                .allowsHitTesting(!showLaunch)
                .padding(.horizontal, 10)
                .padding(.bottom, 5)
        }
        .sheet(item: $destination) { item in
            NavigationStack {
                switch item {
                case .key: ActivateKeyView()
                case .premium: PremiumRepoView()
                case .settings: ShinnSettingsHubView()
                case .files: FilesTabSwitcherView(session: .constant(FilesTabSession()))
                case .community: CommunityView()
                case .repository: RepositoryManagerView()
                case .history: ShinnModernDownloadHistoryView()
                case .terms: ShinnModernTermsView()
                case .about: ShinnAboutView()
                case .support: SupportView()
                case .patchBuilder: PatchBuilderView()
                case .patchProjects: session.role == .owner ? AnyView(PatchProjectsView()) : AnyView(PatchOwnerOnlyView())
                case .cleanup: PhoneCleanupView()
                }
            }
            .preferredColorScheme(.dark)
        }
        .task {
            try? await Task.sleep(nanoseconds: 1_850_000_000)
            withAnimation(.easeOut(duration: 0.55)) { showLaunch = false }
        }
    }
}

private struct NexusLaunchView: View {
    @State private var pulse = false
    @State private var sweep = false
    var body: some View {
        ZStack {
            NexusBackdrop()
            Circle().stroke(NexusColor.blue.opacity(0.18), lineWidth: 1).frame(width: 270).scaleEffect(sweep ? 1.3 : 0.7).opacity(sweep ? 0 : 1)
                .animation(.easeOut(duration: 1.7).repeatForever(autoreverses: false), value: sweep)
            Circle().stroke(NexusColor.purple.opacity(0.28), lineWidth: 1).frame(width: 195).rotationEffect(.degrees(pulse ? 360 : 0))
                .animation(.linear(duration: 5).repeatForever(autoreverses: false), value: pulse)
            VStack(spacing: 16) {
                ZStack {
                    Circle().fill(NexusColor.purple.opacity(0.24)).frame(width: 132).blur(radius: 30)
                    Image("ShinnSplashArt").resizable().scaledToFill().frame(width: 118, height: 118).clipShape(Circle())
                        .overlay(Circle().stroke(.white.opacity(0.42), lineWidth: 1))
                        .shadow(color: NexusColor.purple.opacity(0.75), radius: 25)
                }
                Text("SHINN").font(.system(size: 44, weight: .black, design: .rounded)).tracking(9).foregroundStyle(.white)
                Text("N E X U S").font(.system(size: 10, weight: .bold, design: .monospaced)).tracking(6).foregroundStyle(NexusColor.cyan)
                HStack(spacing: 7) { Circle().fill(NexusColor.green).frame(width: 5); Text("INITIALIZING CORE").font(.system(size: 9, weight: .bold, design: .monospaced)).foregroundStyle(.white.opacity(0.48)) }
            }
        }
        .onAppear { pulse = true; sweep = true }
    }
}

private struct NexusCoreView: View {
    @EnvironmentObject private var store: RepoStore
    @EnvironmentObject private var license: LicenseManager
    @EnvironmentObject private var session: Session
    @Binding var destination: NexusDestination?
    @Binding var tab: NexusTab
    @State private var orbit = false

    private var role: String {
        switch session.role { case .owner: "OWNER"; case .admin: "ADMIN"; case .member: "MEMBER"; case nil: "GUEST" }
    }

    var body: some View {
        GeometryReader { geo in
            ScrollView(showsIndicators: false) {
                VStack(spacing: 18) {
                    topBar
                    nexusHero(width: min(geo.size.width - 28, 430))
                    telemetry
                    actionDeck
                    liveStrip
                }
                .frame(maxWidth: 520)
                .frame(maxWidth: .infinity)
                .padding(.horizontal, 14)
                .padding(.top, 10)
                .padding(.bottom, 22)
            }
        }
    }

    private var topBar: some View {
        HStack(spacing: 10) {
            Image("ShinnAvatarArt").resizable().scaledToFill().frame(width: 34, height: 34).clipShape(Circle())
                .overlay(Circle().stroke(NexusColor.cyan.opacity(0.55), lineWidth: 0.7))
            VStack(alignment: .leading, spacing: 1) {
                Text("SHINN NEXUS").font(.system(size: 17, weight: .black, design: .rounded)).tracking(1.2)
                Text("CONTROL LAYER 5.0").font(.system(size: 8, weight: .bold, design: .monospaced)).foregroundStyle(NexusColor.cyan).tracking(1.5)
            }
            Spacer()
            Button { destination = .settings } label: { Image(systemName: "gearshape.2.fill").font(.system(size: 15, weight: .bold)).frame(width: 38, height: 38).background(.white.opacity(0.06), in: Circle()) }
                .buttonStyle(.plain)
        }.foregroundStyle(.white)
    }

    private func nexusHero(width: CGFloat) -> some View {
        NexusPanel(radius: 34) {
            ZStack {
                Image("ShinnHeroArt").resizable().scaledToFill().frame(height: 245).clipped().opacity(0.52)
                LinearGradient(colors: [.clear, NexusColor.void.opacity(0.20), NexusColor.void.opacity(0.98)], startPoint: .top, endPoint: .bottom)
                HStack(spacing: 16) {
                    NexusOrb(active: license.isActivated).frame(width: 122, height: 122).rotation3DEffect(.degrees(orbit ? 360 : 0), axis: (x: 0, y: 1, z: 0))
                    VStack(alignment: .leading, spacing: 8) {
                        Text(license.isActivated ? "CORE ONLINE" : "CORE STANDBY").font(.system(size: 11, weight: .black, design: .monospaced)).foregroundStyle(license.isActivated ? NexusColor.green : NexusColor.cyan)
                        Text(license.isActivated ? "Everything is ready." : "Welcome to the Nexus.").font(.system(size: 22, weight: .black, design: .rounded)).minimumScaleFactor(0.75)
                        Text(license.isActivated && !license.holderName.isEmpty ? license.holderName : "A new control layer for your Shinn workspace.").font(.system(size: 11, weight: .medium)).foregroundStyle(.white.opacity(0.5)).lineLimit(2)
                        HStack(spacing: 7) { NexusBadge(text: role); NexusBadge(text: store.usingRepoV2 ? "REPO V2" : "REPO V1") }
                    }
                }
                .padding(18)
            }
            .frame(height: 245)
            .clipShape(RoundedRectangle(cornerRadius: 34, style: .continuous))
        }
        .onAppear { orbit = true }
    }

    private var telemetry: some View {
        HStack(spacing: 8) {
            NexusMetric(icon: "square.stack.3d.up.fill", title: "PATCH", value: "\(store.packages.count)", tint: NexusColor.blue)
            NexusMetric(icon: "server.rack", title: "REPO", value: store.usingRepoV2 ? "V2" : "V1", tint: NexusColor.purple)
            NexusMetric(icon: "waveform.path.ecg", title: "STATE", value: license.isActivated ? "LIVE" : "FREE", tint: NexusColor.green)
        }
    }

    private var actionDeck: some View {
        VStack(alignment: .leading, spacing: 10) {
            NexusHeading(kicker: "COMMAND DECK", title: "Choose a module")
            LazyVGrid(columns: [GridItem(.flexible(), spacing: 9), GridItem(.flexible(), spacing: 9)], spacing: 9) {
                NexusAction(title: "Patch Library", detail: "Apply / restore", icon: "bolt.shield.fill", tint: NexusColor.blue) { tab = .library }
                NexusAction(title: "DNS Premium", detail: "V1 / V2 control", icon: "network", tint: NexusColor.cyan) { destination = .premium }
                NexusAction(title: "Shinn AI", detail: "Assistant core", icon: "sparkles", tint: NexusColor.magenta) { tab = .ai }
                NexusAction(title: "Key Center", detail: license.isActivated ? "Session active" : "Activate key", icon: "key.fill", tint: NexusColor.purple) { destination = .key }
            }
        }
    }

    private var liveStrip: some View {
        Button { destination = .repository } label: {
            NexusPanel(radius: 18) {
                HStack(spacing: 11) {
                    Circle().fill(NexusColor.green).frame(width: 7, height: 7).shadow(color: NexusColor.green, radius: 7)
                    VStack(alignment: .leading, spacing: 2) { Text("REPOSITORY LINK").font(.system(size: 9, weight: .black, design: .monospaced)).foregroundStyle(NexusColor.green); Text("Tap to inspect the active source").font(.system(size: 10, weight: .medium)).foregroundStyle(.white.opacity(0.46)) }
                    Spacer(); Image(systemName: "arrow.up.right").foregroundStyle(.white.opacity(0.45))
                }.padding(13)
            }
        }.buttonStyle(.plain)
    }
}

private struct NexusPatchLibrary: View {
    @EnvironmentObject private var store: RepoStore
    @State private var selected = Set<String>()
    @State private var filter = "ALL"
    @State private var search = ""
    @State private var busy = false
    @State private var message: String?

    private var filtered: [RepoPackage] {
        store.packages.filter { pkg in
            let categoryOK = filter == "ALL" || (pkg.category ?? "").localizedCaseInsensitiveContains(filter)
            let q = search.trimmingCharacters(in: .whitespacesAndNewlines)
            let searchOK = q.isEmpty || pkg.name.localizedCaseInsensitiveContains(q) || (pkg.summary ?? "").localizedCaseInsensitiveContains(q)
            return categoryOK && searchOK
        }
    }

    var body: some View {
        VStack(spacing: 0) {
            libraryHeader
            ScrollView(showsIndicators: false) {
                VStack(spacing: 10) {
                    filterBar
                    if filtered.isEmpty { NexusEmptyState(title: "No modules", subtitle: "Refresh the repository to load packages.") }
                    else { ForEach(filtered.prefix(80)) { pkg in NexusPatchRow(pkg: pkg, selected: selected.contains(pkg.id), toggle: toggle, action: applyOne) } }
                }.padding(.horizontal, 14).padding(.bottom, 24)
            }
            if !selected.isEmpty { applyDock }
        }
        .task { if store.packages.isEmpty { await store.refresh() } }
        .alert("Patch", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) { Button("OK", role: .cancel) {} } message: { Text(message ?? "") }
    }

    private var libraryHeader: some View {
        HStack(alignment: .bottom) {
            VStack(alignment: .leading, spacing: 4) {
                Text("PATCH LIBRARY").font(.system(size: 25, weight: .black, design: .rounded)).tracking(-0.5)
                Text("\(store.packages.count) modules · \(store.usingRepoV2 ? "V2" : "V1") source").font(.system(size: 10, weight: .bold, design: .monospaced)).foregroundStyle(NexusColor.cyan)
            }
            Spacer()
            Button { Task { await store.refresh() } } label: { Image(systemName: "arrow.clockwise").font(.system(size: 15, weight: .bold)).frame(width: 40, height: 40).background(.white.opacity(0.06), in: Circle()) }.buttonStyle(.plain)
        }.foregroundStyle(.white).padding(.horizontal, 16).padding(.top, 14).padding(.bottom, 10)
    }

    private var filterBar: some View {
        VStack(spacing: 9) {
            HStack { Image(systemName: "magnifyingglass"); TextField("Search modules", text: $search).textInputAutocapitalization(.never) }.font(.system(size: 12, weight: .medium)).foregroundStyle(.white.opacity(0.72)).padding(12).background(.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 16))
            ScrollView(.horizontal, showsIndicators: false) { HStack(spacing: 7) { ForEach(["ALL", "GAME", "MENU", "ESP"], id: \.self) { f in Button(f) { filter = f }.font(.system(size: 9, weight: .black, design: .monospaced)).foregroundStyle(filter == f ? .black : .white.opacity(0.55)).padding(.horizontal, 13).padding(.vertical, 8).background(filter == f ? NexusColor.cyan : .white.opacity(0.055), in: Capsule()).buttonStyle(.plain) } } }
        }
    }

    private var applyDock: some View {
        HStack(spacing: 10) {
            VStack(alignment: .leading, spacing: 2) { Text("\(selected.count) SELECTED").font(.system(size: 9, weight: .black, design: .monospaced)); Text("Ready for deployment").font(.system(size: 9, weight: .medium)).foregroundStyle(.white.opacity(0.42)) }
            Spacer()
            Button { Task { busy = true; let targets = store.packages.filter { selected.contains($0.id) }; let result = await store.applyMultiple(targets); await MainActor.run { busy = false; selected.removeAll(); message = store.lastApplyMessage ?? (result.fail.isEmpty ? "Patch applied." : "Some modules were rejected.") } } } label: { if busy { ProgressView().tint(.black) } else { Label("DEPLOY", systemImage: "bolt.fill") } }.font(.system(size: 11, weight: .black, design: .rounded)).foregroundStyle(.black).padding(.horizontal, 18).frame(minHeight: 42).background(NexusColor.cyan, in: Capsule()).disabled(busy)
        }.padding(12).background(.ultraThinMaterial).overlay(Rectangle().fill(.white.opacity(0.06)).frame(height: 0.5), alignment: .top)
    }

    private func toggle(_ pkg: RepoPackage) { if selected.contains(pkg.id) { selected.remove(pkg.id) } else { selected.insert(pkg.id) } }
    private func applyOne(_ pkg: RepoPackage) { Task { busy = true; await store.apply(pkg, openGame: true); await MainActor.run { busy = false; message = store.lastApplyMessage } } }
}

private struct NexusPatchRow: View {
    @EnvironmentObject private var store: RepoStore
    let pkg: RepoPackage
    let selected: Bool
    let toggle: (RepoPackage) -> Void
    let action: (RepoPackage) -> Void
    private var applied: Bool { if case .applied = store.patchState(for: pkg) { return true }; return false }
    var body: some View {
        HStack(spacing: 11) {
            ZStack {
                RoundedRectangle(cornerRadius: 14).fill(selected ? NexusColor.cyan.opacity(0.16) : .white.opacity(0.05))
                Image(systemName: applied ? "checkmark.seal.fill" : "cube.fill").font(.system(size: 16, weight: .bold)).foregroundStyle(applied ? NexusColor.green : NexusColor.cyan)
            }.frame(width: 46, height: 46)
            VStack(alignment: .leading, spacing: 3) {
                Text(pkg.name).font(.system(size: 13, weight: .bold, design: .rounded)).lineLimit(1)
                Text([pkg.category, pkg.version].compactMap { $0 }.joined(separator: " · ")).font(.system(size: 9, weight: .medium, design: .monospaced)).foregroundStyle(.white.opacity(0.4)).lineLimit(1)
            }
            Spacer()
            Button { toggle(pkg) } label: { Image(systemName: selected ? "checkmark.circle.fill" : "circle").font(.system(size: 20, weight: .bold)).foregroundStyle(selected ? NexusColor.cyan : .white.opacity(0.22)) }.buttonStyle(.plain)
            Button {
                if applied {
                    Task { await store.restore(pkg) }
                } else {
                    action(pkg)
                }
            } label: {
                Image(systemName: applied ? "arrow.uturn.backward" : "play.fill")
                    .font(.system(size: 11, weight: .black))
                    .frame(width: 34, height: 34)
                    .background(applied ? NexusColor.purple.opacity(0.25) : NexusColor.blue.opacity(0.22), in: Circle())
            }
            .buttonStyle(.plain)
        }.foregroundStyle(.white).padding(10).background(.white.opacity(0.035), in: RoundedRectangle(cornerRadius: 20)).overlay(RoundedRectangle(cornerRadius: 20).stroke(selected ? NexusColor.cyan.opacity(0.55) : .white.opacity(0.06), lineWidth: 0.8))
    }
}

private struct NexusAIView: View {
    @State private var showAssistant = false
    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 16) {
                HStack { VStack(alignment: .leading, spacing: 4) { Text("SHINN AI").font(.system(size: 27, weight: .black, design: .rounded)); Text("INTELLIGENCE LAYER").font(.system(size: 9, weight: .black, design: .monospaced)).foregroundStyle(NexusColor.magenta) }; Spacer(); Circle().fill(NexusColor.green).frame(width: 7).shadow(color: NexusColor.green, radius: 8) }.foregroundStyle(.white)
                NexusPanel(radius: 34) {
                    VStack(spacing: 16) {
                        Image("ShinnAIArt").resizable().scaledToFill().frame(height: 250).clipped().clipShape(RoundedRectangle(cornerRadius: 28))
                        VStack(spacing: 7) { Text("Your Shinn intelligence layer").font(.system(size: 20, weight: .black, design: .rounded)); Text("Ask about the app, repository, key status, settings or how to use an available feature.").font(.system(size: 11, weight: .medium)).foregroundStyle(.white.opacity(0.48)).multilineTextAlignment(.center) }
                        Button { showAssistant = true } label: { Label("OPEN SHINN AI", systemImage: "sparkles") }.font(.system(size: 11, weight: .black, design: .rounded)).foregroundStyle(.black).frame(maxWidth: .infinity, minHeight: 48).background(LinearGradient(colors: [NexusColor.cyan, NexusColor.blue], startPoint: .leading, endPoint: .trailing), in: Capsule())
                    }.padding(14)
                }
                HStack(spacing: 8) { NexusAIChip(icon: "key.fill", text: "Key status"); NexusAIChip(icon: "server.rack", text: "Repository"); NexusAIChip(icon: "gearshape.fill", text: "Settings") }
            }.frame(maxWidth: 520).frame(maxWidth: .infinity).padding(14).foregroundStyle(.white)
        }
        .sheet(isPresented: $showAssistant) { NavigationStack { ShinnAIChatView() }.preferredColorScheme(.dark) }
    }
}

private struct NexusSystemView: View {
    @EnvironmentObject private var license: LicenseManager
    @EnvironmentObject private var session: Session
    @Binding var destination: NexusDestination?
    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 12) {
                HStack { VStack(alignment: .leading, spacing: 4) { Text("CONTROL ROOM").font(.system(size: 26, weight: .black, design: .rounded)); Text("SYSTEM · ACCOUNT · TOOLS").font(.system(size: 9, weight: .black, design: .monospaced)).foregroundStyle(NexusColor.cyan) }; Spacer() }.foregroundStyle(.white)
                NexusPanel(radius: 26) { VStack(alignment: .leading, spacing: 10) { Text("SESSION").font(.system(size: 9, weight: .black, design: .monospaced)).foregroundStyle(NexusColor.green); HStack { NexusSystemValue(label: "STATUS", value: license.isActivated ? "ACTIVE" : "FREE"); NexusSystemValue(label: "ROLE", value: role) } } .padding(15) }
                ForEach(systemItems, id: \.0) { item in Button { destination = item.1 } label: { NexusSystemRow(icon: item.2, title: item.0, subtitle: item.3) }.buttonStyle(.plain) }
            }.frame(maxWidth: 520).frame(maxWidth: .infinity).padding(14)
        }
    }
    private var role: String { switch session.role { case .owner: "OWNER"; case .admin: "ADMIN"; case .member: "MEMBER"; case nil: "GUEST" } }
    private var systemItems: [(String, NexusDestination, String, String)] { [
        ("Key Center", .key, "key.fill", "Activation and session"),
        ("DNS Premium", .premium, "network", "V1 / V2 controls"),
        ("Repository", .repository, "server.rack", "Manage patch source"),
        ("Download History", .history, "clock.arrow.circlepath", "Your download timeline"),
        ("Files", .files, "folder.fill", "Local app storage"),
        ("Settings", .settings, "gearshape.fill", "Appearance and preferences"),
        ("Terms", .terms, "doc.text.fill", "Terms of use"),
        ("About", .about, "info.circle.fill", "App information")
    ] }
}

private struct NexusDock: View {
    @Binding var selection: NexusTab
    var body: some View {
        HStack(spacing: 3) {
            ForEach(NexusTab.allCases, id: \.self) { item in
                Button { withAnimation(.spring(response: 0.3, dampingFraction: 0.82)) { selection = item } } label: {
                    VStack(spacing: 4) { Image(systemName: item.icon).font(.system(size: 15, weight: .bold)); Text(item.title).font(.system(size: 8, weight: .black, design: .rounded)).minimumScaleFactor(0.65) }
                    .foregroundStyle(selection == item ? .white : .white.opacity(0.38)).frame(maxWidth: .infinity).padding(.vertical, 8)
                    .background(selection == item ? LinearGradient(colors: [NexusColor.blue.opacity(0.35), NexusColor.purple.opacity(0.23)], startPoint: .top, endPoint: .bottom) : LinearGradient(colors: [.clear, .clear], startPoint: .top, endPoint: .bottom), in: RoundedRectangle(cornerRadius: 16))
                }.buttonStyle(.plain)
            }
        }.padding(5).background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 23)).overlay(RoundedRectangle(cornerRadius: 23).stroke(.white.opacity(0.10), lineWidth: 0.8)).shadow(color: NexusColor.blue.opacity(0.16), radius: 20, y: 7)
    }
}

private struct NexusHeading: View { let kicker: String; let title: String; var body: some View { VStack(alignment: .leading, spacing: 2) { Text(kicker).font(.system(size: 8, weight: .black, design: .monospaced)).foregroundStyle(NexusColor.cyan); Text(title).font(.system(size: 18, weight: .black, design: .rounded)) }.foregroundStyle(.white) } }
private struct NexusBadge: View { let text: String; var body: some View { Text(text).font(.system(size: 8, weight: .black, design: .monospaced)).foregroundStyle(.white.opacity(0.75)).padding(.horizontal, 8).padding(.vertical, 5).background(.white.opacity(0.08), in: Capsule()) } }
private struct NexusMetric: View { let icon: String; let title: String; let value: String; let tint: Color; var body: some View { NexusPanel(radius: 18) { HStack(spacing: 8) { Image(systemName: icon).foregroundStyle(tint); VStack(alignment: .leading, spacing: 1) { Text(title).font(.system(size: 7, weight: .black, design: .monospaced)).foregroundStyle(.white.opacity(0.4)); Text(value).font(.system(size: 12, weight: .black, design: .rounded)) } }.frame(maxWidth: .infinity, alignment: .leading).padding(10) } } }
private struct NexusAction: View { let title: String; let detail: String; let icon: String; let tint: Color; let action: () -> Void; var body: some View { Button(action: action) { NexusPanel(radius: 20) { HStack(spacing: 10) { Image(systemName: icon).font(.system(size: 15, weight: .black)).foregroundStyle(tint).frame(width: 36, height: 36).background(tint.opacity(0.10), in: Circle()); VStack(alignment: .leading, spacing: 2) { Text(title).font(.system(size: 12, weight: .bold, design: .rounded)); Text(detail).font(.system(size: 8, weight: .medium)).foregroundStyle(.white.opacity(0.38)) }; Spacer(); Image(systemName: "chevron.right").font(.system(size: 9, weight: .bold)).foregroundStyle(.white.opacity(0.25)) }.padding(10) } }.buttonStyle(.plain) } }
private struct NexusAIChip: View { let icon: String; let text: String; var body: some View { HStack(spacing: 5) { Image(systemName: icon); Text(text) }.font(.system(size: 8, weight: .bold)).foregroundStyle(.white.opacity(0.58)).padding(.horizontal, 10).padding(.vertical, 8).background(.white.opacity(0.05), in: Capsule()) } }
private struct NexusSystemValue: View { let label: String; let value: String; var body: some View { VStack(alignment: .leading, spacing: 3) { Text(label).font(.system(size: 7, weight: .black, design: .monospaced)).foregroundStyle(.white.opacity(0.35)); Text(value).font(.system(size: 12, weight: .black, design: .rounded)) }.frame(maxWidth: .infinity, alignment: .leading) } }
private struct NexusSystemRow: View { let icon: String; let title: String; let subtitle: String; var body: some View { NexusPanel(radius: 19) { HStack(spacing: 11) { Image(systemName: icon).font(.system(size: 15, weight: .bold)).foregroundStyle(NexusColor.cyan).frame(width: 38, height: 38).background(NexusColor.cyan.opacity(0.09), in: Circle()); VStack(alignment: .leading, spacing: 2) { Text(title).font(.system(size: 13, weight: .bold, design: .rounded)); Text(subtitle).font(.system(size: 9, weight: .medium)).foregroundStyle(.white.opacity(0.38)) }; Spacer(); Image(systemName: "arrow.up.right").foregroundStyle(.white.opacity(0.25)) }.padding(10) } } }
private struct NexusEmptyState: View { let title: String; let subtitle: String; var body: some View { NexusPanel(radius: 24) { VStack(spacing: 8) { Image(systemName: "square.stack.3d.up").font(.system(size: 26)).foregroundStyle(NexusColor.cyan); Text(title).font(.system(size: 15, weight: .black, design: .rounded)); Text(subtitle).font(.system(size: 10)).foregroundStyle(.white.opacity(0.4)).multilineTextAlignment(.center) }.frame(maxWidth: .infinity).padding(30) } } }

// Compatibility name retained for any other file that references the modern root.
typealias ShinnModernRootView = ShinnNovaRootView


// MARK: - Restored legacy destination used by Nexus UI
private struct ShinnModernDownloadHistoryView: View {
    @EnvironmentObject private var store: RepoStore

    var body: some View {
        ZStack {
            ShinnModernBackground()
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 14) {
                    HStack {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Lịch sử tải xuống")
                                .font(.system(size: 28, weight: .black, design: .rounded))
                            Text("\(store.downloadHistory.count) lượt tải được lưu")
                                .font(.system(size: 11, weight: .medium, design: .rounded))
                                .foregroundStyle(.white.opacity(0.45))
                        }
                        Spacer()
                        if !store.downloadHistory.isEmpty {
                            Button("Xóa") {
                                store.clearDownloadHistory()
                            }
                            .font(.system(size: 12, weight: .bold, design: .rounded))
                            .foregroundStyle(.red)
                        }
                    }

                    if store.downloadHistory.isEmpty {
                        ShinnModernCard(radius: 22) {
                            VStack(spacing: 10) {
                                Image(systemName: "clock.arrow.circlepath")
                                    .font(.system(size: 32, weight: .bold))
                                    .foregroundStyle(ShinnModernPalette.cyan)
                                Text("Chưa có lịch sử tải")
                                    .font(.system(size: 17, weight: .black, design: .rounded))
                                Text("Các patch tải thành công sẽ xuất hiện ở đây.")
                                    .font(.system(size: 11, weight: .medium, design: .rounded))
                                    .foregroundStyle(.white.opacity(0.45))
                                    .multilineTextAlignment(.center)
                            }
                            .frame(maxWidth: .infinity)
                            .padding(22)
                        }
                    } else {
                        ForEach(store.downloadHistory) { item in
                            ShinnModernCard(radius: 18) {
                                HStack(spacing: 12) {
                                    Image(systemName: "arrow.down.circle.fill")
                                        .font(.system(size: 28, weight: .bold))
                                        .foregroundStyle(ShinnModernPalette.cyan)
                                    VStack(alignment: .leading, spacing: 4) {
                                        Text(item.name)
                                            .font(.system(size: 14, weight: .bold, design: .rounded))
                                            .foregroundStyle(.white)
                                            .lineLimit(1)
                                        HStack(spacing: 7) {
                                            Text(item.repo)
                                            if let version = item.version, !version.isEmpty {
                                                Text("v\(version)")
                                            }
                                            if let size = item.size {
                                                Text(formatBytes(size))
                                            }
                                        }
                                        .font(.system(size: 9, weight: .medium, design: .rounded))
                                        .foregroundStyle(.white.opacity(0.40))
                                        Text(item.downloadedAt.formatted(date: .abbreviated, time: .shortened))
                                            .font(.system(size: 9, weight: .medium, design: .rounded))
                                            .foregroundStyle(.white.opacity(0.30))
                                    }
                                    Spacer()
                                }
                                .padding(14)
                            }
                        }
                    }
                }
                .padding(16)
            }
        }
        .navigationTitle("Download History")
        .navigationBarTitleDisplayMode(.inline)
    }
}



// MARK: - Restored legacy destination used by Nexus UI
private struct ShinnModernTermsView: View {
    var body: some View {
        ZStack {
            ShinnModernBackground()
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 14) {
                    Text("Điều khoản sử dụng")
                        .font(.system(size: 28, weight: .black, design: .rounded))
                    Text("Vui lòng đọc trước khi sử dụng Shinn Cheat.")
                        .font(.system(size: 12, weight: .medium, design: .rounded))
                        .foregroundStyle(.white.opacity(0.45))

                    termsCard("1. Sử dụng ứng dụng", """
Shinn Cheat là công cụ quản lý và cài đặt các gói patch do người dùng lựa chọn. Bạn chịu trách nhiệm kiểm tra nguồn, phiên bản và tính tương thích của từng patch trước khi bật.
""")
                    termsCard("2. Patch và dữ liệu", """
Patch được tải từ repository được cấu hình trong ứng dụng. Ứng dụng kiểm tra SHA-256 khi manifest cung cấp mã xác thực. Không chỉnh sửa hoặc chia sẻ lại gói nếu bạn không có quyền đối với nội dung đó.
""")
                    termsCard("3. Trách nhiệm người dùng", """
Bạn tự chịu trách nhiệm về việc sử dụng patch trên thiết bị và ứng dụng đích. Hãy tôn trọng điều khoản của dịch vụ hoặc trò chơi mà bạn sử dụng.
""")
                    termsCard("4. Key và quyền truy cập", """
Key, thời hạn và quyền truy cập repository được quản lý theo hệ thống của Shinn Cheat. Không chia sẻ key cá nhân cho người khác.
""")
                    termsCard("5. Cập nhật điều khoản", """
Điều khoản có thể được cập nhật khi ứng dụng hoặc hệ thống repository thay đổi. Phiên bản hiển thị trong ứng dụng là phiên bản đang được cài đặt.
""")
                }
                .padding(16)
            }
        }
        .navigationTitle("Terms")
        .navigationBarTitleDisplayMode(.inline)
    }

    private func termsCard(_ title: String, _ text: String) -> some View {
        ShinnModernCard(radius: 20) {
            VStack(alignment: .leading, spacing: 8) {
                Text(title)
                    .font(.system(size: 15, weight: .black, design: .rounded))
                    .foregroundStyle(ShinnModernPalette.cyan)
                Text(text)
                    .font(.system(size: 11, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.62))
                    .lineSpacing(3)
            }
            .padding(15)
        }
    }
}

private struct ShinnModernAboutView: View {
    var body: some View {
        ZStack {
            ShinnModernBackground()
            ScrollView(showsIndicators: false) {
                VStack(spacing: 16) {
                    Image("ShinnSplashArt")
                        .resizable()
                        .scaledToFill()
                        .frame(width: 110, height: 110)
                        .clipShape(RoundedRectangle(cornerRadius: 28, style: .continuous))
                        .overlay(RoundedRectangle(cornerRadius: 28).stroke(ShinnModernPalette.blue.opacity(0.45), lineWidth: 1))

                    Text("Shinn Cheat")
                        .font(.system(size: 30, weight: .black, design: .rounded))
                    Text("Play Smarter · Win Easier")
                        .font(.system(size: 12, weight: .semibold, design: .rounded))
                        .foregroundStyle(.white.opacity(0.45))

                    ShinnModernCard(radius: 22) {
                        VStack(spacing: 0) {
                            aboutRow("Version", AppInfo.version)
                            Divider().background(Color.white.opacity(0.06))
                            aboutRow("Developer", "Shinn")
                            Divider().background(Color.white.opacity(0.06))
                            aboutRow("Support", AppInfo.telegramHandle)
                            Divider().background(Color.white.opacity(0.06))
                            aboutRow("Repository", "ShinnCheat Repo")
                        }
                        .padding(15)
                    }

                    ShinnModernCard(radius: 22) {
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Ứng dụng")
                                .font(.system(size: 15, weight: .black, design: .rounded))
                            Text("Shinn Cheat cung cấp giao diện quản lý repository, tải patch, bật/tắt patch, quản lý file và các công cụ hỗ trợ liên quan.")
                                .font(.system(size: 11, weight: .medium, design: .rounded))
                                .foregroundStyle(.white.opacity(0.55))
                                .lineSpacing(3)
                        }
                        .padding(15)
                    }

                    Text("© Shinn Cheat")
                        .font(.system(size: 10, weight: .medium, design: .rounded))
                        .foregroundStyle(.white.opacity(0.25))
                }
                .frame(maxWidth: .infinity)
                .padding(20)
            }
        }
        .navigationTitle("About")
        .navigationBarTitleDisplayMode(.inline)
    }

    private func aboutRow(_ key: String, _ value: String) -> some View {
        HStack {
            Text(key)
                .font(.system(size: 11, weight: .medium, design: .rounded))
                .foregroundStyle(.white.opacity(0.42))
            Spacer()
            Text(value)
                .font(.system(size: 11, weight: .bold, design: .rounded))
                .foregroundStyle(.white)
                .lineLimit(1)
        }
        .padding(.vertical, 9)
    }
}

private struct ShinnModernPremiumView: View {
    @EnvironmentObject private var store: RepoStore
    @EnvironmentObject private var license: LicenseManager
    @Binding var destination: ShinnModernDestination?
    @State private var key = ""
    @State private var message = ""
    @State private var busy = false

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 16) {
                Image("ShinnHeroArt")
                    .resizable().scaledToFill()
                    .frame(height: 180)
                    .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))

                ShinnModernCard(radius: 24, stroke: ShinnModernPalette.purple.opacity(0.35)) {
                    VStack(spacing: 12) {
                        Image(systemName: "crown.fill")
                            .font(.system(size: 34, weight: .black))
                            .foregroundStyle(ShinnModernPalette.purple)
                        Text("Repo 2 - Premium").font(.system(size: 22, weight: .black, design: .rounded))
                        benefit("Nhiều patch độc quyền")
                        benefit("Cập nhật sớm nhất")
                        benefit("Hỗ trợ 24/7")
                        benefit("Sử dụng key để mở khóa")
                    }
                    .padding(18)
                }

                Button { destination = .key } label: {
                    Label("Nhập key", systemImage: "key.fill").frame(maxWidth: .infinity)
                }
                .buttonStyle(ShinnModernPrimaryButtonStyle(tint: ShinnModernPalette.purple))

                if !message.isEmpty {
                    Text(message).font(.footnote).foregroundStyle(.red).multilineTextAlignment(.center)
                }

                Button { UIApplication.shared.open(AppInfo.telegramLinkURL) } label: {
                    HStack { ShinnModernIcon(systemName: "paperplane.fill", tint: ShinnModernPalette.blue, size: 42); Text("Chưa có key? Liên hệ Telegram để mua key Premium"); Spacer(); Image(systemName: "chevron.right") }
                        .padding(13)
                }
                .buttonStyle(.plain)
                .background(ShinnModernPalette.card.opacity(0.78), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            }
            .padding(16)
        }
        .background(ShinnModernBackground())
        .navigationTitle("Premium Repo")
        .navigationBarTitleDisplayMode(.inline)
    }

    private func benefit(_ text: String) -> some View {
        HStack { Image(systemName: "checkmark.circle.fill").foregroundStyle(ShinnModernPalette.blue); Text(text); Spacer() }
            .font(.system(size: 13, weight: .medium, design: .rounded))
    }
}

private struct ShinnModernKeyView: View {
    @EnvironmentObject private var store: RepoStore
    @EnvironmentObject private var license: LicenseManager
    @Environment(\.dismiss) private var dismiss
    @State private var key = ""
    @State private var busy = false
    @State private var message = ""

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 18) {
                Spacer(minLength: 20)
                ShinnModernCard(radius: 25, stroke: ShinnModernPalette.blue.opacity(0.30)) {
                    VStack(spacing: 15) {
                        Image(systemName: "crown.fill")
                            .font(.system(size: 36, weight: .black))
                            .foregroundStyle(.white)
                            .frame(width: 72, height: 72)
                            .background(ShinnModernPalette.blue.opacity(0.20), in: Circle())
                        Text("Premium Key").font(.system(size: 23, weight: .black, design: .rounded))
                        SecureField("Nhập key của bạn…", text: $key)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled(true)
                            .padding(15)
                            .background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                        Button {
                            Task { await activate() }
                        } label: {
                            if busy { ProgressView().tint(.white) } else { Text("Xác nhận") }
                        }
                        .buttonStyle(ShinnModernPrimaryButtonStyle())
                        Button("Kiểm tra key") { Task { await activate() } }
                            .font(.system(size: 12, weight: .semibold, design: .rounded))
                            .foregroundStyle(ShinnModernPalette.cyan)

                        Button {
                            // Skip is deliberately V1-only: no key, no V2 access.
                            UserDefaults.standard.set(true, forKey: "shinn.key.skipped")
                            Task {
                                await store.selectRepo(v2: false)
                                dismiss()
                            }
                        } label: {
                            Text("Bỏ qua · vào app với Repo V1")
                                .font(.system(size: 12, weight: .semibold, design: .rounded))
                                .foregroundStyle(.white.opacity(0.55))
                        }
                    }
                    .padding(18)
                }
                if !message.isEmpty { Text(message).font(.footnote).foregroundStyle(.red).multilineTextAlignment(.center) }
                Text("Key hợp lệ sẽ mở khóa Repo 2 và các patch đặc biệt.")
                    .font(.system(size: 11, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.40))
                    .multilineTextAlignment(.center)
            }
            .padding(16)
        }
        .background(ShinnModernBackground())
        .navigationTitle("Nhập Key")
        .navigationBarTitleDisplayMode(.inline)
    }

    private func activate() async {
        let value = key.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !value.isEmpty else { message = "Vui lòng nhập key."; return }
        busy = true
        defer { busy = false }
        let ok = await license.activate(key: value, language: .en)
        if ok && license.isActivated && store.isRepoV2Authorized {
            UserDefaults.standard.set(false, forKey: "shinn.key.skipped")
            await store.selectRepo(v2: true)
            message = "Đã xác thực key · Repo V2 đã mở khóa."
            key = ""
            dismiss()
        } else if ok && license.isActivated {
            message = license.lastError ?? "Key không hợp lệ."
        }
    }
}

private struct ShinnModernAIView: View {
    @State private var input = ""
    @State private var messages: [(String, Bool)] = [("Xin chào! 👋\nMình là Shinn AI. Bạn cần hỗ trợ gì hôm nay?", false)]
    private let commands = ["/start", "/help", "/patch", "/info", "/key", "/menu"]

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 10) {
                Image("ShinnAvatarArt").resizable().scaledToFill().frame(width: 46, height: 46).clipShape(Circle())
                VStack(alignment: .leading) { Text("Shinn AI").font(.system(size: 21, weight: .black, design: .rounded)); Text("Trợ lý AI thông minh").font(.system(size: 10, weight: .medium, design: .rounded)).foregroundStyle(.white.opacity(0.45)) }
                Spacer()
                Image(systemName: "sparkles").foregroundStyle(ShinnModernPalette.cyan)
            }
            .foregroundStyle(.white)
            .padding(.horizontal, 16).padding(.top, 8).padding(.bottom, 12)

            ScrollView(showsIndicators: false) {
                LazyVStack(alignment: .leading, spacing: 10) {
                    ForEach(Array(messages.enumerated()), id: \.offset) { _, item in
                        HStack {
                            if item.1 { Spacer() }
                            Text(item.0)
                                .font(.system(size: 13, weight: .medium, design: .rounded))
                                .foregroundStyle(.white)
                                .padding(12)
                                .background(item.1 ? ShinnModernPalette.blue.opacity(0.30) : ShinnModernPalette.card, in: RoundedRectangle(cornerRadius: 17, style: .continuous))
                            if !item.1 { Spacer() }
                        }
                    }

                    ShinnModernCard(radius: 18) {
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Các lệnh có sẵn:").font(.system(size: 12, weight: .bold, design: .rounded))
                            ForEach(commands, id: \.self) { command in
                                Button { send(command) } label: {
                                    HStack { Text(command).foregroundStyle(ShinnModernPalette.cyan); Spacer(); Text(commandDescription(command)).foregroundStyle(.white.opacity(0.45)) }
                                        .font(.system(size: 11, weight: .medium, design: .rounded))
                                        .padding(.vertical, 7)
                                }.buttonStyle(.plain)
                            }
                        }.padding(13)
                    }
                }
                .padding(16)
            }

            HStack(spacing: 8) {
                TextField("Nhập tin nhắn…", text: $input)
                    .textFieldStyle(.plain)
                    .foregroundStyle(.white)
                    .padding(12)
                    .background(ShinnModernPalette.card, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                Button { send(input); input = "" } label: { Image(systemName: "arrow.up").frame(width: 40, height: 40) }
                    .buttonStyle(ShinnModernPrimaryButtonStyle(compact: true))
            }
            .padding(10)
        }
    }

    private func send(_ text: String) {
        let value = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !value.isEmpty else { return }
        messages.append((value, true))
        let lower = value.lowercased()
        let reply: String
        if lower.contains("patch") { reply = "Bạn có thể mở Kho Patch để xem và tải patch mới." }
        else if lower.contains("key") { reply = "Premium Key dùng để mở khóa Repo 2. Nếu chưa có key, hãy liên hệ Admin." }
        else if lower.contains("help") || lower.contains("hướng dẫn") { reply = "Dùng /patch để tìm patch, /key để kiểm tra key và /info để xem thông tin app." }
        else if lower.contains("version") || lower.contains("info") { reply = "Shinn Cheat · Patch Center · Community · AI" }
        else { reply = "Mình sẵn sàng hỗ trợ. Thử /help để xem các lệnh." }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) { messages.append((reply, false)) }
    }

    private func commandDescription(_ command: String) -> String {
        switch command {
        case "/start": return "Bắt đầu sử dụng"
        case "/help": return "Xem danh sách lệnh"
        case "/patch": return "Tìm patch nhanh"
        case "/info": return "Thông tin app"
        case "/key": return "Kiểm tra key"
        default: return "Hiển thị menu"
        }
    }
}

private struct ShinnModernCommunityView: View {
    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 13) {
                VStack(alignment: .leading, spacing: 5) {
                    Text("Cộng đồng").font(.system(size: 30, weight: .black, design: .rounded))
                    Text("Tham gia group để nhận hỗ trợ").font(.system(size: 12, weight: .medium, design: .rounded)).foregroundStyle(.white.opacity(0.48))
                }
                community("Group chính", "ShinnCheatShare", "Cập nhật · Thông báo · Tài nguyên", AppInfo.telegramMainGroupURL)
                community("English Chat", "ShinnCheatChat", "English only · Discussion · Support", AppInfo.telegramEnglishChatURL)
                community("Hỗ trợ liên hệ", "@ShinnThieuu", "Hỗ trợ nhanh · Giải đáp thắc mắc", AppInfo.telegramLinkURL)
                Image("ShinnCatCommunity")
                    .resizable().scaledToFill().frame(height: 125).clipped()
                    .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
                    .overlay(alignment: .bottomLeading) { Text("Join our community\nStay updated!").font(.system(size: 17, weight: .black, design: .rounded)).padding(16) }
            }
            .foregroundStyle(.white)
            .padding(16)
        }
    }

    private func community(_ title: String, _ name: String, _ subtitle: String, _ url: URL) -> some View {
        Button { UIApplication.shared.open(url) } label: {
            HStack(spacing: 12) {
                ShinnModernIcon(systemName: "paperplane.fill", tint: ShinnModernPalette.blue, size: 48)
                VStack(alignment: .leading, spacing: 3) {
                    Text(title).font(.system(size: 15, weight: .black, design: .rounded))
                    Text(name).font(.system(size: 12, weight: .semibold, design: .rounded)).foregroundStyle(ShinnModernPalette.cyan)
                    Text(subtitle).font(.system(size: 10, weight: .medium, design: .rounded)).foregroundStyle(.white.opacity(0.42))
                }
                Spacer()
                Image(systemName: "chevron.right").foregroundStyle(.white.opacity(0.30))
            }
            .padding(13)
            .background(ShinnModernPalette.card.opacity(0.80), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        }
        .buttonStyle(.plain)
    }
}

private struct ShinnModernMoreView: View {
    @Binding var destination: ShinnModernDestination?
    let session: Session
    @EnvironmentObject private var license: LicenseManager
    @EnvironmentObject private var store: RepoStore

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 13) {
                Text("Thêm").font(.system(size: 30, weight: .black, design: .rounded))
                Text("Cài đặt và thông tin ứng dụng").font(.system(size: 12, weight: .medium, design: .rounded)).foregroundStyle(.white.opacity(0.48))

                moreRow("Shinn Cheat", "Play Smarter · Win Easier", "ShinnAvatarArt", nil)
                moreRow("Lịch sử tải xuống", "Patch đã tải", nil, "clock.arrow.circlepath") { destination = .downloadHistory }
                moreRow("Tệp của tôi", "File manager", nil, "folder.fill") { destination = .files }
                moreRow("Cài đặt", "Giao diện", nil, "gearshape.fill") { destination = .settings }
                moreRow("Hỗ trợ & Liên hệ", "@ShinnThieuu", nil, "questionmark.circle.fill") { UIApplication.shared.open(AppInfo.telegramLinkURL) }
                moreRow("Điều khoản sử dụng", "Quy định và trách nhiệm", nil, "doc.text.fill") { destination = .terms }
                moreRow("Giới thiệu ứng dụng", "Shinn Cheat", nil, "info.circle.fill") { destination = .about }

                if license.isActivated {
                    ShinnModernCard(radius: 18, stroke: ShinnModernPalette.cyan.opacity(0.22)) {
                        VStack(alignment: .leading, spacing: 8) {
                            HStack {
                                Image(systemName: "key.fill").foregroundStyle(ShinnModernPalette.cyan)
                                VStack(alignment: .leading, spacing: 2) {
                                    Text("Key đang đăng nhập")
                                        .font(.system(size: 14, weight: .black, design: .rounded))
                                    Text(license.holderName.isEmpty ? license.savedLicenseKey : license.holderName)
                                        .font(.system(size: 10, weight: .medium, design: .rounded))
                                        .foregroundStyle(.white.opacity(0.48))
                                        .lineLimit(1)
                                }
                                Spacer()
                            }
                            if let expires = license.expiresAt {
                                TimelineView(.periodic(from: .now, by: 30)) { context in
                                    Text("Còn lại: \(remainingText(until: expires, now: context.date))")
                                        .font(.system(size: 11, weight: .bold, design: .rounded))
                                        .foregroundStyle(expires > context.date ? ShinnModernPalette.green : .red)
                                }
                            } else {
                                Text("Thời hạn: Vĩnh viễn")
                                    .font(.system(size: 11, weight: .bold, design: .rounded))
                                    .foregroundStyle(ShinnModernPalette.green)
                            }
                            Button {
                                license.signOutLicense()
                                session.role = nil
                                Task { await store.selectRepo(v2: false) }
                            } label: {
                                Label("Đăng xuất key · về Repo V1", systemImage: "rectangle.portrait.and.arrow.right")
                                    .frame(maxWidth: .infinity)
                            }
                            .buttonStyle(ShinnModernPrimaryButtonStyle(tint: .red, compact: true))
                        }
                        .padding(13)
                    }
                }

                if session.role == .owner {
                    moreRow("Tạo / Xoá Key", "Chỉ Owner · quản lý key", nil, "key.fill") { destination = .ownerKeys }
                    moreRow("Repo V2 · Gán Key", "Chỉ Owner · cấp quyền Repo V2", nil, "crown.fill") { destination = .repositoryManager }
                    moreRow("Quản lý Patch", "Owner tools", nil, "wrench.and.screwdriver.fill") { destination = .patchProjects }
                }

                ShinnModernCard(radius: 20) {
                    HStack(spacing: 12) {
                        Image("ShinnAIArt").resizable().scaledToFill().frame(width: 50, height: 50).clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                        VStack(alignment: .leading, spacing: 3) { Text("Cảm ơn bạn").font(.system(size: 16, weight: .black, design: .rounded)); Text("Đã đồng hành cùng Shinn Cheat").font(.system(size: 10, weight: .medium, design: .rounded)).foregroundStyle(.white.opacity(0.45)) }
                        Spacer()
                    }
                    .padding(13)
                }
            }
            .foregroundStyle(.white)
            .padding(16)
        }
    }

    private func remainingText(until date: Date, now: Date) -> String {
        let seconds = max(0, Int(date.timeIntervalSince(now)))
        if seconds == 0 { return "Đã hết hạn" }
        let days = seconds / 86_400
        let hours = (seconds % 86_400) / 3_600
        let minutes = (seconds % 3_600) / 60
        if days > 0 { return "\(days) ngày \(hours) giờ" }
        if hours > 0 { return "\(hours) giờ \(minutes) phút" }
        return "\(max(1, minutes)) phút"
    }

    private func moreRow(_ title: String, _ subtitle: String, _ image: String?, _ icon: String?, action: @escaping () -> Void = {}) -> some View {
        Button(action: action) {
            HStack(spacing: 12) {
                if let image {
                    Image(image).resizable().scaledToFill().frame(width: 43, height: 43).clipShape(RoundedRectangle(cornerRadius: 13, style: .continuous))
                } else if let icon {
                    ShinnModernIcon(systemName: icon, tint: ShinnModernPalette.blue, size: 43)
                }
                VStack(alignment: .leading, spacing: 3) { Text(title).font(.system(size: 14, weight: .bold, design: .rounded)); Text(subtitle).font(.system(size: 10, weight: .medium, design: .rounded)).foregroundStyle(.white.opacity(0.40)) }
                Spacer()
                Image(systemName: "chevron.right").foregroundStyle(.white.opacity(0.30))
            }
            .padding(11)
            .background(ShinnModernPalette.card.opacity(0.80), in: RoundedRectangle(cornerRadius: 17, style: .continuous))
        }
        .buttonStyle(.plain)
    }
}


private struct ShinnModernOwnerKeysView: View {
    @EnvironmentObject private var session: Session
    @StateObject private var manager = OwnerKeyManager()
    @State private var copied = false
    @State private var selectedImage: PhotosPickerItem?
    @State private var keyArtwork: UIImage?
    @State private var imageStatus = ""

    private let durations = [1, 3, 7, 30, 90, 365]

    var body: some View {
        Group {
            if session.role == .owner {
                ScrollView(showsIndicators: false) {
                    VStack(alignment: .leading, spacing: 14) {
                        Text("Tạo / Xoá Key")
                            .font(.system(size: 28, weight: .black, design: .rounded))
                        Text("Chỉ Owner mới nhìn thấy và sử dụng khu vực này.")
                            .font(.system(size: 12, weight: .medium, design: .rounded))
                            .foregroundStyle(.white.opacity(0.48))

                        ShinnModernCard(radius: 22, stroke: ShinnModernPalette.purple.opacity(0.30)) {
                            VStack(alignment: .leading, spacing: 12) {
                                Text("Tạo key")
                                    .font(.system(size: 18, weight: .black, design: .rounded))

                                TextField("Tên người nhận (tuỳ chọn)", text: $manager.keyLabel)
                                    .textFieldStyle(.plain)
                                    .foregroundStyle(.white)
                                    .padding(12)
                                    .background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 13, style: .continuous))

                                TextField("Custom key (tuỳ chọn)", text: $manager.customKey)
                                    .textFieldStyle(.plain)
                                    .textInputAutocapitalization(.never)
                                    .autocorrectionDisabled(true)
                                    .foregroundStyle(.white)
                                    .padding(12)
                                    .background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 13, style: .continuous))

                                HStack(spacing: 12) {
                                    Group {
                                        if let keyArtwork {
                                            Image(uiImage: keyArtwork)
                                                .resizable()
                                                .scaledToFill()
                                        } else {
                                            Image(systemName: "photo.badge.plus")
                                                .font(.system(size: 21, weight: .bold))
                                                .foregroundStyle(ShinnModernPalette.cyan)
                                        }
                                    }
                                    .frame(width: 54, height: 54)
                                    .clipShape(RoundedRectangle(cornerRadius: 15, style: .continuous))
                                    .background(Color.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 15, style: .continuous))

                                    VStack(alignment: .leading, spacing: 3) {
                                        Text("Ảnh Key")
                                            .font(.system(size: 13, weight: .black, design: .rounded))
                                        Text("Chọn ảnh riêng để hiển thị trong bảng key.")
                                            .font(.system(size: 9.5, weight: .medium, design: .rounded))
                                            .foregroundStyle(.white.opacity(0.45))
                                    }
                                    Spacer()
                                    PhotosPicker(selection: $selectedImage, matching: .images) {
                                        Text("Chọn ảnh")
                                            .font(.system(size: 11, weight: .black, design: .rounded))
                                            .foregroundStyle(.white)
                                            .padding(.horizontal, 12)
                                            .padding(.vertical, 9)
                                            .background(ShinnModernPalette.blue.opacity(0.22), in: Capsule())
                                    }
                                    .onChange(of: selectedImage) { item in
                                        guard let item else { return }
                                        Task {
                                            do {
                                                if let data = try await item.loadTransferable(type: Data.self),
                                                   let image = UIImage(data: data) {
                                                    let resized = image.shinnKeyPreview(maxDimension: 900)
                                                    keyArtwork = resized
                                                    if let jpeg = resized.jpegData(compressionQuality: 0.82) {
                                                        UserDefaults.standard.set(jpeg, forKey: "shinn.owner.keyArtwork")
                                                        imageStatus = "Đã lưu ảnh trong app"
                                                    }
                                                }
                                            } catch {
                                                imageStatus = "Không đọc được ảnh"
                                            }
                                        }
                                    }
                                }

                                if !imageStatus.isEmpty {
                                    Text(imageStatus)
                                        .font(.system(size: 9, weight: .medium, design: .rounded))
                                        .foregroundStyle(ShinnModernPalette.green)
                                }

                                Picker("Thời hạn", selection: $manager.selectedHours) {
                                    Text("1 giờ · Test").tag(1)
                                    Text("Theo ngày").tag(0)
                                }
                                .pickerStyle(.segmented)

                                if manager.selectedHours == 0 {
                                    Toggle("Vĩnh viễn", isOn: $manager.lifetime)
                                    if !manager.lifetime {
                                        Picker("Số ngày", selection: $manager.selectedDays) {
                                            ForEach(durations, id: \.self) { d in
                                                Text(d == 365 ? "1 năm" : "\(d) ngày").tag(d)
                                            }
                                        }
                                        .pickerStyle(.menu)
                                    }
                                }

                                Stepper("Số lượng: \(manager.createCount)", value: $manager.createCount, in: 1...99)

                                Button {
                                    Task { await manager.createKey() }
                                } label: {
                                    Label(manager.isLoading ? "Đang tạo…" : "Tạo Key", systemImage: "plus.circle.fill")
                                        .frame(maxWidth: .infinity)
                                }
                                .buttonStyle(ShinnModernPrimaryButtonStyle(tint: ShinnModernPalette.purple))
                                .disabled(manager.isLoading)

                                if !manager.prettyCreated.isEmpty {
                                    Text(manager.prettyCreated)
                                        .font(.system(size: 12, weight: .bold, design: .monospaced))
                                        .foregroundStyle(ShinnModernPalette.cyan)
                                        .textSelection(.enabled)
                                    Button {
                                        UIPasteboard.general.string = manager.prettyCreated
                                        copied = true
                                    } label: {
                                        Label(copied ? "Đã sao chép" : "Sao chép", systemImage: copied ? "checkmark" : "doc.on.doc")
                                            .frame(maxWidth: .infinity)
                                    }
                                    .buttonStyle(.plain)
                                }
                            }
                            .padding(16)
                        }

                        ShinnModernCard(radius: 22) {
                            VStack(alignment: .leading, spacing: 10) {
                                HStack {
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text("Key đã tạo (\(manager.keys.count))")
                                            .font(.system(size: 17, weight: .black, design: .rounded))
                                        Text("Mỗi key do Owner tạo sẽ tự mở Repo V2.")
                                            .font(.system(size: 9.5, weight: .medium, design: .rounded))
                                            .foregroundStyle(.white.opacity(0.42))
                                    }
                                    Spacer()
                                    Button { Task { await manager.listKeys() } } label: {
                                        Image(systemName: manager.isLoading ? "hourglass" : "arrow.clockwise")
                                    }
                                    .buttonStyle(.plain)
                                }

                                Button {
                                    Task { await manager.syncAllKeysToV2() }
                                } label: {
                                    Label("Đồng bộ V2 cho tất cả key", systemImage: "arrow.triangle.2.circlepath")
                                        .frame(maxWidth: .infinity)
                                }
                                .buttonStyle(ShinnModernPrimaryButtonStyle(tint: ShinnModernPalette.cyan, compact: true))
                                .disabled(manager.isLoading || manager.keys.isEmpty)

                                if manager.keys.isEmpty {
                                    Text("Chưa có key hoặc chưa tải danh sách.")
                                        .font(.caption)
                                        .foregroundStyle(.white.opacity(0.45))
                                } else {
                                    ForEach(manager.keys) { row in
                                        HStack(spacing: 10) {
                                            VStack(alignment: .leading, spacing: 3) {
                                                Text(row.key)
                                                    .font(.system(size: 12, weight: .bold, design: .monospaced))
                                                    .textSelection(.enabled)
                                                Text(row.label?.isEmpty == false ? row.label! : (row.role ?? "member"))
                                                    .font(.system(size: 10, weight: .medium, design: .rounded))
                                                    .foregroundStyle(.white.opacity(0.42))
                                                HStack(spacing: 6) {
                                                    TimelineView(.periodic(from: .now, by: 1)) { context in
                                                        Text(ownerRemainingText(row.expires_at, now: context.date))
                                                            .font(.system(size: 10, weight: .bold, design: .rounded))
                                                            .foregroundStyle(ownerExpiryDate(row.expires_at).map { $0 > context.date ? ShinnModernPalette.green : .red } ?? ShinnModernPalette.cyan)
                                                    }
                                                    ShinnModernPill(
                                                        text: "V2 OPEN",
                                                        tint: ShinnModernPalette.purple
                                                    )
                                                }
                                                if let date = ownerExpiryDate(row.expires_at) {
                                                    Text(date.formatted(date: .numeric, time: .shortened))
                                                        .font(.system(size: 8.5, weight: .medium, design: .rounded))
                                                        .foregroundStyle(.white.opacity(0.30))
                                                }
                                            }
                                            Spacer()
                                            Button {
                                                UIPasteboard.general.string = row.key
                                            } label: {
                                                Image(systemName: "doc.on.doc")
                                            }
                                            .buttonStyle(.plain)
                                            Button {
                                                Task { await manager.deleteKey(row.key) }
                                            } label: {
                                                Image(systemName: "trash.fill")
                                                    .foregroundStyle(.red)
                                            }
                                            .buttonStyle(.plain)
                                        }
                                        .padding(10)
                                        .background(Color.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                                    }
                                }

                                if !manager.keys.isEmpty {
                                    Button(role: .destructive) {
                                        Task { await manager.deleteAllKeys() }
                                    } label: {
                                        Label("Xoá tất cả key", systemImage: "trash")
                                            .frame(maxWidth: .infinity)
                                    }
                                    .buttonStyle(.plain)
                                    .padding(.top, 4)
                                }

                                if let error = manager.error, !error.isEmpty {
                                    Text(error)
                                        .font(.caption)
                                        .foregroundStyle(.red)
                                }
                            }
                            .padding(16)
                        }
                    }
                    .foregroundStyle(.white)
                    .padding(12)
                }
                .background(ShinnModernBackground())
                .navigationTitle("Owner Keys")
                .navigationBarTitleDisplayMode(.inline)
                .task {
                    await manager.listKeys()
                    if let data = UserDefaults.standard.data(forKey: "shinn.owner.keyArtwork"),
                       let image = UIImage(data: data) {
                        keyArtwork = image
                    }
                }
            } else {
                Text("Owner only")
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .background(ShinnModernBackground())
            }
        }
    }
}

private extension UIImage {
    func shinnKeyPreview(maxDimension: CGFloat) -> UIImage {
        let largestDimension = Swift.max(size.width, size.height)
        guard largestDimension > 0 else { return self }
        let scale = Swift.min(CGFloat(1), maxDimension / largestDimension)
        guard scale < 1 else { return self }
        let target = CGSize(width: size.width * scale, height: size.height * scale)
        let renderer = UIGraphicsImageRenderer(size: target)
        return renderer.image { _ in
            draw(in: CGRect(origin: .zero, size: target))
        }
    }
}

private func ownerExpiryDate(_ raw: String?) -> Date? {
    guard let raw, !raw.isEmpty else { return nil }
    let f1 = ISO8601DateFormatter()
    f1.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
    if let date = f1.date(from: raw) { return date }
    let f2 = ISO8601DateFormatter()
    f2.formatOptions = [.withInternetDateTime]
    return f2.date(from: raw)
}

private func ownerRemainingText(_ raw: String?, now: Date) -> String {
    guard let date = ownerExpiryDate(raw) else { return "Vĩnh viễn" }
    let seconds = max(0, Int(date.timeIntervalSince(now)))
    if seconds == 0 { return "ĐÃ HẾT HẠN" }
    let days = seconds / 86_400
    let hours = (seconds % 86_400) / 3_600
    let minutes = (seconds % 3_600) / 60
    if days > 0 { return "Còn \(days)d \(hours)h" }
    if hours > 0 { return "Còn \(hours)h \(minutes)m" }
    return "Còn \(max(1, minutes))m"
}

private struct ShinnModernPrimaryButtonStyle: ButtonStyle {
    var tint: Color = ShinnModernPalette.blue
    var compact = false

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: compact ? 13 : 15, weight: .black, design: .rounded))
            .foregroundStyle(.white)
            .padding(.vertical, compact ? 0 : 14)
            .frame(maxWidth: .infinity)
            .background(LinearGradient(colors: [tint, tint.opacity(0.68)], startPoint: .topLeading, endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: compact ? 15 : 16, style: .continuous))
            .scaleEffect(configuration.isPressed ? 0.97 : 1)
            .animation(.spring(response: 0.22, dampingFraction: 0.75), value: configuration.isPressed)
    }
}
