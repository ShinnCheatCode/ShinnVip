import SwiftUI
import UIKit
import PhotosUI

// MARK: - Modern Shinn UI
// This file is the visual shell only. Existing RepoStore, LicenseManager,
// patch/file services and owner tooling remain untouched.

private enum ShinnModernTab: Int, CaseIterable {
    case home, patch, ai, community, more

    var title: String {
        switch self {
        case .home: return "Trang chủ"
        case .patch: return "Patch"
        case .ai: return "AI"
        case .community: return "Cộng đồng"
        case .more: return "Thêm"
        }
    }

    var icon: String {
        switch self {
        case .home: return "house.fill"
        case .patch: return "square.grid.2x2.fill"
        case .ai: return "sparkles"
        case .community: return "person.2.fill"
        case .more: return "ellipsis"
        }
    }
}

private enum ShinnModernDestination: String, Identifiable {
    case premium, key, files, settings, patchProjects, ownerKeys, repositoryManager
    var id: String { rawValue }
}

private enum ShinnModernPalette {
    static let bg = Color(red: 0.008, green: 0.015, blue: 0.027)
    static let card = Color(red: 0.045, green: 0.065, blue: 0.090)
    static let card2 = Color(red: 0.025, green: 0.045, blue: 0.070)
    static let blue = Color(red: 0.08, green: 0.56, blue: 1.0)
    static let cyan = Color(red: 0.08, green: 0.82, blue: 1.0)
    static let purple = Color(red: 0.63, green: 0.25, blue: 1.0)
    static let green = Color(red: 0.15, green: 0.86, blue: 0.65)
    static let orange = Color(red: 1.0, green: 0.30, blue: 0.20)
}

private struct ShinnModernBackground: View {
    var body: some View {
        ZStack {
            ShinnModernPalette.bg.ignoresSafeArea()
            RadialGradient(
                colors: [ShinnModernPalette.blue.opacity(0.16), .clear],
                center: .topTrailing,
                startRadius: 20,
                endRadius: 480
            ).ignoresSafeArea()
            RadialGradient(
                colors: [ShinnModernPalette.purple.opacity(0.10), .clear],
                center: .bottomLeading,
                startRadius: 20,
                endRadius: 420
            ).ignoresSafeArea()
        }
    }
}

private struct ShinnModernCard<Content: View>: View {
    let content: Content
    var radius: CGFloat = 20
    var stroke: Color = Color.white.opacity(0.08)

    init(radius: CGFloat = 20, stroke: Color = Color.white.opacity(0.08), @ViewBuilder content: () -> Content) {
        self.radius = radius
        self.stroke = stroke
        self.content = content()
    }

    var body: some View {
        content
            .background(
                RoundedRectangle(cornerRadius: radius, style: .continuous)
                    .fill(.ultraThinMaterial)
                    .overlay(
                        RoundedRectangle(cornerRadius: radius, style: .continuous)
                            .fill(ShinnModernPalette.card.opacity(0.70))
                    )
                    .overlay(
                        RoundedRectangle(cornerRadius: radius, style: .continuous)
                            .stroke(stroke, lineWidth: 1)
                    )
            )
    }
}

private struct ShinnModernPill: View {
    let text: String
    let tint: Color

    var body: some View {
        Text(text)
            .font(.system(size: 10, weight: .bold, design: .rounded))
            .foregroundStyle(.white)
            .padding(.horizontal, 9)
            .padding(.vertical, 5)
            .background(tint.opacity(0.22), in: Capsule())
            .overlay(Capsule().stroke(tint.opacity(0.45), lineWidth: 0.7))
    }
}

private struct ShinnModernIcon: View {
    let systemName: String
    let tint: Color
    var size: CGFloat = 48

    var body: some View {
        Image(systemName: systemName)
            .font(.system(size: size * 0.38, weight: .bold))
            .foregroundStyle(.white)
            .frame(width: size, height: size)
            .background(tint.opacity(0.20), in: RoundedRectangle(cornerRadius: size * 0.28, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: size * 0.28, style: .continuous).stroke(tint.opacity(0.30), lineWidth: 0.8))
    }
}

struct ShinnModernRootView: View {
    @EnvironmentObject private var store: RepoStore
    @EnvironmentObject private var license: LicenseManager
    @EnvironmentObject private var session: Session

    @State private var tab: ShinnModernTab = .home
    @State private var destination: ShinnModernDestination?
    @State private var patchCategory: String?
    @State private var showSplash = true

    var body: some View {
        ZStack {
            ShinnModernBackground()

            Group {
                switch tab {
                case .home:
                    ShinnModernHomeView(tab: $tab, destination: $destination, patchCategory: $patchCategory)
                case .patch:
                    ShinnModernPatchView(destination: $destination, initialCategory: $patchCategory)
                case .ai:
                    ShinnModernAIView()
                case .community:
                    ShinnModernCommunityView()
                case .more:
                    ShinnModernMoreView(destination: $destination, session: session)
                }
            }
            .transition(.opacity)

            if showSplash {
                ShinnModernSplashView()
                    .transition(.opacity)
                    .zIndex(10)
            }
        }
        .safeAreaInset(edge: .bottom, spacing: 0) {
            ShinnModernTabBar(selection: $tab)
                .opacity(showSplash ? 0 : 1)
                .allowsHitTesting(!showSplash)
                .padding(.horizontal, 10)
                .padding(.bottom, 5)
        }
        .sheet(item: $destination) { destination in
            NavigationStack {
                switch destination {
                case .premium:
                    ShinnModernPremiumView(destination: $destination)
                case .key:
                    ShinnModernKeyView()
                case .files:
                    FilesTabSwitcherView(session: .constant(FilesTabSession()))
                case .settings:
                    ShinnSettingsHubView()
                case .patchProjects:
                    PatchProjectsView()
                case .ownerKeys:
                    ShinnModernOwnerKeysView()
                case .repositoryManager:
                    RepositoryManagerView()
                }
            }
            .preferredColorScheme(.dark)
        }
        .task {
            try? await Task.sleep(nanoseconds: 1_450_000_000)
            withAnimation(.easeOut(duration: 0.35)) { showSplash = false }
        }
    }
}

private struct ShinnModernSplashView: View {
    @State private var progress = 0.0

    var body: some View {
        ZStack {
            ShinnModernBackground()
            VStack(spacing: 18) {
                Image("ShinnSplashArt")
                    .resizable()
                    .scaledToFill()
                    .frame(width: 235, height: 310)
                    .clipShape(RoundedRectangle(cornerRadius: 34, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 34).stroke(ShinnModernPalette.blue.opacity(0.65), lineWidth: 1))
                    .shadow(color: ShinnModernPalette.blue.opacity(0.30), radius: 28)

                Text("Shinn Cheat")
                    .font(.system(size: 34, weight: .black, design: .rounded))
                Text("Play Smarter · Win Easier")
                    .font(.system(size: 13, weight: .semibold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.55))

                VStack(spacing: 8) {
                    ProgressView(value: progress)
                        .tint(ShinnModernPalette.blue)
                        .frame(width: 230)
                    Text("Đang khởi động…")
                        .font(.system(size: 11, weight: .medium, design: .rounded))
                        .foregroundStyle(.white.opacity(0.45))
                }
            }
            .foregroundStyle(.white)
        }
        .task {
            withAnimation(.easeInOut(duration: 1.2)) { progress = 1 }
        }
    }
}

private struct ShinnModernTabBar: View {
    @Binding var selection: ShinnModernTab

    var body: some View {
        HStack(spacing: 4) {
            ForEach(ShinnModernTab.allCases, id: \.self) { item in
                Button {
                    withAnimation(.spring(response: 0.28, dampingFraction: 0.82)) { selection = item }
                } label: {
                    VStack(spacing: 4) {
                        Image(systemName: item.icon)
                            .font(.system(size: 17, weight: .bold))
                        Text(item.title)
                            .font(.system(size: 8.5, weight: .semibold, design: .rounded))
                    }
                    .foregroundStyle(selection == item ? ShinnModernPalette.cyan : .white.opacity(0.48))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 8)
                    .background(selection == item ? ShinnModernPalette.blue.opacity(0.13) : .clear, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                }
                .buttonStyle(.plain)
            }
        }
        .padding(5)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 21, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 21).stroke(ShinnModernPalette.blue.opacity(0.25), lineWidth: 0.8))
    }
}

private struct ShinnModernHomeView: View {
    @EnvironmentObject private var store: RepoStore
    @EnvironmentObject private var license: LicenseManager
    @EnvironmentObject private var session: Session
    @Binding var tab: ShinnModernTab
    @Binding var destination: ShinnModernDestination?
    @Binding var patchCategory: String?

    private var count: Int { store.packages.count }

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 16) {
                hero
                keyStatusCard
                sectionHeader("Danh mục", trailing: "\(count) patch")
                categoryGrid
                utilityGrid
                premiumCard
                aiCard
                communityCard
            }
            .padding(.horizontal, 12)
            .padding(.top, 4)
            .padding(.bottom, 14)
        }
        .refreshable { await store.refresh() }
    }

    private var hero: some View {
        ZStack(alignment: .bottomLeading) {
            Image("ShinnHeroArt")
                .resizable()
                .scaledToFill()
                .frame(height: 148)
                .clipped()
            LinearGradient(colors: [.clear, .black.opacity(0.95)], startPoint: .center, endPoint: .bottom)
            VStack(alignment: .leading, spacing: 5) {
                Text("WELCOME TO")
                    .font(.system(size: 11, weight: .black, design: .rounded))
                    .tracking(2.4)
                    .foregroundStyle(ShinnModernPalette.cyan)
                Text("Shinn Cheat")
                    .font(.system(size: 24, weight: .black, design: .rounded))
                Text("Patch Center · Community · AI")
                    .font(.system(size: 12, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.55))
            }
            .padding(16)
        }
        .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 24).stroke(ShinnModernPalette.blue.opacity(0.30), lineWidth: 1))
        .shadow(color: ShinnModernPalette.blue.opacity(0.12), radius: 24, y: 8)
    }

    private var keyStatusCard: some View {
        ShinnModernCard(
            radius: 24,
            stroke: session.role == .owner
                ? ShinnModernPalette.cyan.opacity(0.42)
                : ShinnModernPalette.blue.opacity(0.28)
        ) {
            VStack(alignment: .leading, spacing: 12) {
                HStack(spacing: 12) {
                    ZStack {
                        Circle()
                            .fill(
                                LinearGradient(
                                    colors: [ShinnModernPalette.blue, ShinnModernPalette.cyan],
                                    startPoint: .topLeading,
                                    endPoint: .bottomTrailing
                                )
                            )
                            .frame(width: 54, height: 54)
                        Image(systemName: session.role == .owner ? "crown.fill" : "key.fill")
                            .font(.system(size: 21, weight: .black))
                            .foregroundStyle(.white)
                    }

                    VStack(alignment: .leading, spacing: 3) {
                        HStack(spacing: 7) {
                            Text(session.role == .owner ? "SHINN CHEAT" : "SHINN CHEAT")
                                .font(.system(size: 18, weight: .black, design: .rounded))
                            if session.role == .owner {
                                ShinnModernPill(text: "OWNER", tint: ShinnModernPalette.green)
                            }
                        }

                        Text(license.isActivated
                             ? (license.holderName.isEmpty ? "Key đang sử dụng" : license.holderName)
                             : "Chưa kích hoạt key · Repo V1")
                            .font(.system(size: 11, weight: .bold, design: .rounded))
                            .foregroundStyle(ShinnModernPalette.cyan)
                    }

                    Spacer()
                }

                HStack(spacing: 8) {
                    keyInfoPill(
                        title: "KEY",
                        value: license.isActivated
                            ? (license.savedLicenseKey.isEmpty ? "Đã kích hoạt" : license.savedLicenseKey)
                            : "FREE / V1"
                    )

                    if let expires = license.expiresAt {
                        TimelineView(.periodic(from: .now, by: 1)) { context in
                            keyInfoPill(
                                title: "THỜI HẠN",
                                value: homeRemainingText(until: expires, now: context.date)
                            )
                        }
                    } else {
                        keyInfoPill(title: "THỜI HẠN", value: license.isActivated ? "Vĩnh viễn" : "—")
                    }
                }

                if license.isActivated {
                    HStack(spacing: 8) {
                        statusPill(
                            title: "PATCH",
                            value: store.packages.isEmpty ? "READY" : "\(store.packages.count)",
                            tint: ShinnModernPalette.cyan
                        )
                        statusPill(
                            title: "REPO",
                            value: store.isRepoV2Authorized ? "V2 OPEN" : "V1",
                            tint: store.isRepoV2Authorized ? ShinnModernPalette.green : ShinnModernPalette.blue
                        )
                        statusPill(
                            title: "KEY",
                            value: store.isRepoV2Authorized ? "OK" : "V1",
                            tint: store.isRepoV2Authorized ? ShinnModernPalette.green : ShinnModernPalette.orange
                        )
                    }

                    HStack(spacing: 8) {
                        if session.role == .owner {
                            Button { destination = .ownerKeys } label: {
                                Label("Owner Panel", systemImage: "crown.fill")
                                    .frame(maxWidth: .infinity)
                            }
                            .buttonStyle(ShinnModernPrimaryButtonStyle(tint: ShinnModernPalette.purple, compact: true))
                        } else {
                            Button { destination = .key } label: {
                                Label("Đổi / Nhập key", systemImage: "key.fill")
                                    .frame(maxWidth: .infinity)
                            }
                            .buttonStyle(ShinnModernPrimaryButtonStyle(tint: ShinnModernPalette.blue, compact: true))
                        }

                        Button {
                            license.signOutLicense()
                            session.role = nil
                            Task { await store.selectRepo(v2: false) }
                        } label: {
                            Label("Đăng xuất", systemImage: "rectangle.portrait.and.arrow.right")
                                .frame(maxWidth: .infinity)
                        }
                        .buttonStyle(ShinnModernPrimaryButtonStyle(tint: .red, compact: true))
                    }

                    if session.role == .owner {
                        Button { destination = .repositoryManager } label: {
                            HStack {
                                ShinnModernIcon(systemName: "folder.badge.gearshape", tint: ShinnModernPalette.cyan, size: 38)
                                VStack(alignment: .leading, spacing: 2) {
                                    Text("Repository Manager")
                                        .font(.system(size: 13, weight: .black, design: .rounded))
                                    Text("Quản lý Repo V1 · V2 và quyền key")
                                        .font(.system(size: 9.5, weight: .medium, design: .rounded))
                                        .foregroundStyle(.white.opacity(0.45))
                                }
                                Spacer()
                                Image(systemName: "chevron.right")
                                    .foregroundStyle(.white.opacity(0.3))
                            }
                        }
                        .buttonStyle(.plain)
                    }
                } else {
                    Button { destination = .key } label: {
                        Label("Nhập key để mở Repo V2", systemImage: "key.fill")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(ShinnModernPrimaryButtonStyle(tint: ShinnModernPalette.blue, compact: true))
                }
            }
            .padding(15)
        }
    }

    private func statusPill(title: String, value: String, tint: Color) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(title)
                .font(.system(size: 7.5, weight: .black, design: .rounded))
                .foregroundStyle(.white.opacity(0.34))
            Text(value)
                .font(.system(size: 9.5, weight: .black, design: .rounded))
                .foregroundStyle(tint)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.horizontal, 9)
        .padding(.vertical, 7)
        .background(Color.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 11, style: .continuous))
    }

    private func keyInfoPill(title: String, value: String) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(title.uppercased())
                .font(.system(size: 8, weight: .black, design: .rounded))
                .foregroundStyle(.white.opacity(0.38))
            Text(value)
                .font(.system(size: 10, weight: .bold, design: .rounded))
                .foregroundStyle(.white)
                .lineLimit(1)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.horizontal, 10)
        .padding(.vertical, 8)
        .background(Color.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
    }

    private func homeRemainingText(until date: Date, now: Date) -> String {
        let seconds = max(0, Int(date.timeIntervalSince(now)))
        if seconds == 0 { return "Đã hết hạn" }
        let days = seconds / 86_400
        let hours = (seconds % 86_400) / 3_600
        let minutes = (seconds % 3_600) / 60
        if days > 0 { return "\(days)d \(hours)h" }
        if hours > 0 { return "\(hours)h \(minutes)m" }
        return "\(max(1, minutes))m"
    }

    private var categoryGrid: some View {
        LazyVGrid(columns: [GridItem(.flexible(), spacing: 12), GridItem(.flexible(), spacing: 12)], spacing: 12) {
            categoryCard("Free Fire", "PATCH", "flame.fill", .red, "Free Fire")
            categoryCard("Free Fire Max", "MAX", "bolt.fill", ShinnModernPalette.purple, "Free Fire Max")
            categoryCard("Liên Quân", "MOBA", "gamecontroller.fill", ShinnModernPalette.blue, "Liên Quân")
            categoryCard("CapCut", "TOOLS", "scissors", ShinnModernPalette.green, "CapCut")
        }
    }

    private func categoryCard(_ title: String, _ subtitle: String, _ icon: String, _ tint: Color, _ category: String) -> some View {
        Button {
            patchCategory = category
            tab = .patch
        } label: {
            VStack(alignment: .leading, spacing: 15) {
                HStack {
                    ShinnModernIcon(systemName: icon, tint: tint, size: 50)
                    Spacer()
                    Image(systemName: "chevron.right")
                        .font(.system(size: 18, weight: .bold))
                        .foregroundStyle(.white.opacity(0.35))
                }
                Spacer(minLength: 0)
                Text(title)
                    .font(.system(size: 15, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                Text(subtitle)
                    .font(.system(size: 10, weight: .bold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.40))
            }
            .frame(maxWidth: .infinity, minHeight: 112, alignment: .leading)
            .padding(11)
            .background(ShinnModernPalette.card.opacity(0.78), in: RoundedRectangle(cornerRadius: 26, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 26).stroke(tint.opacity(0.40), lineWidth: 1))
        }
        .buttonStyle(.plain)
        .accessibilityLabel("Mở \(category)")
    }

    private var utilityGrid: some View {
        HStack(spacing: 10) {
            homeUtility("Kho Patch", "Tất cả patch", "square.grid.2x2.fill", ShinnModernPalette.cyan) { patchCategory = nil; tab = .patch }
            homeUtility("Tệp", "File manager", "folder.fill", ShinnModernPalette.blue) { destination = .files }
            homeUtility("Cài đặt", "Giao diện", "slider.horizontal.3", ShinnModernPalette.cyan) { destination = .settings }
        }
    }

    private func homeUtility(_ title: String, _ subtitle: String, _ icon: String, _ tint: Color, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 9) {
                Image(systemName: icon).font(.system(size: 21, weight: .bold)).foregroundStyle(tint)
                Text(title).font(.system(size: 14, weight: .black, design: .rounded))
                Text(subtitle).font(.system(size: 10, weight: .medium, design: .rounded)).foregroundStyle(.white.opacity(0.38))
            }
            .frame(maxWidth: .infinity, minHeight: 76, alignment: .leading)
            .padding(14)
            .background(ShinnModernPalette.card.opacity(0.78), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.white.opacity(0.07), lineWidth: 0.8))
        }
        .buttonStyle(.plain)
    }

    private var premiumCard: some View {
        Button { destination = .premium } label: {
            HStack(spacing: 14) {
                ShinnModernIcon(systemName: "crown.fill", tint: ShinnModernPalette.purple, size: 50)
                VStack(alignment: .leading, spacing: 4) {
                    Text("Premium Repo").font(.system(size: 17, weight: .black, design: .rounded))
                    Text(license.isActivated ? "Đã mở khóa Repo 2" : "Mở khóa Repo 2")
                        .font(.system(size: 12, weight: .medium, design: .rounded))
                        .foregroundStyle(.white.opacity(0.46))
                }
                Spacer()
                Text("OPEN")
                    .font(.system(size: 11, weight: .black, design: .rounded))
                    .padding(.horizontal, 13).padding(.vertical, 9)
                    .background(ShinnModernPalette.purple.opacity(0.65), in: Capsule())
            }
            .padding(16)
            .background(ShinnModernPalette.card.opacity(0.80), in: RoundedRectangle(cornerRadius: 23, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 23).stroke(ShinnModernPalette.purple.opacity(0.38), lineWidth: 1))
        }
        .buttonStyle(.plain)
    }

    private var aiCard: some View {
        Button { tab = .ai } label: {
            HStack(spacing: 14) {
                Image("ShinnAIArt")
                    .resizable().scaledToFill()
                    .frame(width: 50, height: 50)
                    .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                VStack(alignment: .leading, spacing: 4) {
                    Text("Shinn AI").font(.system(size: 17, weight: .black, design: .rounded))
                    Text("Commands · Support · Patch helper")
                        .font(.system(size: 12, weight: .medium, design: .rounded))
                        .foregroundStyle(.white.opacity(0.46))
                }
                Spacer()
                Image(systemName: "sparkles").foregroundStyle(ShinnModernPalette.cyan)
            }
            .padding(16)
            .background(ShinnModernPalette.card.opacity(0.80), in: RoundedRectangle(cornerRadius: 23, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 23).stroke(ShinnModernPalette.blue.opacity(0.25), lineWidth: 1))
        }
        .buttonStyle(.plain)
    }

    private var communityCard: some View {
        Button { tab = .community } label: {
            HStack(spacing: 14) {
                ShinnModernIcon(systemName: "paperplane.fill", tint: ShinnModernPalette.blue, size: 50)
                VStack(alignment: .leading, spacing: 4) {
                    Text("Community").font(.system(size: 17, weight: .black, design: .rounded))
                    Text("Main Group · English Chat · Support")
                        .font(.system(size: 12, weight: .medium, design: .rounded))
                        .foregroundStyle(.white.opacity(0.46))
                }
                Spacer()
                Image(systemName: "chevron.right").foregroundStyle(.white.opacity(0.32))
            }
            .padding(16)
            .background(ShinnModernPalette.card.opacity(0.80), in: RoundedRectangle(cornerRadius: 23, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 23).stroke(ShinnModernPalette.blue.opacity(0.25), lineWidth: 1))
        }
        .buttonStyle(.plain)
    }

    private func sectionHeader(_ title: String, trailing: String) -> some View {
        HStack(alignment: .bottom) {
            Text(title).font(.system(size: 22, weight: .black, design: .rounded))
            Spacer()
            Text(trailing).font(.system(size: 13, weight: .semibold, design: .rounded)).foregroundStyle(.white.opacity(0.35))
        }
        .foregroundStyle(.white)
    }
}

private struct ShinnModernPatchView: View {
    @EnvironmentObject private var store: RepoStore
    @Binding var destination: ShinnModernDestination?
    @Binding var initialCategory: String?
    @State private var selectedCategory = "Tất cả"
    @State private var selectedPackage: RepoPackage?

    private var categories: [String] { ["Tất cả", "Free Fire", "Free Fire Max", "Liên Quân", "CapCut", "Khác"] }

    private var filtered: [RepoPackage] {
        // Repo V2 is not even displayed until the current key is authorized.
        guard !store.usingRepoV2 || store.isRepoV2Authorized else { return [] }
        guard selectedCategory != "Tất cả" else { return store.packages }
        return store.packages.filter { matches($0, category: selectedCategory) }
    }

    var body: some View {
        NavigationStack {
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 14) {
                    HStack(alignment: .bottom) {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Kho Patch").font(.system(size: 27, weight: .black, design: .rounded))
                            Text("Repo V1 + Repo V2").font(.system(size: 11, weight: .medium, design: .rounded)).foregroundStyle(.white.opacity(0.48))
                        }
                        Spacer()
                        Text("\(filtered.count)").font(.system(size: 20, weight: .black, design: .rounded)).foregroundStyle(ShinnModernPalette.cyan)
                    }

                    HStack(spacing: 7) {
                        repoSourceButton(title: "Repo V1", v2: false)
                        repoSourceButton(title: store.isRepoV2Authorized ? "Repo V2" : "Repo V2 🔒", v2: true)
                    }

                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 8) {
                            ForEach(categories, id: \.self) { item in
                                Button { selectedCategory = item } label: {
                                    Text(item)
                                        .font(.system(size: 11, weight: .bold, design: .rounded))
                                        .foregroundStyle(selectedCategory == item ? .white : .white.opacity(0.55))
                                        .padding(.horizontal, 14).padding(.vertical, 9)
                                        .background(selectedCategory == item ? ShinnModernPalette.blue : Color.white.opacity(0.06), in: Capsule())
                                }
                                .buttonStyle(.plain)
                            }
                        }
                    }

                    if store.usingRepoV2 && !store.isRepoV2Authorized {
                        ShinnModernCard(radius: 22, stroke: ShinnModernPalette.purple.opacity(0.35)) {
                            VStack(spacing: 12) {
                                Image(systemName: "lock.fill")
                                    .font(.system(size: 28, weight: .black))
                                    .foregroundStyle(ShinnModernPalette.purple)
                                Text("Repo V2 đã khóa")
                                    .font(.system(size: 19, weight: .black, design: .rounded))
                                Text("Nhập key được Owner cấp để xem và sử dụng patch V2.")
                                    .font(.system(size: 12, weight: .medium, design: .rounded))
                                    .foregroundStyle(.white.opacity(0.48))
                                    .multilineTextAlignment(.center)
                                Button { destination = .key } label: {
                                    Label("Nhập key V2", systemImage: "key.fill")
                                        .frame(maxWidth: .infinity)
                                }
                                .buttonStyle(ShinnModernPrimaryButtonStyle(tint: ShinnModernPalette.purple))
                            }
                            .padding(18)
                        }
                    } else {
                        LazyVStack(spacing: 8) {
                            ForEach(filtered) { pkg in
                            ShinnModernPatchRow(pkg: pkg) {
                                selectedPackage = pkg
                            } download: {
                                Task { await store.download(pkg) }
                            }
                        }
                        }
                    }
                }
                .padding(.horizontal, 16)
                .padding(.top, 8)
                .padding(.bottom, 20)
            }
            .refreshable { await store.refresh() }
            .onAppear {
                if let initialCategory { selectedCategory = initialCategory }
            }
            .navigationBarHidden(true)
            .sheet(item: $selectedPackage) { pkg in
                NavigationStack { ShinnModernPatchDetail(pkg: pkg) }
                    .preferredColorScheme(.dark)
            }
        }
    }

    private func repoSourceButton(title: String, v2: Bool) -> some View {
        Button {
            guard !v2 || store.isRepoV2Authorized else { return }
            Task { await store.selectRepo(v2: v2) }
        } label: {
            HStack(spacing: 5) {
                Image(systemName: v2 ? (store.isRepoV2Authorized ? "crown.fill" : "lock.fill") : "square.stack.3d.up.fill")
                Text(title)
            }
            .font(.system(size: 10.5, weight: .bold, design: .rounded))
            .foregroundStyle(store.usingRepoV2 == v2 ? .white : .white.opacity(0.55))
            .frame(maxWidth: .infinity)
            .padding(.vertical, 8)
            .background(store.usingRepoV2 == v2 ? ShinnModernPalette.blue : Color.white.opacity(0.06), in: Capsule())
        }
        .buttonStyle(.plain)
    }

    private func matches(_ pkg: RepoPackage, category: String) -> Bool {
        let value = "\(pkg.category ?? "") \(pkg.name) \(pkg.summary ?? "")".lowercased()
        switch category {
        case "Free Fire": return value.contains("free fire") && !value.contains("max")
        case "Free Fire Max": return value.contains("free fire max") || value.contains("ff max")
        case "Liên Quân": return value.contains("liên quân") || value.contains("lien quan") || value.contains("moba")
        case "CapCut": return value.contains("capcut") || value.contains("cap cut")
        case "Khác": return !categories.dropFirst().dropLast().contains(where: { matches(pkg, category: $0) })
        default: return true
        }
    }
}

private struct ShinnModernPatchRow: View {
    @EnvironmentObject private var store: RepoStore
    let pkg: RepoPackage
    let action: () -> Void
    let download: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 12) {
                Image("ShinnPatchArt")
                    .resizable().scaledToFill()
                    .frame(width: 48, height: 48)
                    .clipShape(Circle())
                    .overlay(Circle().stroke(ShinnModernPalette.blue.opacity(0.6), lineWidth: 1))

                VStack(alignment: .leading, spacing: 3) {
                    HStack(spacing: 7) {
                        Text(pkg.name)
                            .font(.system(size: 14, weight: .bold, design: .rounded))
                            .foregroundStyle(.white)
                            .lineLimit(1)
                        if pkg.tags?.contains(where: { $0.lowercased().contains("hot") }) == true {
                            ShinnModernPill(text: "Hot", tint: .red)
                        }
                    }
                    Text(pkg.summary ?? pkg.description ?? "Patch")
                        .font(.system(size: 10, weight: .medium, design: .rounded))
                        .foregroundStyle(.white.opacity(0.42))
                        .lineLimit(1)
                }
                Spacer(minLength: 4)
                Button(action: download) {
                    switch store.state(for: pkg) {
                    case .downloading:
                        ProgressView().tint(.white).frame(width: 34, height: 34)
                    case .done:
                        Image(systemName: "checkmark.circle.fill").foregroundStyle(ShinnModernPalette.green).frame(width: 34, height: 34)
                    default:
                        Image(systemName: "arrow.down.circle.fill").foregroundStyle(ShinnModernPalette.cyan).frame(width: 34, height: 34)
                    }
                }
                .buttonStyle(.plain)
            }
            .padding(12)
            .background(ShinnModernPalette.card.opacity(0.80), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 18).stroke(Color.white.opacity(0.06), lineWidth: 0.8))
        }
        .buttonStyle(.plain)
    }
}

private struct ShinnModernPatchDetail: View {
    @EnvironmentObject private var store: RepoStore
    let pkg: RepoPackage

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 16) {
                Image("ShinnPatchArt")
                    .resizable().scaledToFill()
                    .frame(height: 210)
                    .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))

                Text(pkg.name).font(.system(size: 28, weight: .black, design: .rounded))
                Text(pkg.summary ?? pkg.description ?? "Patch")
                    .foregroundStyle(.white.opacity(0.58))

                ShinnModernCard {
                    VStack(alignment: .leading, spacing: 10) {
                        detail("Category", pkg.category ?? "Other")
                        detail("Version", pkg.version ?? "—")
                        detail("Size", pkg.size.map { ByteCountFormatter.string(fromByteCount: Int64($0), countStyle: .file) } ?? "—")
                        detail("SHA-256", pkg.sha256 ?? "—")
                        detail("Path", pkg.patchPath ?? "—")
                    }
                    .padding(16)
                }

                Button { Task { await store.download(pkg) } } label: {
                    Label("Tải patch", systemImage: "arrow.down.circle.fill")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(ShinnModernPrimaryButtonStyle())
            }
            .padding(16)
        }
        .background(ShinnModernBackground())
        .navigationTitle("Patch")
        .navigationBarTitleDisplayMode(.inline)
    }

    private func detail(_ key: String, _ value: String) -> some View {
        HStack(alignment: .top) {
            Text(key).foregroundStyle(.white.opacity(0.45)).frame(width: 75, alignment: .leading)
            Text(value).font(.system(size: 12, weight: .medium, design: .monospaced)).foregroundStyle(.white).lineLimit(2)
            Spacer()
        }
    }
}

private struct ShinnModernPremiumView: View {
    @EnvironmentObject private var store: RepoStore
    @EnvironmentObject private var license: LicenseManager
    @Binding var destination: ShinnModernDestination?
    @State private var key = ""
    @State private var message = ""
    @State private var busy = false

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 16) {
                Image("ShinnHeroArt")
                    .resizable().scaledToFill()
                    .frame(height: 180)
                    .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))

                ShinnModernCard(radius: 24, stroke: ShinnModernPalette.purple.opacity(0.35)) {
                    VStack(spacing: 12) {
                        Image(systemName: "crown.fill")
                            .font(.system(size: 34, weight: .black))
                            .foregroundStyle(ShinnModernPalette.purple)
                        Text("Repo 2 - Premium").font(.system(size: 22, weight: .black, design: .rounded))
                        benefit("Nhiều patch độc quyền")
                        benefit("Cập nhật sớm nhất")
                        benefit("Hỗ trợ 24/7")
                        benefit("Sử dụng key để mở khóa")
                    }
                    .padding(18)
                }

                Button { destination = .key } label: {
                    Label("Nhập key", systemImage: "key.fill").frame(maxWidth: .infinity)
                }
                .buttonStyle(ShinnModernPrimaryButtonStyle(tint: ShinnModernPalette.purple))

                if !message.isEmpty {
                    Text(message).font(.footnote).foregroundStyle(.red).multilineTextAlignment(.center)
                }

                Button { UIApplication.shared.open(AppInfo.telegramLinkURL) } label: {
                    HStack { ShinnModernIcon(systemName: "paperplane.fill", tint: ShinnModernPalette.blue, size: 42); Text("Chưa có key? Liên hệ Telegram để mua key Premium"); Spacer(); Image(systemName: "chevron.right") }
                        .padding(13)
                }
                .buttonStyle(.plain)
                .background(ShinnModernPalette.card.opacity(0.78), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            }
            .padding(16)
        }
        .background(ShinnModernBackground())
        .navigationTitle("Premium Repo")
        .navigationBarTitleDisplayMode(.inline)
    }

    private func benefit(_ text: String) -> some View {
        HStack { Image(systemName: "checkmark.circle.fill").foregroundStyle(ShinnModernPalette.blue); Text(text); Spacer() }
            .font(.system(size: 13, weight: .medium, design: .rounded))
    }
}

private struct ShinnModernKeyView: View {
    @EnvironmentObject private var store: RepoStore
    @EnvironmentObject private var license: LicenseManager
    @Environment(\.dismiss) private var dismiss
    @State private var key = ""
    @State private var busy = false
    @State private var message = ""

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 18) {
                Spacer(minLength: 20)
                ShinnModernCard(radius: 25, stroke: ShinnModernPalette.blue.opacity(0.30)) {
                    VStack(spacing: 15) {
                        Image(systemName: "crown.fill")
                            .font(.system(size: 36, weight: .black))
                            .foregroundStyle(.white)
                            .frame(width: 72, height: 72)
                            .background(ShinnModernPalette.blue.opacity(0.20), in: Circle())
                        Text("Premium Key").font(.system(size: 23, weight: .black, design: .rounded))
                        SecureField("Nhập key của bạn…", text: $key)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled(true)
                            .padding(15)
                            .background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                        Button {
                            Task { await activate() }
                        } label: {
                            if busy { ProgressView().tint(.white) } else { Text("Xác nhận") }
                        }
                        .buttonStyle(ShinnModernPrimaryButtonStyle())
                        Button("Kiểm tra key") { Task { await activate() } }
                            .font(.system(size: 12, weight: .semibold, design: .rounded))
                            .foregroundStyle(ShinnModernPalette.cyan)

                        Button {
                            // Skip is deliberately V1-only: no key, no V2 access.
                            UserDefaults.standard.set(true, forKey: "shinn.key.skipped")
                            Task {
                                await store.selectRepo(v2: false)
                                dismiss()
                            }
                        } label: {
                            Text("Bỏ qua · vào app với Repo V1")
                                .font(.system(size: 12, weight: .semibold, design: .rounded))
                                .foregroundStyle(.white.opacity(0.55))
                        }
                    }
                    .padding(18)
                }
                if !message.isEmpty { Text(message).font(.footnote).foregroundStyle(.red).multilineTextAlignment(.center) }
                Text("Key hợp lệ sẽ mở khóa Repo 2 và các patch đặc biệt.")
                    .font(.system(size: 11, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.40))
                    .multilineTextAlignment(.center)
            }
            .padding(16)
        }
        .background(ShinnModernBackground())
        .navigationTitle("Nhập Key")
        .navigationBarTitleDisplayMode(.inline)
    }

    private func activate() async {
        let value = key.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !value.isEmpty else { message = "Vui lòng nhập key."; return }
        busy = true
        defer { busy = false }
        let ok = await license.activate(key: value, language: .en)
        if ok && license.isActivated && store.isRepoV2Authorized {
            UserDefaults.standard.set(false, forKey: "shinn.key.skipped")
            await store.selectRepo(v2: true)
            message = "Đã xác thực key · Repo V2 đã mở khóa."
            key = ""
            dismiss()
        } else if ok && license.isActivated {
            message = license.lastError ?? "Key không hợp lệ."
        }
    }
}

private struct ShinnModernAIView: View {
    @State private var input = ""
    @State private var messages: [(String, Bool)] = [("Xin chào! 👋\nMình là Shinn AI. Bạn cần hỗ trợ gì hôm nay?", false)]
    private let commands = ["/start", "/help", "/patch", "/info", "/key", "/menu"]

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 10) {
                Image("ShinnAvatarArt").resizable().scaledToFill().frame(width: 46, height: 46).clipShape(Circle())
                VStack(alignment: .leading) { Text("Shinn AI").font(.system(size: 21, weight: .black, design: .rounded)); Text("Trợ lý AI thông minh").font(.system(size: 10, weight: .medium, design: .rounded)).foregroundStyle(.white.opacity(0.45)) }
                Spacer()
                Image(systemName: "sparkles").foregroundStyle(ShinnModernPalette.cyan)
            }
            .foregroundStyle(.white)
            .padding(.horizontal, 16).padding(.top, 8).padding(.bottom, 12)

            ScrollView(showsIndicators: false) {
                LazyVStack(alignment: .leading, spacing: 10) {
                    ForEach(Array(messages.enumerated()), id: \.offset) { _, item in
                        HStack {
                            if item.1 { Spacer() }
                            Text(item.0)
                                .font(.system(size: 13, weight: .medium, design: .rounded))
                                .foregroundStyle(.white)
                                .padding(12)
                                .background(item.1 ? ShinnModernPalette.blue.opacity(0.30) : ShinnModernPalette.card, in: RoundedRectangle(cornerRadius: 17, style: .continuous))
                            if !item.1 { Spacer() }
                        }
                    }

                    ShinnModernCard(radius: 18) {
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Các lệnh có sẵn:").font(.system(size: 12, weight: .bold, design: .rounded))
                            ForEach(commands, id: \.self) { command in
                                Button { send(command) } label: {
                                    HStack { Text(command).foregroundStyle(ShinnModernPalette.cyan); Spacer(); Text(commandDescription(command)).foregroundStyle(.white.opacity(0.45)) }
                                        .font(.system(size: 11, weight: .medium, design: .rounded))
                                        .padding(.vertical, 7)
                                }.buttonStyle(.plain)
                            }
                        }.padding(13)
                    }
                }
                .padding(16)
            }

            HStack(spacing: 8) {
                TextField("Nhập tin nhắn…", text: $input)
                    .textFieldStyle(.plain)
                    .foregroundStyle(.white)
                    .padding(12)
                    .background(ShinnModernPalette.card, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                Button { send(input); input = "" } label: { Image(systemName: "arrow.up").frame(width: 40, height: 40) }
                    .buttonStyle(ShinnModernPrimaryButtonStyle(compact: true))
            }
            .padding(10)
        }
    }

    private func send(_ text: String) {
        let value = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !value.isEmpty else { return }
        messages.append((value, true))
        let lower = value.lowercased()
        let reply: String
        if lower.contains("patch") { reply = "Bạn có thể mở Kho Patch để xem và tải patch mới." }
        else if lower.contains("key") { reply = "Premium Key dùng để mở khóa Repo 2. Nếu chưa có key, hãy liên hệ Admin." }
        else if lower.contains("help") || lower.contains("hướng dẫn") { reply = "Dùng /patch để tìm patch, /key để kiểm tra key và /info để xem thông tin app." }
        else if lower.contains("version") || lower.contains("info") { reply = "Shinn Cheat · Patch Center · Community · AI" }
        else { reply = "Mình sẵn sàng hỗ trợ. Thử /help để xem các lệnh." }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) { messages.append((reply, false)) }
    }

    private func commandDescription(_ command: String) -> String {
        switch command {
        case "/start": return "Bắt đầu sử dụng"
        case "/help": return "Xem danh sách lệnh"
        case "/patch": return "Tìm patch nhanh"
        case "/info": return "Thông tin app"
        case "/key": return "Kiểm tra key"
        default: return "Hiển thị menu"
        }
    }
}

private struct ShinnModernCommunityView: View {
    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 13) {
                VStack(alignment: .leading, spacing: 5) {
                    Text("Cộng đồng").font(.system(size: 30, weight: .black, design: .rounded))
                    Text("Tham gia group để nhận hỗ trợ").font(.system(size: 12, weight: .medium, design: .rounded)).foregroundStyle(.white.opacity(0.48))
                }
                community("Group chính", "ShinnCheatShare", "Cập nhật · Thông báo · Tài nguyên", AppInfo.telegramMainGroupURL)
                community("English Chat", "ShinnCheatChat", "English only · Discussion · Support", AppInfo.telegramEnglishChatURL)
                community("Hỗ trợ liên hệ", "@ShinnThieuu", "Hỗ trợ nhanh · Giải đáp thắc mắc", AppInfo.telegramLinkURL)
                Image("ShinnCatCommunity")
                    .resizable().scaledToFill().frame(height: 125).clipped()
                    .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
                    .overlay(alignment: .bottomLeading) { Text("Join our community\nStay updated!").font(.system(size: 17, weight: .black, design: .rounded)).padding(16) }
            }
            .foregroundStyle(.white)
            .padding(16)
        }
    }

    private func community(_ title: String, _ name: String, _ subtitle: String, _ url: URL) -> some View {
        Button { UIApplication.shared.open(url) } label: {
            HStack(spacing: 12) {
                ShinnModernIcon(systemName: "paperplane.fill", tint: ShinnModernPalette.blue, size: 48)
                VStack(alignment: .leading, spacing: 3) {
                    Text(title).font(.system(size: 15, weight: .black, design: .rounded))
                    Text(name).font(.system(size: 12, weight: .semibold, design: .rounded)).foregroundStyle(ShinnModernPalette.cyan)
                    Text(subtitle).font(.system(size: 10, weight: .medium, design: .rounded)).foregroundStyle(.white.opacity(0.42))
                }
                Spacer()
                Image(systemName: "chevron.right").foregroundStyle(.white.opacity(0.30))
            }
            .padding(13)
            .background(ShinnModernPalette.card.opacity(0.80), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        }
        .buttonStyle(.plain)
    }
}

private struct ShinnModernMoreView: View {
    @Binding var destination: ShinnModernDestination?
    let session: Session
    @EnvironmentObject private var license: LicenseManager
    @EnvironmentObject private var store: RepoStore

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 13) {
                Text("Thêm").font(.system(size: 30, weight: .black, design: .rounded))
                Text("Cài đặt và thông tin ứng dụng").font(.system(size: 12, weight: .medium, design: .rounded)).foregroundStyle(.white.opacity(0.48))

                moreRow("Shinn Cheat", "Play Smarter · Win Easier", "ShinnAvatarArt", nil)
                moreRow("Lịch sử tải xuống", "Patch đã tải", nil, "clock.arrow.circlepath") { }
                moreRow("Tệp của tôi", "File manager", nil, "folder.fill") { destination = .files }
                moreRow("Cài đặt", "Giao diện", nil, "gearshape.fill") { destination = .settings }
                moreRow("Hỗ trợ & Liên hệ", "@ShinnThieuu", nil, "questionmark.circle.fill") { UIApplication.shared.open(AppInfo.telegramLinkURL) }
                moreRow("Điều khoản sử dụng", "Thông tin", nil, "doc.text.fill") { }
                moreRow("Giới thiệu ứng dụng", "Shinn Cheat", nil, "info.circle.fill") { }

                if license.isActivated {
                    ShinnModernCard(radius: 18, stroke: ShinnModernPalette.cyan.opacity(0.22)) {
                        VStack(alignment: .leading, spacing: 8) {
                            HStack {
                                Image(systemName: "key.fill").foregroundStyle(ShinnModernPalette.cyan)
                                VStack(alignment: .leading, spacing: 2) {
                                    Text("Key đang đăng nhập")
                                        .font(.system(size: 14, weight: .black, design: .rounded))
                                    Text(license.holderName.isEmpty ? license.savedLicenseKey : license.holderName)
                                        .font(.system(size: 10, weight: .medium, design: .rounded))
                                        .foregroundStyle(.white.opacity(0.48))
                                        .lineLimit(1)
                                }
                                Spacer()
                            }
                            if let expires = license.expiresAt {
                                TimelineView(.periodic(from: .now, by: 30)) { context in
                                    Text("Còn lại: \(remainingText(until: expires, now: context.date))")
                                        .font(.system(size: 11, weight: .bold, design: .rounded))
                                        .foregroundStyle(expires > context.date ? ShinnModernPalette.green : .red)
                                }
                            } else {
                                Text("Thời hạn: Vĩnh viễn")
                                    .font(.system(size: 11, weight: .bold, design: .rounded))
                                    .foregroundStyle(ShinnModernPalette.green)
                            }
                            Button {
                                license.signOutLicense()
                                session.role = nil
                                Task { await store.selectRepo(v2: false) }
                            } label: {
                                Label("Đăng xuất key · về Repo V1", systemImage: "rectangle.portrait.and.arrow.right")
                                    .frame(maxWidth: .infinity)
                            }
                            .buttonStyle(ShinnModernPrimaryButtonStyle(tint: .red, compact: true))
                        }
                        .padding(13)
                    }
                }

                if session.role == .owner {
                    moreRow("Tạo / Xoá Key", "Chỉ Owner · quản lý key", nil, "key.fill") { destination = .ownerKeys }
                    moreRow("Repo V2 · Gán Key", "Chỉ Owner · cấp quyền Repo V2", nil, "crown.fill") { destination = .repositoryManager }
                    moreRow("Quản lý Patch", "Owner tools", nil, "wrench.and.screwdriver.fill") { destination = .patchProjects }
                }

                ShinnModernCard(radius: 20) {
                    HStack(spacing: 12) {
                        Image("ShinnAIArt").resizable().scaledToFill().frame(width: 50, height: 50).clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                        VStack(alignment: .leading, spacing: 3) { Text("Cảm ơn bạn").font(.system(size: 16, weight: .black, design: .rounded)); Text("Đã đồng hành cùng Shinn Cheat").font(.system(size: 10, weight: .medium, design: .rounded)).foregroundStyle(.white.opacity(0.45)) }
                        Spacer()
                    }
                    .padding(13)
                }
            }
            .foregroundStyle(.white)
            .padding(16)
        }
    }

    private func remainingText(until date: Date, now: Date) -> String {
        let seconds = max(0, Int(date.timeIntervalSince(now)))
        if seconds == 0 { return "Đã hết hạn" }
        let days = seconds / 86_400
        let hours = (seconds % 86_400) / 3_600
        let minutes = (seconds % 3_600) / 60
        if days > 0 { return "\(days) ngày \(hours) giờ" }
        if hours > 0 { return "\(hours) giờ \(minutes) phút" }
        return "\(max(1, minutes)) phút"
    }

    private func moreRow(_ title: String, _ subtitle: String, _ image: String?, _ icon: String?, action: @escaping () -> Void = {}) -> some View {
        Button(action: action) {
            HStack(spacing: 12) {
                if let image {
                    Image(image).resizable().scaledToFill().frame(width: 43, height: 43).clipShape(RoundedRectangle(cornerRadius: 13, style: .continuous))
                } else if let icon {
                    ShinnModernIcon(systemName: icon, tint: ShinnModernPalette.blue, size: 43)
                }
                VStack(alignment: .leading, spacing: 3) { Text(title).font(.system(size: 14, weight: .bold, design: .rounded)); Text(subtitle).font(.system(size: 10, weight: .medium, design: .rounded)).foregroundStyle(.white.opacity(0.40)) }
                Spacer()
                Image(systemName: "chevron.right").foregroundStyle(.white.opacity(0.30))
            }
            .padding(11)
            .background(ShinnModernPalette.card.opacity(0.80), in: RoundedRectangle(cornerRadius: 17, style: .continuous))
        }
        .buttonStyle(.plain)
    }
}


private struct ShinnModernOwnerKeysView: View {
    @EnvironmentObject private var session: Session
    @StateObject private var manager = OwnerKeyManager()
    @State private var copied = false
    @State private var selectedImage: PhotosPickerItem?
    @State private var keyArtwork: UIImage?
    @State private var imageStatus = ""

    private let durations = [1, 3, 7, 30, 90, 365]

    var body: some View {
        Group {
            if session.role == .owner {
                ScrollView(showsIndicators: false) {
                    VStack(alignment: .leading, spacing: 14) {
                        Text("Tạo / Xoá Key")
                            .font(.system(size: 28, weight: .black, design: .rounded))
                        Text("Chỉ Owner mới nhìn thấy và sử dụng khu vực này.")
                            .font(.system(size: 12, weight: .medium, design: .rounded))
                            .foregroundStyle(.white.opacity(0.48))

                        ShinnModernCard(radius: 22, stroke: ShinnModernPalette.purple.opacity(0.30)) {
                            VStack(alignment: .leading, spacing: 12) {
                                Text("Tạo key")
                                    .font(.system(size: 18, weight: .black, design: .rounded))

                                TextField("Tên người nhận (tuỳ chọn)", text: $manager.keyLabel)
                                    .textFieldStyle(.plain)
                                    .foregroundStyle(.white)
                                    .padding(12)
                                    .background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 13, style: .continuous))

                                TextField("Custom key (tuỳ chọn)", text: $manager.customKey)
                                    .textFieldStyle(.plain)
                                    .textInputAutocapitalization(.never)
                                    .autocorrectionDisabled(true)
                                    .foregroundStyle(.white)
                                    .padding(12)
                                    .background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 13, style: .continuous))

                                HStack(spacing: 12) {
                                    Group {
                                        if let keyArtwork {
                                            Image(uiImage: keyArtwork)
                                                .resizable()
                                                .scaledToFill()
                                        } else {
                                            Image(systemName: "photo.badge.plus")
                                                .font(.system(size: 21, weight: .bold))
                                                .foregroundStyle(ShinnModernPalette.cyan)
                                        }
                                    }
                                    .frame(width: 54, height: 54)
                                    .clipShape(RoundedRectangle(cornerRadius: 15, style: .continuous))
                                    .background(Color.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 15, style: .continuous))

                                    VStack(alignment: .leading, spacing: 3) {
                                        Text("Ảnh Key")
                                            .font(.system(size: 13, weight: .black, design: .rounded))
                                        Text("Chọn ảnh riêng để hiển thị trong bảng key.")
                                            .font(.system(size: 9.5, weight: .medium, design: .rounded))
                                            .foregroundStyle(.white.opacity(0.45))
                                    }
                                    Spacer()
                                    PhotosPicker(selection: $selectedImage, matching: .images) {
                                        Text("Chọn ảnh")
                                            .font(.system(size: 11, weight: .black, design: .rounded))
                                            .foregroundStyle(.white)
                                            .padding(.horizontal, 12)
                                            .padding(.vertical, 9)
                                            .background(ShinnModernPalette.blue.opacity(0.22), in: Capsule())
                                    }
                                    .onChange(of: selectedImage) { _, item in
                                        guard let item else { return }
                                        Task {
                                            do {
                                                if let data = try await item.loadTransferable(type: Data.self),
                                                   let image = UIImage(data: data) {
                                                    let resized = image.shinnKeyPreview(maxDimension: 900)
                                                    keyArtwork = resized
                                                    if let jpeg = resized.jpegData(compressionQuality: 0.82) {
                                                        UserDefaults.standard.set(jpeg, forKey: "shinn.owner.keyArtwork")
                                                        imageStatus = "Đã lưu ảnh trong app"
                                                    }
                                                }
                                            } catch {
                                                imageStatus = "Không đọc được ảnh"
                                            }
                                        }
                                    }
                                }

                                if !imageStatus.isEmpty {
                                    Text(imageStatus)
                                        .font(.system(size: 9, weight: .medium, design: .rounded))
                                        .foregroundStyle(ShinnModernPalette.green)
                                }

                                Picker("Thời hạn", selection: $manager.selectedHours) {
                                    Text("1 giờ · Test").tag(1)
                                    Text("Theo ngày").tag(0)
                                }
                                .pickerStyle(.segmented)

                                if manager.selectedHours == 0 {
                                    Toggle("Vĩnh viễn", isOn: $manager.lifetime)
                                    if !manager.lifetime {
                                        Picker("Số ngày", selection: $manager.selectedDays) {
                                            ForEach(durations, id: \.self) { d in
                                                Text(d == 365 ? "1 năm" : "\(d) ngày").tag(d)
                                            }
                                        }
                                        .pickerStyle(.menu)
                                    }
                                }

                                Stepper("Số lượng: \(manager.createCount)", value: $manager.createCount, in: 1...99)

                                Button {
                                    Task { await manager.createKey() }
                                } label: {
                                    Label(manager.isLoading ? "Đang tạo…" : "Tạo Key", systemImage: "plus.circle.fill")
                                        .frame(maxWidth: .infinity)
                                }
                                .buttonStyle(ShinnModernPrimaryButtonStyle(tint: ShinnModernPalette.purple))
                                .disabled(manager.isLoading)

                                if !manager.prettyCreated.isEmpty {
                                    Text(manager.prettyCreated)
                                        .font(.system(size: 12, weight: .bold, design: .monospaced))
                                        .foregroundStyle(ShinnModernPalette.cyan)
                                        .textSelection(.enabled)
                                    Button {
                                        UIPasteboard.general.string = manager.prettyCreated
                                        copied = true
                                    } label: {
                                        Label(copied ? "Đã sao chép" : "Sao chép", systemImage: copied ? "checkmark" : "doc.on.doc")
                                            .frame(maxWidth: .infinity)
                                    }
                                    .buttonStyle(.plain)
                                }
                            }
                            .padding(16)
                        }

                        ShinnModernCard(radius: 22) {
                            VStack(alignment: .leading, spacing: 10) {
                                HStack {
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text("Key đã tạo (\(manager.keys.count))")
                                            .font(.system(size: 17, weight: .black, design: .rounded))
                                        Text("Mỗi key do Owner tạo sẽ tự mở Repo V2.")
                                            .font(.system(size: 9.5, weight: .medium, design: .rounded))
                                            .foregroundStyle(.white.opacity(0.42))
                                    }
                                    Spacer()
                                    Button { Task { await manager.listKeys() } } label: {
                                        Image(systemName: manager.isLoading ? "hourglass" : "arrow.clockwise")
                                    }
                                    .buttonStyle(.plain)
                                }

                                Button {
                                    Task { await manager.syncAllKeysToV2() }
                                } label: {
                                    Label("Đồng bộ V2 cho tất cả key", systemImage: "arrow.triangle.2.circlepath")
                                        .frame(maxWidth: .infinity)
                                }
                                .buttonStyle(ShinnModernPrimaryButtonStyle(tint: ShinnModernPalette.cyan, compact: true))
                                .disabled(manager.isLoading || manager.keys.isEmpty)

                                if manager.keys.isEmpty {
                                    Text("Chưa có key hoặc chưa tải danh sách.")
                                        .font(.caption)
                                        .foregroundStyle(.white.opacity(0.45))
                                } else {
                                    ForEach(manager.keys) { row in
                                        HStack(spacing: 10) {
                                            VStack(alignment: .leading, spacing: 3) {
                                                Text(row.key)
                                                    .font(.system(size: 12, weight: .bold, design: .monospaced))
                                                    .textSelection(.enabled)
                                                Text(row.label?.isEmpty == false ? row.label! : (row.role ?? "member"))
                                                    .font(.system(size: 10, weight: .medium, design: .rounded))
                                                    .foregroundStyle(.white.opacity(0.42))
                                                HStack(spacing: 6) {
                                                    TimelineView(.periodic(from: .now, by: 1)) { context in
                                                        Text(ownerRemainingText(row.expires_at, now: context.date))
                                                            .font(.system(size: 10, weight: .bold, design: .rounded))
                                                            .foregroundStyle(ownerExpiryDate(row.expires_at).map { $0 > context.date ? ShinnModernPalette.green : .red } ?? ShinnModernPalette.cyan)
                                                    }
                                                    ShinnModernPill(
                                                        text: "V2 OPEN",
                                                        tint: ShinnModernPalette.purple
                                                    )
                                                }
                                                if let date = ownerExpiryDate(row.expires_at) {
                                                    Text(date.formatted(date: .numeric, time: .shortened))
                                                        .font(.system(size: 8.5, weight: .medium, design: .rounded))
                                                        .foregroundStyle(.white.opacity(0.30))
                                                }
                                            }
                                            Spacer()
                                            Button {
                                                UIPasteboard.general.string = row.key
                                            } label: {
                                                Image(systemName: "doc.on.doc")
                                            }
                                            .buttonStyle(.plain)
                                            Button {
                                                Task { await manager.deleteKey(row.key) }
                                            } label: {
                                                Image(systemName: "trash.fill")
                                                    .foregroundStyle(.red)
                                            }
                                            .buttonStyle(.plain)
                                        }
                                        .padding(10)
                                        .background(Color.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                                    }
                                }

                                if !manager.keys.isEmpty {
                                    Button(role: .destructive) {
                                        Task { await manager.deleteAllKeys() }
                                    } label: {
                                        Label("Xoá tất cả key", systemImage: "trash")
                                            .frame(maxWidth: .infinity)
                                    }
                                    .buttonStyle(.plain)
                                    .padding(.top, 4)
                                }

                                if let error = manager.error, !error.isEmpty {
                                    Text(error)
                                        .font(.caption)
                                        .foregroundStyle(.red)
                                }
                            }
                            .padding(16)
                        }
                    }
                    .foregroundStyle(.white)
                    .padding(12)
                }
                .background(ShinnModernBackground())
                .navigationTitle("Owner Keys")
                .navigationBarTitleDisplayMode(.inline)
                .task {
                    await manager.listKeys()
                    if let data = UserDefaults.standard.data(forKey: "shinn.owner.keyArtwork"),
                       let image = UIImage(data: data) {
                        keyArtwork = image
                    }
                }
            } else {
                Text("Owner only")
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .background(ShinnModernBackground())
            }
        }
    }
}

private extension UIImage {
    func shinnKeyPreview(maxDimension: CGFloat) -> UIImage {
        let largestDimension = Swift.max(size.width, size.height)
        guard largestDimension > 0 else { return self }
        let scale = Swift.min(CGFloat(1), maxDimension / largestDimension)
        guard scale < 1 else { return self }
        let target = CGSize(width: size.width * scale, height: size.height * scale)
        let renderer = UIGraphicsImageRenderer(size: target)
        return renderer.image { _ in
            draw(in: CGRect(origin: .zero, size: target))
        }
    }
}

private func ownerExpiryDate(_ raw: String?) -> Date? {
    guard let raw, !raw.isEmpty else { return nil }
    let f1 = ISO8601DateFormatter()
    f1.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
    if let date = f1.date(from: raw) { return date }
    let f2 = ISO8601DateFormatter()
    f2.formatOptions = [.withInternetDateTime]
    return f2.date(from: raw)
}

private func ownerRemainingText(_ raw: String?, now: Date) -> String {
    guard let date = ownerExpiryDate(raw) else { return "Vĩnh viễn" }
    let seconds = max(0, Int(date.timeIntervalSince(now)))
    if seconds == 0 { return "ĐÃ HẾT HẠN" }
    let days = seconds / 86_400
    let hours = (seconds % 86_400) / 3_600
    let minutes = (seconds % 3_600) / 60
    if days > 0 { return "Còn \(days)d \(hours)h" }
    if hours > 0 { return "Còn \(hours)h \(minutes)m" }
    return "Còn \(max(1, minutes))m"
}

private struct ShinnModernPrimaryButtonStyle: ButtonStyle {
    var tint: Color = ShinnModernPalette.blue
    var compact = false

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: compact ? 13 : 15, weight: .black, design: .rounded))
            .foregroundStyle(.white)
            .padding(.vertical, compact ? 0 : 14)
            .frame(maxWidth: .infinity)
            .background(LinearGradient(colors: [tint, tint.opacity(0.68)], startPoint: .topLeading, endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: compact ? 15 : 16, style: .continuous))
            .scaleEffect(configuration.isPressed ? 0.97 : 1)
            .animation(.spring(response: 0.22, dampingFraction: 0.75), value: configuration.isPressed)
    }
}
