import SwiftUI
import UIKit
import PhotosUI

// MARK: - Modern Shinn UI
// This file is the visual shell only. Existing RepoStore, LicenseManager,
// patch/file services and owner tooling remain untouched.

private enum ShinnModernTab: Int, CaseIterable {
    case home, patch, ai, files, more

    var title: String {
        switch self {
        case .home: return "Trang chủ"
        case .patch: return "Patch"
        case .ai: return "Shinn AI"
        case .files: return "Files"
        case .more: return "Account"
        }
    }

    var icon: String {
        switch self {
        case .home: return "house.fill"
        case .patch: return "square.grid.2x2.fill"
        case .ai: return "sparkles"
        case .files: return "folder.fill"
        case .more: return "ellipsis"
        }
    }
}

enum ShinnModernDestination: String, Identifiable {
    case premium, key, files, settings, patchProjects, ownerKeys, repositoryManager, downloadHistory, patchUsageHistory, personalization, terms, about
    var id: String { rawValue }
}

private enum ShinnModernPalette {
    static let bg = Color(red: 0.008, green: 0.015, blue: 0.027)
    static let card = Color(red: 0.045, green: 0.065, blue: 0.090)
    static let card2 = Color(red: 0.025, green: 0.045, blue: 0.070)
    static let blue = Color(red: 0.08, green: 0.56, blue: 1.0)
    static let cyan = Color(red: 0.08, green: 0.82, blue: 1.0)
    static let purple = Color(red: 0.63, green: 0.25, blue: 1.0)
    static let green = Color(red: 0.15, green: 0.86, blue: 0.65)
    static let orange = Color(red: 1.0, green: 0.30, blue: 0.20)
}

private struct ShinnModernBackground: View {
    var body: some View {
        ZStack {
            ShinnModernPalette.bg.ignoresSafeArea()
            RadialGradient(
                colors: [ShinnModernPalette.blue.opacity(0.16), .clear],
                center: .topTrailing,
                startRadius: 20,
                endRadius: 480
            ).ignoresSafeArea()
            RadialGradient(
                colors: [ShinnModernPalette.purple.opacity(0.10), .clear],
                center: .bottomLeading,
                startRadius: 20,
                endRadius: 420
            ).ignoresSafeArea()
        }
    }
}

private struct ShinnModernCard<Content: View>: View {
    let content: Content
    var radius: CGFloat = 20
    var stroke: Color = Color.white.opacity(0.08)

    init(radius: CGFloat = 20, stroke: Color = Color.white.opacity(0.08), @ViewBuilder content: () -> Content) {
        self.radius = radius
        self.stroke = stroke
        self.content = content()
    }

    var body: some View {
        content
            .background(
                RoundedRectangle(cornerRadius: radius, style: .continuous)
                    .fill(.ultraThinMaterial)
                    .overlay(
                        RoundedRectangle(cornerRadius: radius, style: .continuous)
                            .fill(ShinnModernPalette.card.opacity(0.70))
                    )
                    .overlay(
                        RoundedRectangle(cornerRadius: radius, style: .continuous)
                            .stroke(stroke, lineWidth: 1)
                    )
            )
    }
}

private struct ShinnModernPill: View {
    let text: String
    let tint: Color

    var body: some View {
        Text(text)
            .font(.system(size: 10, weight: .bold, design: .rounded))
            .foregroundStyle(.white)
            .padding(.horizontal, 9)
            .padding(.vertical, 5)
            .background(tint.opacity(0.22), in: Capsule())
            .overlay(Capsule().stroke(tint.opacity(0.45), lineWidth: 0.7))
    }
}

private struct ShinnModernIcon: View {
    let systemName: String
    let tint: Color
    var size: CGFloat = 48

    var body: some View {
        Image(systemName: systemName)
            .font(.system(size: size * 0.38, weight: .bold))
            .foregroundStyle(.white)
            .frame(width: size, height: size)
            .background(tint.opacity(0.20), in: RoundedRectangle(cornerRadius: size * 0.28, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: size * 0.28, style: .continuous).stroke(tint.opacity(0.30), lineWidth: 0.8))
    }
}

struct ShinnModernRootView: View {
    @EnvironmentObject private var store: RepoStore
    @EnvironmentObject private var license: LicenseManager
    @EnvironmentObject private var session: Session

    @State private var tab: ShinnModernTab = .home
    @State private var destination: ShinnModernDestination?
    @State private var showAI = false
    @State private var showSplash = true
    @State private var pulse = false
    @State private var filesSession = FilesTabSession()
    @StateObject private var personalization = ShinnPersonalizationStore()

    var body: some View {
        ZStack {
            ShinnFuturisticBackground(pulse: pulse)

            Group {
                switch tab {
                case .home:
                    ShinnFuturisticHome(
                        license: license,
                        session: session,
                        personalization: personalization,
                        onPatch: { withAnimation(.spring(response: 0.35, dampingFraction: 0.8)) { tab = .patch } },
                        onAI: { showAI = true },
                        onMore: { withAnimation(.spring(response: 0.35, dampingFraction: 0.8)) { tab = .more } },
                        onPremium: { destination = .premium },
                        onKey: { destination = .key }
                    )
                case .patch:
                    ShinnModernPatchView(destination: $destination, initialCategory: .constant(nil))
                case .ai:
                    ShinnModernAIView()
                case .files:
                    ShinnModernFilesCenter(session: $filesSession)
                case .more:
                    ShinnFuturisticMore(destination: $destination)
                }
            }
            .transition(.opacity.combined(with: .scale(scale: 0.985)))
        }
        .safeAreaInset(edge: .bottom, spacing: 0) {
            ShinnFuturisticTabBar(selection: $tab)
                .padding(.horizontal, 12)
                .padding(.bottom, 6)
        }
        .sheet(item: $destination) { destination in
            NavigationStack {
                switch destination {
                case .premium: ShinnModernPremiumView(destination: $destination)
                case .key: ShinnModernKeyView()
                case .files: FilesTabSwitcherView(session: .constant(FilesTabSession()))
                case .settings: ShinnSettingsHubView()
                case .patchProjects: PatchProjectsView()
                case .ownerKeys: ShinnModernOwnerKeysView()
                case .repositoryManager: RepositoryManagerView()
                case .downloadHistory: ShinnModernDownloadHistoryView()
                case .patchUsageHistory: ShinnModernPatchUsageHistoryView()
                case .personalization: ShinnPersonalizationView(store: personalization)
                case .terms: ShinnModernTermsView()
                case .about: ShinnModernAboutView()
                }
            }
            .preferredColorScheme(.dark)
        }
        .sheet(isPresented: $showAI) {
            NavigationStack { ShinnModernAIView().preferredColorScheme(.dark) }
        }
        .task {
            try? await Task.sleep(nanoseconds: 900_000_000)
            withAnimation(.easeInOut(duration: 0.7)) { showSplash = false; pulse = true }
        }
        .overlay {
            if showSplash { ShinnFuturisticSplash(personalization: personalization).transition(.opacity) }
        }
    }
}

private struct ShinnFuturisticBackground: View {
    let pulse: Bool
    @State private var drift = false

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            LinearGradient(
                colors: [Color(red: 0.01, green: 0.02, blue: 0.07), Color(red: 0.01, green: 0.005, blue: 0.025), .black],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            ).ignoresSafeArea()

            Circle()
                .fill(Color.cyan.opacity(0.13))
                .frame(width: 360, height: 360)
                .blur(radius: 75)
                .offset(x: drift ? 125 : 45, y: drift ? -290 : -235)

            Circle()
                .fill(Color.purple.opacity(0.13))
                .frame(width: 420, height: 420)
                .blur(radius: 95)
                .offset(x: drift ? -145 : -55, y: drift ? 350 : 290)

            Canvas { context, size in
                for i in stride(from: 0, to: 90, by: 1) {
                    let x = CGFloat((i * 71) % max(Int(size.width), 1))
                    let y = CGFloat((i * 127) % max(Int(size.height), 1))
                    let r: CGFloat = i % 9 == 0 ? 1.25 : 0.55
                    context.fill(Path(ellipseIn: CGRect(x: x, y: y, width: r, height: r)), with: .color(.white.opacity(i % 9 == 0 ? 0.18 : 0.07)))
                }
            }
            .ignoresSafeArea()
        }
        .onAppear {
            withAnimation(.easeInOut(duration: 8).repeatForever(autoreverses: true)) { drift = true }
        }
        .animation(.easeInOut(duration: 0.8), value: pulse)
    }
}

private struct ShinnFuturisticHome: View {
    @ObservedObject var license: LicenseManager
    @ObservedObject var session: Session
    let personalization: ShinnPersonalizationStore
    let onPatch: () -> Void
    let onAI: () -> Void
    let onMore: () -> Void
    let onPremium: () -> Void
    let onKey: () -> Void

    private var roleText: String {
        if session.role == .owner { return "OWNER" }
        if license.isActivated { return (license.boundRole ?? "MEMBER").uppercased() }
        return "GUEST"
    }

    private var expiryText: String {
        guard let date = license.expiresAt else { return license.isActivated ? "Active" : "Not activated" }
        return date.formatted(.dateTime.day().month().year().hour().minute())
    }

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 18) {
                HStack {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("SHINNCHEAT")
                            .font(.system(size: 25, weight: .black, design: .rounded))
                            .tracking(2.2)
                            .foregroundStyle(.white)
                        Text("COMMAND CENTER  •  V5")
                            .font(.system(size: 9, weight: .bold, design: .rounded))
                            .tracking(2)
                            .foregroundStyle(.cyan.opacity(0.72))
                    }
                    Spacer()
                    Circle()
                        .fill(.ultraThinMaterial)
                        .frame(width: 44, height: 44)
                        .overlay(Image(systemName: "bell.badge.fill").foregroundStyle(.white))
                        .overlay(Circle().stroke(.white.opacity(0.12)))
                }

                ShinnFuturisticHero(role: roleText, expiry: expiryText, activated: license.isActivated, personalization: personalization, onKey: onKey)

                HStack(spacing: 10) {
                    ShinnFuturisticQuick(title: "PATCH", subtitle: "Control Center", icon: "bolt.fill", tint: .cyan, action: onPatch)
                    ShinnFuturisticQuick(title: "AI", subtitle: "Shinn Assistant", icon: "sparkles", tint: .purple, action: onAI)
                }

                ShinnFuturisticSystemCard(activated: license.isActivated)

                HStack(spacing: 10) {
                    ShinnFuturisticMetric(value: "99.9%", label: "SYSTEM", icon: "waveform.path.ecg", tint: .green)
                    ShinnFuturisticMetric(value: "V5", label: "ENGINE", icon: "cpu.fill", tint: .cyan)
                    ShinnFuturisticMetric(value: roleText, label: "ACCESS", icon: "person.crop.circle.fill", tint: .purple)
                }

                Button(action: onMore) {
                    HStack(spacing: 12) {
                        Image(systemName: "square.grid.2x2.fill")
                            .foregroundStyle(.cyan)
                        VStack(alignment: .leading, spacing: 3) {
                            Text("OPEN CONTROL HUB")
                                .font(.system(size: 12, weight: .black, design: .rounded))
                                .foregroundStyle(.white)
                            Text("History  •  Settings  •  Account  •  Repository")
                                .font(.system(size: 10, weight: .medium, design: .rounded))
                                .foregroundStyle(.white.opacity(0.45))
                        }
                        Spacer()
                        Image(systemName: "arrow.up.right")
                            .font(.system(size: 13, weight: .bold))
                            .foregroundStyle(.white.opacity(0.7))
                    }
                    .padding(16)
                    .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 22).stroke(.white.opacity(0.09)))
                }
                .buttonStyle(.plain)
            }
            .padding(.horizontal, 18)
            .padding(.top, 16)
            .padding(.bottom, 22)
        }
    }
}

private struct ShinnFuturisticHero: View {
    let role: String
    let expiry: String
    let activated: Bool
    @ObservedObject var personalization: ShinnPersonalizationStore
    let onKey: () -> Void
    @State private var rotate = false

    var body: some View {
        ZStack(alignment: .bottomLeading) {
            ZStack {
                RoundedRectangle(cornerRadius: 30, style: .continuous)
                    .fill(LinearGradient(colors: [Color.blue.opacity(0.30), Color.purple.opacity(0.25), Color.black.opacity(0.55)], startPoint: .topLeading, endPoint: .bottomTrailing))
                if let bg = personalization.backgroundImage {
                    Image(uiImage: bg).resizable().scaledToFill().opacity(0.28).clipShape(RoundedRectangle(cornerRadius: 30, style: .continuous))
                }
                RoundedRectangle(cornerRadius: 30, style: .continuous).stroke(Color.cyan.opacity(0.30), lineWidth: 1)
            }

            Circle()
                .fill(Color.cyan.opacity(0.18))
                .frame(width: 170, height: 170)
                .blur(radius: 18)
                .offset(x: 220, y: -85)

            VStack(alignment: .leading, spacing: 13) {
                HStack {
                    Text(activated ? "SYSTEM ONLINE" : "ACTIVATION REQUIRED")
                        .font(.system(size: 9, weight: .black, design: .rounded))
                        .tracking(1.4)
                        .foregroundStyle(activated ? .green : .orange)
                    Spacer()
                    Text(role)
                        .font(.system(size: 9, weight: .black, design: .rounded))
                        .foregroundStyle(.white.opacity(0.75))
                        .padding(.horizontal, 9).padding(.vertical, 5)
                        .background(.white.opacity(0.08), in: Capsule())
                }

                HStack(alignment: .center, spacing: 15) {
                    ZStack {
                        Circle().stroke(Color.cyan.opacity(0.25), lineWidth: 1)
                        Circle().trim(from: 0.08, to: activated ? 0.92 : 0.28)
                            .stroke(AngularGradient(colors: [.cyan, .blue, .purple, .cyan], center: .center), style: StrokeStyle(lineWidth: 4, lineCap: .round))
                            .rotationEffect(.degrees(rotate ? 360 : 0))
                        Group {
                            if let image = personalization.sImage {
                                Image(uiImage: image).resizable().scaledToFill()
                            } else {
                                Text("S").font(.system(size: 30, weight: .black, design: .rounded)).foregroundStyle(.white)
                            }
                        }
                        .frame(width: 62, height: 62)
                        .clipShape(Circle())
                    }
                    .frame(width: 76, height: 76)

                    VStack(alignment: .leading, spacing: 5) {
                        Text("Shinn Command")
                            .font(.system(size: 22, weight: .black, design: .rounded))
                        Text(activated ? "Your workspace is ready." : "Activate a key to unlock access.")
                            .font(.system(size: 11, weight: .medium, design: .rounded))
                            .foregroundStyle(.white.opacity(0.58))
                        if activated {
                            Text("Valid until  •  \(expiry)")
                                .font(.system(size: 9, weight: .semibold, design: .rounded))
                                .foregroundStyle(.cyan.opacity(0.82))
                        }
                    }
                }

                if !activated {
                    Button("ACTIVATE KEY", action: onKey)
                        .font(.system(size: 10, weight: .black, design: .rounded))
                        .foregroundStyle(.black)
                        .padding(.horizontal, 16).padding(.vertical, 9)
                        .background(LinearGradient(colors: [.cyan, .blue], startPoint: .leading, endPoint: .trailing), in: Capsule())
                }
            }
            .padding(20)
        }
        .frame(height: 205)
        .clipShape(RoundedRectangle(cornerRadius: 30, style: .continuous))
        .shadow(color: .cyan.opacity(0.13), radius: 30, y: 14)
        .onAppear { withAnimation(.linear(duration: 7).repeatForever(autoreverses: false)) { rotate = true } }
    }
}

private struct ShinnFuturisticQuick: View {
    let title: String
    let subtitle: String
    let icon: String
    let tint: Color
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 10) {
                Image(systemName: icon)
                    .font(.system(size: 16, weight: .bold))
                    .foregroundStyle(tint)
                    .frame(width: 34, height: 34)
                    .background(tint.opacity(0.12), in: RoundedRectangle(cornerRadius: 11))
                Text(title).font(.system(size: 11, weight: .black, design: .rounded)).foregroundStyle(.white)
                Text(subtitle).font(.system(size: 8, weight: .medium, design: .rounded)).foregroundStyle(.white.opacity(0.42)).lineLimit(1)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(13)
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 20).stroke(tint.opacity(0.14)))
        }
        .buttonStyle(.plain)
    }
}

private struct ShinnFuturisticSystemCard: View {
    let activated: Bool
    var body: some View {
        VStack(spacing: 14) {
            HStack {
                Label("LIVE SYSTEM", systemImage: "dot.radiowaves.left.and.right")
                    .font(.system(size: 10, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                Spacer()
                Text(activated ? "CONNECTED" : "LOCKED")
                    .font(.system(size: 9, weight: .black, design: .rounded))
                    .foregroundStyle(activated ? .green : .orange)
            }
            HStack(spacing: 8) {
                ForEach(0..<28, id: \.self) { i in
                    Capsule()
                        .fill((i % 5 == 0 || i % 7 == 0) ? Color.cyan.opacity(0.9) : Color.white.opacity(0.10))
                        .frame(width: 3, height: CGFloat(7 + (i * 13) % 19))
                }
            }
            HStack {
                Text("Secure workspace")
                Spacer()
                Text("Ready")
            }
            .font(.system(size: 9, weight: .semibold, design: .rounded))
            .foregroundStyle(.white.opacity(0.42))
        }
        .padding(16)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 24).stroke(.white.opacity(0.08)))
    }
}

private struct ShinnFuturisticMetric: View {
    let value: String
    let label: String
    let icon: String
    let tint: Color
    var body: some View {
        VStack(alignment: .leading, spacing: 9) {
            Image(systemName: icon).font(.system(size: 13, weight: .bold)).foregroundStyle(tint)
            Text(value).font(.system(size: 14, weight: .black, design: .rounded)).foregroundStyle(.white)
            Text(label).font(.system(size: 8, weight: .black, design: .rounded)).tracking(1).foregroundStyle(.white.opacity(0.38))
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(13)
        .background(.white.opacity(0.035), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 18).stroke(.white.opacity(0.06)))
    }
}

private struct ShinnFuturisticTabBar: View {
    @Binding var selection: ShinnModernTab
    var body: some View {
        HStack(spacing: 5) {
            ForEach(ShinnModernTab.allCases, id: \.self) { item in
                Button {
                    withAnimation(.spring(response: 0.30, dampingFraction: 0.82)) { selection = item }
                } label: {
                    VStack(spacing: 5) {
                        Image(systemName: item.icon)
                            .font(.system(size: 14, weight: .bold))
                        Text(item.title)
                            .font(.system(size: 8, weight: .bold, design: .rounded))
                    }
                    .foregroundStyle(selection == item ? Color.white : Color.white.opacity(0.40))
                    .frame(maxWidth: .infinity)
                    .frame(height: 50)
                    .background {
                        if selection == item {
                            RoundedRectangle(cornerRadius: 17, style: .continuous)
                                .fill(LinearGradient(colors: [.blue.opacity(0.85), .purple.opacity(0.72)], startPoint: .topLeading, endPoint: .bottomTrailing))
                                .shadow(color: .blue.opacity(0.25), radius: 14)
                        }
                    }
                }
                .buttonStyle(.plain)
            }
        }
        .padding(6)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 25, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 25).stroke(.white.opacity(0.10)))
    }
}

private struct ShinnFuturisticMore: View {
    @EnvironmentObject private var session: Session
    @Binding var destination: ShinnModernDestination?

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 15) {
                Text("CONTROL HUB")
                    .font(.system(size: 27, weight: .black, design: .rounded))
                Text("Everything in one command layer.")
                    .font(.system(size: 11, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.45))

                ShinnFuturisticHubRow(title: "Key & Account", subtitle: "Activation and access", icon: "person.badge.key.fill", tint: .cyan) { destination = .key }
                if session.role == .owner {
                    ShinnFuturisticHubRow(title: "Owner Key Manager", subtitle: "Create keys · expiry · assigned user", icon: "crown.fill", tint: .orange) { destination = .ownerKeys }
                }
                ShinnFuturisticHubRow(title: "Patch Projects", subtitle: "Workspace and project tools", icon: "square.stack.3d.up.fill", tint: .purple) { destination = .patchProjects }
                ShinnFuturisticHubRow(title: "Repository", subtitle: "Manage your app repository", icon: "shippingbox.fill", tint: .blue) { destination = .repositoryManager }
                ShinnFuturisticHubRow(title: "Patch Usage History", subtitle: "Applied, restored and failed patches", icon: "clock.arrow.circlepath", tint: .orange) { destination = .patchUsageHistory }
                ShinnFuturisticHubRow(title: "Download History", subtitle: "Downloaded package activity", icon: "arrow.down.circle.fill", tint: .cyan) { destination = .downloadHistory }
                ShinnFuturisticHubRow(title: "Personalize", subtitle: "S image · Home background · Splash", icon: "photo.on.rectangle.angled", tint: .purple) { destination = .personalization }
                ShinnFuturisticHubRow(title: "Settings", subtitle: "Appearance and preferences", icon: "slider.horizontal.3", tint: .white) { destination = .settings }
                ShinnFuturisticHubRow(title: "About ShinnCheat", subtitle: "Version and information", icon: "info.circle.fill", tint: .cyan) { destination = .about }
            }
            .padding(.horizontal, 18).padding(.top, 20).padding(.bottom, 30)
        }
    }
}

private struct ShinnFuturisticHubRow: View {
    let title: String
    let subtitle: String
    let icon: String
    let tint: Color
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            HStack(spacing: 13) {
                Image(systemName: icon)
                    .font(.system(size: 15, weight: .bold))
                    .foregroundStyle(tint)
                    .frame(width: 42, height: 42)
                    .background(tint.opacity(0.12), in: RoundedRectangle(cornerRadius: 13, style: .continuous))
                VStack(alignment: .leading, spacing: 4) {
                    Text(title).font(.system(size: 12, weight: .black, design: .rounded)).foregroundStyle(.white)
                    Text(subtitle).font(.system(size: 9, weight: .medium, design: .rounded)).foregroundStyle(.white.opacity(0.42))
                }
                Spacer()
                Image(systemName: "chevron.right").font(.system(size: 11, weight: .bold)).foregroundStyle(.white.opacity(0.28))
            }
            .padding(13)
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 21, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 21).stroke(.white.opacity(0.07)))
        }
        .buttonStyle(.plain)
    }
}


final class ShinnPersonalizationStore: ObservableObject {
    @Published var sImage: UIImage?
    @Published var backgroundImage: UIImage?
    @Published var splashImage: UIImage?
    init() { reload() }
    func reload() {
        let d = UserDefaults.standard
        sImage = Self.load(d.data(forKey: "shinn.custom.sImage"))
        backgroundImage = Self.load(d.data(forKey: "shinn.custom.background"))
        splashImage = Self.load(d.data(forKey: "shinn.custom.splash"))
    }
    func save(_ image: UIImage?, key: String, max: CGFloat = 1600) {
        guard let image else { UserDefaults.standard.removeObject(forKey: key); reload(); return }
        let scaled = image.shinnKeyPreview(maxDimension: max)
        if let data = scaled.jpegData(compressionQuality: 0.78) { UserDefaults.standard.set(data, forKey: key) }
        reload()
    }
    private static func load(_ data: Data?) -> UIImage? { guard let data else { return nil }; return UIImage(data: data) }
}

private struct ShinnPersonalizationView: View {
    @ObservedObject var store: ShinnPersonalizationStore
    @State private var picker: PhotosPickerItem?
    @State private var target = ""
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                Text("PERSONALIZE").font(.system(size: 28, weight: .black, design: .rounded))
                Text("Mỗi key có thể tự chọn ảnh riêng trên thiết bị này.").font(.caption).foregroundStyle(.white.opacity(0.48))
                imageCard("S / Command Image", "Thay chữ S ở trung tâm Shinn Command", store.sImage, "shinn.custom.sImage")
                imageCard("Command Background", "Ảnh nền phía sau khu vực Command", store.backgroundImage, "shinn.custom.background")
                imageCard("Opening Splash", "Ảnh hiển thị khi mở app", store.splashImage, "shinn.custom.splash")
            }.padding(18)
        }
        .background(ShinnModernPalette.bg.ignoresSafeArea())
        .photosPicker(isPresented: Binding(get: { target != "" }, set: { if !$0 { target = "" } }), selection: $picker, matching: .images)
        .onChange(of: picker) { item in
            guard let item else { return }
            Task {
                if let data = try? await item.loadTransferable(type: Data.self), let image = UIImage(data: data) {
                    await MainActor.run {
                        store.save(image, key: target)
                        target = ""; picker = nil
                    }
                }
            }
        }
    }
    @ViewBuilder private func imageCard(_ title: String, _ subtitle: String, _ image: UIImage?, _ key: String) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 12) {
                Group { if let image { Image(uiImage: image).resizable().scaledToFill() } else { Image(systemName: "photo") .foregroundStyle(.cyan) } }
                    .frame(width: 62, height: 62).clipShape(RoundedRectangle(cornerRadius: 15))
                VStack(alignment: .leading) { Text(title).font(.headline.bold()); Text(subtitle).font(.caption).foregroundStyle(.white.opacity(0.45)) }
                Spacer()
            }
            HStack {
                Button("Choose Photo") { target = key }
                    .buttonStyle(.borderedProminent)
                if image != nil { Button("Reset", role: .destructive) { store.save(nil, key: key) } }
            }
        }.padding(15).background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 22)).overlay(RoundedRectangle(cornerRadius: 22).stroke(.white.opacity(0.08)))
    }
}

private struct ShinnFuturisticSplash: View {
    @ObservedObject var personalization: ShinnPersonalizationStore
    @State private var spin = false
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            Circle().fill(Color.blue.opacity(0.18)).frame(width: 260, height: 260).blur(radius: 70)
            Circle().fill(Color.purple.opacity(0.13)).frame(width: 220, height: 220).blur(radius: 65).offset(y: 130)
            VStack(spacing: 18) {
                ZStack {
                    Circle().stroke(Color.cyan.opacity(0.12), lineWidth: 1)
                        .frame(width: 130, height: 130)
                    Circle().trim(from: 0.08, to: 0.74)
                        .stroke(AngularGradient(colors: [.cyan, .blue, .purple, .cyan], center: .center), style: StrokeStyle(lineWidth: 4, lineCap: .round))
                        .frame(width: 130, height: 130)
                        .rotationEffect(.degrees(spin ? 360 : 0))
                    Group {
                        if let image = personalization.splashImage { Image(uiImage: image).resizable().scaledToFill() }
                        else { Text("S").font(.system(size: 48, weight: .black, design: .rounded)).foregroundStyle(.white) }
                    }.frame(width: 104, height: 104).clipShape(Circle())
                }
                Text("SHINNCHEAT").font(.system(size: 24, weight: .black, design: .rounded)).tracking(4).foregroundStyle(.white)
                Text("COMMAND CENTER").font(.system(size: 9, weight: .bold, design: .rounded)).tracking(3).foregroundStyle(.cyan.opacity(0.65))
            }
        }
        .onAppear { withAnimation(.linear(duration: 2.5).repeatForever(autoreverses: false)) { spin = true } }
    }
}

private struct ShinnModernSplashView: View {
    @State private var progress = 0.0

    var body: some View {
        ZStack {
            ShinnModernBackground()
            VStack(spacing: 18) {
                Image("ShinnSplashArt")
                    .resizable()
                    .scaledToFill()
                    .frame(width: 235, height: 310)
                    .clipShape(RoundedRectangle(cornerRadius: 34, style: .continuous))
                    .overlay(RoundedRectangle(cornerRadius: 34).stroke(ShinnModernPalette.blue.opacity(0.65), lineWidth: 1))
                    .shadow(color: ShinnModernPalette.blue.opacity(0.30), radius: 28)

                Text("Shinn Cheat")
                    .font(.system(size: 34, weight: .black, design: .rounded))
                Text("Play Smarter · Win Easier")
                    .font(.system(size: 13, weight: .semibold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.55))

                VStack(spacing: 8) {
                    ProgressView(value: progress)
                        .tint(ShinnModernPalette.blue)
                        .frame(width: 230)
                    Text("Đang khởi động…")
                        .font(.system(size: 11, weight: .medium, design: .rounded))
                        .foregroundStyle(.white.opacity(0.45))
                }
            }
            .foregroundStyle(.white)
        }
        .task {
            withAnimation(.easeInOut(duration: 1.2)) { progress = 1 }
        }
    }
}

private struct ShinnModernTabBar: View {
    @Binding var selection: ShinnModernTab

    var body: some View {
        HStack(spacing: 4) {
            ForEach(ShinnModernTab.allCases, id: \.self) { item in
                Button {
                    withAnimation(.spring(response: 0.28, dampingFraction: 0.82)) { selection = item }
                } label: {
                    VStack(spacing: 4) {
                        Image(systemName: item.icon)
                            .font(.system(size: 17, weight: .bold))
                        Text(item.title)
                            .font(.system(size: 8.5, weight: .semibold, design: .rounded))
                    }
                    .foregroundStyle(selection == item ? ShinnModernPalette.cyan : .white.opacity(0.48))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 8)
                    .background(selection == item ? ShinnModernPalette.blue.opacity(0.13) : .clear, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                }
                .buttonStyle(.plain)
            }
        }
        .padding(5)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 21, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 21).stroke(ShinnModernPalette.blue.opacity(0.25), lineWidth: 0.8))
    }
}

private struct ShinnModernHomeView: View {
    @EnvironmentObject private var store: RepoStore
    @EnvironmentObject private var license: LicenseManager
    @EnvironmentObject private var session: Session
    @Binding var tab: ShinnModernTab
    @Binding var destination: ShinnModernDestination?
    @Binding var patchCategory: String?

    private var count: Int { store.packages.count }

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 16) {
                hero
                keyStatusCard
                sectionHeader("Danh mục", trailing: "\(count) patch")
                categoryGrid
                utilityGrid
                premiumCard
                aiCard
                communityCard
            }
            .padding(.horizontal, 12)
            .padding(.top, 4)
            .padding(.bottom, 14)
        }
        .refreshable { await store.refresh() }
    }

    private var hero: some View {
        ZStack(alignment: .bottomLeading) {
            Image("ShinnHeroArt")
                .resizable()
                .scaledToFill()
                .frame(height: 148)
                .clipped()
            LinearGradient(colors: [.clear, .black.opacity(0.95)], startPoint: .center, endPoint: .bottom)
            VStack(alignment: .leading, spacing: 5) {
                Text("WELCOME TO")
                    .font(.system(size: 11, weight: .black, design: .rounded))
                    .tracking(2.4)
                    .foregroundStyle(ShinnModernPalette.cyan)
                Text("Shinn Cheat")
                    .font(.system(size: 24, weight: .black, design: .rounded))
                Text("Patch Center · Community · AI")
                    .font(.system(size: 12, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.55))
            }
            .padding(16)
        }
        .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 24).stroke(ShinnModernPalette.blue.opacity(0.30), lineWidth: 1))
        .shadow(color: ShinnModernPalette.blue.opacity(0.12), radius: 24, y: 8)
    }

    private var keyStatusCard: some View {
        ShinnModernCard(
            radius: 24,
            stroke: session.role == .owner
                ? ShinnModernPalette.cyan.opacity(0.42)
                : ShinnModernPalette.blue.opacity(0.28)
        ) {
            VStack(alignment: .leading, spacing: 12) {
                HStack(spacing: 12) {
                    ZStack {
                        Circle()
                            .fill(
                                LinearGradient(
                                    colors: [ShinnModernPalette.blue, ShinnModernPalette.cyan],
                                    startPoint: .topLeading,
                                    endPoint: .bottomTrailing
                                )
                            )
                            .frame(width: 54, height: 54)
                        Image(systemName: session.role == .owner ? "crown.fill" : "key.fill")
                            .font(.system(size: 21, weight: .black))
                            .foregroundStyle(.white)
                    }

                    VStack(alignment: .leading, spacing: 3) {
                        HStack(spacing: 7) {
                            Text(session.role == .owner ? "SHINN CHEAT" : "SHINN CHEAT")
                                .font(.system(size: 18, weight: .black, design: .rounded))
                            if session.role == .owner {
                                ShinnModernPill(text: "OWNER", tint: ShinnModernPalette.green)
                            }
                        }

                        Text(license.isActivated
                             ? (license.holderName.isEmpty ? "Key đang sử dụng" : license.holderName)
                             : "Chưa kích hoạt key · Repo V1")
                            .font(.system(size: 11, weight: .bold, design: .rounded))
                            .foregroundStyle(ShinnModernPalette.cyan)
                    }

                    Spacer()
                }

                HStack(spacing: 8) {
                    keyInfoPill(
                        title: "KEY",
                        value: license.isActivated
                            ? (license.savedLicenseKey.isEmpty ? "Đã kích hoạt" : license.savedLicenseKey)
                            : "FREE / V1"
                    )

                    if let expires = license.expiresAt {
                        TimelineView(.periodic(from: .now, by: 1)) { context in
                            keyInfoPill(
                                title: "THỜI HẠN",
                                value: homeRemainingText(until: expires, now: context.date)
                            )
                        }
                    } else {
                        keyInfoPill(title: "THỜI HẠN", value: license.isActivated ? "Vĩnh viễn" : "—")
                    }
                }

                if license.isActivated {
                    HStack(spacing: 8) {
                        statusPill(
                            title: "PATCH",
                            value: store.packages.isEmpty ? "READY" : "\(store.packages.count)",
                            tint: ShinnModernPalette.cyan
                        )
                        statusPill(
                            title: "REPO",
                            value: store.isRepoV2Authorized ? "V2 OPEN" : "V1",
                            tint: store.isRepoV2Authorized ? ShinnModernPalette.green : ShinnModernPalette.blue
                        )
                        statusPill(
                            title: "KEY",
                            value: store.isRepoV2Authorized ? "OK" : "V1",
                            tint: store.isRepoV2Authorized ? ShinnModernPalette.green : ShinnModernPalette.orange
                        )
                    }

                    HStack(spacing: 8) {
                        if session.role == .owner {
                            Button { destination = .ownerKeys } label: {
                                Label("Owner Panel", systemImage: "crown.fill")
                                    .frame(maxWidth: .infinity)
                            }
                            .buttonStyle(ShinnModernPrimaryButtonStyle(tint: ShinnModernPalette.purple, compact: true))
                        } else {
                            Button { destination = .key } label: {
                                Label("Đổi / Nhập key", systemImage: "key.fill")
                                    .frame(maxWidth: .infinity)
                            }
                            .buttonStyle(ShinnModernPrimaryButtonStyle(tint: ShinnModernPalette.blue, compact: true))
                        }

                        Button {
                            license.signOutLicense()
                            session.role = nil
                            Task { await store.selectRepo(v2: false) }
                        } label: {
                            Label("Đăng xuất", systemImage: "rectangle.portrait.and.arrow.right")
                                .frame(maxWidth: .infinity)
                        }
                        .buttonStyle(ShinnModernPrimaryButtonStyle(tint: .red, compact: true))
                    }

                    if session.role == .owner {
                        Button { destination = .repositoryManager } label: {
                            HStack {
                                ShinnModernIcon(systemName: "folder.badge.gearshape", tint: ShinnModernPalette.cyan, size: 38)
                                VStack(alignment: .leading, spacing: 2) {
                                    Text("Repository Manager")
                                        .font(.system(size: 13, weight: .black, design: .rounded))
                                    Text("Quản lý Repo V1 · V2 và quyền key")
                                        .font(.system(size: 9.5, weight: .medium, design: .rounded))
                                        .foregroundStyle(.white.opacity(0.45))
                                }
                                Spacer()
                                Image(systemName: "chevron.right")
                                    .foregroundStyle(.white.opacity(0.3))
                            }
                        }
                        .buttonStyle(.plain)
                    }
                } else {
                    Button { destination = .key } label: {
                        Label("Nhập key để mở Repo V2", systemImage: "key.fill")
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(ShinnModernPrimaryButtonStyle(tint: ShinnModernPalette.blue, compact: true))
                }
            }
            .padding(15)
        }
    }

    private func statusPill(title: String, value: String, tint: Color) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(title)
                .font(.system(size: 7.5, weight: .black, design: .rounded))
                .foregroundStyle(.white.opacity(0.34))
            Text(value)
                .font(.system(size: 9.5, weight: .black, design: .rounded))
                .foregroundStyle(tint)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.horizontal, 9)
        .padding(.vertical, 7)
        .background(Color.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 11, style: .continuous))
    }

    private func keyInfoPill(title: String, value: String) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(title.uppercased())
                .font(.system(size: 8, weight: .black, design: .rounded))
                .foregroundStyle(.white.opacity(0.38))
            Text(value)
                .font(.system(size: 10, weight: .bold, design: .rounded))
                .foregroundStyle(.white)
                .lineLimit(1)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.horizontal, 10)
        .padding(.vertical, 8)
        .background(Color.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
    }

    private func homeRemainingText(until date: Date, now: Date) -> String {
        let seconds = max(0, Int(date.timeIntervalSince(now)))
        if seconds == 0 { return "Đã hết hạn" }
        let days = seconds / 86_400
        let hours = (seconds % 86_400) / 3_600
        let minutes = (seconds % 3_600) / 60
        if days > 0 { return "\(days)d \(hours)h" }
        if hours > 0 { return "\(hours)h \(minutes)m" }
        return "\(max(1, minutes))m"
    }

    private var categoryGrid: some View {
        LazyVGrid(columns: [GridItem(.flexible(), spacing: 12), GridItem(.flexible(), spacing: 12)], spacing: 12) {
            categoryCard("Free Fire", "PATCH", "flame.fill", .red, "Free Fire")
            categoryCard("Free Fire Max", "MAX", "bolt.fill", ShinnModernPalette.purple, "Free Fire Max")
            categoryCard("Liên Quân", "MOBA", "gamecontroller.fill", ShinnModernPalette.blue, "Liên Quân")
            categoryCard("CapCut", "TOOLS", "scissors", ShinnModernPalette.green, "CapCut")
        }
    }

    private func categoryCard(_ title: String, _ subtitle: String, _ icon: String, _ tint: Color, _ category: String) -> some View {
        Button {
            patchCategory = category
            tab = .patch
        } label: {
            VStack(alignment: .leading, spacing: 15) {
                HStack {
                    ShinnModernIcon(systemName: icon, tint: tint, size: 50)
                    Spacer()
                    Image(systemName: "chevron.right")
                        .font(.system(size: 18, weight: .bold))
                        .foregroundStyle(.white.opacity(0.35))
                }
                Spacer(minLength: 0)
                Text(title)
                    .font(.system(size: 15, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                Text(subtitle)
                    .font(.system(size: 10, weight: .bold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.40))
            }
            .frame(maxWidth: .infinity, minHeight: 112, alignment: .leading)
            .padding(11)
            .background(ShinnModernPalette.card.opacity(0.78), in: RoundedRectangle(cornerRadius: 26, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 26).stroke(tint.opacity(0.40), lineWidth: 1))
        }
        .buttonStyle(.plain)
        .accessibilityLabel("Mở \(category)")
    }

    private var utilityGrid: some View {
        HStack(spacing: 10) {
            homeUtility("Kho Patch", "Tất cả patch", "square.grid.2x2.fill", ShinnModernPalette.cyan) { patchCategory = nil; tab = .patch }
            homeUtility("Tệp", "File manager", "folder.fill", ShinnModernPalette.blue) { destination = .files }
            homeUtility("Cài đặt", "Giao diện", "slider.horizontal.3", ShinnModernPalette.cyan) { destination = .settings }
        }
    }

    private func homeUtility(_ title: String, _ subtitle: String, _ icon: String, _ tint: Color, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 9) {
                Image(systemName: icon).font(.system(size: 21, weight: .bold)).foregroundStyle(tint)
                Text(title).font(.system(size: 14, weight: .black, design: .rounded))
                Text(subtitle).font(.system(size: 10, weight: .medium, design: .rounded)).foregroundStyle(.white.opacity(0.38))
            }
            .frame(maxWidth: .infinity, minHeight: 76, alignment: .leading)
            .padding(14)
            .background(ShinnModernPalette.card.opacity(0.78), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 20).stroke(Color.white.opacity(0.07), lineWidth: 0.8))
        }
        .buttonStyle(.plain)
    }

    private var premiumCard: some View {
        Button { destination = .premium } label: {
            HStack(spacing: 14) {
                ShinnModernIcon(systemName: "crown.fill", tint: ShinnModernPalette.purple, size: 50)
                VStack(alignment: .leading, spacing: 4) {
                    Text("Premium Repo").font(.system(size: 17, weight: .black, design: .rounded))
                    Text(license.isActivated ? "Đã mở khóa Repo 2" : "Mở khóa Repo 2")
                        .font(.system(size: 12, weight: .medium, design: .rounded))
                        .foregroundStyle(.white.opacity(0.46))
                }
                Spacer()
                Text("OPEN")
                    .font(.system(size: 11, weight: .black, design: .rounded))
                    .padding(.horizontal, 13).padding(.vertical, 9)
                    .background(ShinnModernPalette.purple.opacity(0.65), in: Capsule())
            }
            .padding(16)
            .background(ShinnModernPalette.card.opacity(0.80), in: RoundedRectangle(cornerRadius: 23, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 23).stroke(ShinnModernPalette.purple.opacity(0.38), lineWidth: 1))
        }
        .buttonStyle(.plain)
    }

    private var aiCard: some View {
        Button { tab = .ai } label: {
            HStack(spacing: 14) {
                Image("ShinnAIArt")
                    .resizable().scaledToFill()
                    .frame(width: 50, height: 50)
                    .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                VStack(alignment: .leading, spacing: 4) {
                    Text("Shinn AI").font(.system(size: 17, weight: .black, design: .rounded))
                    Text("Commands · Support · Patch helper")
                        .font(.system(size: 12, weight: .medium, design: .rounded))
                        .foregroundStyle(.white.opacity(0.46))
                }
                Spacer()
                Image(systemName: "sparkles").foregroundStyle(ShinnModernPalette.cyan)
            }
            .padding(16)
            .background(ShinnModernPalette.card.opacity(0.80), in: RoundedRectangle(cornerRadius: 23, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 23).stroke(ShinnModernPalette.blue.opacity(0.25), lineWidth: 1))
        }
        .buttonStyle(.plain)
    }

    private var communityCard: some View {
        Button { tab = .community } label: {
            HStack(spacing: 14) {
                ShinnModernIcon(systemName: "paperplane.fill", tint: ShinnModernPalette.blue, size: 50)
                VStack(alignment: .leading, spacing: 4) {
                    Text("Community").font(.system(size: 17, weight: .black, design: .rounded))
                    Text("Main Group · English Chat · Support")
                        .font(.system(size: 12, weight: .medium, design: .rounded))
                        .foregroundStyle(.white.opacity(0.46))
                }
                Spacer()
                Image(systemName: "chevron.right").foregroundStyle(.white.opacity(0.32))
            }
            .padding(16)
            .background(ShinnModernPalette.card.opacity(0.80), in: RoundedRectangle(cornerRadius: 23, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 23).stroke(ShinnModernPalette.blue.opacity(0.25), lineWidth: 1))
        }
        .buttonStyle(.plain)
    }

    private func sectionHeader(_ title: String, trailing: String) -> some View {
        HStack(alignment: .bottom) {
            Text(title).font(.system(size: 22, weight: .black, design: .rounded))
            Spacer()
            Text(trailing).font(.system(size: 13, weight: .semibold, design: .rounded)).foregroundStyle(.white.opacity(0.35))
        }
        .foregroundStyle(.white)
    }
}

struct ShinnModernPatchView: View {
    @EnvironmentObject private var store: RepoStore
    @Binding var destination: ShinnModernDestination?
    @Binding var initialCategory: String?
    @State private var selectedCategory = "Tất cả"
    @State private var selectedPackage: RepoPackage?

    private var categories: [String] { ["Tất cả", "Free Fire", "Free Fire Max", "Liên Quân", "CapCut", "Khác"] }

    private var filtered: [RepoPackage] {
        // Repo V2 is visible to every valid key; download permission is enforced by RepoStore.
        guard selectedCategory != "Tất cả" else { return store.packages }
        return store.packages.filter { matches($0, category: selectedCategory) }
    }

    var body: some View {
        NavigationStack {
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 14) {
                    HStack(alignment: .bottom) {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Patch Center").font(.system(size: 27, weight: .black, design: .rounded))
                            Text("Repo V1 + Repo V2 · Browse everything you are allowed to use")
                                .font(.system(size: 10, weight: .medium, design: .rounded))
                                .foregroundStyle(.white.opacity(0.48))
                        }
                        Spacer()
                        Text("\(filtered.count)").font(.system(size: 20, weight: .black, design: .rounded)).foregroundStyle(ShinnModernPalette.cyan)
                    }

                    HStack(spacing: 7) {
                        repoSourceButton(title: "Repo V1", v2: false)
                        repoSourceButton(title: store.isRepoV2Authorized ? "Repo V2" : "Repo V2 · VIEW", v2: true)
                    }

                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 8) {
                            ForEach(categories, id: \.self) { item in
                                Button { selectedCategory = item } label: {
                                    Text(item)
                                        .font(.system(size: 11, weight: .bold, design: .rounded))
                                        .foregroundStyle(selectedCategory == item ? .white : .white.opacity(0.55))
                                        .padding(.horizontal, 14).padding(.vertical, 9)
                                        .background(selectedCategory == item ? ShinnModernPalette.blue : Color.white.opacity(0.06), in: Capsule())
                                }
                                .buttonStyle(.plain)
                            }
                        }
                    }

                    LazyVStack(spacing: 8) {
                            ForEach(filtered) { pkg in
                            ShinnModernPatchRow(pkg: pkg) {
                                selectedPackage = pkg
                            } download: {
                                Task { await store.download(pkg) }
                            }
                        }
                        }
                }
                .padding(.horizontal, 16)
                .padding(.top, 8)
                .padding(.bottom, 20)
            }
            .refreshable { await store.refresh() }
            .onAppear {
                if let initialCategory { selectedCategory = initialCategory }
            }
            .navigationBarHidden(true)
            .sheet(item: $selectedPackage) { pkg in
                NavigationStack { ShinnModernPatchDetail(pkg: pkg) }
                    .preferredColorScheme(.dark)
            }
        }
    }

    private func repoSourceButton(title: String, v2: Bool) -> some View {
        Button {
            Task { await store.selectRepo(v2: v2) }
        } label: {
            HStack(spacing: 5) {
                Image(systemName: v2 ? (store.isRepoV2Authorized ? "crown.fill" : "lock.fill") : "square.stack.3d.up.fill")
                Text(title)
            }
            .font(.system(size: 10.5, weight: .bold, design: .rounded))
            .foregroundStyle(store.usingRepoV2 == v2 ? .white : .white.opacity(0.55))
            .frame(maxWidth: .infinity)
            .padding(.vertical, 8)
            .background(store.usingRepoV2 == v2 ? ShinnModernPalette.blue : Color.white.opacity(0.06), in: Capsule())
        }
        .buttonStyle(.plain)
    }

    private func matches(_ pkg: RepoPackage, category: String) -> Bool {
        let value = "\(pkg.category ?? "") \(pkg.name) \(pkg.summary ?? "")".lowercased()
        switch category {
        case "Free Fire": return value.contains("free fire") && !value.contains("max")
        case "Free Fire Max": return value.contains("free fire max") || value.contains("ff max")
        case "Liên Quân": return value.contains("liên quân") || value.contains("lien quan") || value.contains("moba")
        case "CapCut": return value.contains("capcut") || value.contains("cap cut")
        case "Khác": return !categories.dropFirst().dropLast().contains(where: { matches(pkg, category: $0) })
        default: return true
        }
    }
}

private struct ShinnModernPatchRow: View {
    @EnvironmentObject private var store: RepoStore
    let pkg: RepoPackage
    let action: () -> Void
    let download: () -> Void

    private var isApplied: Bool {
        if case .applied = store.patchState(for: pkg) { return true }
        return false
    }

    private var isBusy: Bool {
        switch store.patchState(for: pkg) {
        case .applying, .restoring: return true
        default: return false
        }
    }

    var body: some View {
        HStack(spacing: 12) {
            Button(action: action) {
                HStack(spacing: 12) {
                    Image("ShinnPatchArt")
                        .resizable().scaledToFill()
                        .frame(width: 48, height: 48)
                        .clipShape(Circle())
                        .overlay(Circle().stroke(ShinnModernPalette.blue.opacity(0.6), lineWidth: 1))

                    VStack(alignment: .leading, spacing: 4) {
                        HStack(spacing: 7) {
                            Text(pkg.name)
                                .font(.system(size: 14, weight: .bold, design: .rounded))
                                .foregroundStyle(.white)
                                .lineLimit(1)
                            if pkg.tags?.contains(where: { $0.lowercased().contains("hot") }) == true {
                                ShinnModernPill(text: "Hot", tint: .red)
                            }
                        }
                        Text(pkg.summary ?? pkg.description ?? "Patch")
                            .font(.system(size: 10, weight: .medium, design: .rounded))
                            .foregroundStyle(.white.opacity(0.42))
                            .lineLimit(1)
                        HStack(spacing: 6) {
                            Circle()
                                .fill(isApplied ? ShinnModernPalette.green : Color.white.opacity(0.25))
                                .frame(width: 6, height: 6)
                            Text(isApplied ? "Enabled" : "Disabled")
                                .font(.system(size: 9, weight: .bold, design: .rounded))
                                .foregroundStyle(isApplied ? ShinnModernPalette.green : .white.opacity(0.38))
                        }
                    }
                    Spacer(minLength: 0)
                }
            }
            .buttonStyle(.plain)

            Button {
                Task {
                    if isApplied {
                        await store.restore(pkg)
                    } else {
                        await store.apply(pkg)
                    }
                }
            } label: {
                Group {
                    if isBusy {
                        ProgressView().tint(.white)
                    } else {
                        Image(systemName: isApplied ? "power.circle.fill" : "power.circle")
                            .font(.system(size: 28, weight: .bold))
                            .foregroundStyle(isApplied ? ShinnModernPalette.green : .white.opacity(0.48))
                    }
                }
                .frame(width: 38, height: 38)
            }
            .buttonStyle(.plain)
            .disabled(isBusy)

            Button(action: download) {
                switch store.state(for: pkg) {
                case .downloading:
                    ProgressView().tint(.white).frame(width: 32, height: 32)
                case .done:
                    Image(systemName: "checkmark.circle.fill")
                        .foregroundStyle(ShinnModernPalette.green)
                        .frame(width: 32, height: 32)
                default:
                    Image(systemName: "arrow.down.circle.fill")
                        .foregroundStyle(ShinnModernPalette.cyan)
                        .frame(width: 32, height: 32)
                }
            }
            .buttonStyle(.plain)
        }
        .padding(12)
        .background(ShinnModernPalette.card.opacity(0.80), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 18)
                .stroke(isApplied ? ShinnModernPalette.green.opacity(0.35) : Color.white.opacity(0.06), lineWidth: 0.8)
        )
    }
}

private struct ShinnModernPatchDetail: View {
    @EnvironmentObject private var store: RepoStore
    let pkg: RepoPackage

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 16) {
                Image("ShinnPatchArt")
                    .resizable().scaledToFill()
                    .frame(height: 210)
                    .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))

                Text(pkg.name).font(.system(size: 28, weight: .black, design: .rounded))
                Text(pkg.summary ?? pkg.description ?? "Patch")
                    .foregroundStyle(.white.opacity(0.58))

                ShinnModernCard {
                    VStack(alignment: .leading, spacing: 10) {
                        detail("Category", pkg.category ?? "Other")
                        detail("Version", pkg.version ?? "—")
                        detail("Size", pkg.size.map { ByteCountFormatter.string(fromByteCount: Int64($0), countStyle: .file) } ?? "—")
                        detail("SHA-256", pkg.sha256 ?? "—")
                        detail("Path", pkg.patchPath ?? "—")
                    }
                    .padding(16)
                }

                Button { Task { await store.download(pkg) } } label: {
                    Label("Tải patch", systemImage: "arrow.down.circle.fill")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(ShinnModernPrimaryButtonStyle())
            }
            .padding(16)
        }
        .background(ShinnModernBackground())
        .navigationTitle("Patch")
        .navigationBarTitleDisplayMode(.inline)
    }

    private func detail(_ key: String, _ value: String) -> some View {
        HStack(alignment: .top) {
            Text(key).foregroundStyle(.white.opacity(0.45)).frame(width: 75, alignment: .leading)
            Text(value).font(.system(size: 12, weight: .medium, design: .monospaced)).foregroundStyle(.white).lineLimit(2)
            Spacer()
        }
    }
}


private struct ShinnModernPatchUsageHistoryView: View {
    @EnvironmentObject private var store: RepoStore

    private var sortedItems: [PatchUsageHistoryItem] {
        store.patchUsageHistory.sorted { $0.usedAt > $1.usedAt }
    }

    var body: some View {
        ZStack {
            ShinnModernBackground()
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 14) {
                    HStack(alignment: .bottom) {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Lịch sử sử dụng Patch")
                                .font(.system(size: 27, weight: .black, design: .rounded))
                            Text("Theo dõi các lần bật, khôi phục và lỗi của patch")
                                .font(.system(size: 11, weight: .medium, design: .rounded))
                                .foregroundStyle(.white.opacity(0.45))
                        }
                        Spacer()
                        if !store.patchUsageHistory.isEmpty {
                            Button("Xóa") {
                                store.clearPatchUsageHistory()
                            }
                            .font(.system(size: 12, weight: .bold, design: .rounded))
                            .foregroundStyle(.red)
                        }
                    }

                    if sortedItems.isEmpty {
                        ShinnModernCard(radius: 22) {
                            VStack(spacing: 10) {
                                Image(systemName: "clock.arrow.circlepath")
                                    .font(.system(size: 34, weight: .bold))
                                    .foregroundStyle(ShinnModernPalette.cyan)
                                Text("Chưa có lịch sử sử dụng")
                                    .font(.system(size: 17, weight: .black, design: .rounded))
                                Text("Các lần sử dụng Patch sẽ được ghi lại ở đây.")
                                    .font(.system(size: 11, weight: .medium, design: .rounded))
                                    .foregroundStyle(.white.opacity(0.45))
                                    .multilineTextAlignment(.center)
                            }
                            .frame(maxWidth: .infinity)
                            .padding(24)
                        }
                    } else {
                        ForEach(sortedItems) { item in
                            usageRow(item)
                        }
                    }
                }
                .padding(16)
            }
        }
        .navigationTitle("Patch Usage")
        .navigationBarTitleDisplayMode(.inline)
    }

    @ViewBuilder
    private func usageRow(_ item: PatchUsageHistoryItem) -> some View {
        let tint = item.success ? ShinnModernPalette.green : ShinnModernPalette.orange
        let icon: String = {
            switch item.action.lowercased() {
            case "apply": return "bolt.fill"
            case "restore": return "arrow.uturn.backward.circle.fill"
            default: return item.success ? "checkmark.circle.fill" : "xmark.circle.fill"
            }
        }()
        let actionTitle: String = {
            switch item.action.lowercased() {
            case "apply": return "Applied"
            case "restore": return "Restored"
            default: return item.action
            }
        }()

        ShinnModernCard(radius: 18) {
            HStack(spacing: 12) {
                ShinnModernIcon(systemName: icon, tint: tint, size: 46)
                VStack(alignment: .leading, spacing: 5) {
                    Text(item.name)
                        .font(.system(size: 14, weight: .bold, design: .rounded))
                        .foregroundStyle(.white)
                        .lineLimit(1)
                    HStack(spacing: 7) {
                        ShinnModernPill(text: actionTitle, tint: tint)
                        Text(item.repo)
                        if let version = item.version, !version.isEmpty {
                            Text("v\(version)")
                        }
                    }
                    .font(.system(size: 9, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.40))
                    Text(item.usedAt.formatted(date: .abbreviated, time: .shortened))
                        .font(.system(size: 9, weight: .medium, design: .rounded))
                        .foregroundStyle(.white.opacity(0.30))
                }
                Spacer(minLength: 4)
                Image(systemName: item.success ? "checkmark.circle.fill" : "xmark.circle.fill")
                    .foregroundStyle(tint)
                    .font(.system(size: 18, weight: .bold))
            }
            .padding(13)
        }
    }
}


private struct ShinnModernDownloadHistoryView: View {
    @EnvironmentObject private var store: RepoStore

    var body: some View {
        ZStack {
            ShinnModernBackground()
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 14) {
                    HStack {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Lịch sử tải xuống")
                                .font(.system(size: 28, weight: .black, design: .rounded))
                            Text("\(store.downloadHistory.count) lượt tải được lưu")
                                .font(.system(size: 11, weight: .medium, design: .rounded))
                                .foregroundStyle(.white.opacity(0.45))
                        }
                        Spacer()
                        if !store.downloadHistory.isEmpty {
                            Button("Xóa") {
                                store.clearDownloadHistory()
                            }
                            .font(.system(size: 12, weight: .bold, design: .rounded))
                            .foregroundStyle(.red)
                        }
                    }

                    if store.downloadHistory.isEmpty {
                        ShinnModernCard(radius: 22) {
                            VStack(spacing: 10) {
                                Image(systemName: "clock.arrow.circlepath")
                                    .font(.system(size: 32, weight: .bold))
                                    .foregroundStyle(ShinnModernPalette.cyan)
                                Text("Chưa có lịch sử tải")
                                    .font(.system(size: 17, weight: .black, design: .rounded))
                                Text("Các patch tải thành công sẽ xuất hiện ở đây.")
                                    .font(.system(size: 11, weight: .medium, design: .rounded))
                                    .foregroundStyle(.white.opacity(0.45))
                                    .multilineTextAlignment(.center)
                            }
                            .frame(maxWidth: .infinity)
                            .padding(22)
                        }
                    } else {
                        ForEach(store.downloadHistory) { item in
                            ShinnModernCard(radius: 18) {
                                HStack(spacing: 12) {
                                    Image(systemName: "arrow.down.circle.fill")
                                        .font(.system(size: 28, weight: .bold))
                                        .foregroundStyle(ShinnModernPalette.cyan)
                                    VStack(alignment: .leading, spacing: 4) {
                                        Text(item.name)
                                            .font(.system(size: 14, weight: .bold, design: .rounded))
                                            .foregroundStyle(.white)
                                            .lineLimit(1)
                                        HStack(spacing: 7) {
                                            Text(item.repo)
                                            if let version = item.version, !version.isEmpty {
                                                Text("v\(version)")
                                            }
                                            if let size = item.size {
                                                Text(formatBytes(size))
                                            }
                                        }
                                        .font(.system(size: 9, weight: .medium, design: .rounded))
                                        .foregroundStyle(.white.opacity(0.40))
                                        Text(item.downloadedAt.formatted(date: .abbreviated, time: .shortened))
                                            .font(.system(size: 9, weight: .medium, design: .rounded))
                                            .foregroundStyle(.white.opacity(0.30))
                                    }
                                    Spacer()
                                }
                                .padding(14)
                            }
                        }
                    }
                }
                .padding(16)
            }
        }
        .navigationTitle("Download History")
        .navigationBarTitleDisplayMode(.inline)
    }
}

private struct ShinnModernTermsView: View {
    var body: some View {
        ZStack {
            ShinnModernBackground()
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 14) {
                    Text("Điều khoản sử dụng")
                        .font(.system(size: 28, weight: .black, design: .rounded))
                    Text("Vui lòng đọc trước khi sử dụng Shinn Cheat.")
                        .font(.system(size: 12, weight: .medium, design: .rounded))
                        .foregroundStyle(.white.opacity(0.45))

                    termsCard("1. Sử dụng ứng dụng", """
Shinn Cheat là công cụ quản lý và cài đặt các gói patch do người dùng lựa chọn. Bạn chịu trách nhiệm kiểm tra nguồn, phiên bản và tính tương thích của từng patch trước khi bật.
""")
                    termsCard("2. Patch và dữ liệu", """
Patch được tải từ repository được cấu hình trong ứng dụng. Ứng dụng kiểm tra SHA-256 khi manifest cung cấp mã xác thực. Không chỉnh sửa hoặc chia sẻ lại gói nếu bạn không có quyền đối với nội dung đó.
""")
                    termsCard("3. Trách nhiệm người dùng", """
Bạn tự chịu trách nhiệm về việc sử dụng patch trên thiết bị và ứng dụng đích. Hãy tôn trọng điều khoản của dịch vụ hoặc trò chơi mà bạn sử dụng.
""")
                    termsCard("4. Key và quyền truy cập", """
Key, thời hạn và quyền truy cập repository được quản lý theo hệ thống của Shinn Cheat. Không chia sẻ key cá nhân cho người khác.
""")
                    termsCard("5. Cập nhật điều khoản", """
Điều khoản có thể được cập nhật khi ứng dụng hoặc hệ thống repository thay đổi. Phiên bản hiển thị trong ứng dụng là phiên bản đang được cài đặt.
""")
                }
                .padding(16)
            }
        }
        .navigationTitle("Terms")
        .navigationBarTitleDisplayMode(.inline)
    }

    private func termsCard(_ title: String, _ text: String) -> some View {
        ShinnModernCard(radius: 20) {
            VStack(alignment: .leading, spacing: 8) {
                Text(title)
                    .font(.system(size: 15, weight: .black, design: .rounded))
                    .foregroundStyle(ShinnModernPalette.cyan)
                Text(text)
                    .font(.system(size: 11, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.62))
                    .lineSpacing(3)
            }
            .padding(15)
        }
    }
}

private struct ShinnModernAboutView: View {
    var body: some View {
        ZStack {
            ShinnModernBackground()
            ScrollView(showsIndicators: false) {
                VStack(spacing: 16) {
                    Image("ShinnSplashArt")
                        .resizable()
                        .scaledToFill()
                        .frame(width: 110, height: 110)
                        .clipShape(RoundedRectangle(cornerRadius: 28, style: .continuous))
                        .overlay(RoundedRectangle(cornerRadius: 28).stroke(ShinnModernPalette.blue.opacity(0.45), lineWidth: 1))

                    Text("Shinn Cheat")
                        .font(.system(size: 30, weight: .black, design: .rounded))
                    Text("Play Smarter · Win Easier")
                        .font(.system(size: 12, weight: .semibold, design: .rounded))
                        .foregroundStyle(.white.opacity(0.45))

                    ShinnModernCard(radius: 22) {
                        VStack(spacing: 0) {
                            aboutRow("Version", AppInfo.version)
                            Divider().background(Color.white.opacity(0.06))
                            aboutRow("Developer", "Shinn")
                            Divider().background(Color.white.opacity(0.06))
                            aboutRow("Support", AppInfo.telegramHandle)
                            Divider().background(Color.white.opacity(0.06))
                            aboutRow("Repository", "ShinnCheat Repo")
                        }
                        .padding(15)
                    }

                    ShinnModernCard(radius: 22) {
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Ứng dụng")
                                .font(.system(size: 15, weight: .black, design: .rounded))
                            Text("Shinn Cheat cung cấp giao diện quản lý repository, tải patch, bật/tắt patch, quản lý file và các công cụ hỗ trợ liên quan.")
                                .font(.system(size: 11, weight: .medium, design: .rounded))
                                .foregroundStyle(.white.opacity(0.55))
                                .lineSpacing(3)
                        }
                        .padding(15)
                    }

                    Text("© Shinn Cheat")
                        .font(.system(size: 10, weight: .medium, design: .rounded))
                        .foregroundStyle(.white.opacity(0.25))
                }
                .frame(maxWidth: .infinity)
                .padding(20)
            }
        }
        .navigationTitle("About")
        .navigationBarTitleDisplayMode(.inline)
    }

    private func aboutRow(_ key: String, _ value: String) -> some View {
        HStack {
            Text(key)
                .font(.system(size: 11, weight: .medium, design: .rounded))
                .foregroundStyle(.white.opacity(0.42))
            Spacer()
            Text(value)
                .font(.system(size: 11, weight: .bold, design: .rounded))
                .foregroundStyle(.white)
                .lineLimit(1)
        }
        .padding(.vertical, 9)
    }
}

private struct ShinnModernPremiumView: View {
    @EnvironmentObject private var store: RepoStore
    @EnvironmentObject private var license: LicenseManager
    @Binding var destination: ShinnModernDestination?
    @State private var key = ""
    @State private var message = ""
    @State private var busy = false

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 16) {
                Image("ShinnHeroArt")
                    .resizable().scaledToFill()
                    .frame(height: 180)
                    .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))

                ShinnModernCard(radius: 24, stroke: ShinnModernPalette.purple.opacity(0.35)) {
                    VStack(spacing: 12) {
                        Image(systemName: "crown.fill")
                            .font(.system(size: 34, weight: .black))
                            .foregroundStyle(ShinnModernPalette.purple)
                        Text("Repo 2 - Premium").font(.system(size: 22, weight: .black, design: .rounded))
                        benefit("Nhiều patch độc quyền")
                        benefit("Cập nhật sớm nhất")
                        benefit("Hỗ trợ 24/7")
                        benefit("Sử dụng key để mở khóa")
                    }
                    .padding(18)
                }

                Button { destination = .key } label: {
                    Label("Nhập key", systemImage: "key.fill").frame(maxWidth: .infinity)
                }
                .buttonStyle(ShinnModernPrimaryButtonStyle(tint: ShinnModernPalette.purple))

                if !message.isEmpty {
                    Text(message).font(.footnote).foregroundStyle(.red).multilineTextAlignment(.center)
                }

                Button { UIApplication.shared.open(AppInfo.telegramLinkURL) } label: {
                    HStack { ShinnModernIcon(systemName: "paperplane.fill", tint: ShinnModernPalette.blue, size: 42); Text("Chưa có key? Liên hệ Telegram để mua key Premium"); Spacer(); Image(systemName: "chevron.right") }
                        .padding(13)
                }
                .buttonStyle(.plain)
                .background(ShinnModernPalette.card.opacity(0.78), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            }
            .padding(16)
        }
        .background(ShinnModernBackground())
        .navigationTitle("Premium Repo")
        .navigationBarTitleDisplayMode(.inline)
    }

    private func benefit(_ text: String) -> some View {
        HStack { Image(systemName: "checkmark.circle.fill").foregroundStyle(ShinnModernPalette.blue); Text(text); Spacer() }
            .font(.system(size: 13, weight: .medium, design: .rounded))
    }
}

private struct ShinnModernKeyView: View {
    @EnvironmentObject private var store: RepoStore
    @EnvironmentObject private var license: LicenseManager
    @Environment(\.dismiss) private var dismiss
    @State private var key = ""
    @State private var busy = false
    @State private var message = ""

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 18) {
                Spacer(minLength: 20)
                ShinnModernCard(radius: 25, stroke: ShinnModernPalette.blue.opacity(0.30)) {
                    VStack(spacing: 15) {
                        Image(systemName: "crown.fill")
                            .font(.system(size: 36, weight: .black))
                            .foregroundStyle(.white)
                            .frame(width: 72, height: 72)
                            .background(ShinnModernPalette.blue.opacity(0.20), in: Circle())
                        Text("Premium Key").font(.system(size: 23, weight: .black, design: .rounded))
                        SecureField("Nhập key của bạn…", text: $key)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled(true)
                            .padding(15)
                            .background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                        Button {
                            Task { await activate() }
                        } label: {
                            if busy { ProgressView().tint(.white) } else { Text("Xác nhận") }
                        }
                        .buttonStyle(ShinnModernPrimaryButtonStyle())
                        Button("Kiểm tra key") { Task { await activate() } }
                            .font(.system(size: 12, weight: .semibold, design: .rounded))
                            .foregroundStyle(ShinnModernPalette.cyan)

                        Button {
                            // Skip is deliberately V1-only: no key, no V2 access.
                            UserDefaults.standard.set(true, forKey: "shinn.key.skipped")
                            Task {
                                await store.selectRepo(v2: false)
                                dismiss()
                            }
                        } label: {
                            Text("Bỏ qua · vào app với Repo V1")
                                .font(.system(size: 12, weight: .semibold, design: .rounded))
                                .foregroundStyle(.white.opacity(0.55))
                        }
                    }
                    .padding(18)
                }
                if !message.isEmpty { Text(message).font(.footnote).foregroundStyle(.red).multilineTextAlignment(.center) }
                Text("Key hợp lệ sẽ mở khóa Repo 2 và các patch đặc biệt.")
                    .font(.system(size: 11, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.40))
                    .multilineTextAlignment(.center)
            }
            .padding(16)
        }
        .background(ShinnModernBackground())
        .navigationTitle("Nhập Key")
        .navigationBarTitleDisplayMode(.inline)
    }

    private func activate() async {
        let value = key.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !value.isEmpty else { message = "Vui lòng nhập key."; return }
        busy = true
        defer { busy = false }
        let ok = await license.activate(key: value, language: .en)
        if ok && license.isActivated && store.isRepoV2Authorized {
            UserDefaults.standard.set(false, forKey: "shinn.key.skipped")
            await store.selectRepo(v2: true)
            message = "Đã xác thực key · Repo V2 đã mở khóa."
            key = ""
            dismiss()
        } else if ok && license.isActivated {
            message = license.lastError ?? "Key không hợp lệ."
        }
    }
}

private struct ShinnModernAIView: View {
    @EnvironmentObject private var license: LicenseManager
    @EnvironmentObject private var store: RepoStore
    @State private var input = ""
    @State private var messages: [(String, Bool)] = [
        ("Xin chào! Mình là Shinn AI. Mình có thể giúp bạn tìm patch, kiểm tra key và điều hướng các chức năng của app.", false)
    ]
    private let commands = ["/start", "/help", "/patch", "/key", "/files", "/info"]

    var body: some View {
        VStack(spacing: 0) {
            aiHeader
            ScrollViewReader { proxy in
                ScrollView(showsIndicators: false) {
                    LazyVStack(alignment: .leading, spacing: 10) {
                        ForEach(Array(messages.enumerated()), id: \.offset) { index, item in
                            aiBubble(item.0, user: item.1).id(index)
                        }
                        quickCommands
                    }
                    .padding(16)
                }
                .onChange(of: messages.count) { _ in
                    withAnimation(.easeOut(duration: 0.2)) {
                        proxy.scrollTo(messages.count - 1, anchor: .bottom)
                    }
                }
            }
            aiComposer
        }
        .foregroundStyle(.white)
    }

    private var aiHeader: some View {
        HStack(spacing: 11) {
            Image("ShinnAIArt")
                .resizable().scaledToFill()
                .frame(width: 48, height: 48)
                .clipShape(RoundedRectangle(cornerRadius: 15, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 15).stroke(ShinnModernPalette.cyan.opacity(0.35)))
            VStack(alignment: .leading, spacing: 3) {
                Text("Shinn AI").font(.system(size: 21, weight: .black, design: .rounded))
                Text("Patch · Key · Files · App control")
                    .font(.system(size: 9.5, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.45))
            }
            Spacer()
            ShinnModernPill(text: "ONLINE", tint: ShinnModernPalette.green)
        }
        .padding(.horizontal, 16).padding(.top, 10).padding(.bottom, 12)
    }

    private func aiBubble(_ text: String, user: Bool) -> some View {
        HStack {
            if user { Spacer(minLength: 35) }
            Text(text)
                .font(.system(size: 13, weight: .medium, design: .rounded))
                .foregroundStyle(.white)
                .padding(12)
                .background(user ? ShinnModernPalette.blue.opacity(0.28) : ShinnModernPalette.card, in: RoundedRectangle(cornerRadius: 17, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 17).stroke((user ? ShinnModernPalette.blue : Color.white).opacity(0.10)))
            if !user { Spacer(minLength: 35) }
        }
    }

    private var quickCommands: some View {
        ShinnModernCard(radius: 18) {
            VStack(alignment: .leading, spacing: 8) {
                Text("Quick actions").font(.system(size: 12, weight: .black, design: .rounded))
                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 7) {
                    ForEach(commands, id: \.self) { command in
                        Button { send(command) } label: {
                            HStack {
                                Text(command).foregroundStyle(ShinnModernPalette.cyan)
                                Spacer()
                                Image(systemName: "arrow.up.right").foregroundStyle(.white.opacity(0.25))
                            }
                            .font(.system(size: 10, weight: .bold, design: .rounded))
                            .padding(9)
                            .background(Color.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 11, style: .continuous))
                        }.buttonStyle(.plain)
                    }
                }
            }.padding(12)
        }
    }

    private var aiComposer: some View {
        HStack(spacing: 8) {
            TextField("Ask Shinn AI…", text: $input)
                .textFieldStyle(.plain)
                .foregroundStyle(.white)
                .padding(12)
                .background(ShinnModernPalette.card, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            Button { let value = input; input = ""; send(value) } label: {
                Image(systemName: "arrow.up").frame(width: 42, height: 42)
            }
            .buttonStyle(ShinnModernPrimaryButtonStyle(tint: ShinnModernPalette.cyan, compact: true))
        }
        .padding(10)
    }

    private func send(_ text: String) {
        let value = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !value.isEmpty else { return }
        messages.append((value, true))
        let lower = value.lowercased()
        let reply: String
        if lower.contains("/patch") || lower.contains("patch") {
            reply = "Patch Center currently has \(store.packages.count) visible package(s). Open the Patch tab to browse Repo V1 or Repo V2."
        } else if lower.contains("/files") || lower.contains("file") || lower.contains("tệp") {
            reply = "Open the Files tab to manage the existing file tools and tabbed file browser."
        } else if lower.contains("/key") || lower.contains("key") {
            if license.isActivated {
                reply = "Current key: \(license.holderName.isEmpty ? license.savedLicenseKey : license.holderName)."
            } else {
                reply = "No key is currently activated. Open Account → Key & Account to activate one."
            }
        } else if lower.contains("/info") || lower.contains("version") {
            reply = "ShinnCheat · Patch Center · Shinn AI · Files · Account."
        } else if lower.contains("/help") || lower.contains("help") {
            reply = "Try /patch, /key, /files or /info."
        } else {
            reply = "I can help with Patch, Key, Files and app information. Try /help."
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.22) {
            messages.append((reply, false))
        }
    }
}


private struct ShinnModernFilesCenter: View {
    @Binding var session: FilesTabSession
    @State private var showTabs = false
    @State private var showDownloads = false
    @EnvironmentObject private var store: RepoStore

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 14) {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Files").font(.system(size: 29, weight: .black, design: .rounded))
                    Text("File tools remain available without removing the original browser features.")
                        .font(.system(size: 10.5, weight: .medium, design: .rounded))
                        .foregroundStyle(.white.opacity(0.45))
                }

                ShinnModernCard(radius: 22, stroke: ShinnModernPalette.blue.opacity(0.24)) {
                    VStack(alignment: .leading, spacing: 12) {
                        HStack {
                            ShinnModernIcon(systemName: "folder.fill", tint: ShinnModernPalette.blue, size: 48)
                            VStack(alignment: .leading, spacing: 3) {
                                Text("File Browser").font(.system(size: 16, weight: .black, design: .rounded))
                                Text("Browse, search and manage your existing file tabs.")
                                    .font(.system(size: 9.5, weight: .medium, design: .rounded))
                                    .foregroundStyle(.white.opacity(0.45))
                            }
                            Spacer()
                        }
                        Button { showTabs = true } label: {
                            Label("Open File Tabs", systemImage: "folder.badge.gearshape")
                                .frame(maxWidth: .infinity)
                        }
                        .buttonStyle(ShinnModernPrimaryButtonStyle(tint: ShinnModernPalette.blue))
                    }
                    .padding(15)
                }

                ShinnModernCard(radius: 22) {
                    VStack(alignment: .leading, spacing: 10) {
                        HStack {
                            Text("Recent Downloads").font(.system(size: 16, weight: .black, design: .rounded))
                            Spacer()
                            Text("\(store.downloadHistory.count)").font(.system(size: 16, weight: .black, design: .rounded)).foregroundStyle(ShinnModernPalette.cyan)
                        }
                        if store.downloadHistory.isEmpty {
                            Text("No downloaded patches yet.").font(.system(size: 10, weight: .medium, design: .rounded)).foregroundStyle(.white.opacity(0.40))
                        } else {
                            ForEach(Array(store.downloadHistory.prefix(6))) { item in
                                HStack(spacing: 9) {
                                    Image(systemName: "arrow.down.circle.fill").foregroundStyle(ShinnModernPalette.cyan)
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text(item.name).font(.system(size: 11, weight: .bold, design: .rounded)).lineLimit(1)
                                        Text("\(item.repo) · \(item.version ?? "—")").font(.system(size: 8.5, weight: .medium, design: .rounded)).foregroundStyle(.white.opacity(0.38))
                                    }
                                    Spacer()
                                }
                                .padding(.vertical, 4)
                            }
                        }
                    }
                    .padding(15)
                }
            }
            .foregroundStyle(.white)
            .padding(16)
        }
        .sheet(isPresented: $showTabs) {
            FilesTabSwitcherView(session: $session)
        }
    }
}

private struct ShinnModernCommunityView: View {
    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 13) {
                VStack(alignment: .leading, spacing: 5) {
                    Text("Cộng đồng").font(.system(size: 30, weight: .black, design: .rounded))
                    Text("Tham gia group để nhận hỗ trợ").font(.system(size: 12, weight: .medium, design: .rounded)).foregroundStyle(.white.opacity(0.48))
                }
                community("Group chính", "ShinnCheatShare", "Cập nhật · Thông báo · Tài nguyên", AppInfo.telegramMainGroupURL)
                community("English Chat", "ShinnCheatChat", "English only · Discussion · Support", AppInfo.telegramEnglishChatURL)
                community("Hỗ trợ liên hệ", "@ShinnThieuu", "Hỗ trợ nhanh · Giải đáp thắc mắc", AppInfo.telegramLinkURL)
                Image("ShinnCatCommunity")
                    .resizable().scaledToFill().frame(height: 125).clipped()
                    .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
                    .overlay(alignment: .bottomLeading) { Text("Join our community\nStay updated!").font(.system(size: 17, weight: .black, design: .rounded)).padding(16) }
            }
            .foregroundStyle(.white)
            .padding(16)
        }
    }

    private func community(_ title: String, _ name: String, _ subtitle: String, _ url: URL) -> some View {
        Button { UIApplication.shared.open(url) } label: {
            HStack(spacing: 12) {
                ShinnModernIcon(systemName: "paperplane.fill", tint: ShinnModernPalette.blue, size: 48)
                VStack(alignment: .leading, spacing: 3) {
                    Text(title).font(.system(size: 15, weight: .black, design: .rounded))
                    Text(name).font(.system(size: 12, weight: .semibold, design: .rounded)).foregroundStyle(ShinnModernPalette.cyan)
                    Text(subtitle).font(.system(size: 10, weight: .medium, design: .rounded)).foregroundStyle(.white.opacity(0.42))
                }
                Spacer()
                Image(systemName: "chevron.right").foregroundStyle(.white.opacity(0.30))
            }
            .padding(13)
            .background(ShinnModernPalette.card.opacity(0.80), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        }
        .buttonStyle(.plain)
    }
}

private struct ShinnModernMoreView: View {
    @Binding var destination: ShinnModernDestination?
    let session: Session
    @EnvironmentObject private var license: LicenseManager
    @EnvironmentObject private var store: RepoStore

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 13) {
                Text("Account").font(.system(size: 30, weight: .black, design: .rounded))
                Text("Cài đặt và thông tin ứng dụng").font(.system(size: 12, weight: .medium, design: .rounded)).foregroundStyle(.white.opacity(0.48))

                moreRow("Shinn Cheat", "Play Smarter · Win Easier", "ShinnAvatarArt", nil)
                moreRow("Lịch sử tải xuống", "Patch đã tải", nil, "clock.arrow.circlepath") { destination = .downloadHistory }
                moreRow("Tệp của tôi", "File manager", nil, "folder.fill") { destination = .files }
                moreRow("Cài đặt", "Giao diện", nil, "gearshape.fill") { destination = .settings }
                moreRow("Hỗ trợ & Liên hệ", "@ShinnThieuu", nil, "questionmark.circle.fill") { UIApplication.shared.open(AppInfo.telegramLinkURL) }
                moreRow("Điều khoản sử dụng", "Quy định và trách nhiệm", nil, "doc.text.fill") { destination = .terms }
                moreRow("Giới thiệu ứng dụng", "Shinn Cheat", nil, "info.circle.fill") { destination = .about }

                if license.isActivated {
                    ShinnModernCard(radius: 18, stroke: ShinnModernPalette.cyan.opacity(0.22)) {
                        VStack(alignment: .leading, spacing: 8) {
                            HStack {
                                Image(systemName: "key.fill").foregroundStyle(ShinnModernPalette.cyan)
                                VStack(alignment: .leading, spacing: 2) {
                                    Text("Key đang đăng nhập")
                                        .font(.system(size: 14, weight: .black, design: .rounded))
                                    Text(license.holderName.isEmpty ? license.savedLicenseKey : license.holderName)
                                        .font(.system(size: 10, weight: .medium, design: .rounded))
                                        .foregroundStyle(.white.opacity(0.48))
                                        .lineLimit(1)
                                }
                                Spacer()
                            }
                            if let expires = license.expiresAt {
                                TimelineView(.periodic(from: .now, by: 30)) { context in
                                    Text("Còn lại: \(remainingText(until: expires, now: context.date))")
                                        .font(.system(size: 11, weight: .bold, design: .rounded))
                                        .foregroundStyle(expires > context.date ? ShinnModernPalette.green : .red)
                                }
                            } else {
                                Text("Thời hạn: Vĩnh viễn")
                                    .font(.system(size: 11, weight: .bold, design: .rounded))
                                    .foregroundStyle(ShinnModernPalette.green)
                            }
                            Button {
                                license.signOutLicense()
                                session.role = nil
                                Task { await store.selectRepo(v2: false) }
                            } label: {
                                Label("Đăng xuất key · về Repo V1", systemImage: "rectangle.portrait.and.arrow.right")
                                    .frame(maxWidth: .infinity)
                            }
                            .buttonStyle(ShinnModernPrimaryButtonStyle(tint: .red, compact: true))
                        }
                        .padding(13)
                    }
                }

                if session.role == .owner {
                    moreRow("Tạo / Xoá Key", "Chỉ Owner · quản lý key", nil, "key.fill") { destination = .ownerKeys }
                    moreRow("Repo V2 · Gán Key", "Chỉ Owner · cấp quyền Repo V2", nil, "crown.fill") { destination = .repositoryManager }
                    moreRow("Quản lý Patch", "Owner tools", nil, "wrench.and.screwdriver.fill") { destination = .patchProjects }
                }

                ShinnModernCard(radius: 20) {
                    HStack(spacing: 12) {
                        Image("ShinnAIArt").resizable().scaledToFill().frame(width: 50, height: 50).clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                        VStack(alignment: .leading, spacing: 3) { Text("Cảm ơn bạn").font(.system(size: 16, weight: .black, design: .rounded)); Text("Đã đồng hành cùng Shinn Cheat").font(.system(size: 10, weight: .medium, design: .rounded)).foregroundStyle(.white.opacity(0.45)) }
                        Spacer()
                    }
                    .padding(13)
                }
            }
            .foregroundStyle(.white)
            .padding(16)
        }
    }

    private func remainingText(until date: Date, now: Date) -> String {
        let seconds = max(0, Int(date.timeIntervalSince(now)))
        if seconds == 0 { return "Đã hết hạn" }
        let days = seconds / 86_400
        let hours = (seconds % 86_400) / 3_600
        let minutes = (seconds % 3_600) / 60
        if days > 0 { return "\(days) ngày \(hours) giờ" }
        if hours > 0 { return "\(hours) giờ \(minutes) phút" }
        return "\(max(1, minutes)) phút"
    }

    private func moreRow(_ title: String, _ subtitle: String, _ image: String?, _ icon: String?, action: @escaping () -> Void = {}) -> some View {
        Button(action: action) {
            HStack(spacing: 12) {
                if let image {
                    Image(image).resizable().scaledToFill().frame(width: 43, height: 43).clipShape(RoundedRectangle(cornerRadius: 13, style: .continuous))
                } else if let icon {
                    ShinnModernIcon(systemName: icon, tint: ShinnModernPalette.blue, size: 43)
                }
                VStack(alignment: .leading, spacing: 3) { Text(title).font(.system(size: 14, weight: .bold, design: .rounded)); Text(subtitle).font(.system(size: 10, weight: .medium, design: .rounded)).foregroundStyle(.white.opacity(0.40)) }
                Spacer()
                Image(systemName: "chevron.right").foregroundStyle(.white.opacity(0.30))
            }
            .padding(11)
            .background(ShinnModernPalette.card.opacity(0.80), in: RoundedRectangle(cornerRadius: 17, style: .continuous))
        }
        .buttonStyle(.plain)
    }
}


private struct ShinnModernOwnerKeysView: View {
    @EnvironmentObject private var session: Session
    @StateObject private var manager = OwnerKeyManager()
    @State private var copied = false
    @State private var selectedImage: PhotosPickerItem?
    @State private var keyArtwork: UIImage?
    @State private var imageStatus = ""

    private let durations = [1, 3, 7, 30, 90, 365]

    var body: some View {
        ownerGate
    }

    @ViewBuilder
    private var ownerGate: some View {
        if session.role == .owner {
            ownerPage
        } else {
            Text("Owner only")
                .foregroundStyle(.white)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(ShinnModernBackground())
        }
    }

    private var ownerPage: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 14) {
                ownerHeader
                ownerCreateCard
                ownerKeysCard
            }
            .foregroundStyle(.white)
            .padding(12)
        }
        .background(ShinnModernBackground())
        .navigationTitle("Owner Keys")
        .navigationBarTitleDisplayMode(.inline)
        .task {
            await manager.listKeys()
            loadArtwork()
        }
    }

    private var ownerHeader: some View {
        VStack(alignment: .leading, spacing: 5) {
            Text("Tạo / Xoá Key")
                .font(.system(size: 28, weight: .black, design: .rounded))
            Text("Chỉ Owner mới nhìn thấy và sử dụng khu vực này.")
                .font(.system(size: 12, weight: .medium, design: .rounded))
                .foregroundStyle(.white.opacity(0.48))
        }
    }

    private var ownerCreateCard: some View {
        ShinnModernCard(radius: 22, stroke: ShinnModernPalette.purple.opacity(0.30)) {
            VStack(alignment: .leading, spacing: 12) {
                Text("Tạo key")
                    .font(.system(size: 18, weight: .black, design: .rounded))

                TextField("Tên người nhận (tuỳ chọn)", text: $manager.keyLabel)
                    .textFieldStyle(.plain)
                    .foregroundStyle(.white)
                    .padding(12)
                    .background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 13, style: .continuous))

                TextField("Custom key (tuỳ chọn)", text: $manager.customKey)
                    .textFieldStyle(.plain)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled(true)
                    .foregroundStyle(.white)
                    .padding(12)
                    .background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 13, style: .continuous))

                ownerArtworkPicker

                if !imageStatus.isEmpty {
                    Text(imageStatus)
                        .font(.system(size: 9, weight: .medium, design: .rounded))
                        .foregroundStyle(ShinnModernPalette.green)
                }

                Picker("Thời hạn", selection: $manager.selectedHours) {
                    Text("1 giờ · Test").tag(1)
                    Text("Theo ngày").tag(0)
                }
                .pickerStyle(.segmented)

                if manager.selectedHours == 0 {
                    Toggle("Vĩnh viễn", isOn: $manager.lifetime)
                    if !manager.lifetime {
                        Picker("Số ngày", selection: $manager.selectedDays) {
                            ForEach(durations, id: \.self) { dayCount in
                                Text(dayCount == 365 ? "1 năm" : "\(dayCount) ngày").tag(dayCount)
                            }
                        }
                        .pickerStyle(.menu)
                    }
                }

                Stepper("Số lượng: \(manager.createCount)", value: $manager.createCount, in: 1...99)
                createKeyButton
                createdKeySection
            }
            .padding(16)
        }
    }

    private var ownerArtworkPicker: some View {
        HStack(spacing: 12) {
            Group {
                if let keyArtwork {
                    Image(uiImage: keyArtwork)
                        .resizable()
                        .scaledToFill()
                } else {
                    Image(systemName: "photo.badge.plus")
                        .font(.system(size: 21, weight: .bold))
                        .foregroundStyle(ShinnModernPalette.cyan)
                }
            }
            .frame(width: 54, height: 54)
            .clipShape(RoundedRectangle(cornerRadius: 15, style: .continuous))
            .background(Color.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 15, style: .continuous))

            VStack(alignment: .leading, spacing: 3) {
                Text("Ảnh Key")
                    .font(.system(size: 13, weight: .black, design: .rounded))
                Text("Chọn ảnh riêng để hiển thị trong bảng key.")
                    .font(.system(size: 9.5, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.45))
            }
            Spacer()
            PhotosPicker(selection: $selectedImage, matching: .images) {
                Text("Chọn ảnh")
                    .font(.system(size: 11, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 9)
                    .background(ShinnModernPalette.blue.opacity(0.22), in: Capsule())
            }
            .onChange(of: selectedImage) { item in
                handleArtworkSelection(item)
            }
        }
    }

    private var createKeyButton: some View {
        Button {
            Task { await manager.createKey() }
        } label: {
            Label(manager.isLoading ? "Đang tạo…" : "Tạo Key", systemImage: "plus.circle.fill")
                .frame(maxWidth: .infinity)
        }
        .buttonStyle(ShinnModernPrimaryButtonStyle(tint: ShinnModernPalette.purple))
        .disabled(manager.isLoading)
    }

    @ViewBuilder
    private var createdKeySection: some View {
        if !manager.prettyCreated.isEmpty {
            Text(manager.prettyCreated)
                .font(.system(size: 12, weight: .bold, design: .monospaced))
                .foregroundStyle(ShinnModernPalette.cyan)
                .textSelection(.enabled)
            Button {
                UIPasteboard.general.string = manager.prettyCreated
                copied = true
            } label: {
                Label(copied ? "Đã sao chép" : "Sao chép", systemImage: copied ? "checkmark" : "doc.on.doc")
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.plain)
        }
    }

    private var ownerKeysCard: some View {
        ShinnModernCard(radius: 22) {
            VStack(alignment: .leading, spacing: 10) {
                ownerKeysHeader
                ownerRepoPolicyCard
                ownerKeysList
                deleteAllButton
                ownerError
            }
            .padding(16)
        }
    }

    private var ownerKeysHeader: some View {
        HStack {
            VStack(alignment: .leading, spacing: 2) {
                Text("Key đã tạo (\(manager.keys.count))")
                    .font(.system(size: 17, weight: .black, design: .rounded))
                Text("Mỗi key do Owner tạo sẽ tự mở Repo V2.")
                    .font(.system(size: 9.5, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.42))
            }
            Spacer()
            Button {
                Task { await manager.listKeys() }
            } label: {
                Image(systemName: manager.isLoading ? "hourglass" : "arrow.clockwise")
            }
            .buttonStyle(.plain)
        }
    }

    private var ownerRepoPolicyCard: some View {
        HStack(spacing: 10) {
            ShinnModernIcon(systemName: "shippingbox.fill", tint: ShinnModernPalette.cyan, size: 40)
            VStack(alignment: .leading, spacing: 3) {
                Text("New keys · V1 + V2")
                    .font(.system(size: 12, weight: .black, design: .rounded))
                Text("Keys created here are intended to receive both repositories. The fixed ShinnCheat key remains V1-only.")
                    .font(.system(size: 9, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.42))
            }
            Spacer()
            ShinnModernPill(text: "ALL REPOS", tint: ShinnModernPalette.cyan)
        }
        .padding(11)
        .background(ShinnModernPalette.cyan.opacity(0.07), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(ShinnModernPalette.cyan.opacity(0.18), lineWidth: 0.8))
    }

    @ViewBuilder
    private var ownerKeysList: some View {
        if manager.keys.isEmpty {
            Text("Chưa có key hoặc chưa tải danh sách.")
                .font(.caption)
                .foregroundStyle(.white.opacity(0.45))
        } else {
            ForEach(manager.keys) { row in
                ownerKeyRow(row)
            }
        }
    }

    private func ownerKeyRow(_ row: ShinnKeyRow) -> some View {
        HStack(spacing: 10) {
            VStack(alignment: .leading, spacing: 3) {
                Text(row.key)
                    .font(.system(size: 12, weight: .bold, design: .monospaced))
                    .textSelection(.enabled)
                Text(row.label?.isEmpty == false ? row.label! : (row.role ?? "member"))
                    .font(.system(size: 10, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.42))
                ownerKeyMeta(row)
                HStack(spacing: 5) {
                    ShinnModernPill(text: row.repo_v1 == true ? "V1" : "V1 LOCK", tint: row.repo_v1 == true ? ShinnModernPalette.blue : .gray)
                    ShinnModernPill(text: row.repo_v2 == true ? "V2" : "V2 LOCK", tint: row.repo_v2 == true ? ShinnModernPalette.purple : .gray)
                }
                ownerKeyDate(row)
            }
            Spacer()
            Button {
                UIPasteboard.general.string = row.key
            } label: {
                Image(systemName: "doc.on.doc")
            }
            .buttonStyle(.plain)
            Button {
                Task { await manager.deleteKey(row.key) }
            } label: {
                Image(systemName: "trash.fill")
                    .foregroundStyle(.red)
            }
            .buttonStyle(.plain)
        }
        .padding(10)
        .background(Color.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
    }

    private func ownerKeyMeta(_ row: ShinnKeyRow) -> some View {
        HStack(spacing: 6) {
            TimelineView(.periodic(from: .now, by: 1)) { context in
                Text(ownerRemainingText(row.expires_at, now: context.date))
                    .font(.system(size: 10, weight: .bold, design: .rounded))
                    .foregroundStyle(ownerExpiryColor(row.expires_at, now: context.date))
            }
            ShinnModernPill(text: "V2 OPEN", tint: ShinnModernPalette.purple)
        }
    }

    private func ownerKeyDate(_ row: ShinnKeyRow) -> some View {
        Group {
            if let date = ownerExpiryDate(row.expires_at) {
                Text(date.formatted(date: .numeric, time: .shortened))
                    .font(.system(size: 8.5, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.30))
            }
        }
    }

    private func ownerExpiryColor(_ raw: String?, now: Date) -> Color {
        guard let date = ownerExpiryDate(raw) else { return ShinnModernPalette.cyan }
        return date > now ? ShinnModernPalette.green : .red
    }

    @ViewBuilder
    private var deleteAllButton: some View {
        if !manager.keys.isEmpty {
            Button(role: .destructive) {
                Task { await manager.deleteAllKeys() }
            } label: {
                Label("Xoá tất cả key", systemImage: "trash")
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.plain)
            .padding(.top, 4)
        }
    }

    @ViewBuilder
    private var ownerError: some View {
        if let error = manager.error, !error.isEmpty {
            Text(error)
                .font(.caption)
                .foregroundStyle(.red)
        }
    }

    private func loadArtwork() {
        guard let data = UserDefaults.standard.data(forKey: "shinn.owner.keyArtwork"),
              let image = UIImage(data: data) else { return }
        keyArtwork = image
    }

    private func handleArtworkSelection(_ item: PhotosPickerItem?) {
        guard let item else { return }
        Task {
            do {
                guard let data = try await item.loadTransferable(type: Data.self),
                      let image = UIImage(data: data) else {
                    imageStatus = "Không đọc được ảnh"
                    return
                }
                let resized = image.shinnKeyPreview(maxDimension: 900)
                keyArtwork = resized
                if let jpeg = resized.jpegData(compressionQuality: 0.82) {
                    UserDefaults.standard.set(jpeg, forKey: "shinn.owner.keyArtwork")
                    imageStatus = "Đã lưu ảnh trong app"
                }
            } catch {
                imageStatus = "Không đọc được ảnh"
            }
        }
    }
}

private extension UIImage {
    func shinnKeyPreview(maxDimension: CGFloat) -> UIImage {
        let largestDimension = Swift.max(size.width, size.height)
        guard largestDimension > 0 else { return self }
        let scale = Swift.min(CGFloat(1), maxDimension / largestDimension)
        guard scale < 1 else { return self }
        let target = CGSize(width: size.width * scale, height: size.height * scale)
        let renderer = UIGraphicsImageRenderer(size: target)
        return renderer.image { _ in
            draw(in: CGRect(origin: .zero, size: target))
        }
    }
}

private func ownerExpiryDate(_ raw: String?) -> Date? {
    guard let raw, !raw.isEmpty else { return nil }
    let f1 = ISO8601DateFormatter()
    f1.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
    if let date = f1.date(from: raw) { return date }
    let f2 = ISO8601DateFormatter()
    f2.formatOptions = [.withInternetDateTime]
    return f2.date(from: raw)
}

private func ownerRemainingText(_ raw: String?, now: Date) -> String {
    guard let date = ownerExpiryDate(raw) else { return "Vĩnh viễn" }
    let seconds = max(0, Int(date.timeIntervalSince(now)))
    if seconds == 0 { return "ĐÃ HẾT HẠN" }
    let days = seconds / 86_400
    let hours = (seconds % 86_400) / 3_600
    let minutes = (seconds % 3_600) / 60
    if days > 0 { return "Còn \(days)d \(hours)h" }
    if hours > 0 { return "Còn \(hours)h \(minutes)m" }
    return "Còn \(max(1, minutes))m"
}

private struct ShinnModernPrimaryButtonStyle: ButtonStyle {
    var tint: Color = ShinnModernPalette.blue
    var compact = false

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: compact ? 13 : 15, weight: .black, design: .rounded))
            .foregroundStyle(.white)
            .padding(.vertical, compact ? 0 : 14)
            .frame(maxWidth: .infinity)
            .background(LinearGradient(colors: [tint, tint.opacity(0.68)], startPoint: .topLeading, endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: compact ? 15 : 16, style: .continuous))
            .scaleEffect(configuration.isPressed ? 0.97 : 1)
            .animation(.spring(response: 0.22, dampingFraction: 0.75), value: configuration.isPressed)
    }
}
