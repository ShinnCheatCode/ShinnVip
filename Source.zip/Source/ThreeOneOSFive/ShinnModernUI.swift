import SwiftUI
import UIKit

// MARK: - SHINN // NEXUS UI
// A new visual shell. Existing services, licensing, repositories, patch engine,
// DNS controls, history, settings and AI are intentionally reused.

private enum NexusTab: Int, CaseIterable {
    case core, library, ai, system
    var title: String {
        switch self { case .core: "Nexus"; case .library: "Library"; case .ai: "Shinn AI"; case .system: "System" }
    }
    var icon: String {
        switch self { case .core: "circle.hexagongrid.fill"; case .library: "square.stack.3d.up.fill"; case .ai: "sparkles"; case .system: "slider.horizontal.3.square" }
    }
}

private enum NexusDestination: String, Identifiable {
    case key, premium, settings, files, community, repository, history, terms, about, support, patchBuilder, patchProjects, cleanup
    var id: String { rawValue }
}

private enum NexusColor {
    static let void = Color(red: 0.008, green: 0.010, blue: 0.018)
    static let blue = Color(red: 0.12, green: 0.54, blue: 1.0)
    static let cyan = Color(red: 0.08, green: 0.92, blue: 1.0)
    static let purple = Color(red: 0.58, green: 0.20, blue: 1.0)
    static let magenta = Color(red: 1.0, green: 0.16, blue: 0.72)
    static let green = Color(red: 0.18, green: 0.95, blue: 0.64)
}

private struct NexusBackdrop: View {
    @State private var animate = false
    var body: some View {
        ZStack {
            NexusColor.void.ignoresSafeArea()
            Circle().fill(NexusColor.blue.opacity(0.13)).frame(width: 360).blur(radius: 100)
                .offset(x: animate ? 145 : -125, y: -290)
            Circle().fill(NexusColor.purple.opacity(0.12)).frame(width: 330).blur(radius: 110)
                .offset(x: animate ? -130 : 120, y: 270)
            LinearGradient(colors: [.clear, NexusColor.blue.opacity(0.035), .clear], startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()
            NexusScanlines()
        }
        .animation(.easeInOut(duration: 8).repeatForever(autoreverses: true), value: animate)
        .onAppear { animate = true }
    }
}

private struct NexusScanlines: View {
    var body: some View {
        Canvas { ctx, size in
            var p = Path()
            let gap: CGFloat = 34
            var y: CGFloat = 0
            while y < size.height {
                p.move(to: CGPoint(x: 0, y: y)); p.addLine(to: CGPoint(x: size.width, y: y)); y += gap
            }
            ctx.stroke(p, with: .color(.white.opacity(0.014)), lineWidth: 0.5)
        }
        .ignoresSafeArea()
        .allowsHitTesting(false)
    }
}

private struct NexusPanel<Content: View>: View {
    var radius: CGFloat = 24
    @ViewBuilder var content: Content
    var body: some View {
        content
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: radius, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: radius).stroke(
                LinearGradient(colors: [NexusColor.blue.opacity(0.42), .white.opacity(0.06), NexusColor.purple.opacity(0.35)], startPoint: .topLeading, endPoint: .bottomTrailing), lineWidth: 0.8))
    }
}

private struct NexusOrb: View {
    var active: Bool
    @State private var spin = false
    var body: some View {
        ZStack {
            Circle().fill((active ? NexusColor.cyan : NexusColor.purple).opacity(0.15)).blur(radius: 24)
            Circle().stroke((active ? NexusColor.cyan : NexusColor.purple).opacity(0.25), lineWidth: 1)
                .padding(12).rotationEffect(.degrees(spin ? 360 : 0))
            Circle().stroke(NexusColor.blue.opacity(0.35), lineWidth: 1).padding(28)
            Image(systemName: active ? "bolt.fill" : "crown.fill")
                .font(.system(size: 28, weight: .black))
                .foregroundStyle(.white)
                .shadow(color: (active ? NexusColor.cyan : NexusColor.purple), radius: 16)
        }
        .onAppear { spin = true }
        .animation(.linear(duration: 9).repeatForever(autoreverses: false), value: spin)
    }
}

struct ShinnNovaRootView: View {
    @EnvironmentObject private var store: RepoStore
    @EnvironmentObject private var license: LicenseManager
    @EnvironmentObject private var session: Session
    @State private var tab: NexusTab = .core
    @State private var destination: NexusDestination?
    @State private var showLaunch = true

    var body: some View {
        ZStack {
            NexusBackdrop()
            Group {
                switch tab {
                case .core: NexusCoreView(destination: $destination, tab: $tab)
                case .library: NexusPatchLibrary()
                case .ai: NexusAIView()
                case .system: NexusSystemView(destination: $destination)
                }
            }
            .transition(.opacity)
            if showLaunch {
                NexusLaunchView()
                    .transition(.opacity)
                    .zIndex(100)
            }
        }
        .safeAreaInset(edge: .bottom, spacing: 0) {
            NexusDock(selection: $tab)
                .opacity(showLaunch ? 0 : 1)
                .allowsHitTesting(!showLaunch)
                .padding(.horizontal, 10)
                .padding(.bottom, 5)
        }
        .sheet(item: $destination) { item in
            NavigationStack {
                switch item {
                case .key: ActivateKeyView()
                case .premium: PremiumRepoView()
                case .settings: ShinnSettingsHubView()
                case .files: FilesTabSwitcherView(session: .constant(FilesTabSession()))
                case .community: CommunityView()
                case .repository: RepositoryManagerView()
                case .history: ShinnModernDownloadHistoryView()
                case .terms: ShinnModernTermsView()
                case .about: ShinnAboutView()
                case .support: SupportView()
                case .patchBuilder: PatchBuilderView()
                case .patchProjects: session.role == .owner ? AnyView(PatchProjectsView()) : AnyView(PatchOwnerOnlyView())
                case .cleanup: PhoneCleanupView()
                }
            }
            .preferredColorScheme(.dark)
        }
        .task {
            try? await Task.sleep(nanoseconds: 1_850_000_000)
            withAnimation(.easeOut(duration: 0.55)) { showLaunch = false }
        }
    }
}

private struct NexusLaunchView: View {
    @State private var pulse = false
    @State private var sweep = false
    var body: some View {
        ZStack {
            NexusBackdrop()
            Circle().stroke(NexusColor.blue.opacity(0.18), lineWidth: 1).frame(width: 270).scaleEffect(sweep ? 1.3 : 0.7).opacity(sweep ? 0 : 1)
                .animation(.easeOut(duration: 1.7).repeatForever(autoreverses: false), value: sweep)
            Circle().stroke(NexusColor.purple.opacity(0.28), lineWidth: 1).frame(width: 195).rotationEffect(.degrees(pulse ? 360 : 0))
                .animation(.linear(duration: 5).repeatForever(autoreverses: false), value: pulse)
            VStack(spacing: 16) {
                ZStack {
                    Circle().fill(NexusColor.purple.opacity(0.24)).frame(width: 132).blur(radius: 30)
                    Image("ShinnSplashArt").resizable().scaledToFill().frame(width: 118, height: 118).clipShape(Circle())
                        .overlay(Circle().stroke(.white.opacity(0.42), lineWidth: 1))
                        .shadow(color: NexusColor.purple.opacity(0.75), radius: 25)
                }
                Text("SHINN").font(.system(size: 44, weight: .black, design: .rounded)).tracking(9).foregroundStyle(.white)
                Text("N E X U S").font(.system(size: 10, weight: .bold, design: .monospaced)).tracking(6).foregroundStyle(NexusColor.cyan)
                HStack(spacing: 7) { Circle().fill(NexusColor.green).frame(width: 5); Text("INITIALIZING CORE").font(.system(size: 9, weight: .bold, design: .monospaced)).foregroundStyle(.white.opacity(0.48)) }
            }
        }
        .onAppear { pulse = true; sweep = true }
    }
}

private struct NexusCoreView: View {
    @EnvironmentObject private var store: RepoStore
    @EnvironmentObject private var license: LicenseManager
    @EnvironmentObject private var session: Session
    @Binding var destination: NexusDestination?
    @Binding var tab: NexusTab
    @State private var orbit = false

    private var role: String {
        switch session.role { case .owner: "OWNER"; case .admin: "ADMIN"; case .member: "MEMBER"; case nil: "GUEST" }
    }

    var body: some View {
        GeometryReader { geo in
            ScrollView(showsIndicators: false) {
                VStack(spacing: 18) {
                    topBar
                    nexusHero(width: min(geo.size.width - 28, 430))
                    telemetry
                    actionDeck
                    liveStrip
                }
                .frame(maxWidth: 520)
                .frame(maxWidth: .infinity)
                .padding(.horizontal, 14)
                .padding(.top, 10)
                .padding(.bottom, 22)
            }
        }
    }

    private var topBar: some View {
        HStack(spacing: 10) {
            Image("ShinnAvatarArt").resizable().scaledToFill().frame(width: 34, height: 34).clipShape(Circle())
                .overlay(Circle().stroke(NexusColor.cyan.opacity(0.55), lineWidth: 0.7))
            VStack(alignment: .leading, spacing: 1) {
                Text("SHINN NEXUS").font(.system(size: 17, weight: .black, design: .rounded)).tracking(1.2)
                Text("CONTROL LAYER 5.0").font(.system(size: 8, weight: .bold, design: .monospaced)).foregroundStyle(NexusColor.cyan).tracking(1.5)
            }
            Spacer()
            Button { destination = .settings } label: { Image(systemName: "gearshape.2.fill").font(.system(size: 15, weight: .bold)).frame(width: 38, height: 38).background(.white.opacity(0.06), in: Circle()) }
                .buttonStyle(.plain)
        }.foregroundStyle(.white)
    }

    private func nexusHero(width: CGFloat) -> some View {
        NexusPanel(radius: 34) {
            ZStack {
                Image("ShinnHeroArt").resizable().scaledToFill().frame(height: 245).clipped().opacity(0.52)
                LinearGradient(colors: [.clear, NexusColor.void.opacity(0.20), NexusColor.void.opacity(0.98)], startPoint: .top, endPoint: .bottom)
                HStack(spacing: 16) {
                    NexusOrb(active: license.isActivated).frame(width: 122, height: 122).rotation3DEffect(.degrees(orbit ? 360 : 0), axis: (x: 0, y: 1, z: 0))
                    VStack(alignment: .leading, spacing: 8) {
                        Text(license.isActivated ? "CORE ONLINE" : "CORE STANDBY").font(.system(size: 11, weight: .black, design: .monospaced)).foregroundStyle(license.isActivated ? NexusColor.green : NexusColor.cyan)
                        Text(license.isActivated ? "Everything is ready." : "Welcome to the Nexus.").font(.system(size: 22, weight: .black, design: .rounded)).minimumScaleFactor(0.75)
                        Text(license.isActivated && !license.holderName.isEmpty ? license.holderName : "A new control layer for your Shinn workspace.").font(.system(size: 11, weight: .medium)).foregroundStyle(.white.opacity(0.5)).lineLimit(2)
                        HStack(spacing: 7) { NexusBadge(text: role); NexusBadge(text: store.usingRepoV2 ? "REPO V2" : "REPO V1") }
                    }
                }
                .padding(18)
            }
            .frame(height: 245)
            .clipShape(RoundedRectangle(cornerRadius: 34, style: .continuous))
        }
        .onAppear { orbit = true }
    }

    private var telemetry: some View {
        HStack(spacing: 8) {
            NexusMetric(icon: "square.stack.3d.up.fill", title: "PATCH", value: "\(store.packages.count)", tint: NexusColor.blue)
            NexusMetric(icon: "server.rack", title: "REPO", value: store.usingRepoV2 ? "V2" : "V1", tint: NexusColor.purple)
            NexusMetric(icon: "waveform.path.ecg", title: "STATE", value: license.isActivated ? "LIVE" : "FREE", tint: NexusColor.green)
        }
    }

    private var actionDeck: some View {
        VStack(alignment: .leading, spacing: 10) {
            NexusHeading(kicker: "COMMAND DECK", title: "Choose a module")
            LazyVGrid(columns: [GridItem(.flexible(), spacing: 9), GridItem(.flexible(), spacing: 9)], spacing: 9) {
                NexusAction(title: "Patch Library", detail: "Apply / restore", icon: "bolt.shield.fill", tint: NexusColor.blue) { tab = .library }
                NexusAction(title: "DNS Premium", detail: "V1 / V2 control", icon: "network", tint: NexusColor.cyan) { destination = .premium }
                NexusAction(title: "Shinn AI", detail: "Assistant core", icon: "sparkles", tint: NexusColor.magenta) { tab = .ai }
                NexusAction(title: "Key Center", detail: license.isActivated ? "Session active" : "Activate key", icon: "key.fill", tint: NexusColor.purple) { destination = .key }
            }
        }
    }

    private var liveStrip: some View {
        Button { destination = .repository } label: {
            NexusPanel(radius: 18) {
                HStack(spacing: 11) {
                    Circle().fill(NexusColor.green).frame(width: 7, height: 7).shadow(color: NexusColor.green, radius: 7)
                    VStack(alignment: .leading, spacing: 2) { Text("REPOSITORY LINK").font(.system(size: 9, weight: .black, design: .monospaced)).foregroundStyle(NexusColor.green); Text("Tap to inspect the active source").font(.system(size: 10, weight: .medium)).foregroundStyle(.white.opacity(0.46)) }
                    Spacer(); Image(systemName: "arrow.up.right").foregroundStyle(.white.opacity(0.45))
                }.padding(13)
            }
        }.buttonStyle(.plain)
    }
}

private struct NexusPatchLibrary: View {
    @EnvironmentObject private var store: RepoStore
    @State private var selected = Set<String>()
    @State private var filter = "ALL"
    @State private var search = ""
    @State private var busy = false
    @State private var message: String?

    private var filtered: [RepoPackage] {
        store.packages.filter { pkg in
            let categoryOK = filter == "ALL" || (pkg.category ?? "").localizedCaseInsensitiveContains(filter)
            let q = search.trimmingCharacters(in: .whitespacesAndNewlines)
            let searchOK = q.isEmpty || pkg.name.localizedCaseInsensitiveContains(q) || (pkg.summary ?? "").localizedCaseInsensitiveContains(q)
            return categoryOK && searchOK
        }
    }

    var body: some View {
        VStack(spacing: 0) {
            libraryHeader
            ScrollView(showsIndicators: false) {
                VStack(spacing: 10) {
                    filterBar
                    if filtered.isEmpty { NexusEmptyState(title: "No modules", subtitle: "Refresh the repository to load packages.") }
                    else { ForEach(filtered.prefix(80)) { pkg in NexusPatchRow(pkg: pkg, selected: selected.contains(pkg.id), toggle: toggle, action: applyOne) } }
                }.padding(.horizontal, 14).padding(.bottom, 24)
            }
            if !selected.isEmpty { applyDock }
        }
        .task { if store.packages.isEmpty { await store.refresh() } }
        .alert("Patch", isPresented: Binding(get: { message != nil }, set: { if !$0 { message = nil } })) { Button("OK", role: .cancel) {} } message: { Text(message ?? "") }
    }

    private var libraryHeader: some View {
        HStack(alignment: .bottom) {
            VStack(alignment: .leading, spacing: 4) {
                Text("PATCH LIBRARY").font(.system(size: 25, weight: .black, design: .rounded)).tracking(-0.5)
                Text("\(store.packages.count) modules · \(store.usingRepoV2 ? "V2" : "V1") source").font(.system(size: 10, weight: .bold, design: .monospaced)).foregroundStyle(NexusColor.cyan)
            }
            Spacer()
            Button { Task { await store.refresh() } } label: { Image(systemName: "arrow.clockwise").font(.system(size: 15, weight: .bold)).frame(width: 40, height: 40).background(.white.opacity(0.06), in: Circle()) }.buttonStyle(.plain)
        }.foregroundStyle(.white).padding(.horizontal, 16).padding(.top, 14).padding(.bottom, 10)
    }

    private var filterBar: some View {
        VStack(spacing: 9) {
            HStack { Image(systemName: "magnifyingglass"); TextField("Search modules", text: $search).textInputAutocapitalization(.never) }.font(.system(size: 12, weight: .medium)).foregroundStyle(.white.opacity(0.72)).padding(12).background(.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 16))
            ScrollView(.horizontal, showsIndicators: false) { HStack(spacing: 7) { ForEach(["ALL", "GAME", "MENU", "ESP"], id: \.self) { f in Button(f) { filter = f }.font(.system(size: 9, weight: .black, design: .monospaced)).foregroundStyle(filter == f ? .black : .white.opacity(0.55)).padding(.horizontal, 13).padding(.vertical, 8).background(filter == f ? NexusColor.cyan : .white.opacity(0.055), in: Capsule()).buttonStyle(.plain) } } }
        }
    }

    private var applyDock: some View {
        HStack(spacing: 10) {
            VStack(alignment: .leading, spacing: 2) { Text("\(selected.count) SELECTED").font(.system(size: 9, weight: .black, design: .monospaced)); Text("Ready for deployment").font(.system(size: 9, weight: .medium)).foregroundStyle(.white.opacity(0.42)) }
            Spacer()
            Button { Task { busy = true; let targets = store.packages.filter { selected.contains($0.id) }; let result = await store.applyMultiple(targets); await MainActor.run { busy = false; selected.removeAll(); message = store.lastApplyMessage ?? (result.fail.isEmpty ? "Patch applied." : "Some modules were rejected.") } } } label: { if busy { ProgressView().tint(.black) } else { Label("DEPLOY", systemImage: "bolt.fill") } }.font(.system(size: 11, weight: .black, design: .rounded)).foregroundStyle(.black).padding(.horizontal, 18).frame(minHeight: 42).background(NexusColor.cyan, in: Capsule()).disabled(busy)
        }.padding(12).background(.ultraThinMaterial).overlay(Rectangle().fill(.white.opacity(0.06)).frame(height: 0.5), alignment: .top)
    }

    private func toggle(_ pkg: RepoPackage) { if selected.contains(pkg.id) { selected.remove(pkg.id) } else { selected.insert(pkg.id) } }
    private func applyOne(_ pkg: RepoPackage) { Task { busy = true; await store.apply(pkg, openGame: true); await MainActor.run { busy = false; message = store.lastApplyMessage } } }
}

private struct NexusPatchRow: View {
    @EnvironmentObject private var store: RepoStore
    let pkg: RepoPackage
    let selected: Bool
    let toggle: (RepoPackage) -> Void
    let action: (RepoPackage) -> Void
    private var applied: Bool { if case .applied = store.patchState(for: pkg) { return true }; return false }
    var body: some View {
        HStack(spacing: 11) {
            ZStack {
                RoundedRectangle(cornerRadius: 14).fill(selected ? NexusColor.cyan.opacity(0.16) : .white.opacity(0.05))
                Image(systemName: applied ? "checkmark.seal.fill" : "cube.fill").font(.system(size: 16, weight: .bold)).foregroundStyle(applied ? NexusColor.green : NexusColor.cyan)
            }.frame(width: 46, height: 46)
            VStack(alignment: .leading, spacing: 3) {
                Text(pkg.name).font(.system(size: 13, weight: .bold, design: .rounded)).lineLimit(1)
                Text([pkg.category, pkg.version].compactMap { $0 }.joined(separator: " · ")).font(.system(size: 9, weight: .medium, design: .monospaced)).foregroundStyle(.white.opacity(0.4)).lineLimit(1)
            }
            Spacer()
            Button { toggle(pkg) } label: { Image(systemName: selected ? "checkmark.circle.fill" : "circle").font(.system(size: 20, weight: .bold)).foregroundStyle(selected ? NexusColor.cyan : .white.opacity(0.22)) }.buttonStyle(.plain)
            Button {
                if applied {
                    Task { await store.restore(pkg) }
                } else {
                    action(pkg)
                }
            } label: {
                Image(systemName: applied ? "arrow.uturn.backward" : "play.fill")
                    .font(.system(size: 11, weight: .black))
                    .frame(width: 34, height: 34)
                    .background(applied ? NexusColor.purple.opacity(0.25) : NexusColor.blue.opacity(0.22), in: Circle())
            }
            .buttonStyle(.plain)
        }.foregroundStyle(.white).padding(10).background(.white.opacity(0.035), in: RoundedRectangle(cornerRadius: 20)).overlay(RoundedRectangle(cornerRadius: 20).stroke(selected ? NexusColor.cyan.opacity(0.55) : .white.opacity(0.06), lineWidth: 0.8))
    }
}

private struct NexusAIView: View {
    @State private var showAssistant = false
    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 16) {
                HStack { VStack(alignment: .leading, spacing: 4) { Text("SHINN AI").font(.system(size: 27, weight: .black, design: .rounded)); Text("INTELLIGENCE LAYER").font(.system(size: 9, weight: .black, design: .monospaced)).foregroundStyle(NexusColor.magenta) }; Spacer(); Circle().fill(NexusColor.green).frame(width: 7).shadow(color: NexusColor.green, radius: 8) }.foregroundStyle(.white)
                NexusPanel(radius: 34) {
                    VStack(spacing: 16) {
                        Image("ShinnAIArt").resizable().scaledToFill().frame(height: 250).clipped().clipShape(RoundedRectangle(cornerRadius: 28))
                        VStack(spacing: 7) { Text("Your Shinn intelligence layer").font(.system(size: 20, weight: .black, design: .rounded)); Text("Ask about the app, repository, key status, settings or how to use an available feature.").font(.system(size: 11, weight: .medium)).foregroundStyle(.white.opacity(0.48)).multilineTextAlignment(.center) }
                        Button { showAssistant = true } label: { Label("OPEN SHINN AI", systemImage: "sparkles") }.font(.system(size: 11, weight: .black, design: .rounded)).foregroundStyle(.black).frame(maxWidth: .infinity, minHeight: 48).background(LinearGradient(colors: [NexusColor.cyan, NexusColor.blue], startPoint: .leading, endPoint: .trailing), in: Capsule())
                    }.padding(14)
                }
                HStack(spacing: 8) { NexusAIChip(icon: "key.fill", text: "Key status"); NexusAIChip(icon: "server.rack", text: "Repository"); NexusAIChip(icon: "gearshape.fill", text: "Settings") }
            }.frame(maxWidth: 520).frame(maxWidth: .infinity).padding(14).foregroundStyle(.white)
        }
        .sheet(isPresented: $showAssistant) { NavigationStack { ShinnAIChatView() }.preferredColorScheme(.dark) }
    }
}

private struct NexusSystemView: View {
    @EnvironmentObject private var license: LicenseManager
    @EnvironmentObject private var session: Session
    @Binding var destination: NexusDestination?
    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 12) {
                HStack { VStack(alignment: .leading, spacing: 4) { Text("CONTROL ROOM").font(.system(size: 26, weight: .black, design: .rounded)); Text("SYSTEM · ACCOUNT · TOOLS").font(.system(size: 9, weight: .black, design: .monospaced)).foregroundStyle(NexusColor.cyan) }; Spacer() }.foregroundStyle(.white)
                NexusPanel(radius: 26) { VStack(alignment: .leading, spacing: 10) { Text("SESSION").font(.system(size: 9, weight: .black, design: .monospaced)).foregroundStyle(NexusColor.green); HStack { NexusSystemValue(label: "STATUS", value: license.isActivated ? "ACTIVE" : "FREE"); NexusSystemValue(label: "ROLE", value: role) } } .padding(15) }
                ForEach(systemItems, id: \.0) { item in Button { destination = item.1 } label: { NexusSystemRow(icon: item.2, title: item.0, subtitle: item.3) }.buttonStyle(.plain) }
            }.frame(maxWidth: 520).frame(maxWidth: .infinity).padding(14)
        }
    }
    private var role: String { switch session.role { case .owner: "OWNER"; case .admin: "ADMIN"; case .member: "MEMBER"; case nil: "GUEST" } }
    private var systemItems: [(String, NexusDestination, String, String)] { [
        ("Key Center", .key, "key.fill", "Activation and session"),
        ("DNS Premium", .premium, "network", "V1 / V2 controls"),
        ("Repository", .repository, "server.rack", "Manage patch source"),
        ("Download History", .history, "clock.arrow.circlepath", "Your download timeline"),
        ("Files", .files, "folder.fill", "Local app storage"),
        ("Settings", .settings, "gearshape.fill", "Appearance and preferences"),
        ("Terms", .terms, "doc.text.fill", "Terms of use"),
        ("About", .about, "info.circle.fill", "App information")
    ] }
}

private struct NexusDock: View {
    @Binding var selection: NexusTab
    var body: some View {
        HStack(spacing: 3) {
            ForEach(NexusTab.allCases, id: \.self) { item in
                Button { withAnimation(.spring(response: 0.3, dampingFraction: 0.82)) { selection = item } } label: {
                    VStack(spacing: 4) { Image(systemName: item.icon).font(.system(size: 15, weight: .bold)); Text(item.title).font(.system(size: 8, weight: .black, design: .rounded)).minimumScaleFactor(0.65) }
                    .foregroundStyle(selection == item ? .white : .white.opacity(0.38)).frame(maxWidth: .infinity).padding(.vertical, 8)
                    .background(selection == item ? LinearGradient(colors: [NexusColor.blue.opacity(0.35), NexusColor.purple.opacity(0.23)], startPoint: .top, endPoint: .bottom) : LinearGradient(colors: [.clear, .clear], startPoint: .top, endPoint: .bottom), in: RoundedRectangle(cornerRadius: 16))
                }.buttonStyle(.plain)
            }
        }.padding(5).background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 23)).overlay(RoundedRectangle(cornerRadius: 23).stroke(.white.opacity(0.10), lineWidth: 0.8)).shadow(color: NexusColor.blue.opacity(0.16), radius: 20, y: 7)
    }
}

private struct NexusHeading: View { let kicker: String; let title: String; var body: some View { VStack(alignment: .leading, spacing: 2) { Text(kicker).font(.system(size: 8, weight: .black, design: .monospaced)).foregroundStyle(NexusColor.cyan); Text(title).font(.system(size: 18, weight: .black, design: .rounded)) }.foregroundStyle(.white) } }
private struct NexusBadge: View { let text: String; var body: some View { Text(text).font(.system(size: 8, weight: .black, design: .monospaced)).foregroundStyle(.white.opacity(0.75)).padding(.horizontal, 8).padding(.vertical, 5).background(.white.opacity(0.08), in: Capsule()) } }
private struct NexusMetric: View { let icon: String; let title: String; let value: String; let tint: Color; var body: some View { NexusPanel(radius: 18) { HStack(spacing: 8) { Image(systemName: icon).foregroundStyle(tint); VStack(alignment: .leading, spacing: 1) { Text(title).font(.system(size: 7, weight: .black, design: .monospaced)).foregroundStyle(.white.opacity(0.4)); Text(value).font(.system(size: 12, weight: .black, design: .rounded)) } }.frame(maxWidth: .infinity, alignment: .leading).padding(10) } } }
private struct NexusAction: View { let title: String; let detail: String; let icon: String; let tint: Color; let action: () -> Void; var body: some View { Button(action: action) { NexusPanel(radius: 20) { HStack(spacing: 10) { Image(systemName: icon).font(.system(size: 15, weight: .black)).foregroundStyle(tint).frame(width: 36, height: 36).background(tint.opacity(0.10), in: Circle()); VStack(alignment: .leading, spacing: 2) { Text(title).font(.system(size: 12, weight: .bold, design: .rounded)); Text(detail).font(.system(size: 8, weight: .medium)).foregroundStyle(.white.opacity(0.38)) }; Spacer(); Image(systemName: "chevron.right").font(.system(size: 9, weight: .bold)).foregroundStyle(.white.opacity(0.25)) }.padding(10) } }.buttonStyle(.plain) } }
private struct NexusAIChip: View { let icon: String; let text: String; var body: some View { HStack(spacing: 5) { Image(systemName: icon); Text(text) }.font(.system(size: 8, weight: .bold)).foregroundStyle(.white.opacity(0.58)).padding(.horizontal, 10).padding(.vertical, 8).background(.white.opacity(0.05), in: Capsule()) } }
private struct NexusSystemValue: View { let label: String; let value: String; var body: some View { VStack(alignment: .leading, spacing: 3) { Text(label).font(.system(size: 7, weight: .black, design: .monospaced)).foregroundStyle(.white.opacity(0.35)); Text(value).font(.system(size: 12, weight: .black, design: .rounded)) }.frame(maxWidth: .infinity, alignment: .leading) } }
private struct NexusSystemRow: View { let icon: String; let title: String; let subtitle: String; var body: some View { NexusPanel(radius: 19) { HStack(spacing: 11) { Image(systemName: icon).font(.system(size: 15, weight: .bold)).foregroundStyle(NexusColor.cyan).frame(width: 38, height: 38).background(NexusColor.cyan.opacity(0.09), in: Circle()); VStack(alignment: .leading, spacing: 2) { Text(title).font(.system(size: 13, weight: .bold, design: .rounded)); Text(subtitle).font(.system(size: 9, weight: .medium)).foregroundStyle(.white.opacity(0.38)) }; Spacer(); Image(systemName: "arrow.up.right").foregroundStyle(.white.opacity(0.25)) }.padding(10) } } }
private struct NexusEmptyState: View { let title: String; let subtitle: String; var body: some View { NexusPanel(radius: 24) { VStack(spacing: 8) { Image(systemName: "square.stack.3d.up").font(.system(size: 26)).foregroundStyle(NexusColor.cyan); Text(title).font(.system(size: 15, weight: .black, design: .rounded)); Text(subtitle).font(.system(size: 10)).foregroundStyle(.white.opacity(0.4)).multilineTextAlignment(.center) }.frame(maxWidth: .infinity).padding(30) } } }

// Compatibility name retained for any other file that references the modern root.
typealias ShinnModernRootView = ShinnNovaRootView
