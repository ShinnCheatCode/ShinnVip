import SwiftUI
import UIKit

// MARK: - Shinn WOW UI
// Visual shell only. Existing business logic, repositories, licensing,
// patch services, settings, files and Shinn AI screens are reused.

private enum ShinnWOWTab: Int, CaseIterable {
    case command, patches, ai, more

    var title: String {
        switch self {
        case .command: return "Command"
        case .patches: return "Patches"
        case .ai: return "Shinn AI"
        case .more: return "More"
        }
    }

    var icon: String {
        switch self {
        case .command: return "circle.hexagongrid.fill"
        case .patches: return "bolt.shield.fill"
        case .ai: return "brain.head.profile"
        case .more: return "square.grid.2x2.fill"
        }
    }
}

private enum ShinnWOWDestination: String, Identifiable {
    case key, premium, settings, files, community, repository, history, terms, about, support, patchBuilder, patchProjects, cleanup
    var id: String { rawValue }
}

private enum ShinnWOWPalette {
    static let black = Color(red: 0.004, green: 0.006, blue: 0.010)
    static let ink = Color(red: 0.012, green: 0.020, blue: 0.035)
    static let blue = Color(red: 0.16, green: 0.45, blue: 1.0)
    static let cyan = Color(red: 0.08, green: 0.90, blue: 1.0)
    static let violet = Color(red: 0.55, green: 0.20, blue: 1.0)
    static let pink = Color(red: 0.95, green: 0.20, blue: 0.72)
    static let green = Color(red: 0.18, green: 0.95, blue: 0.62)
}

private struct ShinnWOWBackground: View {
    @State private var phase = false

    var body: some View {
        ZStack {
            ShinnWOWPalette.black.ignoresSafeArea()
            Circle()
                .fill(ShinnWOWPalette.blue.opacity(0.18))
                .frame(width: 420, height: 420)
                .blur(radius: 110)
                .offset(x: phase ? 160 : -130, y: -260)
            Circle()
                .fill(ShinnWOWPalette.violet.opacity(0.13))
                .frame(width: 380, height: 380)
                .blur(radius: 120)
                .offset(x: phase ? -160 : 120, y: 300)
            LinearGradient(
                colors: [.clear, ShinnWOWPalette.cyan.opacity(0.025), .clear],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
        }
        .animation(.easeInOut(duration: 7).repeatForever(autoreverses: true), value: phase)
        .onAppear { phase = true }
    }
}

private struct ShinnWOWGrid: View {
    var body: some View {
        Canvas { context, size in
            let spacing: CGFloat = 30
            var path = Path()
            var x: CGFloat = 0
            while x < size.width {
                path.move(to: CGPoint(x: x, y: 0))
                path.addLine(to: CGPoint(x: x, y: size.height))
                x += spacing
            }
            var y: CGFloat = 0
            while y < size.height {
                path.move(to: CGPoint(x: 0, y: y))
                path.addLine(to: CGPoint(x: size.width, y: y))
                y += spacing
            }
            context.stroke(path, with: .color(.white.opacity(0.018)), lineWidth: 0.5)
        }
        .ignoresSafeArea()
        .allowsHitTesting(false)
    }
}

private struct ShinnWOWGlass<Content: View>: View {
    let radius: CGFloat
    let content: Content

    init(radius: CGFloat = 26, @ViewBuilder content: () -> Content) {
        self.radius = radius
        self.content = content()
    }

    var body: some View {
        content
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: radius, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: radius, style: .continuous)
                    .fill(LinearGradient(
                        colors: [Color.white.opacity(0.065), .clear],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    ))
            )
            .overlay(
                RoundedRectangle(cornerRadius: radius, style: .continuous)
                    .stroke(LinearGradient(
                        colors: [ShinnWOWPalette.blue.opacity(0.38), Color.white.opacity(0.08), ShinnWOWPalette.violet.opacity(0.28)],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    ), lineWidth: 0.9)
            )
    }
}

private struct ShinnGlowIcon: View {
    let systemName: String
    let tint: Color
    var size: CGFloat = 48

    var body: some View {
        ZStack {
            Circle()
                .fill(tint.opacity(0.16))
                .frame(width: size, height: size)
                .blur(radius: 9)
            Image(systemName: systemName)
                .font(.system(size: size * 0.38, weight: .bold))
                .foregroundStyle(.white)
                .frame(width: size, height: size)
                .background(tint.opacity(0.13), in: Circle())
                .overlay(Circle().stroke(tint.opacity(0.45), lineWidth: 0.8))
        }
    }
}

struct ShinnNovaRootView: View {
    @EnvironmentObject private var store: RepoStore
    @EnvironmentObject private var license: LicenseManager
    @EnvironmentObject private var session: Session

    @State private var tab: ShinnWOWTab = .command
    @State private var destination: ShinnWOWDestination?
    @State private var showLaunch = true

    var body: some View {
        ZStack {
            ShinnWOWBackground()
            ShinnWOWGrid()

            Group {
                switch tab {
                case .command:
                    ShinnWOWCommandHome(destination: $destination, tab: $tab)
                case .patches:
                    ShinnWOWPatches(destination: $destination)
                case .ai:
                    ShinnWOWShinnAI()
                case .more:
                    ShinnWOWMore(destination: $destination)
                }
            }
            .transition(.opacity.combined(with: .scale(scale: 0.985)))

            if showLaunch {
                ShinnWOWLaunchScreen()
                    .transition(.opacity)
                    .zIndex(20)
            }
        }
        .safeAreaInset(edge: .bottom, spacing: 0) {
            ShinnWOWDock(selection: $tab)
                .opacity(showLaunch ? 0 : 1)
                .allowsHitTesting(!showLaunch)
                .padding(.horizontal, 12)
                .padding(.bottom, 6)
        }
        .sheet(item: $destination) { item in
            NavigationStack {
                switch item {
                case .key:
                    ActivateKeyView()
                case .premium:
                    PremiumRepoView()
                case .settings:
                    ShinnSettingsHubView()
                case .files:
                    FilesTabSwitcherView(session: .constant(FilesTabSession()))
                case .community:
                    CommunityView()
                case .repository:
                    RepositoryManagerView()
                case .history:
                    ShinnModernDownloadHistoryView()
                case .terms:
                    ShinnModernTermsView()
                case .about:
                    ShinnAboutView()
                case .support:
                    SupportView()
                case .patchBuilder:
                    PatchBuilderView()
                case .patchProjects:
                    if session.role == .owner { PatchProjectsView() } else { PatchOwnerOnlyView() }
                case .cleanup:
                    PhoneCleanupView()
                }
            }
            .preferredColorScheme(.dark)
        }
        .task {
            try? await Task.sleep(nanoseconds: 1_900_000_000)
            withAnimation(.easeOut(duration: 0.55)) { showLaunch = false }
        }
    }
}

private struct ShinnWOWLaunchScreen: View {
    @State private var pulse = false
    @State private var ring = false

    var body: some View {
        ZStack {
            ShinnWOWBackground()
            ShinnWOWGrid()

            Circle()
                .stroke(ShinnWOWPalette.blue.opacity(0.18), lineWidth: 1)
                .frame(width: 280, height: 280)
                .scaleEffect(ring ? 1.22 : 0.72)
                .opacity(ring ? 0 : 1)
                .animation(.easeOut(duration: 1.8).repeatForever(autoreverses: false), value: ring)

            Circle()
                .stroke(ShinnWOWPalette.violet.opacity(0.24), lineWidth: 1)
                .frame(width: 205, height: 205)
                .rotationEffect(.degrees(pulse ? 360 : 0))
                .animation(.linear(duration: 5).repeatForever(autoreverses: false), value: pulse)

            VStack(spacing: 18) {
                ZStack {
                    Circle()
                        .fill(ShinnWOWPalette.blue.opacity(0.24))
                        .frame(width: 132, height: 132)
                        .blur(radius: 30)
                    Image("ShinnAvatarArt")
                        .resizable()
                        .scaledToFill()
                        .frame(width: 112, height: 112)
                        .clipShape(Circle())
                        .overlay(Circle().stroke(Color.white.opacity(0.5), lineWidth: 1))
                        .shadow(color: ShinnWOWPalette.blue.opacity(0.55), radius: 28)
                }

                Text("SHINN")
                    .font(.system(size: 42, weight: .black, design: .rounded))
                    .tracking(8)
                    .foregroundStyle(.white)

                Text("COMMAND CENTER")
                    .font(.system(size: 10, weight: .bold, design: .rounded))
                    .tracking(4)
                    .foregroundStyle(ShinnWOWPalette.cyan)

                HStack(spacing: 8) {
                    Circle().fill(ShinnWOWPalette.green).frame(width: 6, height: 6)
                    Text("SYSTEM READY")
                        .font(.system(size: 10, weight: .bold, design: .monospaced))
                        .foregroundStyle(.white.opacity(0.52))
                }
                .padding(.top, 8)
            }
        }
        .onAppear { pulse = true; ring = true }
    }
}

private struct ShinnWOWCommandHome: View {
    @EnvironmentObject private var store: RepoStore
    @EnvironmentObject private var license: LicenseManager
    @EnvironmentObject private var session: Session
    @EnvironmentObject private var settings: AppSettings

    @Binding var destination: ShinnWOWDestination?
    @Binding var tab: ShinnWOWTab
    @State private var heroFloat = false

    private var roleText: String {
        switch session.role {
        case .owner: return "OWNER"
        case .admin: return "ADMIN"
        case .member: return "MEMBER"
        case nil: return "GUEST"
        }
    }

    private var statusText: String {
        license.isActivated ? "ACTIVE SESSION" : "FREE SESSION"
    }

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(spacing: 18) {
                header
                commandHero
                signalRow
                quickMatrix
                dnsSection
                patchPreview
            }
            .padding(.horizontal, 16)
            .padding(.top, 14)
            .padding(.bottom, 24)
        }
        .scrollDismissesKeyboard(.interactively)
    }

    private var header: some View {
        HStack(spacing: 12) {
            ZStack {
                Circle().fill(ShinnWOWPalette.blue.opacity(0.18)).frame(width: 42, height: 42).blur(radius: 6)
                Image("ShinnAvatarArt")
                    .resizable().scaledToFill().frame(width: 38, height: 38)
                    .clipShape(Circle())
                    .overlay(Circle().stroke(Color.white.opacity(0.25), lineWidth: 0.7))
            }
            VStack(alignment: .leading, spacing: 1) {
                Text("SHINN")
                    .font(.system(size: 18, weight: .black, design: .rounded))
                    .tracking(2)
                Text("COMMAND CENTER")
                    .font(.system(size: 8, weight: .bold, design: .rounded))
                    .tracking(2.5)
                    .foregroundStyle(ShinnWOWPalette.cyan)
            }
            Spacer()
            Button { destination = .settings } label: {
                Image(systemName: "slider.horizontal.3")
                    .font(.system(size: 17, weight: .bold))
                    .frame(width: 40, height: 40)
                    .background(Color.white.opacity(0.055), in: Circle())
                    .overlay(Circle().stroke(Color.white.opacity(0.10), lineWidth: 0.7))
            }
            .buttonStyle(.plain)
        }
        .foregroundStyle(.white)
    }

    private var commandHero: some View {
        ShinnWOWGlass(radius: 32) {
            ZStack(alignment: .bottomLeading) {
                Image("ShinnHeroArt")
                    .resizable()
                    .scaledToFill()
                    .frame(height: 235)
                    .clipped()
                    .opacity(0.82)
                    .offset(x: heroFloat ? 4 : -4)
                    .animation(.easeInOut(duration: 5).repeatForever(autoreverses: true), value: heroFloat)

                LinearGradient(colors: [.clear, ShinnWOWPalette.black.opacity(0.25), ShinnWOWPalette.black.opacity(0.94)], startPoint: .top, endPoint: .bottom)
                    .frame(height: 235)

                VStack(alignment: .leading, spacing: 8) {
                    HStack {
                        Label(statusText, systemImage: license.isActivated ? "checkmark.shield.fill" : "bolt.fill")
                            .font(.system(size: 10, weight: .black, design: .rounded))
                            .foregroundStyle(license.isActivated ? ShinnWOWPalette.green : ShinnWOWPalette.cyan)
                            .padding(.horizontal, 10).padding(.vertical, 6)
                            .background(Color.black.opacity(0.42), in: Capsule())
                        Spacer()
                        Text(roleText)
                            .font(.system(size: 9, weight: .black, design: .rounded))
                            .foregroundStyle(.white.opacity(0.7))
                            .padding(.horizontal, 9).padding(.vertical, 6)
                            .background(Color.white.opacity(0.08), in: Capsule())
                    }

                    Text(license.isActivated ? "Your session is ready." : "Welcome to Shinn.")
                        .font(.system(size: 26, weight: .black, design: .rounded))
                    Text(license.isActivated && !license.holderName.isEmpty ? license.holderName : "Command your workspace from one place.")
                        .font(.system(size: 12, weight: .semibold, design: .rounded))
                        .foregroundStyle(.white.opacity(0.56))

                    HStack(spacing: 9) {
                        Button { tab = .patches } label: {
                            Label("Open Patches", systemImage: "bolt.fill")
                        }
                        .buttonStyle(ShinnWOWPrimaryButtonStyle())
                        Button { tab = .ai } label: {
                            Image(systemName: "brain.head.profile")
                        }
                        .buttonStyle(ShinnWOWIconButtonStyle())
                    }
                }
                .padding(18)
            }
            .frame(height: 235)
            .clipShape(RoundedRectangle(cornerRadius: 32, style: .continuous))
        }
        .onAppear { heroFloat = true }
    }

    private var signalRow: some View {
        HStack(spacing: 10) {
            ShinnSignal(title: "REPO", value: store.usingRepoV2 ? "V2" : "V1", icon: "server.rack", tint: ShinnWOWPalette.blue)
            ShinnSignal(title: "PATCHES", value: "\(store.packages.count)", icon: "square.stack.3d.up.fill", tint: ShinnWOWPalette.violet)
            ShinnSignal(title: "STATUS", value: license.isActivated ? "ON" : "FREE", icon: "waveform.path.ecg", tint: ShinnWOWPalette.green)
        }
    }

    private var quickMatrix: some View {
        VStack(alignment: .leading, spacing: 10) {
            ShinnSectionTitle(title: "COMMAND MATRIX", subtitle: "Everything important, one tap away")
            LazyVGrid(columns: [GridItem(.flexible(), spacing: 10), GridItem(.flexible(), spacing: 10)], spacing: 10) {
                ShinnCommandTile(title: "Patches", subtitle: "Browse & manage", icon: "bolt.fill", tint: ShinnWOWPalette.blue) { tab = .patches }
                ShinnCommandTile(title: "Shinn AI", subtitle: "Ask & control", icon: "brain.head.profile", tint: ShinnWOWPalette.violet) { tab = .ai }
                ShinnCommandTile(title: "License", subtitle: license.isActivated ? "Active key" : "Activate key", icon: "key.fill", tint: ShinnWOWPalette.cyan) { destination = .key }
                ShinnCommandTile(title: "Repository", subtitle: store.usingRepoV2 ? "Premium V2" : "Default V1", icon: "server.rack", tint: ShinnWOWPalette.green) { destination = .repository }
            }
        }
    }

    private var dnsSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            ShinnSectionTitle(title: "DNS PREMIUM", subtitle: "Your existing V1 / V2 controls")
            ShinnDNSPremiumCard()
        }
    }

    private var patchPreview: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                ShinnSectionTitle(title: "RECENT WORKSPACE", subtitle: "Jump back into your patch library")
                Spacer()
                Button("View all") { tab = .patches }
                    .font(.system(size: 11, weight: .bold, design: .rounded))
                    .foregroundStyle(ShinnWOWPalette.cyan)
            }

            if store.packages.isEmpty {
                ShinnWOWGlass(radius: 22) {
                    HStack(spacing: 12) {
                        ShinnGlowIcon(systemName: "square.stack.3d.up", tint: ShinnWOWPalette.blue, size: 44)
                        VStack(alignment: .leading, spacing: 3) {
                            Text("No packages loaded")
                                .font(.system(size: 14, weight: .bold, design: .rounded))
                            Text("Open Patches to refresh your repository.")
                                .font(.system(size: 11, weight: .medium, design: .rounded))
                                .foregroundStyle(.white.opacity(0.45))
                        }
                        Spacer()
                    }
                    .padding(14)
                }
            } else {
                ForEach(Array(store.packages.prefix(3))) { pkg in
                    Button { tab = .patches } label: {
                        ShinnWOWGlass(radius: 18) {
                            HStack(spacing: 12) {
                                ShinnGlowIcon(systemName: "cube.transparent", tint: ShinnWOWPalette.blue, size: 42)
                                VStack(alignment: .leading, spacing: 3) {
                                    Text(pkg.name)
                                        .font(.system(size: 13, weight: .bold, design: .rounded))
                                        .foregroundStyle(.white)
                                        .lineLimit(1)
                                    Text(pkg.category ?? "Patch")
                                        .font(.system(size: 10, weight: .medium, design: .rounded))
                                        .foregroundStyle(.white.opacity(0.42))
                                }
                                Spacer()
                                Image(systemName: "chevron.right")
                                    .font(.system(size: 12, weight: .bold))
                                    .foregroundStyle(.white.opacity(0.35))
                            }
                            .padding(12)
                        }
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }
}

private struct ShinnSignal: View {
    let title: String
    let value: String
    let icon: String
    let tint: Color

    var body: some View {
        ShinnWOWGlass(radius: 19) {
            VStack(alignment: .leading, spacing: 7) {
                Image(systemName: icon).foregroundStyle(tint).font(.system(size: 15, weight: .bold))
                Text(value).font(.system(size: 17, weight: .black, design: .rounded)).foregroundStyle(.white)
                Text(title).font(.system(size: 8, weight: .bold, design: .monospaced)).foregroundStyle(.white.opacity(0.35))
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(12)
        }
    }
}

private struct ShinnSectionTitle: View {
    let title: String
    let subtitle: String
    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(title).font(.system(size: 11, weight: .black, design: .rounded)).tracking(1.6).foregroundStyle(.white)
            Text(subtitle).font(.system(size: 10, weight: .medium, design: .rounded)).foregroundStyle(.white.opacity(0.34))
        }
    }
}

private struct ShinnCommandTile: View {
    let title: String
    let subtitle: String
    let icon: String
    let tint: Color
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            ShinnWOWGlass(radius: 22) {
                VStack(alignment: .leading, spacing: 12) {
                    HStack {
                        ShinnGlowIcon(systemName: icon, tint: tint, size: 42)
                        Spacer()
                        Image(systemName: "arrow.up.right")
                            .font(.system(size: 11, weight: .bold))
                            .foregroundStyle(.white.opacity(0.25))
                    }
                    VStack(alignment: .leading, spacing: 3) {
                        Text(title).font(.system(size: 14, weight: .black, design: .rounded)).foregroundStyle(.white)
                        Text(subtitle).font(.system(size: 10, weight: .medium, design: .rounded)).foregroundStyle(.white.opacity(0.38))
                    }
                }
                .padding(13)
            }
        }
        .buttonStyle(.plain)
    }
}

private struct ShinnWOWPatches: View {
    @EnvironmentObject private var store: RepoStore
    @EnvironmentObject private var session: Session
    @Binding var destination: ShinnWOWDestination?

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                VStack(alignment: .leading, spacing: 3) {
                    Text("PATCH LIBRARY")
                        .font(.system(size: 21, weight: .black, design: .rounded))
                    Text(store.usingRepoV2 ? "Premium Repository V2" : "Repository V1")
                        .font(.system(size: 10, weight: .bold, design: .monospaced))
                        .foregroundStyle(ShinnWOWPalette.cyan)
                }
                Spacer()
                Button { destination = .history } label: {
                    Image(systemName: "clock.arrow.circlepath")
                        .frame(width: 40, height: 40)
                        .background(Color.white.opacity(0.06), in: Circle())
                }
                .buttonStyle(.plain)
            }
            .foregroundStyle(.white)
            .padding(.horizontal, 16)
            .padding(.top, 16)
            .padding(.bottom, 10)

            PackagesView(initialCategory: nil)
        }
    }
}

private struct ShinnWOWShinnAI: View {
    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 12) {
                ShinnGlowIcon(systemName: "brain.head.profile", tint: ShinnWOWPalette.violet, size: 46)
                VStack(alignment: .leading, spacing: 2) {
                    Text("SHINN AI")
                        .font(.system(size: 22, weight: .black, design: .rounded))
                    Text("Your in-app intelligence")
                        .font(.system(size: 10, weight: .medium, design: .rounded))
                        .foregroundStyle(.white.opacity(0.4))
                }
                Spacer()
            }
            .foregroundStyle(.white)
            .padding(.horizontal, 16)
            .padding(.top, 14)
            .padding(.bottom, 4)

            ShinnAIChatView()
        }
    }
}

private struct ShinnWOWMore: View {
    @EnvironmentObject private var session: Session
    @EnvironmentObject private var license: LicenseManager
    @Binding var destination: ShinnWOWDestination?

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 14) {
                HStack {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("CONTROL ROOM")
                            .font(.system(size: 24, weight: .black, design: .rounded))
                        Text("Account, repository, files and system tools")
                            .font(.system(size: 11, weight: .medium, design: .rounded))
                            .foregroundStyle(.white.opacity(0.38))
                    }
                    Spacer()
                }
                .foregroundStyle(.white)

                ShinnWOWGlass(radius: 25) {
                    HStack(spacing: 13) {
                        ShinnGlowIcon(systemName: "person.crop.circle.badge.checkmark", tint: ShinnWOWPalette.cyan, size: 48)
                        VStack(alignment: .leading, spacing: 4) {
                            Text(license.isActivated ? (license.holderName.isEmpty ? "Activated key" : license.holderName) : "No active key")
                                .font(.system(size: 15, weight: .black, design: .rounded))
                            Text(session.role.map { "\($0.rawValue.uppercased()) · LICENSE" } ?? "GUEST · FREE")
                                .font(.system(size: 9, weight: .bold, design: .monospaced))
                                .foregroundStyle(ShinnWOWPalette.green)
                        }
                        Spacer()
                        Button { destination = .key } label: {
                            Image(systemName: "chevron.right")
                                .foregroundStyle(.white.opacity(0.45))
                        }
                    }
                    .padding(14)
                }

                Text("WORKSPACE")
                    .font(.system(size: 10, weight: .black, design: .rounded))
                    .tracking(1.6)
                    .foregroundStyle(.white.opacity(0.42))

                ShinnMoreButton(title: "Repository Manager", subtitle: "Switch and manage repositories", icon: "server.rack", tint: ShinnWOWPalette.blue) { destination = .repository }
                ShinnMoreButton(title: "Download History", subtitle: "Your patch activity", icon: "clock.arrow.circlepath", tint: ShinnWOWPalette.violet) { destination = .history }
                ShinnMoreButton(title: "Files", subtitle: "Browse app files", icon: "folder.fill", tint: ShinnWOWPalette.cyan) { destination = .files }
                ShinnMoreButton(title: "Community", subtitle: "Open community tools", icon: "person.3.fill", tint: ShinnWOWPalette.green) { destination = .community }

                Text("TOOLS")
                    .font(.system(size: 10, weight: .black, design: .rounded))
                    .tracking(1.6)
                    .foregroundStyle(.white.opacity(0.42))
                    .padding(.top, 4)

                ShinnMoreButton(title: "Settings", subtitle: "Appearance and app options", icon: "slider.horizontal.3", tint: ShinnWOWPalette.blue) { destination = .settings }
                ShinnMoreButton(title: "Terms of Use", subtitle: "Read the current terms", icon: "doc.text.fill", tint: ShinnWOWPalette.violet) { destination = .terms }
                ShinnMoreButton(title: "About Shinn", subtitle: "App information", icon: "info.circle.fill", tint: ShinnWOWPalette.cyan) { destination = .about }
                ShinnMoreButton(title: "Support", subtitle: "Get help", icon: "questionmark.circle.fill", tint: ShinnWOWPalette.green) { destination = .support }
            }
            .padding(.horizontal, 16)
            .padding(.top, 16)
            .padding(.bottom, 24)
        }
    }
}

private struct ShinnMoreButton: View {
    let title: String
    let subtitle: String
    let icon: String
    let tint: Color
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            ShinnWOWGlass(radius: 20) {
                HStack(spacing: 12) {
                    ShinnGlowIcon(systemName: icon, tint: tint, size: 43)
                    VStack(alignment: .leading, spacing: 3) {
                        Text(title).font(.system(size: 13, weight: .bold, design: .rounded)).foregroundStyle(.white)
                        Text(subtitle).font(.system(size: 10, weight: .medium, design: .rounded)).foregroundStyle(.white.opacity(0.35))
                    }
                    Spacer()
                    Image(systemName: "chevron.right")
                        .font(.system(size: 11, weight: .bold))
                        .foregroundStyle(.white.opacity(0.25))
                }
                .padding(12)
            }
        }
        .buttonStyle(.plain)
    }
}

private struct ShinnWOWDock: View {
    @Binding var selection: ShinnWOWTab

    var body: some View {
        HStack(spacing: 4) {
            ForEach(ShinnWOWTab.allCases, id: \.self) { item in
                Button {
                    withAnimation(.spring(response: 0.28, dampingFraction: 0.82)) { selection = item }
                } label: {
                    VStack(spacing: 5) {
                        Image(systemName: item.icon)
                            .font(.system(size: 16, weight: .bold))
                        Text(item.title)
                            .font(.system(size: 8, weight: .black, design: .rounded))
                    }
                    .foregroundStyle(selection == item ? .white : .white.opacity(0.38))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 8)
                    .background(
                        selection == item
                        ? LinearGradient(colors: [ShinnWOWPalette.blue.opacity(0.30), ShinnWOWPalette.violet.opacity(0.18)], startPoint: .topLeading, endPoint: .bottomTrailing)
                        : LinearGradient(colors: [.clear, .clear], startPoint: .top, endPoint: .bottom),
                        in: RoundedRectangle(cornerRadius: 17, style: .continuous)
                    )
                }
                .buttonStyle(.plain)
            }
        }
        .padding(5)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 24).stroke(Color.white.opacity(0.11), lineWidth: 0.8))
        .shadow(color: ShinnWOWPalette.blue.opacity(0.15), radius: 22, y: 8)
    }
}

private struct ShinnWOWPrimaryButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 11, weight: .black, design: .rounded))
            .foregroundStyle(.white)
            .padding(.horizontal, 13)
            .frame(minHeight: 40)
            .background(LinearGradient(colors: [ShinnWOWPalette.blue, ShinnWOWPalette.violet], startPoint: .leading, endPoint: .trailing), in: Capsule())
            .opacity(configuration.isPressed ? 0.75 : 1)
            .scaleEffect(configuration.isPressed ? 0.97 : 1)
    }
}

private struct ShinnWOWIconButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 15, weight: .bold))
            .foregroundStyle(.white)
            .frame(width: 40, height: 40)
            .background(Color.white.opacity(configuration.isPressed ? 0.12 : 0.07), in: Circle())
            .overlay(Circle().stroke(Color.white.opacity(0.12), lineWidth: 0.7))
    }
}



private struct ShinnModernDownloadHistoryView: View {
    @EnvironmentObject private var store: RepoStore

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 12) {
                Text("Download History")
                    .font(.system(size: 28, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                Text("Your existing patch download records")
                    .font(.system(size: 11, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.42))

                if store.downloadHistory.isEmpty {
                    ShinnWOWGlass(radius: 24) {
                        VStack(spacing: 10) {
                            ShinnGlowIcon(systemName: "clock.arrow.circlepath", tint: ShinnWOWPalette.blue, size: 52)
                            Text("No download history")
                                .font(.system(size: 15, weight: .bold, design: .rounded))
                                .foregroundStyle(.white)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(28)
                    }
                } else {
                    ForEach(store.downloadHistory) { item in
                        ShinnWOWGlass(radius: 20) {
                            HStack(spacing: 12) {
                                ShinnGlowIcon(systemName: "arrow.down.circle.fill", tint: ShinnWOWPalette.cyan, size: 42)
                                VStack(alignment: .leading, spacing: 3) {
                                    Text(item.name)
                                        .font(.system(size: 13, weight: .bold, design: .rounded))
                                        .foregroundStyle(.white)
                                    Text("\(item.repo) · \(item.version ?? "Unknown")")
                                        .font(.system(size: 10, weight: .medium, design: .rounded))
                                        .foregroundStyle(.white.opacity(0.42))
                                    Text(item.downloadedAt.formatted(date: .abbreviated, time: .shortened))
                                        .font(.system(size: 9, weight: .medium, design: .monospaced))
                                        .foregroundStyle(.white.opacity(0.28))
                                }
                                Spacer()
                            }
                            .padding(12)
                        }
                    }
                }
            }
            .padding(16)
        }
        .background(ShinnWOWBackground())
        .navigationTitle("History")
        .navigationBarTitleDisplayMode(.inline)
    }
}

private struct ShinnModernTermsView: View {
    @EnvironmentObject private var settings: AppSettings

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 14) {
                Text("Terms of Use")
                    .font(.system(size: 28, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                Text("Please review the current app terms before using the available features.")
                    .font(.system(size: 12, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.48))

                ShinnWOWGlass(radius: 24) {
                    VStack(alignment: .leading, spacing: 16) {
                        Text(settings.t(.termsBody))
                            .font(.system(size: 12, weight: .medium, design: .rounded))
                            .foregroundStyle(.white.opacity(0.78))
                            .lineSpacing(4)
                    }
                    .padding(18)
                }
            }
            .padding(16)
        }
        .background(ShinnWOWBackground())
        .navigationTitle("Terms")
        .navigationBarTitleDisplayMode(.inline)
    }
}

// MARK: - Compatibility aliases for code that may still reference the previous shell.
typealias ShinnModernRootView = ShinnNovaRootView
