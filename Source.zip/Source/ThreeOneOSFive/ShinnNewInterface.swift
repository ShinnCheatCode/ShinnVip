import SwiftUI
import UIKit

// MARK: - Shinn New Interface
// New visual shell only. Existing patch/file/license/backend services remain intact.
// Owner key-management views are intentionally not surfaced in this interface.

private enum ShinnNewTab: Hashable {
    case home, patch, ai, account

    var title: String {
        switch self {
        case .home: return "Home"
        case .patch: return "Patch"
        case .ai: return "Shinn AI"
        case .account: return "Account"
        }
    }

    var icon: String {
        switch self {
        case .home: return "house.fill"
        case .patch: return "square.grid.2x2.fill"
        case .ai: return "sparkles"
        case .account: return "person.crop.circle.fill"
        }
    }
}

struct ShinnNewInterfaceView: View {
    @EnvironmentObject private var store: RepoStore
    @EnvironmentObject private var license: LicenseManager
    @EnvironmentObject private var session: Session
    @EnvironmentObject private var settings: AppSettings

    @State private var tab: ShinnNewTab = .home
    @State private var destination: ShinnModernDestination?
    @StateObject private var personalization = ShinnPersonalizationStore()

    var body: some View {
        ZStack {
            ShinnNewBackground()

            Group {
                switch tab {
                case .home:
                    ShinnNewHomeView(
                        license: license,
                        session: session,
                        store: store,
                        onPatch: { tab = .patch },
                        onAI: { tab = .ai },
                        onFiles: { destination = .files },
                        onSettings: { destination = .settings }
                    )
                case .patch:
                    ShinnModernPatchView(
                        destination: $destination,
                        initialCategory: .constant(nil)
                    )
                case .ai:
                    ShinnModernAIView()
                case .account:
                    ShinnNewAccountView(
                        license: license,
                        session: session,
                        onFiles: { destination = .files },
                        onSettings: { destination = .settings },
                        onPersonalization: { destination = .personalization },
                        onHistory: { destination = .downloadHistory },
                        onAbout: { destination = .about },
                        onTerms: { destination = .terms }
                    )
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .safeAreaInset(edge: .bottom, spacing: 0) {
            ShinnNewTabBar(selection: $tab)
                .padding(.horizontal, 12)
                .padding(.bottom, 7)
        }
        .sheet(item: $destination) { item in
            NavigationStack {
                switch item {
                case .premium:
                    ShinnModernPremiumView(destination: $destination)
                case .key:
                    ShinnModernKeyView()
                case .files:
                    FilesTabSwitcherView(session: .constant(FilesTabSession()))
                case .settings:
                    ShinnSettingsHubView()
                case .patchProjects:
                    PatchProjectsView()
                case .ownerKeys:
                    Text("Owner tools are not part of the new interface.")
                        .foregroundStyle(.white)
                case .repositoryManager:
                    RepositoryManagerView()
                case .downloadHistory:
                    ShinnModernDownloadHistoryView()
                case .patchUsageHistory:
                    ShinnModernPatchUsageHistoryView()
                case .personalization:
                    ShinnPersonalizationView(store: personalization)
                case .terms:
                    ShinnModernTermsView()
                case .about:
                    ShinnModernAboutView()
                }
            }
            .preferredColorScheme(.dark)
        }
    }
}

private struct ShinnNewBackground: View {
    var body: some View {
        ZStack {
            Color(red: 0.008, green: 0.012, blue: 0.024)
                .ignoresSafeArea()

            RadialGradient(
                colors: [Color.cyan.opacity(0.14), .clear],
                center: .topTrailing,
                startRadius: 10,
                endRadius: 430
            )
            .ignoresSafeArea()

            RadialGradient(
                colors: [Color.purple.opacity(0.10), .clear],
                center: .bottomLeading,
                startRadius: 20,
                endRadius: 400
            )
            .ignoresSafeArea()
        }
    }
}

private struct ShinnNewHomeView: View {
    @ObservedObject var license: LicenseManager
    @ObservedObject var session: Session
    @ObservedObject var store: RepoStore

    let onPatch: () -> Void
    let onAI: () -> Void
    let onFiles: () -> Void
    let onSettings: () -> Void

    private var keyTitle: String {
        Self.displayKey(license.boundKey)
    }

    private static func displayKey(_ key: String?) -> String {
        guard let key, !key.isEmpty else { return "No active key" }
        return key
    }

    private var roleTitle: String {
        session.role?.rawValue.capitalized ?? "Member"
    }

    var body: some View {
        NavigationStack {
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 16) {
                    header
                    accountCard
                    quickActions
                    patchSummary
                    recentArea
                }
                .padding(.horizontal, 16)
                .padding(.top, 12)
                .padding(.bottom, 20)
            }
            .navigationBarHidden(true)
        }
    }

    private var header: some View {
        HStack(alignment: .center, spacing: 12) {
            Image(systemName: "sparkles.tv.fill")
                .font(.system(size: 25, weight: .black))
                .foregroundStyle(.cyan)
                .frame(width: 48, height: 48)
                .background(.cyan.opacity(0.10), in: RoundedRectangle(cornerRadius: 15, style: .continuous))

            VStack(alignment: .leading, spacing: 2) {
                Text("SHINN CHEAT")
                    .font(.system(size: 23, weight: .black, design: .rounded))
                Text("Modern Control Center")
                    .font(.system(size: 11, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.45))
            }
            Spacer()
            Button(action: onSettings) {
                Image(systemName: "gearshape.fill")
                    .font(.system(size: 17, weight: .bold))
                    .foregroundStyle(.white.opacity(0.8))
                    .frame(width: 42, height: 42)
                    .background(.white.opacity(0.06), in: Circle())
            }
            .buttonStyle(.plain)
        }
        .foregroundStyle(.white)
    }

    private var accountCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text("ACTIVE SESSION")
                        .font(.system(size: 10, weight: .black, design: .rounded))
                        .foregroundStyle(.cyan)
                    Text(keyTitle)
                        .font(.system(size: 17, weight: .bold, design: .rounded))
                        .lineLimit(1)
                    Text("Role · \(roleTitle)")
                        .font(.system(size: 11, weight: .medium, design: .rounded))
                        .foregroundStyle(.white.opacity(0.48))
                }
                Spacer()
                Circle()
                    .fill(license.isActivated ? Color.green : Color.orange)
                    .frame(width: 11, height: 11)
                    .shadow(color: (license.isActivated ? Color.green : Color.orange).opacity(0.8), radius: 7)
            }

            HStack(spacing: 8) {
                statusPill(title: license.isActivated ? "ACTIVE" : "OFFLINE", icon: "checkmark.shield.fill")
                statusPill(title: store.isRepoV2Authorized ? "V2 ACCESS" : "V1 ACCESS", icon: "shippingbox.fill")
            }
        }
        .padding(17)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 23, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 23, style: .continuous).stroke(.white.opacity(0.08)))
    }

    private func statusPill(title: String, icon: String) -> some View {
        Label(title, systemImage: icon)
            .font(.system(size: 10, weight: .bold, design: .rounded))
            .foregroundStyle(.white.opacity(0.82))
            .padding(.horizontal, 10)
            .padding(.vertical, 7)
            .background(.white.opacity(0.06), in: Capsule())
    }

    private var quickActions: some View {
        HStack(spacing: 10) {
            actionCard("Patch", "square.grid.2x2.fill", .cyan, onPatch)
            actionCard("Shinn AI", "sparkles", .purple, onAI)
            actionCard("Files", "folder.fill", .green, onFiles)
        }
    }

    private func actionCard(_ title: String, _ icon: String, _ color: Color, _ action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 9) {
                Image(systemName: icon)
                    .font(.system(size: 19, weight: .black))
                    .foregroundStyle(color)
                Text(title)
                    .font(.system(size: 12, weight: .bold, design: .rounded))
                    .foregroundStyle(.white)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(14)
            .background(.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(.white.opacity(0.06)))
        }
        .buttonStyle(.plain)
    }

    private var patchSummary: some View {
        HStack(spacing: 12) {
            Image(systemName: "square.grid.2x2.fill")
                .font(.system(size: 20, weight: .black))
                .foregroundStyle(.cyan)
                .frame(width: 45, height: 45)
                .background(.cyan.opacity(0.12), in: RoundedRectangle(cornerRadius: 14, style: .continuous))

            VStack(alignment: .leading, spacing: 3) {
                Text("Patch Center")
                    .font(.system(size: 15, weight: .bold, design: .rounded))
                Text(store.usingRepoV2 ? "Repo V2 selected" : "Repo V1 selected")
                    .font(.system(size: 11, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.42))
            }
            Spacer()
            Text("\(store.packages.count)")
                .font(.system(size: 18, weight: .black, design: .rounded))
                .foregroundStyle(.cyan)
        }
        .padding(15)
        .background(.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 19, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 19, style: .continuous).stroke(.white.opacity(0.06)))
    }

    private var recentArea: some View {
        VStack(alignment: .leading, spacing: 9) {
            Text("QUICK ACCESS")
                .font(.system(size: 10, weight: .black, design: .rounded))
                .foregroundStyle(.white.opacity(0.35))
            Text("Use the bottom navigation to open Patch, Shinn AI or Account.")
                .font(.system(size: 13, weight: .medium, design: .rounded))
                .foregroundStyle(.white.opacity(0.62))
        }
    }
}

private struct ShinnNewAccountView: View {
    @ObservedObject var license: LicenseManager
    @ObservedObject var session: Session

    let onFiles: () -> Void
    let onSettings: () -> Void
    let onPersonalization: () -> Void
    let onHistory: () -> Void
    let onAbout: () -> Void
    let onTerms: () -> Void

    var body: some View {
        NavigationStack {
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 14) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Account")
                            .font(.system(size: 31, weight: .black, design: .rounded))
                        Text("Your Shinn Cheat workspace")
                            .font(.system(size: 12, weight: .medium, design: .rounded))
                            .foregroundStyle(.white.opacity(0.4))
                    }

                    profileCard
                    accountRow("Files", "Browse your local workspace", "folder.fill", onFiles)
                    accountRow("Personalization", "Appearance and profile", "paintbrush.fill", onPersonalization)
                    accountRow("Settings", "App preferences", "gearshape.fill", onSettings)
                    accountRow("Download History", "Recently downloaded patches", "clock.arrow.circlepath", onHistory)
                    accountRow("About Shinn Cheat", "Version and information", "info.circle.fill", onAbout)
                    accountRow("Terms of Use", "Usage information", "doc.text.fill", onTerms)
                }
                .padding(16)
                .padding(.bottom, 20)
            }
            .navigationBarHidden(true)
        }
    }

    private var profileCard: some View {
        HStack(spacing: 13) {
            Image(systemName: "person.crop.circle.fill")
                .font(.system(size: 43))
                .foregroundStyle(.cyan)
            VStack(alignment: .leading, spacing: 4) {
                Text(Self.displayKey(license.boundKey))
                    .font(.system(size: 15, weight: .bold, design: .rounded))
                    .lineLimit(1)
                Text("Role · \(session.role?.rawValue.capitalized ?? "Member")")
                    .font(.system(size: 11, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.43))
            }
            Spacer()
        }
        .padding(16)
        .background(.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).stroke(.white.opacity(0.07)))
    }

    private func accountRow(_ title: String, _ subtitle: String, _ icon: String, _ action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 12) {
                Image(systemName: icon)
                    .font(.system(size: 16, weight: .bold))
                    .foregroundStyle(.cyan)
                    .frame(width: 40, height: 40)
                    .background(.cyan.opacity(0.10), in: RoundedRectangle(cornerRadius: 13, style: .continuous))
                VStack(alignment: .leading, spacing: 3) {
                    Text(title)
                        .font(.system(size: 14, weight: .bold, design: .rounded))
                    Text(subtitle)
                        .font(.system(size: 10, weight: .medium, design: .rounded))
                        .foregroundStyle(.white.opacity(0.38))
                }
                Spacer()
                Image(systemName: "chevron.right")
                    .font(.system(size: 12, weight: .bold))
                    .foregroundStyle(.white.opacity(0.25))
            }
            .foregroundStyle(.white)
            .padding(13)
            .background(.white.opacity(0.035), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        }
        .buttonStyle(.plain)
    }
}

private struct ShinnNewTabBar: View {
    @Binding var selection: ShinnNewTab

    var body: some View {
        HStack(spacing: 5) {
            tab(.home)
            tab(.patch)
            tab(.ai)
            tab(.account)
        }
        .padding(7)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 24, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 24, style: .continuous).stroke(.white.opacity(0.08)))
    }

    private func tab(_ item: ShinnNewTab) -> some View {
        Button { selection = item } label: {
            VStack(spacing: 4) {
                Image(systemName: item.icon)
                    .font(.system(size: 15, weight: .bold))
                Text(item.title)
                    .font(.system(size: 9, weight: .bold, design: .rounded))
            }
            .foregroundStyle(selection == item ? .cyan : .white.opacity(0.45))
            .frame(maxWidth: .infinity)
            .padding(.vertical, 7)
            .background(selection == item ? .cyan.opacity(0.10) : .clear, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        }
        .buttonStyle(.plain)
    }
}
