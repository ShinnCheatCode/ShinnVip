import Foundation
import AVFoundation

final class VoiceManager {
    static let shared = VoiceManager()
    private var player: AVAudioPlayer?

    func play(_ file: String) {
        guard let url = Bundle.main.url(forResource: file, withExtension: "mp3") else { return }
        player = try? AVAudioPlayer(contentsOf: url)
        player?.prepareToPlay()
        player?.play()
    }
}
