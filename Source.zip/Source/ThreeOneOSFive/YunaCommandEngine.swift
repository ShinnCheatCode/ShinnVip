import Foundation

@MainActor
final class YunaCommandEngine: ObservableObject {
    @Published var reply = ""
    @Published var patches: [YunaPatch] = []

    func handle(_ message: String) async -> String {
        let text = normalize(message)

        if patches.isEmpty {
            await loadPatches()
        }

        if let patch = patches.first(where: { p in
            p.searchText.contains(where: { text.contains($0) }) || text.contains(normalize(p.name))
        }) {
            if containsEnable(text) {
                return "Đã tìm thấy và gửi yêu cầu áp dụng: \(patch.name)\nFound patch: \(patch.name)"
            }
            return "Đã tìm thấy patch: \(patch.name)"
        }

        if text.contains("xin chao") || text.contains("hello") {
            return "Xin chào, tôi là Yuna AI."
        }

        return "Yuna chưa tìm thấy patch phù hợp."
    }

    private func loadPatches() async {
        guard let url = URL(string: "https://raw.githubusercontent.com/ShinnCheatCode/RepoV2/main/ShinnCheatV2.json") else { return }
        do {
            let (data, _) = try await URLSession.shared.data(from: url)
            if let decoded = try? JSONDecoder().decode([YunaPatch].self, from: data) {
                patches = decoded
            }
        } catch {}
    }

    private func normalize(_ s: String) -> String {
        s.lowercased().folding(options: .diacriticInsensitive, locale: .current)
    }

    private func containsEnable(_ t: String) -> Bool {
        ["bat", "enable", "apply", "on", "activate", "ap dung"].contains { t.contains($0) }
    }
}

struct YunaPatch: Codable, Identifiable {
    var id: String { name }
    let name: String
    let keywords: [String]?

    var searchText: [String] {
        [name] + (keywords ?? [])
            .map { $0.lowercased().folding(options: .diacriticInsensitive, locale: .current) }
    }
}
