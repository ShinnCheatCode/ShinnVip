import Foundation
import Combine
import Speech
import AVFoundation

@MainActor
final class YunaSpeech: NSObject, ObservableObject {
    @Published var transcript = ""
    @Published var isListening = false
    @Published var errorMessage: String?

    private let recognizer = SFSpeechRecognizer(locale: Locale(identifier: "vi-VN"))
    private let audioEngine = AVAudioEngine()
    private var request: SFSpeechAudioBufferRecognitionRequest?
    private var task: SFSpeechRecognitionTask?
    private var tapInstalled = false

    var onCommand: ((String) -> Void)?

    /// Requests both iOS permissions without starting the audio engine.
    /// Calling this from a user tap lets iOS show the normal system permission dialogs.
    func requestPermissions() {
        errorMessage = nil

        SFSpeechRecognizer.requestAuthorization { [weak self] speechStatus in
            Task { @MainActor in
                guard let self else { return }

                guard speechStatus == .authorized else {
                    self.errorMessage = self.speechPermissionMessage(speechStatus)
                    return
                }

                if #available(iOS 17.0, *) {
                    AVAudioApplication.requestRecordPermission { [weak self] granted in
                        Task { @MainActor in
                            guard let self else { return }
                            if !granted {
                                self.errorMessage = "Microphone chưa được cho phép. Hãy bật Microphone cho 3105 trong Cài đặt > Quyền riêng tư & Bảo mật."
                            }
                        }
                    }
                } else {
                    AVAudioSession.sharedInstance().requestRecordPermission { [weak self] granted in
                        Task { @MainActor in
                            guard let self else { return }
                            if !granted {
                                self.errorMessage = "Microphone chưa được cho phép. Hãy bật Microphone cho 3105 trong Cài đặt > Quyền riêng tư & Bảo mật."
                            }
                        }
                    }
                }
            }
        }
    }

    func startListening() {
        guard !isListening else { return }
        errorMessage = nil
        transcript = ""

        let speechStatus = SFSpeechRecognizer.authorizationStatus()
        guard speechStatus == .authorized else {
            requestPermissions()
            return
        }

        let microphoneGranted: Bool
        if #available(iOS 17.0, *) {
            microphoneGranted = AVAudioApplication.shared.recordPermission == .granted
        } else {
            microphoneGranted = AVAudioSession.sharedInstance().recordPermission == .granted
        }

        guard microphoneGranted else {
            requestPermissions()
            return
        }

        beginListening()
    }

    func stopListening() {
        if tapInstalled {
            audioEngine.inputNode.removeTap(onBus: 0)
            tapInstalled = false
        }
        audioEngine.stop()
        request?.endAudio()
        task?.cancel()
        task = nil
        request = nil
        isListening = false
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
    }

    private func beginListening() {
        guard !isListening else { return }

        do {
            guard let recognizer, recognizer.isAvailable else {
                errorMessage = "Nhận dạng giọng nói hiện không khả dụng."
                return
            }

            let session = AVAudioSession.sharedInstance()
            try session.setCategory(.record, mode: .measurement, options: [])
            try session.setActive(true, options: .notifyOthersOnDeactivation)

            let inputNode = audioEngine.inputNode

            // Always reset a previous engine/tap before installing a new one.
            if tapInstalled {
                inputNode.removeTap(onBus: 0)
                tapInstalled = false
            }
            audioEngine.stop()
            audioEngine.reset()

            let speechRequest = SFSpeechAudioBufferRecognitionRequest()
            speechRequest.shouldReportPartialResults = true
            request = speechRequest

            // nil lets AVAudioEngine use the node's native output format and avoids
            // common "IsFormatSampleRateAndChannelCountValid" crashes.
            inputNode.installTap(onBus: 0, bufferSize: 1024, format: nil) { [weak speechRequest] buffer, _ in
                speechRequest?.append(buffer)
            }
            tapInstalled = true

            task = recognizer.recognitionTask(with: speechRequest) { [weak self] result, error in
                Task { @MainActor in
                    guard let self else { return }

                    if let result {
                        let text = result.bestTranscription.formattedString
                            .trimmingCharacters(in: .whitespacesAndNewlines)
                        self.transcript = text

                        if result.isFinal, !text.isEmpty {
                            self.onCommand?(text)
                            self.stopListening()
                            return
                        }
                    }

                    if error != nil && self.isListening {
                        self.errorMessage = "Không nhận được giọng nói. Hãy thử lại."
                        self.stopListening()
                    }
                }
            }

            audioEngine.prepare()
            try audioEngine.start()
            isListening = true
        } catch {
            stopListening()
            errorMessage = "Không thể khởi động microphone: \(error.localizedDescription)"
        }
    }

    private func speechPermissionMessage(_ status: SFSpeechRecognizerAuthorizationStatus) -> String {
        switch status {
        case .denied:
            return "Nhận dạng giọng nói đã bị từ chối. Hãy bật quyền Speech Recognition cho 3105 trong Cài đặt."
        case .restricted:
            return "Nhận dạng giọng nói đang bị giới hạn trên thiết bị này."
        case .notDetermined:
            return "Chưa cấp quyền nhận dạng giọng nói. Hãy thử bấm mic lại."
        case .authorized:
            return ""
        @unknown default:
            return "Không xác định được trạng thái quyền nhận dạng giọng nói."
        }
    }

    deinit {
        audioEngine.stop()
        if tapInstalled {
            audioEngine.inputNode.removeTap(onBus: 0)
        }
        task?.cancel()
    }
}
