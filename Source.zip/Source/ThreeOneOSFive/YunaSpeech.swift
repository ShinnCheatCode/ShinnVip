import Foundation
import Combine
import Speech
import AVFoundation

@MainActor
final class YunaSpeech: NSObject, ObservableObject {
    @Published var transcript = ""
    @Published var isListening = false
    @Published var errorMessage: String?

    private let recognizer = SFSpeechRecognizer(locale: Locale(identifier: "vi-VN"))
    private let audioEngine = AVAudioEngine()
    private var request: SFSpeechAudioBufferRecognitionRequest?
    private var task: SFSpeechRecognitionTask?
    private var tapInstalled = false

    var onCommand: ((String) -> Void)?

    func startListening() {
        guard !isListening else { return }
        errorMessage = nil
        transcript = ""

        SFSpeechRecognizer.requestAuthorization { [weak self] auth in
            Task { @MainActor in
                guard let self else { return }
                guard auth == .authorized else {
                    self.errorMessage = "Hãy cho phép Nhận dạng giọng nói trong Cài đặt > Quyền riêng tư & Bảo mật."
                    return
                }
                await self.requestMicrophoneAndStart()
            }
        }
    }

    func stopListening() {
        if tapInstalled {
            audioEngine.inputNode.removeTap(onBus: 0)
            tapInstalled = false
        }
        audioEngine.stop()
        request?.endAudio()
        task?.cancel()
        task = nil
        request = nil
        isListening = false
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
    }

    private func requestMicrophoneAndStart() async {
        let granted = await withCheckedContinuation { continuation in
            AVAudioSession.sharedInstance().requestRecordPermission { ok in
                continuation.resume(returning: ok)
            }
        }

        guard granted else {
            errorMessage = "Hãy cho phép Microphone trong Cài đặt > Quyền riêng tư & Bảo mật > Microphone."
            return
        }

        do {
            let session = AVAudioSession.sharedInstance()
            try session.setCategory(.record, mode: .measurement, options: [.duckOthers])
            try session.setActive(true, options: .notifyOthersOnDeactivation)

            guard let recognizer, recognizer.isAvailable else {
                errorMessage = "Nhận dạng giọng nói hiện không khả dụng."
                try? session.setActive(false, options: .notifyOthersOnDeactivation)
                return
            }

            let inputNode = audioEngine.inputNode
            let format = inputNode.inputFormat(forBus: 0)

            guard format.sampleRate > 0, format.channelCount > 0 else {
                errorMessage = "Không tìm thấy microphone. Hãy kiểm tra quyền Microphone và thiết bị âm thanh."
                try? session.setActive(false, options: .notifyOthersOnDeactivation)
                return
            }

            if tapInstalled {
                inputNode.removeTap(onBus: 0)
                tapInstalled = false
            }

            let speechRequest = SFSpeechAudioBufferRecognitionRequest()
            speechRequest.shouldReportPartialResults = true
            request = speechRequest

            inputNode.installTap(onBus: 0, bufferSize: 1024, format: format) { [weak speechRequest] buffer, _ in
                speechRequest?.append(buffer)
            }
            tapInstalled = true

            task = recognizer.recognitionTask(with: speechRequest) { [weak self] result, error in
                Task { @MainActor in
                    guard let self else { return }

                    if let result {
                        let text = result.bestTranscription.formattedString
                            .trimmingCharacters(in: .whitespacesAndNewlines)
                        self.transcript = text

                        if result.isFinal, !text.isEmpty {
                            self.onCommand?(text)
                            self.stopListening()
                            return
                        }
                    }

                    if error != nil && self.isListening {
                        self.errorMessage = "Không nhận được giọng nói."
                        self.stopListening()
                    }
                }
            }

            audioEngine.prepare()
            try audioEngine.start()
            isListening = true
        } catch {
            errorMessage = "Không thể khởi động microphone: \(error.localizedDescription)"
            stopListening()
        }
    }

    deinit {
        audioEngine.stop()
        if tapInstalled {
            audioEngine.inputNode.removeTap(onBus: 0)
        }
        task?.cancel()
    }
}
