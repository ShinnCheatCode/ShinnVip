import SwiftUI

/// New home UI layer. It only reads existing stores and routes; patch/download/file
/// services remain in their original files.
struct ShinnModernHomeSurface: View {
    @EnvironmentObject private var store: RepoStore
    @EnvironmentObject private var session: Session

    let avatar: UIImage?
    let onAvatarTap: () -> Void
    let open: (Route) -> Void
    let selectTab: (Int) -> Void

    private let categories: [(title: String, subtitle: String, icon: String, tint: Color)] = [
        ("Free Fire", "PATCH", "flame.fill", Color(red: 1.0, green: 0.24, blue: 0.18)),
        ("Free Fire Max", "MAX", "bolt.fill", Color(red: 0.60, green: 0.35, blue: 1.0)),
        ("Liên Quân", "MOBA", "gamecontroller.fill", Color(red: 0.20, green: 0.62, blue: 1.0)),
        ("CapCut", "TOOLS", "scissors", Color(red: 0.25, green: 0.90, blue: 0.70))
    ]

    private var featured: [RepoPackage] {
        Array(store.packages.prefix(4))
    }

    var body: some View {
        ZStack {
            ShinnModernBackground()

            ScrollView(showsIndicators: false) {
                LazyVStack(spacing: 14) {
                    header
                    hero
                    categorySection
                    quickActions
                    premiumCard
                    aiCard
                    communityCard
                    featuredSection

                    if session.role == .owner {
                        ownerCard
                    }
                }
                .padding(.horizontal, 16)
                .padding(.top, 10)
                .padding(.bottom, 30)
            }
            .refreshable {
                await store.refresh()
            }
            .tint(AppSettings.currentAccentColor)
        }
    }

    private var header: some View {
        HStack(spacing: 12) {
            Button(action: onAvatarTap) {
                Group {
                    if let avatar {
                        Image(uiImage: avatar)
                            .resizable()
                            .scaledToFill()
                    } else {
                        Image("ShinnCatAvatar")
                            .resizable()
                            .scaledToFill()
                    }
                }
                .frame(width: 48, height: 48)
                .clipShape(RoundedRectangle(cornerRadius: 15, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 15, style: .continuous)
                        .stroke(.white.opacity(0.14), lineWidth: 0.8)
                )
            }
            .buttonStyle(.plain)

            VStack(alignment: .leading, spacing: 2) {
                Text("Shinn Cheat")
                    .font(.system(size: 22, weight: .black, design: .rounded))
                Text("Play Smarter · Win Easier")
                    .font(.system(size: 10.5, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.45))
            }

            Spacer()

            HStack(spacing: 5) {
                Circle()
                    .fill(.green)
                    .frame(width: 7, height: 7)
                Text("ONLINE")
                    .font(.system(size: 9, weight: .black, design: .rounded))
            }
            .foregroundStyle(.white.opacity(0.78))
            .padding(.horizontal, 9)
            .padding(.vertical, 7)
            .background(.white.opacity(0.055), in: Capsule())
        }
        .foregroundStyle(.white)
    }

    private var hero: some View {
        ZStack(alignment: .bottomLeading) {
            Image("ShinnCatHero")
                .resizable()
                .scaledToFill()
                .frame(height: 178)
                .clipped()

            LinearGradient(
                colors: [.clear, .black.opacity(0.96)],
                startPoint: .top,
                endPoint: .bottom
            )

            VStack(alignment: .leading, spacing: 5) {
                Text("WELCOME TO")
                    .font(.system(size: 9, weight: .black, design: .rounded))
                    .tracking(1.2)
                    .foregroundStyle(AppSettings.currentAccentColor)

                Text("Shinn Cheat")
                    .font(.system(size: 28, weight: .black, design: .rounded))

                Text("Patch Center · Community · AI")
                    .font(.system(size: 11, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.62))
            }
            .padding(17)
        }
        .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 24, style: .continuous)
                .stroke(.white.opacity(0.12), lineWidth: 0.8)
        }
        .shadow(color: AppSettings.currentAccentColor.opacity(0.12), radius: 20, y: 8)
    }

    private var categorySection: some View {
        VStack(alignment: .leading, spacing: 10) {
            sectionTitle("Danh mục", trailing: "\(store.packages.count) patch")

            LazyVGrid(
                columns: [
                    GridItem(.flexible(), spacing: 10),
                    GridItem(.flexible(), spacing: 10)
                ],
                spacing: 10
            ) {
                ForEach(categories, id: \.title) { item in
                    Button {
                        open(.packages(item.title))
                    } label: {
                        categoryCard(item)
                    }
                    .buttonStyle(ShinnScaleButtonStyle())
                }
            }
        }
    }

    private func categoryCard(
        _ item: (title: String, subtitle: String, icon: String, tint: Color)
    ) -> some View {
        let count = store.packages.filter { $0.category == item.title }.count

        return VStack(alignment: .leading, spacing: 12) {
            HStack {
                Image(systemName: item.icon)
                    .font(.system(size: 20, weight: .black))
                    .foregroundStyle(item.tint)
                    .frame(width: 42, height: 42)
                    .background(item.tint.opacity(0.13), in: RoundedRectangle(cornerRadius: 13, style: .continuous))

                Spacer()

                Image(systemName: "chevron.right")
                    .font(.system(size: 10, weight: .black))
                    .foregroundStyle(.white.opacity(0.25))
            }

            VStack(alignment: .leading, spacing: 3) {
                Text(item.title)
                    .font(.system(size: 14, weight: .black, design: .rounded))
                    .lineLimit(1)

                Text(count > 0 ? "\(count) patch" : item.subtitle)
                    .font(.system(size: 9.5, weight: .bold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.42))
            }
        }
        .frame(maxWidth: .infinity, minHeight: 112, alignment: .leading)
        .padding(13)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .stroke(
                    LinearGradient(
                        colors: [item.tint.opacity(0.45), .white.opacity(0.08)],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    ),
                    lineWidth: 0.8
                )
        }
    }

    private var quickActions: some View {
        HStack(spacing: 10) {
            quickAction("Kho Patch", "Tất cả patch", "square.grid.2x2.fill") {
                open(.packages(nil))
            }
            quickAction("Tệp", "File manager", "folder.fill") {
                selectTab(1)
            }
            quickAction("Cài đặt", "Giao diện", "slider.horizontal.3") {
                open(.settings)
            }
        }
    }

    private func quickAction(
        _ title: String,
        _ subtitle: String,
        _ icon: String,
        action: @escaping () -> Void
    ) -> some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 7) {
                Image(systemName: icon)
                    .font(.system(size: 16, weight: .black))
                    .foregroundStyle(AppSettings.currentAccentColor)

                Text(title)
                    .font(.system(size: 11.5, weight: .black, design: .rounded))
                    .foregroundStyle(.white)

                Text(subtitle)
                    .font(.system(size: 8.5, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.38))
                    .lineLimit(1)
            }
            .frame(maxWidth: .infinity, minHeight: 76, alignment: .leading)
            .padding(11)
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 17, style: .continuous))
            .overlay {
                RoundedRectangle(cornerRadius: 17, style: .continuous)
                    .stroke(.white.opacity(0.09), lineWidth: 0.8)
            }
        }
        .buttonStyle(ShinnScaleButtonStyle())
    }

    private var premiumCard: some View {
        Button {
            open(.premiumRepo)
        } label: {
            HStack(spacing: 13) {
                Image(systemName: store.isRepoV2Authorized ? "crown.fill" : "lock.fill")
                    .font(.system(size: 20, weight: .black))
                    .foregroundStyle(.white)
                    .frame(width: 50, height: 50)
                    .background(
                        LinearGradient(
                            colors: [.purple.opacity(0.60), AppSettings.currentAccentColor.opacity(0.18)],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        ),
                        in: RoundedRectangle(cornerRadius: 15, style: .continuous)
                    )

                VStack(alignment: .leading, spacing: 3) {
                    Text("Premium Repo")
                        .font(.system(size: 16, weight: .black, design: .rounded))
                    Text(store.isRepoV2Authorized ? "Đã mở khóa Repo 2" : "Mở khóa bằng key Premium")
                        .font(.system(size: 10.5, weight: .medium, design: .rounded))
                        .foregroundStyle(.white.opacity(0.48))
                }

                Spacer()

                Text(store.isRepoV2Authorized ? "OPEN" : "KEY")
                    .font(.system(size: 9.5, weight: .black, design: .rounded))
                    .padding(.horizontal, 9)
                    .padding(.vertical, 7)
                    .background(.purple.opacity(0.45), in: Capsule())
            }
            .padding(13)
            .shinnGlass(radius: 20)
        }
        .buttonStyle(ShinnScaleButtonStyle())
    }

    private var aiCard: some View {
        Button {
            open(.aiChat)
        } label: {
            HStack(spacing: 13) {
                Image("ShinnCatAvatar")
                    .resizable()
                    .scaledToFill()
                    .frame(width: 50, height: 50)
                    .clipShape(RoundedRectangle(cornerRadius: 15, style: .continuous))

                VStack(alignment: .leading, spacing: 3) {
                    Text("Shinn AI")
                        .font(.system(size: 16, weight: .black, design: .rounded))
                    Text("Commands · Support · Patch helper")
                        .font(.system(size: 10.5, weight: .medium, design: .rounded))
                        .foregroundStyle(.white.opacity(0.48))
                }

                Spacer()

                Image(systemName: "sparkles")
                    .foregroundStyle(AppSettings.currentAccentColor)
            }
            .padding(13)
            .shinnGlass(radius: 20)
        }
        .buttonStyle(ShinnScaleButtonStyle())
    }

    private var communityCard: some View {
        Button {
            open(.community)
        } label: {
            HStack(spacing: 13) {
                Image(systemName: "paperplane.fill")
                    .font(.system(size: 20, weight: .black))
                    .foregroundStyle(.white)
                    .frame(width: 50, height: 50)
                    .background(.blue.opacity(0.55), in: RoundedRectangle(cornerRadius: 15, style: .continuous))

                VStack(alignment: .leading, spacing: 3) {
                    Text("Community")
                        .font(.system(size: 16, weight: .black, design: .rounded))
                    Text("Main Group · English Chat · Support")
                        .font(.system(size: 10.5, weight: .medium, design: .rounded))
                        .foregroundStyle(.white.opacity(0.48))
                }

                Spacer()

                Image(systemName: "chevron.right")
                    .foregroundStyle(.white.opacity(0.30))
            }
            .padding(13)
            .shinnGlass(radius: 20)
        }
        .buttonStyle(ShinnScaleButtonStyle())
    }

    private var featuredSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            sectionTitle("Patch nổi bật", trailing: store.packages.isEmpty ? nil : "\(store.packages.count) tổng")

            if featured.isEmpty {
                Text("Chưa có patch. Kéo xuống để làm mới repo.")
                    .font(.caption)
                    .foregroundStyle(.white.opacity(0.45))
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(15)
                    .shinnGlass(radius: 17)
            } else {
                LazyVGrid(
                    columns: [
                        GridItem(.flexible(), spacing: 10),
                        GridItem(.flexible(), spacing: 10)
                    ],
                    spacing: 10
                ) {
                    ForEach(featured) { package in
                        Button {
                            open(.detail(package.id))
                        } label: {
                            HStack(spacing: 9) {
                                Image("ShinnCatPatch")
                                    .resizable()
                                    .scaledToFill()
                                    .frame(width: 40, height: 40)
                                    .clipShape(RoundedRectangle(cornerRadius: 11, style: .continuous))

                                VStack(alignment: .leading, spacing: 2) {
                                    Text(package.name)
                                        .font(.system(size: 11.5, weight: .bold, design: .rounded))
                                        .lineLimit(1)

                                    Text(package.version ?? "Patch")
                                        .font(.system(size: 9, weight: .medium, design: .rounded))
                                        .foregroundStyle(.white.opacity(0.38))
                                }

                                Spacer(minLength: 0)
                            }
                            .padding(10)
                            .frame(maxWidth: .infinity, minHeight: 62)
                            .shinnGlass(radius: 16)
                        }
                        .buttonStyle(ShinnScaleButtonStyle())
                    }
                }
            }
        }
    }

    private var ownerCard: some View {
        Button {
            open(.repositoryManager)
        } label: {
            HStack(spacing: 11) {
                Image(systemName: "lock.shield.fill")
                    .foregroundStyle(AppSettings.currentAccentColor)

                VStack(alignment: .leading, spacing: 2) {
                    Text("Admin Tools")
                        .font(.system(size: 13.5, weight: .black, design: .rounded))
                    Text("Quản lý key và quyền Premium")
                        .font(.caption)
                        .foregroundStyle(.white.opacity(0.42))
                }

                Spacer()

                Image(systemName: "chevron.right")
                    .foregroundStyle(.white.opacity(0.25))
            }
            .padding(13)
            .shinnGlass(radius: 17)
        }
        .buttonStyle(ShinnScaleButtonStyle())
    }

    private func sectionTitle(_ title: String, trailing: String?) -> some View {
        HStack(alignment: .firstTextBaseline) {
            Text(title)
                .font(.system(size: 18, weight: .black, design: .rounded))
            Spacer()
            if let trailing {
                Text(trailing)
                    .font(.system(size: 9.5, weight: .bold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.35))
            }
        }
        .foregroundStyle(.white)
    }
}

private struct ShinnModernBackground: View {
    var body: some View {
        GeometryReader { proxy in
            ZStack {
                Color.black

                RadialGradient(
                    colors: [AppSettings.currentAccentColor.opacity(0.18), .clear],
                    center: .topTrailing,
                    startRadius: 0,
                    endRadius: max(proxy.size.width, proxy.size.height) * 0.75
                )

                RadialGradient(
                    colors: [.purple.opacity(0.10), .clear],
                    center: .bottomLeading,
                    startRadius: 0,
                    endRadius: max(proxy.size.width, proxy.size.height) * 0.85
                )

                LinearGradient(
                    colors: [.black.opacity(0.05), .black.opacity(0.80)],
                    startPoint: .top,
                    endPoint: .bottom
                )
            }
        }
        .ignoresSafeArea()
        .allowsHitTesting(false)
    }
}

private struct ShinnScaleButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.975 : 1)
            .opacity(configuration.isPressed ? 0.88 : 1)
            .animation(.easeOut(duration: 0.14), value: configuration.isPressed)
    }
}
