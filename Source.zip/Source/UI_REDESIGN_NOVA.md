# Shinn Cheat — Nova UI

This revision is a visual redesign only.

## Preserved
- Existing RepoStore and repository refresh logic
- Existing LicenseManager / key activation logic
- Existing Owner/Admin/Member session roles
- Existing patch views and patch operations
- Existing Yuna AI view/command engine
- Existing Settings, Files, History, Terms, About and Repository Manager destinations
- Existing DNS Premium V1/V2 state and permission logic

## Visual changes
- New Control Center home layout
- Compact license/status dashboard
- Quick action row
- Workspace patch cards
- DNS Premium card retained in the Home flow
- Yuna AI feature card
- New bottom navigation
- New glass/gradient visual language

No patch or license implementation was rewritten by this UI layer.
