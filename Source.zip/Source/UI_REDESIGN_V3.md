# Shinn Cheat UI V3

- New dark glass UI inspired by the approved demo.
- Repo URLs and repository source lists are hidden from normal users.
- Repo 1 is free and loads the built-in Repo-V3 manifest.
- Repo 2 is Premium and requires an authorized key.
- First launch opens the Community sheet with Main Group, English Chat and Support.
- Shinn AI and its command/admin views remain available.
- Bulk patch download remains available.
- Cat artwork is bundled locally in Assets.xcassets; no network image is required for the UI mascot.
- Key activation LED remains 1.5 seconds.

Telegram:
- Main Group: https://t.me/ShinnCheatShare
- English Chat: https://t.me/ShinnCheatChat
- Support: @ShinnThieuu
