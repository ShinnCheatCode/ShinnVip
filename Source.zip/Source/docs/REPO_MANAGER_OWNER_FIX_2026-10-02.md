# Repository Manager Owner fix

- Repo V2 grants are authorized by the currently activated Owner key and its server role.
- The previous client-side check incorrectly required the holder label to equal a hard-coded Owner name.
- A valid Owner key can now have a normal display label (for example `Owner`) and still grant Repo V2.
- The add_key_repo request also sends the current installation device ID so it can match server-side Owner/device authorization.
- The selected target keys are still separate from the actor Owner key.
- The server/RPC remains the final authority; the client does not grant itself access.
