# Supabase + Repository integration

The app is wired to the configured Supabase project through the REST RPC API in `ContentView.swift`.

## RPCs used by the current source

- `activate_shinn_key(p_key, p_device_id)`
- `create_shinn_key(p_duration_hours, p_quantity)`
- `get_shinn_keys()`
- `delete_shinn_key(p_key_code)`
- `set_shinn_key_status(p_key_code, p_is_active)`

## Repository access

- Repo V1: `https://raw.githubusercontent.com/ShinnCheatCode/Repo-V3/main/ShinnCheatV3.json`
- Repo V2: `https://raw.githubusercontent.com/ShinnCheatCode/RepoV2/main/ShinnCheatV2.json`
- Every valid normal key can use Repo V1 and Repo V2.
- `ShinnCheat` is the special exception: Repo V1 only, maximum 100 devices, no Repo V2.
- Repo V2 access is read from the Supabase activation response (`repo_v2`). No per-key `add_key_repo` call is required.

## Important

The Supabase RPC names and return fields must match the SQL schema used by the app. The activation response expected by the app is:

```json
{
  "success": true,
  "key": "Shinn-Vip-XXXXXXXXXXXX",
  "expires_at": "...",
  "repo_v1": true,
  "repo_v2": true,
  "max_devices": 1
}
```

For `ShinnCheat`, `repo_v2` must be `false`.
