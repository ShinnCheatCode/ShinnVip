# ShinnCheat source update — 2026-10-02

## App changes
- Home now shows the active key at the top, expiration time, remaining time and unlimited-device status.
- Home includes a Recently Used Patches section.
- Account includes Downloaded Patches, Patch History, Terms of Use, About and Logout Key.
- Owner Control remains available for creating/deleting keys and supports batch creation up to 100 keys.
- New key creation defaults the label to `Feedback@ShinnThieuu`.
- Duration choices in the main Owner Create Key screen: 1 Hour, 1 Day, 3 Days, 7 Days and 30 Days.
- Newly created keys are **not automatically granted Repo V2**. V2 must be granted explicitly through Repository Manager.
- Patch Center now loads and displays Repo V1 and, when authorized, Repo V2 in the same screen.
- Repo V1/Repo V2 actions select the correct repository before applying or downloading a patch.
- Avatar/background personalization remains separate; the Home quick action points to avatar editing.

## Supabase requirement
The app still treats Supabase as the authority for key expiry, device policy and repository permissions.

For the requested `Feedback@ShinnThieuu` key policy, the existing Supabase activation RPC should return/handle:
- expiry according to the selected duration;
- unlimited device access for this key policy;
- Repo V1 enabled;
- Repo V2 disabled by default.

Do not rely on the UI alone to enforce these rules. The `activate_key` RPC should reject expired keys and enforce the server-side repository/device policy.

The source does not overwrite or guess your existing Supabase schema/RPC definitions.
