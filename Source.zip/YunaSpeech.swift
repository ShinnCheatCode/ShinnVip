import Foundation
import Speech
final class YunaSpeech: ObservableObject {
 @Published var transcript=""
 func startListening() {
   // Integrate with existing patch parser in ContentView.swift
 }
}
