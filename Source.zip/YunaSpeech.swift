import Foundation
import Speech

final class YunaSpeech: ObservableObject {
    @Published var transcript = ""
    @Published var isListening = false

    func startListening() {
        isListening = true
        // Integrate parser with existing PatchManager in ContentView.swift
    }

    func stopListening() {
        isListening = false
    }
}
