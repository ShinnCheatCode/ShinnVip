import Foundation
import SwiftUI
import UIKit

enum SupabaseConfig {
    static let projectURL = URL(string: "https://efhqbzdnrtifqjqlqseb.supabase.co")!
    static let anonKey = "sb_publishable_jnycTCgXRMrluvwJORd_4g_B7ojwi9R"

    static var activateKeyURL: URL {
        projectURL.appendingPathComponent("rest/v1/rpc/activate_key")
    }
}

struct ActivateKeyResponse: Decodable {
    let ok: Bool
    let error: String?
    let role: String?
    let key: String?
}

@MainActor
final class LicenseManager: ObservableObject {
    @Published var isActivated: Bool
    @Published var isBusy = false
    @Published var lastError: String?
    @Published var boundRole: String?

    private let activatedKey = "shinn.license.activated"
    private let roleKey = "shinn.license.role"
    private let deviceKey = "shinn.license.device_id"

    init() {
        let defaults = UserDefaults.standard
        isActivated = false
        boundRole = defaults.string(forKey: roleKey)
        UserDefaults.standard.set(false, forKey: activatedKey)
    }

    var deviceID: String {
        let defaults = UserDefaults.standard
        if let existing = defaults.string(forKey: deviceKey), !existing.isEmpty {
            return existing
        }
        let generated = UIDevice.current.identifierForVendor?.uuidString ?? UUID().uuidString
        defaults.set(generated, forKey: deviceKey)
        return generated
    }

    func activate(key raw: String, language: ShinnLanguage) async -> Bool {
        let key = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        lastError = nil

        guard !key.isEmpty else {
            lastError = language == .vi ? "Nhập key kích hoạt." : "Enter an activation key."
            return false
        }

        isBusy = true
        defer { isBusy = false }

        do {
            let result = try await callActivate(key: key)
            if result.ok {
                UserDefaults.standard.set(true, forKey: activatedKey)
                if let role = result.role, !role.isEmpty {
                    UserDefaults.standard.set(role, forKey: roleKey)
                    boundRole = role
                }
                isActivated = true
                return true
            }
            lastError = mappedError(result.error, language: language)
            return false
        } catch let error as URLError where error.code == .userAuthenticationRequired {
            lastError = language == .vi
                ? "Anon key hoặc project URL không đúng."
                : "Anon key or project URL is incorrect."
            return false
        } catch {
            lastError = language == .vi
                ? "Không kết nối được máy chủ key. Kiểm tra mạng."
                : "Could not reach the key server. Check your connection."
            return false
        }
    }

    func signOutLicense() {
        let defaults = UserDefaults.standard
        defaults.set(false, forKey: activatedKey)
        defaults.removeObject(forKey: roleKey)
        isActivated = false
        boundRole = nil
    }

    private func mappedError(_ code: String?, language: ShinnLanguage) -> String {
        let vi = language == .vi
        switch code {
        case "invalid_key":
            return vi ? "Key không hợp lệ." : "Invalid key."
        case "used_on_other_device":
            return vi ? "Key đã được dùng trên máy khác." : "This key is already used on another device."
        case "missing_key":
            return vi ? "Thiếu key." : "Missing key."
        case "missing_device":
            return vi ? "Thiếu mã thiết bị." : "Missing device id."
        default:
            return vi ? "Không kích hoạt được key." : "Could not activate the key."
        }
    }

    private func callActivate(key: String) async throws -> ActivateKeyResponse {
        var request = URLRequest(url: SupabaseConfig.activateKeyURL)
        request.httpMethod = "POST"
        request.timeoutInterval = 20
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue(SupabaseConfig.anonKey, forHTTPHeaderField: "apikey")
        request.setValue("Bearer \(SupabaseConfig.anonKey)", forHTTPHeaderField: "Authorization")

        let body: [String: String] = [
            "p_key": key,
            "p_device_id": deviceID
        ]
        request.httpBody = try JSONSerialization.data(withJSONObject: body)

        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else {
            throw URLError(.badServerResponse)
        }

        print("[Supabase] url=\(request.url?.absoluteString ?? "nil")")
        print("[Supabase] status=\(http.statusCode)")
        print("[Supabase] body=\(String(data: data, encoding: .utf8) ?? "nil")")

        guard (200..<300).contains(http.statusCode) else {
            if http.statusCode == 401 || http.statusCode == 403 {
                throw URLError(.userAuthenticationRequired)
            }
            throw URLError(.badServerResponse)
        }

        return try JSONDecoder().decode(ActivateKeyResponse.self, from: data)
    }
}