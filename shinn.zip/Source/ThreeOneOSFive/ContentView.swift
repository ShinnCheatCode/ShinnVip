import SwiftUI
import UIKit
import CryptoKit
import Foundation

enum UserRole: String, CaseIterable, Identifiable {
    case owner, admin, member
    var id: String { rawValue }

    var title: String {
        switch self {
        case .owner: return "Owner"
        case .admin: return "Admin"
        case .member: return "Member"
        }
    }

    var icon: String {
        switch self {
        case .owner: return "crown.fill"
        case .admin: return "checkmark.shield.fill"
        case .member: return "person.fill"
        }
    }

    var needsPassword: Bool { self != .member }
}

final class Session: ObservableObject {
    @Published var role: UserRole?

    private static let passwordHash =
        "a43535812161a1aec35c04f0b6ea63bb4880d581f3d15df9ba7e68befe6b472e"

    func verify(_ input: String) -> Bool {
        let digest = SHA256.hash(data: Data(input.utf8))
        let hex = digest.map { String(format: "%02x", $0) }.joined()
        return hex == Session.passwordHash
    }
}

struct ContentView: View {
    @StateObject var session = Session()
    @StateObject private var license = LicenseManager()
    @State private var path: [Route] = []

    var body: some View {
        Group {
            if !license.isActivated {
                ActivateKeyView()
            } else if session.role == nil {
                RoleGateView()
            } else {
                NavigationStack(path: $path) {
                    HomeView(open: { path.append($0) })
                        .navigationDestination(for: Route.self) { route in
                            switch route {
                            case .packages(let category):
                                PackagesView(initialCategory: category)
                            case .detail(let id):
                                PackageDetailView(packageID: id)
                            case .settings:
                                SettingsView()
                            case .about:
                                AboutView()
                            case .support:
                                SupportView()
                            }
                        }
                }
                .tint(.primary)
            }
        }
        .environmentObject(session)
        .environmentObject(license)
        .onAppear {
            license.refreshExpiryGate()
            if license.isActivated,
               let raw = license.boundRole,
               let role = UserRole(rawValue: raw.lowercased()) {
                session.role = role
            }
        }
        .onReceive(NotificationCenter.default.publisher(for: UIApplication.willEnterForegroundNotification)) { _ in
            license.refreshExpiryGate()
            if !license.isActivated {
                session.role = nil
            }
        }
        .animation(.easeInOut(duration: 0.25), value: session.role)
        .animation(.easeInOut(duration: 0.25), value: license.isActivated)
    }
}

struct ActivateKeyView: View {
    @EnvironmentObject var settings: AppSettings
    @EnvironmentObject var session: Session
    @EnvironmentObject var license: LicenseManager

    @State private var keyText = ""
    @FocusState private var focused: Bool
    private var isVI: Bool { settings.language == .vi }

    var body: some View {
        ZStack {
            BackgroundView()
            ScrollView(showsIndicators: false) {
                VStack(spacing: 22) {
                    VStack(spacing: 22) {
                        Image(systemName: "key.fill")
                            .font(.system(size: 46))
                        VStack(spacing: 6) {
                            Text("SHINN CHEAT")
                                .font(.system(size: 32, weight: .black, design: .rounded))
                            Text(isVI ? "Nhập key để sử dụng app" : "Enter a key to use the app")
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        }
                    }
                    .padding(.top, 40)

                    VStack(alignment: .leading, spacing: 12) {
                        Label(isVI ? "Key kích hoạt" : "Activation key", systemImage: "lock.fill")
                            .font(.headline)

                        TextField(isVI ? "Dán key vào đây" : "Paste your key", text: $keyText)
                            .textInputAutocapitalization(.characters)
                            .autocorrectionDisabled()
                            .focused($focused)
                            .padding(14)
                            .background(Color.primary.opacity(0.08), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                            .disabled(license.isBusy)
                            .onSubmit { Task { await submit() } }

                        if let error = license.lastError, !error.isEmpty {
                            Text(error)
                                .font(.footnote.bold())
                                .foregroundStyle(.red)
                        }

                        Button(action: { Task { await submit() } }) {
                            HStack {
                                if license.isBusy {
                                    ProgressView().tint(Color(.systemBackground))
                                }
                                Text(isVI ? "Kích hoạt" : "Activate")
                                    .font(.system(size: 15, weight: .bold))
                            }
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 13)
                            .background(Color.primary, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                            .foregroundStyle(Color(.systemBackground))
                        }
                        .buttonStyle(.plain)
                        .disabled(license.isBusy)
                    }
                    .padding(16)
                    .shinnGlass()
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 30)
            }
            .scrollDismissesKeyboard(.interactively)
        }
        .onAppear { DispatchQueue.main.async { focused = true } }
    }

    private func submit() async {
        let ok = await license.activate(key: keyText, language: settings.language)
        guard ok else { return }
        if let raw = license.boundRole,
           let role = UserRole(rawValue: raw.lowercased()) {
            session.role = role
        } else {
            session.role = .member
        }
    }
}

struct RoleGateView: View {
    @EnvironmentObject var settings: AppSettings
    @EnvironmentObject var session: Session
    @State private var pending: UserRole?
    @State private var password = ""
    @State private var attempts = 0
    @FocusState private var focused: Bool
    private var isVI: Bool { settings.language == .vi }

    var body: some View {
        ZStack {
            BackgroundView()
            ScrollView(showsIndicators: false) {
                VStack(spacing: 22) {
                    VStack(spacing: 22) {
                        Image(systemName: "crown.fill")
                            .font(.system(size: 46))
                        VStack(spacing: 6) {
                            Text("SHINN CHEAT")
                                .font(.system(size: 32, weight: .black, design: .rounded))
                            Text(isVI ? "Chọn vai trò" : "Choose a role")
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        }
                    }
                    .padding(.top, 40)

                    ForEach(UserRole.allCases) { role in
                        Button {
                            if role.needsPassword {
                                pending = role
                                password = ""
                                focused = true
                            } else {
                                session.role = role
                            }
                        } label: {
                            HStack(spacing: 16) {
                                IconBox(systemName: role.icon, size: 52)
                                Text(role.title)
                                    .font(.system(size: 20, weight: .bold, design: .rounded))
                                Spacer()
                            }
                            .padding(14)
                            .shinnGlass()
                        }
                        .buttonStyle(.plain)
                    }

                    if let role = pending {
                        VStack(alignment: .leading, spacing: 12) {
                            Label((isVI ? "Mật khẩu " : "Password ") + role.title, systemImage: "lock.fill")
                                .font(.headline)
                            SecureField(isVI ? "Nhập mật khẩu" : "Password", text: $password)
                                .focused($focused)
                                .keyboardType(.numberPad)
                                .padding(14)
                                .background(Color.primary.opacity(0.08), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                            if attempts > 0 {
                                Text(isVI ? "Sai mật khẩu." : "Wrong password.")
                                    .font(.footnote.bold())
                                    .foregroundStyle(.red)
                            }
                            HStack {
                                Button("Hủy") { pending = nil; password = "" }
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical, 13)
                                    .background(Color.primary.opacity(0.08), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                                Button("Xác nhận") {
                                    if session.verify(password) {
                                        session.role = role
                                        pending = nil
                                        password = ""
                                        attempts = 0
                                    } else {
                                        attempts += 1
                                        password = ""
                                    }
                                }
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 13)
                                .background(Color.primary, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                                .foregroundStyle(Color(.systemBackground))
                            }
                            .buttonStyle(.plain)
                        }
                        .padding(16)
                        .shinnGlass()
                    }
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 30)
            }
        }
    }
}

struct HomeView: View {
    @EnvironmentObject var settings: AppSettings
    @EnvironmentObject var store: RepoStore
    @EnvironmentObject var session: Session
    @EnvironmentObject var license: LicenseManager
    let open: (Route) -> Void

    var body: some View {
        ZStack {
            BackgroundView()
            ScrollView(showsIndicators: false) {
                LazyVStack(spacing: 14) {
                    header
                    hero
                    licenseCard

                    if session.role == .owner {
                        NavigationLink {
                            OwnerPanelView()
                        } label: {
                            HStack {
                                IconBox(systemName: "crown.fill", size: 44)
                                VStack(alignment: .leading, spacing: 2) {
                                    Text("Owner Panel")
                                        .font(.headline.bold())
                                    Text("Tạo key thành viên")
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                }
                                Spacer()
                                Image(systemName: "chevron.right")
                            }
                            .padding(12)
                            .shinnGlass()
                        }
                        .buttonStyle(.plain)
                    }

                    sectionTitle
                    categoriesSection
                    quickActions
                    credit
                }
                .padding(.horizontal, 18)
                .padding(.top, 10)
                .padding(.bottom, 28)
            }
            .refreshable { await store.refresh() }
        }
        .toolbar(.hidden, for: .navigationBar)
    }

    private var licenseCard: some View {
        VStack(spacing: 12) {
            HStack {
                Image(systemName: session.role?.icon ?? "person.fill")
                    .font(.title2)
                VStack(alignment: .leading) {
                    Text(session.role?.title ?? "Member")
                        .font(.headline.bold())
                    Text("Shinn Cheat License")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Spacer()
                Image(systemName: "checkmark.seal.fill")
                    .foregroundStyle(.green)
            }
            Divider()
            HStack {
                Label("Thời hạn", systemImage: "clock")
                Spacer()
                Text(isLifetime ? "Vĩnh viễn" : remainString())
                    .fontWeight(.bold)
                    .foregroundStyle(remainColor)
            }
            if session.role == .owner {
                Button {
                    session.role = nil
                    license.signOutLicense()
                } label: {
                    Label("Đăng xuất / Đổi key", systemImage: "rectangle.portrait.and.arrow.right")
                        .font(.subheadline.bold())
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                        .background(Color.primary.opacity(0.08), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                }
                .buttonStyle(.plain)
            }
        }
        .padding()
        .shinnGlass()
    }

    private var isLifetime: Bool {
        (session.role?.rawValue ?? license.boundRole ?? "").lowercased() == "owner"
    }

    private var remainColor: Color {
        if isLifetime { return .green }
        guard let date = license.expiresAt else { return .secondary }
        let days = Calendar.current.dateComponents([.day], from: Date(), to: date).day ?? 0
        if days <= 0 { return .red }
        if days <= 3 { return .orange }
        return .green
    }

    private func remainString() -> String {
        guard let date = license.expiresAt else { return "Không giới hạn" }
        if date <= Date() { return "Đã hết hạn" }
        let comps = Calendar.current.dateComponents([.day, .hour], from: Date(), to: date)
        let days = comps.day ?? 0
        let hours = comps.hour ?? 0
        if days >= 1 { return "Còn \(days) ngày" }
        return "Còn \(max(hours, 1)) giờ"
    }

    private var header: some View {
        HStack(spacing: 12) {
            Image(systemName: "crown.fill").font(.system(size: 28))
            Text("SHINN CHEAT")
                .font(.system(size: 27, weight: .black, design: .rounded))
            Spacer()
            Button(action: { open(.support) }) {
                Image(systemName: "paperplane.fill")
                    .font(.title3)
                    .frame(width: 48, height: 48)
                    .background(Color.primary.opacity(0.08), in: Circle())
            }
            .buttonStyle(.plain)
        }
    }

    @ViewBuilder
    private var hero: some View {
        if let ui = HeroBanner.image {
            Image(uiImage: ui)
                .resizable()
                .scaledToFit()
                .frame(maxWidth: .infinity)
                .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
        } else {
            HStack(spacing: 16) {
                CatLogo(size: 84)
                VStack(alignment: .leading, spacing: 6) {
                    Label("APP", systemImage: "crown.fill")
                        .font(.system(size: 14, weight: .black, design: .rounded))
                    Text("SHINN CHEAT")
                        .font(.system(size: 32, weight: .black, design: .rounded))
                        .lineLimit(1)
                        .minimumScaleFactor(0.5)
                }
                Spacer(minLength: 0)
            }
            .padding(20)
            .shinnGlass()
        }
    }

    private var sectionTitle: some View {
        HStack {
            Label(settings.t(.categoriesTitle), systemImage: "square.grid.2x2.fill")
                .font(.system(size: 18, weight: .black, design: .rounded))
            Spacer()
            Button(action: { session.role = nil }) {
                Label(session.role?.title ?? "", systemImage: session.role?.icon ?? "person.fill")
                    .font(.caption.bold())
                    .padding(.horizontal, 12)
                    .padding(.vertical, 7)
                    .background(Color.primary.opacity(0.1), in: Capsule())
            }
            .buttonStyle(.plain)
        }
    }

    @ViewBuilder
    private var categoriesSection: some View {
        if store.packages.isEmpty {
            VStack(spacing: 12) {
                if store.loadState == .failed {
                    Text(settings.t(.loadFailed))
                    Button(settings.t(.retry)) { Task { await store.refresh() } }
                        .buttonStyle(.bordered)
                } else {
                    ProgressView()
                    Text(settings.t(.loadingText))
                }
            }
            .frame(maxWidth: .infinity)
            .padding(24)
            .shinnGlass()
        } else {
            CategoryCard(icon: "square.grid.2x2.fill", title: settings.t(.allPackages), count: store.packages.count) {
                open(.packages(nil))
            }
            ForEach(store.categories) { c in
                CategoryCard(icon: categoryIcon(c.name), title: c.name, count: c.count) {
                    open(.packages(c.name))
                }
            }
        }
    }

    private var quickActions: some View {
        HStack(spacing: 12) {
            QuickAction(title: settings.t(.settingsTitle), subtitle: settings.t(.settingsSub), icon: "gearshape.fill") {
                open(.settings)
            }
            QuickAction(title: settings.t(.aboutTitle), subtitle: settings.t(.aboutSub), icon: "info.circle.fill") {
                open(.about)
            }
        }
    }

    private var credit: some View {
        HStack {
            Image(systemName: "cube.fill").font(.title2)
            VStack(alignment: .leading) {
                Text("SHINN CHEAT").font(.headline.bold())
                Text("FREE FIRE • FREE FIRE MAX")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            }
            Spacer()
        }
        .padding(18)
        .shinnGlass()
    }
}

struct CategoryCard: View {
    @EnvironmentObject var settings: AppSettings
    let icon: String
    let title: String
    let count: Int
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 14) {
                IconBox(systemName: icon, size: 56)
                VStack(alignment: .leading, spacing: 4) {
                    Text(title).font(.system(size: 18, weight: .bold, design: .rounded))
                    Text(settings.countText(count)).font(.subheadline).foregroundStyle(.secondary)
                }
                Spacer()
                Image(systemName: "chevron.right")
            }
            .padding(12)
            .shinnGlass()
        }
        .buttonStyle(.plain)
    }
}

struct QuickAction: View {
    let title: String
    let subtitle: String
    let icon: String
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 12) {
                Image(systemName: icon).font(.title2)
                Text(title).font(.headline.bold())
                Text(subtitle).font(.caption).foregroundStyle(.secondary)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(18)
            .shinnGlass()
        }
        .buttonStyle(.plain)
    }
}

struct CatLogo: View {
    var size: CGFloat = 84
    private static let remoteURL = URL(string: "https://raw.githubusercontent.com/mhieuushinn-dev/ShinnCheatShare/main/IMG_0508.jpeg")
    private var bundled: UIImage? {
        guard let path = Bundle.main.path(forResource: "CatLogo", ofType: "jpg") else { return nil }
        return UIImage(contentsOfFile: path)
    }

    var body: some View {
        Group {
            if let ui = bundled {
                Image(uiImage: ui).resizable().scaledToFill()
            } else {
                AsyncImage(url: CatLogo.remoteURL) { phase in
                    if case .success(let image) = phase {
                        image.resizable().scaledToFill()
                    } else {
                        Image(systemName: "crown.fill").font(.system(size: size * 0.4))
                    }
                }
            }
        }
        .frame(width: size, height: size)
        .clipShape(Circle())
    }
}

enum HeroBanner {
    static let image: UIImage? = {
        let names = [("IMG_1253", "jpeg"), ("IMG_1253", "jpg"), ("HeroBanner", "jpg")]
        for (name, ext) in names {
            if let path = Bundle.main.path(forResource: name, ofType: ext),
               let img = UIImage(contentsOfFile: path) {
                return img
            }
        }
        return nil
    }()
}