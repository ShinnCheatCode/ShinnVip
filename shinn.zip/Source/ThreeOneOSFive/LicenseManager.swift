import Foundation
import SwiftUI
import UIKit

@MainActor
final class LicenseManager: ObservableObject {
    @Published var isActivated: Bool
    @Published var isBusy = false
    @Published var lastError: String?
    @Published var boundRole: String?
    @Published var expiresAt: Date?

    private let activatedKey = "shinn.license.activated"
    private let roleKey = "shinn.license.role"
    private let deviceKey = "shinn.license.device_id"
    private let expireKey = "shinn.license.expire_at"
    private let savedKey = "shinn.license.key"

    init() {
        let defaults = UserDefaults.standard
        boundRole = defaults.string(forKey: roleKey)

        if defaults.object(forKey: expireKey) != nil {
            expiresAt = Date(timeIntervalSince1970: defaults.double(forKey: expireKey))
        }

        let wasActivated = defaults.bool(forKey: activatedKey)
        if wasActivated, let expiresAt, expiresAt > Date() {
            isActivated = true
        } else if wasActivated, expiresAt == nil {
            isActivated = true
        } else {
            isActivated = false
            if wasActivated { signOutLicense() }
        }
    }

    var isExpired: Bool {
        guard let expiresAt else { return false }
        return expiresAt <= Date()
    }

    var deviceID: String {
        let defaults = UserDefaults.standard
        if let existing = defaults.string(forKey: deviceKey), !existing.isEmpty {
            return existing
        }
        let generated = UIDevice.current.identifierForVendor?.uuidString ?? UUID().uuidString
        defaults.set(generated, forKey: deviceKey)
        return generated
    }

    func activate(key raw: String, language: ShinnLanguage) async -> Bool {
        let key = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        lastError = nil

        guard !key.isEmpty else {
            lastError = language == .vi ? "Nhập key kích hoạt." : "Enter an activation key."
            return false
        }

        isBusy = true
        defer { isBusy = false }

        do {
            let result = try await callActivate(key: key)
            if result.ok {
                persistSuccess(key: key, result: result)
                if isExpired {
                    lastError = language == .vi ? "Key đã hết hạn." : "This key has expired."
                    signOutLicense()
                    return false
                }
                return true
            }
            lastError = mappedError(result.error, language: language)
            return false
        } catch {
            lastError = language == .vi
                ? "Không kết nối được máy chủ key. Kiểm tra mạng."
                : "Could not reach the key server. Check your connection."
            return false
        }
    }

    func refreshExpiryGate() {
        if isExpired { signOutLicense() }
    }

    func signOutLicense() {
        let defaults = UserDefaults.standard
        defaults.set(false, forKey: activatedKey)
        defaults.removeObject(forKey: roleKey)
        defaults.removeObject(forKey: expireKey)
        defaults.removeObject(forKey: savedKey)
        isActivated = false
        boundRole = nil
        expiresAt = nil
    }

    private func persistSuccess(key: String, result: ActivateKeyResponse) {
        UserDefaults.standard.set(key, forKey: savedKey)
        UserDefaults.standard.set(true, forKey: activatedKey)

        if let role = result.role, !role.isEmpty {
            UserDefaults.standard.set(role, forKey: roleKey)
            boundRole = role
        }

        if let exp = result.expires_at, let date = parseISO(exp) {
            expiresAt = date
            UserDefaults.standard.set(date.timeIntervalSince1970, forKey: expireKey)
        } else {
            expiresAt = nil
            UserDefaults.standard.removeObject(forKey: expireKey)
        }

        isActivated = true
    }

    private func parseISO(_ raw: String) -> Date? {
        let iso = ISO8601DateFormatter()
        iso.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        if let date = iso.date(from: raw) { return date }
        iso.formatOptions = [.withInternetDateTime]
        return iso.date(from: raw)
    }

    private func mappedError(_ code: String?, language: ShinnLanguage) -> String {
        let vi = language == .vi
        switch code {
        case "invalid_key": return vi ? "Key không hợp lệ." : "Invalid key."
        case "used_on_other_device": return vi ? "Key đã được dùng trên máy khác." : "This key is already used on another device."
        case "expired_key": return vi ? "Key đã hết hạn." : "This key has expired."
        case "missing_key": return vi ? "Thiếu key." : "Missing key."
        case "missing_device": return vi ? "Thiếu mã thiết bị." : "Missing device id."
        default: return vi ? "Không kích hoạt được key." : "Could not activate the key."
        }
    }

    private func callActivate(key: String) async throws -> ActivateKeyResponse {
        var request = URLRequest(
            url: SupabaseConfig.projectURL.appendingPathComponent("/rest/v1/rpc/activate_key")
        )
        request.httpMethod = "POST"
        request.timeoutInterval = 20
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue(SupabaseConfig.anonKey, forHTTPHeaderField: "apikey")
        request.setValue("Bearer \(SupabaseConfig.anonKey)", forHTTPHeaderField: "Authorization")
        request.httpBody = try JSONSerialization.data(withJSONObject: [
            "p_key": key,
            "p_device_id": deviceID
        ])

        let (data, response) = try await URLSession.shared.data(for: request)
        if let http = response as? HTTPURLResponse, !(200..<300).contains(http.statusCode) {
            throw URLError(.badServerResponse)
        }
        return try JSONDecoder().decode(ActivateKeyResponse.self, from: data)
    }
}