import Foundation

@MainActor
final class OwnerKeyManager: ObservableObject {
    @Published var createdKey = ""
    @Published var isLoading = false
    @Published var error: String?

    func createKey() async {
        isLoading = true
        error = nil
        defer { isLoading = false }

        do {
            var request = URLRequest(
                url: SupabaseConfig.projectURL.appendingPathComponent("/rest/v1/rpc/create_shinn_key")
            )
            request.httpMethod = "POST"
            request.timeoutInterval = 20
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            request.setValue(SupabaseConfig.anonKey, forHTTPHeaderField: "apikey")
            request.setValue("Bearer \(SupabaseConfig.anonKey)", forHTTPHeaderField: "Authorization")
            request.httpBody = Data("{}".utf8)

            let (data, response) = try await URLSession.shared.data(for: request)
            guard let http = response as? HTTPURLResponse, 200...299 ~= http.statusCode else {
                throw URLError(.badServerResponse)
            }

            if let parsed = try? JSONDecoder().decode(CreateKeyResponse.self, from: data),
               !parsed.key.isEmpty {
                createdKey = parsed.key
            } else {
                createdKey = String(decoding: data, as: UTF8.self)
                    .replacingOccurrences(of: "\"", with: "")
                    .trimmingCharacters(in: .whitespacesAndNewlines)
            }

            if createdKey.isEmpty { error = "Không thể tạo key" }
        } catch {
            self.error = "Không thể tạo key"
        }
    }
}