import SwiftUI
import UIKit

struct OwnerPanelView: View {
    @EnvironmentObject var license: LicenseManager
    @EnvironmentObject var session: Session
    @StateObject private var manager = OwnerKeyManager()
    @State private var copied = false

    var body: some View {
        ZStack {
            BackgroundView()

            ScrollView(showsIndicators: false) {
                VStack(spacing: 16) {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("OWNER PANEL")
                            .font(.system(size: 28, weight: .black, design: .rounded))
                        Text("Tạo key Member • 1 máy • 7 ngày")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)

                    VStack(spacing: 14) {
                        if manager.createdKey.isEmpty {
                            Text("Chưa có key")
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        } else {
                            Text(manager.createdKey)
                                .font(.system(.body, design: .monospaced).weight(.bold))
                                .textSelection(.enabled)
                                .frame(maxWidth: .infinity, alignment: .leading)

                            Button {
                                UIPasteboard.general.string = manager.createdKey
                                copied = true
                            } label: {
                                Label(
                                    copied ? "Đã sao chép" : "Sao chép",
                                    systemImage: copied ? "checkmark" : "doc.on.doc"
                                )
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 12)
                            }
                            .buttonStyle(.plain)
                            .background(
                                Color.primary.opacity(0.08),
                                in: RoundedRectangle(cornerRadius: 14, style: .continuous)
                            )
                        }

                        Button {
                            Task {
                                copied = false
                                await manager.createKey()
                            }
                        } label: {
                            Group {
                                if manager.isLoading {
                                    ProgressView()
                                        .tint