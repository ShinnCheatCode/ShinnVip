import Foundation

enum SupabaseConfig {
    static let projectURL = URL(string: "https://efhqbzdnrtifqjqlqseb.supabase.co")!
    static let anonKey = "sb_publishable_jnycTCgXRMrluvwJORd_4g_B7ojwi9R"
}

struct ActivateKeyResponse: Codable {
    let ok: Bool
    let error: String?
    let role: String?
    let expires_at: String?
}

struct CreateKeyResponse: Codable {
    let key: String
}